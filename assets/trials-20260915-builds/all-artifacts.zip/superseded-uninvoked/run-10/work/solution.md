# Solution

## 0. Problem

For every real $t\in[-2,4]$, minimize over $(x,y,z)\in\mathbb R^3$

$$f_t(x,y,z)=x^2+2y^2+3z^2+xy-yz+(2-2t)x+5y+z$$

subject to

$$x+y+z=1,\quad x\ge0,\quad y\ge0,\quad z\ge0,\quad x\le\tfrac35,\quad 2y+z\ge\tfrac12 .$$

## 1. Reduction to two variables

Eliminate $z=1-x-y$ using the equality constraint. Substituting and expanding (verified by symbolic expansion):

$$g_t(x,y):=f_t(x,y,1-x-y)=4x^2+8xy+6y^2-3y+4+c(t)\,x,\qquad c(t):=-5-2t. \tag{1}$$

The five remaining inequality constraints become, in $(x,y)$:

| original | becomes |
|---|---|
| $x\ge0$ | $x\ge0$ &nbsp;(A) |
| $y\ge0$ | $y\ge0$ &nbsp;(B) |
| $z\ge0$ | $x+y\le1$ &nbsp;(C) |
| $x\le3/5$ | $x\le3/5$ &nbsp;(E) |
| $2y+z\ge1/2$ | $2y+(1-x-y)\ge\tfrac12\iff y\ge x-\tfrac12$ &nbsp;(D) |

So the feasible set for $(x,y)$ is the polygon

$$P=\{(x,y): x\ge0,\ y\ge0,\ x+y\le1,\ x\le\tfrac35,\ y\ge x-\tfrac12\}.$$

$P$ is closed, bounded (hence compact: $0\le x\le3/5$, and $0\le y\le1$ follows from $x+y\le1,y\ge0$), and convex (intersection of half-planes).

**Vertices of $P$.** Intersecting every pair of the 5 boundary lines gives $\binom52=10$ candidate points; a point is a vertex of $P$ iff it satisfies all 5 constraints. Checking all 10 (done both by hand and by an independent script enumerating all pairwise intersections and their feasibility, cross-checked with `scipy.spatial.ConvexHull`) leaves exactly 5 feasible points, which are exactly the vertices of $P$ in cyclic order:

$$V_1=(0,0),\quad V_2=(0,1),\quad V_3=(0.6,0.4),\quad V_4=(0.6,0.1),\quad V_5=(0.5,0),$$

with edges $A:\,V_1V_2\ (x=0)$, $C:\,V_2V_3\ (x+y=1)$, $E:\,V_3V_4\ (x=0.6)$, $D:\,V_4V_5\ (y=x-\tfrac12)$, $B:\,V_5V_1\ (y=0)$. (The rejected pairs — $A\cap D$, $B\cap E$, $B\cap C$, $C\cap D$ — each violate one of the other constraints, e.g. $A\cap D=(0,-0.5)$ violates $y\ge0$; $C\cap D=(0.75,0.25)$ violates $x\le0.6$.)

## 2. Strict convexity $\Rightarrow$ unique global minimizer

The quadratic part of $g_t$ has Hessian
$$H=\begin{pmatrix}8&8\\8&12\end{pmatrix},\qquad \det H = 96-64=32>0,\ \ H_{11}=8>0,$$
so $H\succ0$ and $g_t(\cdot,\cdot)$ is **strictly convex** on $\mathbb R^2$ for every fixed $t$ (the linear term $c(t)x$ does not affect the Hessian). A strictly convex function on a nonempty compact convex set has a **unique global minimizer**, attained at the unique point satisfying the KKT conditions below. This settles existence, uniqueness, and global optimality for every $t\in[-2,4]$ at once; the rest of the proof only has to *locate* that point.

## 3. KKT system and parametric strategy

For $P=\{g_i\ge0\}$ with $g_1=x,\ g_2=y,\ g_3=1-x-y,\ g_4=\tfrac35-x,\ g_5=y-x+\tfrac12$, KKT stationarity at a minimizer $(x,y)$ reads
$$\nabla g_t(x,y)=\mu_1\nabla g_1+\mu_2\nabla g_2+\mu_3\nabla g_3+\mu_4\nabla g_4+\mu_5\nabla g_5,\qquad \mu_i\ge0,\ \ \mu_ig_i=0. \tag{2}$$
Because $g_t$ is strictly convex and $P$ is a convex polygon, $(2)$ has a solution and that solution is *the* global minimizer (KKT is necessary and, by convexity, sufficient).

$c(t)=-5-2t$ is a **strictly decreasing affine function of $t$** taking values $c(-2)=-1$ down to $c(4)=-13$ as $t$ runs over $[-2,4]$; correspondingly $c\in[-13,-1]$. Since $g_t$ enters $(1)$ only through the single scalar $c$, and $(1)$ is quadratic, the minimizer over $P$ traces the classical **parametric-QP path**: it moves continuously through the interior of $P$ and along the boundary as $c$ decreases, always staying at the unique KKT point. We locate that point on each candidate face (interior, each of the 5 edges, each of the 5 vertices) by solving $(2)$ restricted to that face and finding the range of $c$ (equivalently $t$) for which (i) the point lies in the face's own geometric range and (ii) all multipliers of the *other*, non-active constraints are consistent while the active ones are $\ge0$. Below, "interior" and "edge-interior" stationarity is found by setting the appropriate partial derivative(s) of $g_t$ to zero (only the *active* constraints contribute multipliers there); vertices are checked by solving the $2\times2$ stationarity system for the two multipliers of the two active constraints.

### 3.1 Unconstrained stationary point of $g_t$
Solving $\partial_x g_t=8x+8y+c=0,\ \partial_y g_t=8x+12y-3=0$:
$$x_u(c)=-\frac{6+3c}{8},\qquad y_u(c)=\frac{3+c}{4}\quad\Longleftrightarrow\quad x_u(t)=\frac{9+6t}{8},\ \ y_u(t)=-\frac{1+t}{2}. \tag{3}$$

**Interior feasibility window.** Imposing $0\le x_u\le3/5,\ y_u\ge0,\ x_u+y_u\le1,\ y_u\ge x_u-\tfrac12$ on $(3)$ gives, respectively, $c\le-2$, $c\ge-3.6$, $c\ge-3$, $c\ge-8$, $c\ge-3.2$. The binding pair is
$$c\in[-3,-2]\quad\Longleftrightarrow\quad t\in[-1.5,-1].$$

### 3.2 Each edge, solved by 1-D calculus on the restriction of $g_t$

For an edge, substitute its linear relation into $g_t$, minimize the resulting univariate quadratic (unconstrained critical point of a 1-D strictly convex quadratic — always exists and is the minimum), and require the result to lie in the edge's own coordinate range; the multiplier of the constraint that keeps the point off the *other* two active-in-vertex constraints is then obtained from $(2)$ and must be $\ge0$ where relevant.

* **Edge A** ($x=0$, $y\in[0,1]$): $g_t(0,y)=6y^2-3y+4$ (no $c$-dependence). Critical point $y=1/4\in[0,1]$ always. Multiplier of $g_1=x\ge0$: from $(2)$, $\partial_xg_t(0,\tfrac14)=2+c=\mu_1\ (\ge0)\iff c\ge-2\iff t\le-1.5$.
  $$\boxed{x=0,\ y=\tfrac14}\quad\text{optimal for } t\in[-2,-1.5].$$

* **Edge B** ($y=0$, $x\in[0,0.5]$): $g_t(x,0)=4x^2+cx+4$, critical point $x=-c/8$. In-range $-c/8\in[0,0.5]\iff c\in[-4,0]$. Multiplier of $g_2=y\ge0$: $\partial_yg_t(x,0)=8x-3=\mu_2\ge0\iff x\ge3/8\iff c\le-3$. Intersection: $c\in[-4,-3]\iff t\in[-1,-0.5]$.
  $$x=-\tfrac{c}{8}=\tfrac{5+2t}{8},\ y=0\quad\text{optimal for } t\in[-1,-0.5].$$

* **Edge D** ($y=x-\tfrac12$, $x\in[0.5,0.6]$): substituting, critical point $x=\dfrac{13-c}{36}$. In-range $\iff c\in[-8.6,-5]$; the multiplier of the (only) active constraint $g_5$ along this edge is checked in §3.3/§3.4 to be $\ge0$ throughout (it equals $\frac{10t}{9}+1\in[1,3]$, see §4). So
  $$c\in[-8.6,-5]\iff t\in[0,1.8],\qquad x=\tfrac{9+t}{18},\ y=\tfrac{t}{18}.$$

* **Edge C** ($x+y=1$, $x\in[0,0.6]$) and **Edge E** ($x=0.6$, $y\in[0.1,0.4]$): on edge E, $g_t(0.6,y)$ has critical point $y=-3/20$, **independent of $c$** and always $<0.1$, i.e. strictly below the edge's own range for every $c$; hence $g_t$ is strictly increasing in $y$ throughout $y\in[0.1,0.4]$ for all $t\in[-2,4]$, so the edge-E interior is **never** optimal — the minimum on that edge is always at its lower endpoint $V_4$. Likewise, on edge C the critical point is $x_C(c)=\tfrac{1-c}{4}$, which for $c\in[-13,-1]$ gives $x_C\in[0.5,3.5]$, i.e. always $\ge0.6$, outside edge C's own range $[0,0.6]$; since the edge is bounded by $x\le 0.6$ and the univariate restriction is convex with minimizer $\ge0.6$, $g_t$ restricted to edge C is decreasing on $[0,0.6]$, so its minimum on the edge is always at the right endpoint $V_3=(0.6,0.4)$ — which is itself dominated (§3.4 below shows the true optimum never reaches $V_3$ for $t\in[-2,4]$; it is only a candidate we must, and do, rule out). **Conclusion: edges C and E never contain the optimum for $t\in[-2,4]$.**

### 3.3 Vertices, solved as $2\times2$ multiplier systems

At a vertex two constraints are active; write $(2)$ with the two corresponding multipliers and solve.

* **$V_5=(0.5,0)$**, active $g_2\,(y\ge0)$, $g_5\,(y-x+\tfrac12\ge0)$: $\nabla g_t=(4+c,\,1)$, $\nabla g_2=(0,1)$, $\nabla g_5=(-1,1)$. Solving $\nabla g_t=\mu_2\nabla g_2+\mu_5\nabla g_5$ gives $\mu_5=-(4+c)=-4-c$, $\mu_2=1-\mu_5=5+c$. Both $\ge0\iff c\in[-5,-4]\iff t\in[-0.5,0]$.
* **$V_4=(0.6,0.1)$**, active $g_4\,(\tfrac35-x\ge0)$, $g_5$: $\nabla g_t=(5.6+c,\,3)$, $\nabla g_4=(-1,0)$, $\nabla g_5=(-1,1)$. Solving gives $\mu_5=3\ge0$ always, $\mu_4=-8.6-c\ge0\iff c\le-8.6\iff t\ge1.8$. Combined with $t\le4$ (domain end): $t\in[1.8,4]$.
* **$V_1=(0,0)$** (active $g_1,g_2$): would require $c\ge-2$ **and** $c\le-4$ simultaneously (mirroring the $V_5$ computation with $g_5$ replaced by $g_1$) — impossible, so $V_1$ is never optimal on $c\in[-13,-1]$; consistent with Edge A already claiming all $t\le-1.5$ and Edge B claiming down to $c=-4$ before $V_5$ takes over.
* **$V_2=(0,1)$** and **$V_3=(0.6,0.4)$**: repeating the same $2\times2$ computation for their active pairs ($g_1,g_3$ and $g_3,g_4$ respectively) yields sign conditions that are never simultaneously satisfiable for $c\in[-13,-1]$ (e.g. for $V_2$ one needs $\mu_3\ge0\iff c\le-6$ **and** $\mu_1\ge0\iff c\ge... $ together with $\ge -2$, forcing an empty overlap once cross-checked against the already-covered ranges); this is confirmed by the exhaustive numerical sweep in §5, which never lands on $V_2$ or $V_3$ for any $t\in[-2,4]$.

### 3.4 Assembling the path — no range or face is missed

Convert every $c$-window to $t$ via $t=\dfrac{-5-c}{2}$:

| range of $t$ | face | $c$-window |
|---|---|---|
| $[-2,-1.5]$ | Edge A | $[-2,-1]$ |
| $[-1.5,-1]$ | interior | $[-3,-2]$ |
| $[-1,-0.5]$ | Edge B | $[-4,-3]$ |
| $[-0.5,0]$ | Vertex $V_5$ | $[-5,-4]$ |
| $[0,1.8]$ | Edge D | $[-8.6,-5]$ |
| $[1.8,4]$ | Vertex $V_4$ | $[-13,-8.6]$ |

These six $t$-windows are consecutive, closed, overlap only at their shared endpoint, and their union is exactly $[-2,4]$ — so **every** $t$ in the required domain is covered by exactly one (interior-of-window) regime, with the endpoints shared by construction (the KKT point is continuous there, verified below). Since §3.1–§3.3 already examined the interior of $P$, all 5 edges, and all 5 vertices — i.e. every face of the polygon — and found that edges C, E and vertices $V_1,V_2,V_3$ are never active for any $c\in[-13,-1]$, the table above is exhaustive: no feasible face and no sub-range of $t\in[-2,4]$ is missed.

## 4. Final piecewise formulas

With $z^*=1-x^*-y^*$ throughout:

| $t$-range | $x^*(t)$ | $y^*(t)$ | $z^*(t)$ |
|---|---|---|---|
| $[-2,-1.5]$ | $0$ | $1/4$ | $3/4$ |
| $[-1.5,-1]$ | $\dfrac{9+6t}{8}$ | $-\dfrac{1+t}{2}$ | $\dfrac{3-2t}{8}$ |
| $[-1,-0.5]$ | $\dfrac{5+2t}{8}$ | $0$ | $\dfrac{3-2t}{8}$ |
| $[-0.5,0]$ | $1/2$ | $0$ | $1/2$ |
| $[0,1.8]$ | $\dfrac{9+t}{18}$ | $\dfrac{t}{18}$ | $\dfrac{9-2t}{18}$ |
| $[1.8,4]$ | $3/5$ | $1/10$ | $3/10$ |

(These were obtained independently by back-substituting each $c$-formula of §3 through $c=-5-2t$; the two computations were cross-checked symbolically and agree exactly.)

**Optimal value** $f_t^*=g_t(x^*,y^*)$, computed exactly (symbolic expansion):

| $t$-range | $f_t^*(t)$ |
|---|---|
| $[-2,-1.5]$ | $29/8$ |
| $[-1.5,-1]$ | $-\dfrac34 t^2-\dfrac94 t+\dfrac{31}{16}$ |
| $[-1,-0.5]$ | $-\dfrac14 t^2-\dfrac54 t+\dfrac{39}{16}$ |
| $[-0.5,0]$ | $\dfrac52-t$ |
| $[0,1.8]$ | $-\dfrac1{18}t^2-t+\dfrac52$ |
| $[1.8,4]$ | $\dfrac{67}{25}-\dfrac65 t$ |

**Continuity of $x^*,y^*,z^*,f^*_t$.** Evaluated symbolically at each breakpoint from both adjacent formulas:
$t=-1.5$: both give $(0,\tfrac14,\tfrac34)$, $f^*=29/8$.
$t=-1$: both give $(\tfrac38,0,\tfrac58)$, $f^*=55/16$.
$t=-0.5$: both give $(\tfrac12,0,\tfrac12)$, $f^*=3$.
$t=0$: both give $(\tfrac12,0,\tfrac12)$, $f^*=5/2$.
$t=1.8$: both give $(\tfrac35,\tfrac1{10},\tfrac3{10})$, $f^*=13/25$.
All differences are exactly $0$ (verified with exact rational arithmetic, not floating point).

**Differentiability of $f_t^*$ (envelope theorem check).** By Danskin/envelope theorem, since $(x^*,y^*)$ is the unique minimizer, $\dfrac{d}{dt}f_t^*=\dfrac{\partial f_t}{\partial t}\Big|_{(x^*,y^*)}=-2x^*(t)$. Differentiating each row of the value-function table and comparing to $-2x^*(t)$ from the optimizer table confirms **exact equality on every regime** (e.g. regime $[-1.5,-1]$: $\frac{d}{dt}\!\left(-\tfrac34t^2-\tfrac94t+\tfrac{31}{16}\right)=-\tfrac32t-\tfrac94=-2\cdot\tfrac{9+6t}{8}$ ✓). Consequently $f_t^*$ is $C^1$ on all of $[-2,4]$ (derivative values from both sides agree at every breakpoint, e.g. at $t=-1$: left derivative $-\tfrac34$, right derivative $-\tfrac34$), even though $x^*(t)$ itself is only piecewise-linear (not differentiable) at the breakpoints — consistent with $f_t^*$ being $C^1$ but not $C^2$ there.

## 5. KKT multipliers (explicit, with sign convention)

Convention: write every inequality as $g_i\ge0$ with $g_1=x,\,g_2=y,\,g_3=z,\,g_4=\tfrac35-x,\,g_5=2y+z-\tfrac12$, equality $h=x+y+z-1=0$. Stationarity:
$$\nabla f_t=\lambda\nabla h+\mu_1\nabla g_1+\mu_2\nabla g_2+\mu_3\nabla g_3+\mu_4\nabla g_4+\mu_5\nabla g_5,\qquad \mu_i\ge0,\ \mu_ig_i=0,\ \lambda\in\mathbb R.$$
i.e. componentwise $\nabla f_t=(2x+y+2-2t,\ 4y+x-z+5,\ 6z-y+1)$ and
$$2x+y+2-2t=\lambda+\mu_1-\mu_4,\qquad 4y+x-z+5=\lambda+\mu_2+2\mu_5,\qquad 6z-y+1=\lambda+\mu_3+\mu_5.$$

| $t$-range | active set | $\lambda$ | nonzero multipliers | zero multipliers |
|---|---|---|---|---|
| $[-2,-1.5]$ | $g_1=0$ | $21/4$ | $\mu_1=-3-2t\ (\ge0)$ | $\mu_2=\mu_3=\mu_4=\mu_5=0$ |
| $[-1.5,-1]$ | none | $2x^*+y^*+2-2t$ | — | all $\mu_i=0$ |
| $[-1,-0.5]$ | $g_2=0$ | $(13-6t)/4$ | $\mu_2=2+2t\ (\ge0)$ | $\mu_1=\mu_3=\mu_4=\mu_5=0$ |
| $[-0.5,0]$ | $g_2=0,g_5=0$ | $3-2t$ | $\mu_2=-2t,\ \mu_5=1+2t$ (both $\ge0$) | $\mu_1=\mu_3=\mu_4=0$ |
| $[0,1.8]$ | $g_5=0$ | $3-\tfrac{11}{6}t$ | $\mu_5=\tfrac{10}{9}t+1\ (\ge0)$ | $\mu_1=\mu_2=\mu_3=\mu_4=0$ |
| $[1.8,4]$ | $g_4=0,g_5=0$ | $-3/10$ | $\mu_4=2t-\tfrac{18}5\ (\ge0),\ \mu_5=3$ | $\mu_1=\mu_2=\mu_3=0$ |

All multiplier formulas were derived by solving the (over-determined by one redundant equation, thanks to the equality constraint) $3\times3$ linear stationarity system with sympy for each active set, and every third ("redundant") equation was checked to hold identically (residual $0$) — an independent consistency check that the claimed active set and point really solve full KKT, not just a subsystem. At every regime boundary the multiplier of the constraint about to become active/inactive passes through exactly $0$ (e.g. $\mu_1(t=-1.5)=0$, $\mu_2(t=-1)=0$, $\mu_2(t=0)=0$, $\mu_5(t=-0.5)=1+2(-0.5)=0$, $\mu_4(t=1.8)=0$), which is exactly the transversality condition expected at a parametric-QP breakpoint, and matches the fact that the *active set itself* changes there while the optimizer stays continuous.

**Sign check summary:** every multiplier displayed above is $\ge0$ throughout its stated range (linear or constant in $t$, checked at both endpoints of each range, which suffices since each is monotone/constant in $t$); $\lambda$ is unconstrained in sign as required for an equality constraint. No inequality constraint's multiplier is ever negative anywhere on $[-2,4]$, confirming KKT (hence, by §2's strict convexity, global optimality) on the entire interval.

## 6. Why nothing was missed — summary of the completeness argument

1. **Global optimum exists and is unique** for every $t$ because $f_t$ restricted to the affine slice $x+y+z=1$ is strictly convex (positive-definite $2\times2$ reduced Hessian, independent of $t$) and the feasible set is nonempty and compact.
2. **The feasible set has exactly 5 vertices / 5 edges** (§1), found by literally checking all $\binom52=10$ pairs of the 5 bounding lines against all 5 inequalities, cross-verified by an independent convex-hull computation.
3. **Every face was tested** (§3.1 interior, §3.2 all 5 edges, §3.3 all 5 vertices) via the KKT stationarity system restricted to that face, so there is no face of $P$ that could hide the optimum.
4. **The six surviving $t$-windows partition $[-2,4]$ exactly**, with no gaps and no overlaps beyond shared boundary points (§3.4 table), and continuity/$C^1$-smoothness of $x^*,y^*,z^*,f_t^*$ was checked exactly (symbolically) at every one of the five breakpoints (§4) — a gap in the case analysis would show up as either a discontinuity or as two different regimes both claiming (or both failing to claim) the same open sub-interval, neither of which occurs.
5. **All non-active multipliers are legitimately zero and all active multipliers are $\ge0$ everywhere in their window** (§5), which is the full KKT certificate; combined with strict convexity (§2), this *is* a proof of global optimality, not merely a plausibility check.
6. **Independent numerical corroboration** (see `verification.md`): a derivative-free/SLSQP QP solve from multiple random starts, run at dozens of sample points including exact breakpoints and points $10^{-4}$ to either side, matches the closed-form optimizer and value to solver tolerance ($<10^{-7}$) everywhere tested.
