"""
Exact closed-form solver for the parametric QP:

    minimize   f_t(x,y,z) = x^2 + 2y^2 + 3z^2 + xy - yz + (2-2t)x + 5y + z
    subject to x+y+z=1, x>=0, y>=0, z>=0, x<=3/5, 2y+z>=1/2

for t in [-2, 4]. See solution.md for the full derivation and proof.

The optimizer (x*, y*, z*) follows six regimes as t sweeps [-2, 4]:

    [-2  , -1.5]  edge x=0                : x=0,            y=1/4
    [-1.5, -1  ]  interior                : x=(9+6t)/8,     y=-(1+t)/2
    [-1  , -0.5]  edge y=0                : x=(5+2t)/8,     y=0
    [-0.5,  0  ]  vertex                  : x=1/2,          y=0
    [ 0  ,  1.8]  edge 2y+z=1/2           : x=(9+t)/18,     y=t/18
    [ 1.8,  4  ]  vertex                  : x=3/5,          y=1/10

z is always recovered as 1 - x - y.
"""


def solve(t):
    t = float(t)
    if not (-2.0 <= t <= 4.0):
        raise ValueError("t must be in [-2, 4]")

    if t <= -1.5:
        x, y = 0.0, 0.25
    elif t <= -1.0:
        x, y = (9.0 + 6.0 * t) / 8.0, -(1.0 + t) / 2.0
    elif t <= -0.5:
        x, y = (5.0 + 2.0 * t) / 8.0, 0.0
    elif t <= 0.0:
        x, y = 0.5, 0.0
    elif t <= 1.8:
        x, y = (9.0 + t) / 18.0, t / 18.0
    else:
        x, y = 0.6, 0.1

    z = 1.0 - x - y

    value = (
        x * x + 2.0 * y * y + 3.0 * z * z
        + x * y - y * z
        + (2.0 - 2.0 * t) * x + 5.0 * y + z
    )

    return {"x": x, "y": y, "z": z, "value": value}
