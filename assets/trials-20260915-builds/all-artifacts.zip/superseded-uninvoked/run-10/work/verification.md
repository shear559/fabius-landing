# Verification

All checks below were actually executed locally (Python 3.9 stdlib for `solution.py` itself;
`sympy`/`numpy`/`scipy` were used only as an independent cross-check tool, never inside
`solution.py`). No network access was used or required.

## 1. Symbolic re-derivation of the reduced 2-variable objective

Confirms the elimination $z=1-x-y$ and expansion in `solution.md` §1 is algebraically exact.

```python
import sympy as sp
x,y,z,t = sp.symbols('x y z t', real=True)
f = x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2-2*t)*x + 5*y + z
print(sp.expand(f.subs(z, 1-x-y)))
# -> -2*t*x + 4*x**2 + 8*x*y - 5*x + 6*y**2 - 3*y + 4   (matches g_t(x,y) in solution.md)
```

## 2. Independent enumeration of the feasible polygon's vertices

All $\binom52=10$ pairwise intersections of the 5 bounding lines were solved with `numpy.linalg.solve`,
filtered for feasibility against all 5 constraints, and cross-checked with `scipy.spatial.ConvexHull`.
Result: exactly the 5 vertices claimed in `solution.md` §1 — `(0,0), (0,1), (0.5,0), (0.6,0.1), (0.6,0.4)` —
confirming no vertex was invented or omitted.

## 3. Exhaustive brute-force KKT active-set search (independent of the geometric face-walk argument)

Rather than reusing the edge-by-edge reasoning of `solution.md` §3, this check enumerates **every**
subset of size 0, 1, 2 of the 5 inequality constraints (all $\binom50+\binom51+\binom52=16$, minus
the trivially inconsistent ones $=15$ solvable systems), solves the exact KKT stationarity system for
each with `sympy.solve`, and intersects primal feasibility + dual feasibility (multiplier signs) with
$t\in[-2,4]$ symbolically via `solve_univariate_inequality`. Also checked separately that no 3 of the
5 boundary lines are concurrent (no degenerate/duplicate vertices), so subsets of size $\ge3$ cannot
contribute additional candidates.

**Result** (script output, verbatim):

```
active=(): x=3*t/4 + 9/8, y=-t/2 - 1/2  =>  t-range = Interval(-3/2, -1)
active=(1,): x=0, y=1/4  =>  t-range = Interval(-2, -3/2)
active=(2,): x=t/4 + 5/8, y=0  =>  t-range = Interval(-1, -1/2)
active=(5,): x=t/18 + 1/2, y=t/18  =>  t-range = Interval(0, 9/5)
active=(2, 5): x=1/2, y=0  =>  t-range = Interval(-1/2, 0)
active=(4, 5): x=3/5, y=1/10  =>  t-range = Interval(9/5, 4)
```

All other 9 active-set candidates (including edges C, E and vertices $V_1,V_2,V_3$) returned an empty
intersection with $[-2,4]$, i.e. they are *never* KKT points on the required domain. These 6 surviving
ranges union to exactly $[-2,4]$ with shared endpoints only — this is a fully independent confirmation
of the 6-regime table in `solution.md` §3.4, obtained by brute force rather than by the geometric
pruning argument.

## 4. Numerical cross-check against a generic nonlinear solver (SLSQP, multi-start)

For 72 sample values of $t$ — all 6 breakpoints exactly, points $10^{-3}$ and $10^{-6}$ to either
side of every breakpoint, 40 uniform random points in $[-2,4]$, and the domain endpoints — the
closed-form `solve(t)` from `solution.py` was compared against `scipy.optimize.minimize` (SLSQP,
6 random Dirichlet-distributed restarts per point, `ftol=1e-14`) solving the original 3-variable
problem directly (equality + 5 inequality constraints, no reduction).

```
tested 72 points
max constraint violation:        1.11e-16   (machine precision)
max |optimizer - scipy optimum|: 1.38e-08   (SLSQP tolerance-level)
max |value - scipy value|:       3.02e-13
```

Continuity was also checked by evaluating `solve(bp - 1e-9)` and `solve(bp + 1e-9)` at every
breakpoint `bp`; left/right values agree to $\sim10^{-9}$ (limited by float step size), confirming
no jump in $x^*,y^*,z^*$ or the optimal value across any regime boundary.

## 5. `solution.py` sanity checks

* **Silent import**: module executed under `contextlib.redirect_stdout`; captured output is `''`.
  No `if __name__ == "__main__"` block, no top-level prints, no file reads.
* **Types**: `solve(t)` accepts both `int` and `float` (`solve(-2)`, `solve(4)`, `solve(0)` all tested);
  all returned dict values are finite Python floats.
* **Domain**: `solve(4.0001)` and `solve(-2.0001)` raise `ValueError("t must be in [-2, 4]")`, confirming
  the closed interval `[-2, 4]` is enforced exactly at both ends (`solve(-2)` and `solve(4)` themselves
  succeed).
* **Self-consistency**: for every tested `t`, the returned `value` field was independently recomputed
  from `x,y,z,t` via the original (unreduced) formula and matched to $<10^{-9}$.

## 6. Reproducing these checks

From this directory, with `sympy`, `numpy`, `scipy` available locally (used only for verification,
not by `solution.py`):

```bash
python3 - << 'EOF'
import importlib.util, random
spec = importlib.util.spec_from_file_location('solution', 'solution.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
solve = mod.solve

def f_true(x,y,z,t):
    return x**2+2*y**2+3*z**2+x*y-y*z+(2-2*t)*x+5*y+z

for t in [-2,-1.5,-1,-0.5,0,1.8,4, -1.3, 0.7, 3.1]:
    r = solve(t)
    x,y,z,val = r['x'],r['y'],r['z'],r['value']
    viol = max(0, -x,-y,-z, x-0.6, -(2*y+z-0.5), abs(x+y+z-1))
    print(t, r, "viol=", viol, "value_check=", abs(val-f_true(x,y,z,t)))
EOF
```

## 7. Limitations

* Numerical cross-checks (SLSQP, `ConvexHull`) confirm the closed-form solution to floating-point/solver
  tolerance ($\sim10^{-8}$–$10^{-13}$), not to infinite precision; the *exact* rational arithmetic
  guarantees come from the symbolic (`sympy`) derivations in §1–§3, which use exact fractions throughout.
* The brute-force KKT search (§3) covered all active sets of size 0, 1, 2 of the 5 inequality
  constraints, which is exhaustive given the confirmed absence of any 3 concurrent boundary lines
  (checked in §2/§3); this rules out larger active sets by construction (2 variables ⇒ at most 2
  linearly independent active constraints at any point, except at a degeneracy, which was ruled out).
* Sampling in §4 is finite (72 points); it is a corroborating spot-check, not a proof. The proof of
  global optimality for *every* $t\in[-2,4]$ is the KKT + strict-convexity argument in `solution.md`,
  which is exact and covers the whole interval, not just sampled points.
