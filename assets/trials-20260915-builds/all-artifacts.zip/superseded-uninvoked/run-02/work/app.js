(function () {
  "use strict";

  /* --------------------------- mobile navigation --------------------------- */

  var menuToggle = document.querySelector('[data-testid="menu-toggle"]');
  var mobileNav = document.querySelector('[data-testid="mobile-nav"]');

  if (menuToggle && mobileNav) {
    // Collapsed by default only once JS is confirmed running; without JS the
    // nav stays visible in the document flow so it remains discoverable.
    mobileNav.hidden = true;
    menuToggle.setAttribute("aria-expanded", "false");

    var closeMobileNav = function (opts) {
      mobileNav.hidden = true;
      menuToggle.setAttribute("aria-expanded", "false");
      if (opts && opts.returnFocus) {
        menuToggle.focus();
      }
    };

    var openMobileNav = function () {
      mobileNav.hidden = false;
      menuToggle.setAttribute("aria-expanded", "true");
    };

    menuToggle.addEventListener("click", function () {
      var isOpen = menuToggle.getAttribute("aria-expanded") === "true";
      if (isOpen) {
        closeMobileNav();
      } else {
        openMobileNav();
      }
    });

    mobileNav.addEventListener("click", function (event) {
      var link = event.target.closest("a");
      if (link) {
        closeMobileNav();
      }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && !mobileNav.hidden) {
        closeMobileNav({ returnFocus: true });
      }
    });
  }

  /* ------------------------------ feature tabs ------------------------------ */

  var tabs = Array.prototype.slice.call(document.querySelectorAll('[role="tab"]'));

  if (tabs.length) {
    var panels = tabs.map(function (tab) {
      return document.getElementById(tab.getAttribute("aria-controls"));
    });

    // Enforce single-visible-panel behavior once JS runs; the markup ships
    // with every panel visible so content is discoverable without JS.
    var selectTab = function (index, opts) {
      tabs.forEach(function (tab, i) {
        var selected = i === index;
        tab.setAttribute("aria-selected", selected ? "true" : "false");
        tab.tabIndex = selected ? 0 : -1;
        panels[i].hidden = !selected;
      });
      if (opts && opts.focus) {
        tabs[index].focus();
      }
    };

    selectTab(0);

    tabs.forEach(function (tab, index) {
      tab.addEventListener("click", function () {
        selectTab(index);
      });

      tab.addEventListener("keydown", function (event) {
        var newIndex = null;

        if (event.key === "ArrowRight" || event.key === "ArrowDown") {
          newIndex = (index + 1) % tabs.length;
        } else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
          newIndex = (index - 1 + tabs.length) % tabs.length;
        } else if (event.key === "Home") {
          newIndex = 0;
        } else if (event.key === "End") {
          newIndex = tabs.length - 1;
        }

        if (newIndex !== null) {
          event.preventDefault();
          selectTab(newIndex, { focus: true });
        }
      });
    });
  }

  /* ------------------------------ billing toggle ------------------------------ */

  var monthlyBtn = document.querySelector('[data-testid="billing-monthly"]');
  var yearlyBtn = document.querySelector('[data-testid="billing-yearly"]');
  var priceSolo = document.querySelector('[data-testid="price-solo"]');
  var priceStudio = document.querySelector('[data-testid="price-studio"]');
  var periodLabel = document.querySelector('[data-testid="billing-period-label"]');

  var PRICES = {
    monthly: { solo: "$12/mo", studio: "$29/mo", label: "Prices shown are billed monthly." },
    yearly: { solo: "$108/yr", studio: "$264/yr", label: "Prices shown are billed yearly." }
  };

  if (monthlyBtn && yearlyBtn && priceSolo && priceStudio) {
    var setBilling = function (period) {
      var data = PRICES[period];
      priceSolo.textContent = data.solo;
      priceStudio.textContent = data.studio;
      if (periodLabel) {
        periodLabel.textContent = data.label;
      }
      monthlyBtn.setAttribute("aria-pressed", period === "monthly" ? "true" : "false");
      yearlyBtn.setAttribute("aria-pressed", period === "yearly" ? "true" : "false");
    };

    monthlyBtn.addEventListener("click", function () {
      setBilling("monthly");
    });

    yearlyBtn.addEventListener("click", function () {
      setBilling("yearly");
    });
  }
})();
