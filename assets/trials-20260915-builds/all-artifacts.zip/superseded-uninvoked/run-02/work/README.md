# Lattice — fictional product landing page

A static marketing page for **Lattice**, a fictional local-first research notebook.
Built for a design/engineering exercise; not a real product, no real data or claims.

## Files

- `index.html` — markup and content
- `styles.css` — design system (CSS custom properties) and layout
- `app.js` — mobile nav, feature tabs, billing toggle
- `BRIEF.md` — original task brief (untouched)

No build step, no dependencies, no remote fonts/assets, no network calls.

## Running it

Any static file server works, including from a nested path (all asset URLs are
relative, e.g. `./styles.css`). For example:

```
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

or simply open `index.html` directly in a browser (`file://` also works since
there are no absolute-root paths or network requests).

## Implementation decisions

- **Progressive enhancement for both interactive widgets.** The mobile nav and
  the feature tabs ship in HTML with *everything visible* (mobile nav in normal
  flow, all three feature panels un-hidden). `app.js` then collapses the mobile
  nav and hides the non-active tab panels on load. This means with JavaScript
  disabled all nav links, all three feature panels, and the default monthly
  prices are present and readable in the DOM — nothing depends on JS to be
  discoverable. With JavaScript enabled, the brief's exact interaction
  contract applies (collapsed hamburger menu, single visible tab panel).
- **Tabs use real ARIA tab semantics**: `role="tablist"/"tab"/"tabpanel"`,
  `aria-selected`, roving `tabindex`, and Left/Right/Up/Down/Home/End arrow-key
  movement with focus following selection, per the WAI-ARIA tabs pattern.
- **Mobile nav** is a single `<nav data-testid="mobile-nav">` toggled by
  `data-testid="menu-toggle"`, with `aria-expanded` kept in sync, `Escape` to
  close and return focus to the toggle, and closing on link selection. Desktop
  navigation is a separate always-present `<nav>` shown only at `≥768px` via
  CSS, so "desktop nav stays available" without relying on the mobile nav's
  JS state.
- **Billing toggle** is two buttons (`aria-pressed`) rather than a checkbox,
  with an `aria-live` text label announcing the active billing period for
  screen reader users. Prices are swapped as exact strings
  (`$12/mo`/`$29/mo` ↔ `$108/yr`/`$264/yr`) with no floating-point math.
- **FAQ** uses native `<details>/<summary>` — inherently keyboard- and
  no-JS-accessible, no custom disclosure code needed.
- **Hero illustration** is an original inline SVG (dotted "lattice" grid,
  an app-window chrome, a sidebar, note cards, a tag chip, and a dashed
  connector suggesting linked notes) built entirely from primitive shapes —
  no external images or icon fonts.
- **Design system**: CSS custom properties for color, spacing (4/8pt-ish
  scale), radius and a system-font stack (`-apple-system, Segoe UI, Roboto…`)
  since remote fonts are disallowed. Palette is an ink/parchment base with a
  green primary and a warm terracotta accent, used consistently across CTAs,
  bullets, tags and the SVG illustration.
- **Motion**: the only transitions are small hover/focus affordances and the
  hamburger icon morph; all are zeroed out under
  `@media (prefers-reduced-motion: reduce)`.
- **Accessibility**: visible `:focus-visible` outline throughout, a skip
  link, `aria-label`s on the desktop/mobile/footer nav landmarks, and no
  content that depends solely on color.
- **Fiction disclosure**: a persistent top banner plus a footer note state
  this is a fictional demo; no invented customers, reviews, ratings or usage
  numbers appear anywhere.

## Checks actually executed

Used Playwright (Chromium, via the local `playwright-qa` install) driving the
page served over `python3 -m http.server`, including once from a nested URL
path (`/nested/path/index.html`) to confirm relative asset URLs work. Verified:

- Desktop (1440px): hero renders; tabs default to Capture with only
  `panel-capture` visible; ArrowRight moves selection/focus through Connect →
  Export and swaps the visible panel each time; clicking a tab also works;
  all four `faq-0`..`faq-3` summaries exist and `faq-0` opens on click;
  billing toggle updates `price-solo`/`price-studio` from `$12/mo`/`$29/mo` →
  `$108/yr`/`$264/yr` and back to the exact original monthly strings; desktop
  nav is visible and `menu-toggle` is hidden; the hero CTA links to
  `#workflow`.
- Mobile (360px): `menu-toggle` visible, desktop nav hidden, `mobile-nav`
  starts hidden with `aria-expanded="false"`; clicking the toggle opens it and
  sets `aria-expanded="true"`; `Escape` closes it, resets `aria-expanded`, and
  moves focus back to `menu-toggle`; clicking a link inside `mobile-nav`
  closes the nav and navigates to the target section (`#pricing`).
- JavaScript disabled (`javaScriptEnabled: false` browser context): hero
  content, `mobile-nav` and its links, default monthly prices, all three
  feature panels, and the native FAQ details all render/are present without
  any script running.
- Manually reviewed full-page and viewport screenshots at 1440px and 360px
  (hero, pricing, mobile nav open) for visual/layout quality.

Not independently checked: automated color-contrast/axe auditing, and manual
testing in non-Chromium browsers (only Chromium via Playwright was available
in this environment).

## Known limitations

- Only Chromium (via Playwright) was available for testing; Safari/Firefox
  rendering was not verified, though only standard CSS/JS features are used.
- No automated accessibility scanner (e.g. axe-core) was run; accessibility
  was addressed via semantic markup and manual ARIA/keyboard checks only.
- The hero SVG illustration is decorative/original artwork, not a
  pixel-accurate app screenshot.
