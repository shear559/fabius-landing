# Fieldnote Board

A local-first task board for a small project team. Fictional demo data only; no
network calls, no backend, no build step.

## Running it

Serve this directory with any static file server and open `index.html`. It
uses only relative paths (`./styles.css`, `./app.js`), so it also works from a
nested URL path (e.g. `/some/sub/path/index.html`).

```
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Opening `index.html` directly via `file://` also works in most browsers,
since there are no ES module imports (everything is one plain script).

If JavaScript is disabled, a visible banner explains the app cannot run.

## Data model

Stored in `localStorage` under the key `fieldnote-board:v1` as:

```json
{ "schemaVersion": 1, "tasks": [ { "id": "...", "title": "...", "project": "...",
  "status": "todo|doing|done", "priority": "low|medium|high",
  "dueDate": "" | "YYYY-MM-DD", "tags": ["..."] } ] }
```

Every task object is required to have exactly these seven fields. `title`
(≤120 chars) and `project` (≤80 chars) must be non-empty after trimming.
`dueDate` is either `""` or a real calendar date (checked by round-tripping
through `Date.UTC` so e.g. `2024-02-30` is rejected, not silently clamped).
`tags` is at most 8 entries, each a trimmed, non-empty string ≤24 chars, with
no two tags equal case-insensitively. IDs are generated with
`crypto.randomUUID()` (falling back to a timestamp+random string).

On genuinely empty storage (no key at all) the app seeds a fictional 8-task
board across two projects ("Harbor Lights Relaunch", "Meridian Data
Migration") covering all three statuses. Existing data — even if it fails
validation — is never silently overwritten by the seed.

## Error handling / recovery design

- **Corrupt storage on startup**: if the stored value isn't valid JSON, or
  doesn't match the schema above (wrong `schemaVersion`, bad enum, invalid
  date, duplicate id, extra/missing fields, etc.), the app treats it as
  corrupt. It does **not** touch the stored bytes or reseed automatically.
  Instead it shows a recovery banner with a "Download original data" button
  (saves the raw, unparsed bytes to a file) and a "Reset board" button that
  asks for confirmation before erasing the corrupt value and writing a fresh
  seeded board. While the banner is showing, creating tasks and importing are
  disabled so nothing can be silently written on top of unrecovered data.
- **`localStorage.setItem` throwing** (e.g. quota exceeded): the write is
  wrapped in try/catch. On failure a banner says the last change was not
  saved, the in-memory task list is left unchanged, and — for the create/edit
  form specifically — the dialog stays open with the user's entered values
  intact so nothing is lost.
- **Cross-tab conflicts**: the app listens for the `storage` event. Any
  write to the `fieldnote-board:v1` key from another tab shows a conflict
  banner and disables "New task" and "Import" in this tab (status/edit/delete
  actions also check the same flag and no-op) until the user clicks "Reload
  board", which re-reads storage from scratch and clears the flag. This
  avoids ever silently overwriting newer state written elsewhere.
- **Import**: validated with the exact same schema check used for startup
  corruption detection, plus a duplicate-id check across the file and a 1 MiB
  size cap (checked via `File.size` before reading). Any single invalid task
  rejects the whole file — the current board is left completely untouched —
  and a specific error message is shown. A valid file requires an explicit
  confirm dialog (listing task counts) before it replaces the board.
- Imported/rendered text (titles, projects, tags) is always set via
  `textContent`, never `innerHTML`, so HTML-looking input can't execute.

## Accessibility & keyboard

- Every input/select is wrapped in a `<label>` with visible text, so no
  control relies on placeholder-only labeling; card-level Edit/Delete/Status
  controls get a per-task `aria-label` (e.g. "Edit Draft relaunch press
  release") since there are many identical buttons on screen.
- The task form is a native `<dialog>` opened with `showModal()`. Escape
  closes it (native browser behavior) and a `close` listener restores focus
  to whatever element opened it, for both the task dialog and the import
  confirmation dialog.
- `@media (prefers-reduced-motion: reduce)` disables all CSS transitions and
  animations.
- A `<noscript>` banner is shown when JavaScript is disabled; the app root is
  `hidden` until `init()` runs, so nothing broken is visible without JS.

## Checks actually executed

Verified with a headless Chromium (Playwright) script driving the real
served app (not the DOM in isolation), covering: seed data shape, create
with tag dedup, blank/overlong-title validation, editing without disturbing
other records, status change via the native select, delete + undo + undo
surviving reload, search and multi-filter combination with a no-results
state, full-board export regardless of filters, import rejecting malformed
JSON / bad enums / invalid dates / duplicate ids atomically (board
unchanged), a valid import's confirm-then-replace flow, HTML-in-imported-
title rendered as literal text (no script execution), startup corruption
recovery (bytes preserved, reset flow, create disabled while corrupt),
same-browser cross-tab conflict detection and the reload-to-clear flow,
`localStorage.setItem` throwing (save-error shown, form data retained),
loading the app from a nested URL path with only relative assets, and
360px/1440px screenshots reviewed by eye for layout correctness. Also
`node --check app.js` for a static syntax pass.

## Known limitations

- Undo only remembers the single most recently deleted task; deleting a
  second task without undoing the first replaces the undo slot.
- Cross-tab conflict handling is "detect and block until reload," not
  automatic merge — the user must explicitly reload to see the other tab's
  state, by design (safer than guessing how to reconcile).
- No drag-and-drop between columns; status changes go through the select
  control only.
- Tag/text length and count limits are enforced on save/import but the form
  inputs don't hard-truncate as you type (you get a validation error on
  submit instead).
