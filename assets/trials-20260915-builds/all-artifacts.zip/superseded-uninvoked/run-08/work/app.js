(function () {
  'use strict';

  var STORAGE_KEY = 'fieldnote-board:v1';
  var STATUSES = ['todo', 'doing', 'done'];
  var PRIORITIES = ['low', 'medium', 'high'];
  var STATUS_LABELS = { todo: 'To do', doing: 'Doing', done: 'Done' };
  var MAX_IMPORT_BYTES = 1024 * 1024;

  var tasks = [];
  var storageCorrupt = false;
  var corruptRaw = null;
  var externalChangeBlocked = false;
  var lastDeleted = null;
  var editingId = null;
  var lastFocusedElement = null;
  var importLastFocused = null;
  var pendingImportTasks = null;

  // ---------- validation ----------

  function isValidDateStr(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
    if (!m) return false;
    var y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return false;
    var date = new Date(Date.UTC(y, mo - 1, d));
    return date.getUTCFullYear() === y && date.getUTCMonth() === mo - 1 && date.getUTCDate() === d;
  }

  function isValidTaskShape(t) {
    if (!t || typeof t !== 'object' || Array.isArray(t)) return false;
    var allowedKeys = ['id', 'title', 'project', 'status', 'priority', 'dueDate', 'tags'];
    var keys = Object.keys(t);
    if (keys.length !== allowedKeys.length) return false;
    for (var i = 0; i < keys.length; i++) if (allowedKeys.indexOf(keys[i]) === -1) return false;

    if (typeof t.id !== 'string' || t.id.length === 0 || t.id.length > 80) return false;
    if (typeof t.title !== 'string' || t.title.trim() !== t.title || t.title.length === 0 || t.title.length > 120) return false;
    if (typeof t.project !== 'string' || t.project.trim() !== t.project || t.project.length === 0 || t.project.length > 80) return false;
    if (STATUSES.indexOf(t.status) === -1) return false;
    if (PRIORITIES.indexOf(t.priority) === -1) return false;
    if (typeof t.dueDate !== 'string') return false;
    if (t.dueDate !== '' && !isValidDateStr(t.dueDate)) return false;
    if (!Array.isArray(t.tags) || t.tags.length > 8) return false;
    var seenTags = {};
    for (var j = 0; j < t.tags.length; j++) {
      var tag = t.tags[j];
      if (typeof tag !== 'string' || tag.trim() !== tag || tag.length === 0 || tag.length > 24) return false;
      var key = tag.toLowerCase();
      if (seenTags[key]) return false;
      seenTags[key] = true;
    }
    return true;
  }

  function validateBoardDocument(parsed) {
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return { ok: false, error: 'File must contain a JSON object.' };
    }
    if (parsed.schemaVersion !== 1) {
      return { ok: false, error: 'Unsupported or missing schemaVersion (expected 1).' };
    }
    if (!Array.isArray(parsed.tasks)) {
      return { ok: false, error: '"tasks" must be an array.' };
    }
    var seen = {};
    for (var i = 0; i < parsed.tasks.length; i++) {
      var t = parsed.tasks[i];
      if (!isValidTaskShape(t)) {
        return { ok: false, error: 'Task at position ' + (i + 1) + ' is invalid (bad field, enum, date, or tag).' };
      }
      if (seen[t.id]) {
        return { ok: false, error: 'Duplicate task id "' + t.id + '" found.' };
      }
      seen[t.id] = true;
    }
    return { ok: true, tasks: parsed.tasks };
  }

  function genId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    return 'task-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function parseTags(raw) {
    var parts = raw.split(',').map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 0; });
    for (var i = 0; i < parts.length; i++) {
      if (parts[i].length > 24) return { tags: null, error: 'Each tag must be 24 characters or fewer.' };
    }
    var seen = {};
    var result = [];
    for (var j = 0; j < parts.length; j++) {
      var key = parts[j].toLowerCase();
      if (!seen[key]) { seen[key] = true; result.push(parts[j]); }
    }
    if (result.length > 8) return { tags: null, error: 'Use at most 8 tags.' };
    return { tags: result, error: null };
  }

  // ---------- seed data ----------

  function seedTasks() {
    return [
      { id: genId(), title: 'Draft relaunch press release', project: 'Harbor Lights Relaunch', status: 'todo', priority: 'high', dueDate: '2026-09-18', tags: ['content', 'launch'] },
      { id: genId(), title: 'Coordinate photographer schedule', project: 'Harbor Lights Relaunch', status: 'doing', priority: 'medium', dueDate: '2026-09-22', tags: ['logistics'] },
      { id: genId(), title: 'Finalize storefront signage design', project: 'Harbor Lights Relaunch', status: 'done', priority: 'low', dueDate: '', tags: ['design'] },
      { id: genId(), title: 'Plan launch-day social posts', project: 'Harbor Lights Relaunch', status: 'todo', priority: 'low', dueDate: '2026-09-25', tags: ['content', 'social'] },
      { id: genId(), title: 'Audit legacy schema tables', project: 'Meridian Data Migration', status: 'todo', priority: 'high', dueDate: '2026-09-19', tags: ['backend', 'risk'] },
      { id: genId(), title: 'Write migration rollback plan', project: 'Meridian Data Migration', status: 'doing', priority: 'high', dueDate: '2026-09-24', tags: ['backend'] },
      { id: genId(), title: 'Stakeholder sign-off review', project: 'Meridian Data Migration', status: 'todo', priority: 'medium', dueDate: '', tags: ['review'] },
      { id: genId(), title: 'Set up staging environment', project: 'Meridian Data Migration', status: 'done', priority: 'medium', dueDate: '2026-09-10', tags: ['infra'] }
    ];
  }

  // ---------- persistence ----------

  function persist(newTasks) {
    var el = document.getElementById('save-error-banner');
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, tasks: newTasks }));
    } catch (err) {
      el.hidden = false;
      return false;
    }
    el.hidden = true;
    return true;
  }

  function loadBoardFromStorage() {
    var raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) {
      tasks = seedTasks();
      persist(tasks);
      corruptRaw = null;
      hideRecoveryBanner();
      return;
    }
    var parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      tasks = [];
      corruptRaw = raw;
      showRecoveryBanner();
      return;
    }
    var validation = validateBoardDocument(parsed);
    if (!validation.ok) {
      tasks = [];
      corruptRaw = raw;
      showRecoveryBanner();
      return;
    }
    tasks = validation.tasks;
    corruptRaw = null;
    hideRecoveryBanner();
  }

  // ---------- banners ----------

  function updateWriteBlockedUI() {
    var blocked = storageCorrupt || externalChangeBlocked;
    document.getElementById('create-task-btn').disabled = blocked;
    document.getElementById('import-file').disabled = blocked;
  }

  function showRecoveryBanner() {
    storageCorrupt = true;
    document.getElementById('recovery-banner-text').textContent =
      'The saved board on this device could not be read (it looks corrupted). Nothing has been changed or overwritten. Download the original data or reset to start fresh.';
    document.getElementById('recovery-banner').hidden = false;
    updateWriteBlockedUI();
  }

  function hideRecoveryBanner() {
    storageCorrupt = false;
    document.getElementById('recovery-banner').hidden = true;
    updateWriteBlockedUI();
  }

  function showConflictBanner() {
    externalChangeBlocked = true;
    document.getElementById('conflict-banner').hidden = false;
    updateWriteBlockedUI();
  }

  function hideConflictBanner() {
    externalChangeBlocked = false;
    document.getElementById('conflict-banner').hidden = true;
    updateWriteBlockedUI();
  }

  function isBlocked() {
    return storageCorrupt || externalChangeBlocked;
  }

  function showImportError(msg) {
    document.getElementById('import-error-text').textContent = msg;
    document.getElementById('import-error-banner').hidden = false;
  }

  function hideImportError() {
    document.getElementById('import-error-banner').hidden = true;
  }

  function downloadTextFile(filename, text, mime) {
    var blob = new Blob([text], { type: mime || 'application/octet-stream' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // ---------- rendering ----------

  function getFilteredTasks() {
    var q = document.getElementById('search').value.trim().toLowerCase();
    var status = document.getElementById('filter-status').value;
    var project = document.getElementById('filter-project').value;
    var priority = document.getElementById('filter-priority').value;
    return tasks.filter(function (t) {
      if (status !== 'all' && t.status !== status) return false;
      if (project !== 'all' && t.project !== project) return false;
      if (priority !== 'all' && t.priority !== priority) return false;
      if (q) {
        var hay = (t.title + ' ' + t.project + ' ' + t.tags.join(' ')).toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function renderProjectFilterOptions() {
    var select = document.getElementById('filter-project');
    var current = select.value || 'all';
    var projects = [];
    var seen = {};
    tasks.forEach(function (t) {
      if (!seen[t.project]) { seen[t.project] = true; projects.push(t.project); }
    });
    projects.sort(function (a, b) { return a.localeCompare(b); });
    select.innerHTML = '';
    var allOpt = document.createElement('option');
    allOpt.value = 'all';
    allOpt.textContent = 'All projects';
    select.appendChild(allOpt);
    projects.forEach(function (p) {
      var o = document.createElement('option');
      o.value = p;
      o.textContent = p;
      select.appendChild(o);
    });
    select.value = (current === 'all' || projects.indexOf(current) !== -1) ? current : 'all';
  }

  function renderCard(t) {
    var card = document.createElement('article');
    card.className = 'task-card';
    card.dataset.testid = 'task-card';
    card.dataset.taskId = t.id;

    var top = document.createElement('div');
    top.className = 'task-card__top';
    var title = document.createElement('h3');
    title.className = 'task-card__title';
    title.textContent = t.title;
    var priority = document.createElement('span');
    priority.className = 'task-card__priority priority-' + t.priority;
    priority.textContent = t.priority;
    top.appendChild(title);
    top.appendChild(priority);

    var meta = document.createElement('div');
    meta.className = 'task-card__meta';
    var projectSpan = document.createElement('span');
    projectSpan.textContent = t.project;
    var dueSpan = document.createElement('span');
    dueSpan.textContent = t.dueDate ? ('Due ' + t.dueDate) : 'No due date';
    meta.appendChild(projectSpan);
    meta.appendChild(dueSpan);

    card.appendChild(top);
    card.appendChild(meta);

    if (t.tags.length) {
      var tagsWrap = document.createElement('div');
      tagsWrap.className = 'task-card__tags';
      t.tags.forEach(function (tag) {
        var chip = document.createElement('span');
        chip.className = 'tag-chip';
        chip.textContent = tag;
        tagsWrap.appendChild(chip);
      });
      card.appendChild(tagsWrap);
    }

    var controls = document.createElement('div');
    controls.className = 'task-card__controls';

    var statusSelect = document.createElement('select');
    statusSelect.className = 'task-card__status-select';
    statusSelect.dataset.action = 'status';
    statusSelect.setAttribute('aria-label', 'Change status for ' + t.title);
    STATUSES.forEach(function (s) {
      var opt = document.createElement('option');
      opt.value = s;
      opt.textContent = STATUS_LABELS[s];
      if (s === t.status) opt.selected = true;
      statusSelect.appendChild(opt);
    });
    statusSelect.addEventListener('change', function () {
      handleStatusChange(t.id, statusSelect.value);
    });

    var buttons = document.createElement('div');
    buttons.className = 'task-card__buttons';

    var editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn--ghost btn--small';
    editBtn.dataset.action = 'edit';
    editBtn.textContent = 'Edit';
    editBtn.setAttribute('aria-label', 'Edit ' + t.title);
    editBtn.addEventListener('click', function () { openEditDialog(t.id); });

    var deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'btn btn--ghost btn--small';
    deleteBtn.dataset.action = 'delete';
    deleteBtn.textContent = 'Delete';
    deleteBtn.setAttribute('aria-label', 'Delete ' + t.title);
    deleteBtn.addEventListener('click', function () { handleDelete(t.id); });

    buttons.appendChild(editBtn);
    buttons.appendChild(deleteBtn);
    controls.appendChild(statusSelect);
    controls.appendChild(buttons);
    card.appendChild(controls);

    return card;
  }

  function renderBoard() {
    var filtered = getFilteredTasks();
    var board = document.getElementById('board');
    var emptyState = document.getElementById('empty-state');

    if (filtered.length === 0) {
      board.hidden = true;
      emptyState.hidden = false;
      emptyState.textContent = tasks.length === 0
        ? 'No tasks yet. Click "New task" to add your first task.'
        : 'No tasks match your search and filters.';
    } else {
      board.hidden = false;
      emptyState.hidden = true;
      STATUSES.forEach(function (status) {
        var listEl = document.getElementById('list-' + status);
        listEl.innerHTML = '';
        var inColumn = filtered.filter(function (t) { return t.status === status; });
        document.getElementById('count-' + status).textContent = String(inColumn.length);
        if (inColumn.length === 0) {
          var p = document.createElement('p');
          p.className = 'board__column-empty';
          p.textContent = 'No tasks here.';
          listEl.appendChild(p);
        } else {
          inColumn.forEach(function (t) { listEl.appendChild(renderCard(t)); });
        }
      });
    }

    document.getElementById('result-count').textContent =
      filtered.length + ' of ' + tasks.length + ' task' + (tasks.length === 1 ? '' : 's') + ' shown';
  }

  // ---------- mutations ----------

  function handleStatusChange(id, newStatus) {
    if (isBlocked()) { renderBoard(); return; }
    var idx = tasks.findIndex(function (t) { return t.id === id; });
    if (idx === -1) return;
    var updated = Object.assign({}, tasks[idx], { status: newStatus });
    var newTasks = tasks.slice();
    newTasks[idx] = updated;
    if (persist(newTasks)) tasks = newTasks;
    renderBoard();
  }

  function handleDelete(id) {
    if (isBlocked()) return;
    var idx = tasks.findIndex(function (t) { return t.id === id; });
    if (idx === -1) return;
    var deletedTask = tasks[idx];
    var newTasks = tasks.slice();
    newTasks.splice(idx, 1);
    if (!persist(newTasks)) return;
    tasks = newTasks;
    lastDeleted = deletedTask;
    renderProjectFilterOptions();
    renderBoard();
    showUndoToast(deletedTask);
  }

  function handleUndoDelete() {
    if (!lastDeleted) return;
    if (isBlocked()) return;
    var restored = lastDeleted;
    var newTasks = tasks.concat([restored]);
    if (persist(newTasks)) {
      tasks = newTasks;
      lastDeleted = null;
      hideToast();
      renderProjectFilterOptions();
      renderBoard();
    }
  }

  function showUndoToast(task) {
    var toast = document.getElementById('toast');
    var text = document.getElementById('toast-text');
    var undoBtn = document.getElementById('undo-delete-btn');
    text.textContent = 'Deleted "' + task.title + '".';
    undoBtn.hidden = false;
    undoBtn.setAttribute('aria-label', 'Undo delete of ' + task.title);
    toast.hidden = false;
  }

  function hideToast() {
    document.getElementById('toast').hidden = true;
    document.getElementById('undo-delete-btn').hidden = true;
  }

  // ---------- task form dialog ----------

  function clearFormErrors() {
    ['title', 'project', 'dueDate', 'tags'].forEach(function (f) {
      document.getElementById('error-' + f).textContent = '';
    });
  }

  function setFieldError(field, msg) {
    document.getElementById('error-' + field).textContent = msg;
  }

  function resetForm() {
    var form = document.getElementById('task-form');
    form.reset();
    document.getElementById('task-id').value = '';
    clearFormErrors();
  }

  function fillFormForEdit(t) {
    document.getElementById('task-id').value = t.id;
    document.getElementById('task-title').value = t.title;
    document.getElementById('task-project').value = t.project;
    document.getElementById('task-status').value = t.status;
    document.getElementById('task-priority').value = t.priority;
    document.getElementById('task-dueDate').value = t.dueDate;
    document.getElementById('task-tags').value = t.tags.join(', ');
  }

  function openCreateDialog() {
    if (isBlocked()) return;
    editingId = null;
    resetForm();
    document.getElementById('task-dialog-title').textContent = 'New task';
    lastFocusedElement = document.activeElement;
    var dialog = document.getElementById('task-dialog');
    dialog.showModal();
    document.getElementById('task-title').focus();
  }

  function openEditDialog(id) {
    if (isBlocked()) return;
    var t = tasks.find(function (x) { return x.id === id; });
    if (!t) return;
    editingId = id;
    clearFormErrors();
    fillFormForEdit(t);
    document.getElementById('task-dialog-title').textContent = 'Edit task';
    lastFocusedElement = document.activeElement;
    var dialog = document.getElementById('task-dialog');
    dialog.showModal();
    document.getElementById('task-title').focus();
  }

  function handleTaskFormSubmit(e) {
    e.preventDefault();
    if (isBlocked()) return;
    clearFormErrors();

    var form = e.target;
    var fd = new FormData(form);
    var titleRaw = String(fd.get('title') || '');
    var projectRaw = String(fd.get('project') || '');
    var status = String(fd.get('status') || 'todo');
    var priority = String(fd.get('priority') || 'medium');
    var dueDateRaw = String(fd.get('dueDate') || '').trim();
    var tagsRaw = String(fd.get('tags') || '');

    var hasError = false;

    var title = titleRaw.trim();
    if (!title) { setFieldError('title', 'Title is required.'); hasError = true; }
    else if (title.length > 120) { setFieldError('title', 'Title must be 120 characters or fewer.'); hasError = true; }

    var project = projectRaw.trim();
    if (!project) { setFieldError('project', 'Project is required.'); hasError = true; }
    else if (project.length > 80) { setFieldError('project', 'Project must be 80 characters or fewer.'); hasError = true; }

    if (dueDateRaw !== '' && !isValidDateStr(dueDateRaw)) {
      setFieldError('dueDate', 'Enter a valid calendar date (YYYY-MM-DD).');
      hasError = true;
    }

    var tagResult = parseTags(tagsRaw);
    if (tagResult.error) { setFieldError('tags', tagResult.error); hasError = true; }

    if (STATUSES.indexOf(status) === -1) status = 'todo';
    if (PRIORITIES.indexOf(priority) === -1) priority = 'medium';

    if (hasError) return;

    if (editingId) {
      var idx = tasks.findIndex(function (t) { return t.id === editingId; });
      if (idx === -1) { closeTaskDialog(); return; }
      var updated = { id: editingId, title: title, project: project, status: status, priority: priority, dueDate: dueDateRaw, tags: tagResult.tags };
      var newTasks = tasks.slice();
      newTasks[idx] = updated;
      if (persist(newTasks)) {
        tasks = newTasks;
        closeTaskDialog();
        renderProjectFilterOptions();
        renderBoard();
      }
    } else {
      var newTask = { id: genId(), title: title, project: project, status: status, priority: priority, dueDate: dueDateRaw, tags: tagResult.tags };
      var appended = tasks.concat([newTask]);
      if (persist(appended)) {
        tasks = appended;
        closeTaskDialog();
        renderProjectFilterOptions();
        renderBoard();
      }
    }
  }

  function closeTaskDialog() {
    document.getElementById('task-dialog').close();
  }

  // ---------- import ----------

  function handleImportFileChange(e) {
    var input = e.target;
    var file = input.files && input.files[0];
    input.value = '';
    if (!file) return;
    hideImportError();
    if (isBlocked()) return;
    if (file.size > MAX_IMPORT_BYTES) {
      showImportError('That file is too large (max 1 MiB).');
      return;
    }
    var reader = new FileReader();
    reader.onerror = function () { showImportError('Could not read the file.'); };
    reader.onload = function () {
      var text = String(reader.result || '');
      var parsed;
      try {
        parsed = JSON.parse(text);
      } catch (err) {
        showImportError('The file is not valid JSON.');
        return;
      }
      var validation = validateBoardDocument(parsed);
      if (!validation.ok) {
        showImportError(validation.error);
        return;
      }
      pendingImportTasks = validation.tasks;
      document.getElementById('import-summary').textContent =
        'This file contains ' + validation.tasks.length + ' task' + (validation.tasks.length === 1 ? '' : 's') +
        '. Your current board has ' + tasks.length + ' task' + (tasks.length === 1 ? '' : 's') + '.';
      importLastFocused = document.activeElement;
      document.getElementById('import-dialog').showModal();
    };
    reader.readAsText(file);
  }

  function confirmImport() {
    if (isBlocked() || !pendingImportTasks) {
      document.getElementById('import-dialog').close();
      return;
    }
    if (persist(pendingImportTasks)) {
      tasks = pendingImportTasks;
      lastDeleted = null;
      hideToast();
      pendingImportTasks = null;
      document.getElementById('import-dialog').close();
      renderProjectFilterOptions();
      renderBoard();
    } else {
      document.getElementById('import-dialog').close();
    }
  }

  function cancelImport() {
    pendingImportTasks = null;
    document.getElementById('import-dialog').close();
  }

  // ---------- wiring ----------

  function bindEvents() {
    document.getElementById('create-task-btn').addEventListener('click', openCreateDialog);
    document.getElementById('cancel-task-btn').addEventListener('click', closeTaskDialog);
    document.getElementById('task-form').addEventListener('submit', handleTaskFormSubmit);
    document.getElementById('task-dialog').addEventListener('close', function () {
      clearFormErrors();
      if (lastFocusedElement) lastFocusedElement.focus();
    });

    document.getElementById('search').addEventListener('input', renderBoard);
    document.getElementById('filter-status').addEventListener('change', renderBoard);
    document.getElementById('filter-project').addEventListener('change', renderBoard);
    document.getElementById('filter-priority').addEventListener('change', renderBoard);

    document.getElementById('undo-delete-btn').addEventListener('click', handleUndoDelete);

    document.getElementById('export-btn').addEventListener('click', function () {
      var payload = JSON.stringify({ schemaVersion: 1, tasks: tasks }, null, 2);
      downloadTextFile('fieldnote-board-export.json', payload, 'application/json');
    });

    document.getElementById('import-file').addEventListener('change', handleImportFileChange);
    document.getElementById('import-confirm-btn').addEventListener('click', confirmImport);
    document.getElementById('import-cancel-btn').addEventListener('click', cancelImport);
    document.getElementById('import-dialog').addEventListener('close', function () {
      if (importLastFocused) importLastFocused.focus();
    });

    document.getElementById('recovery-download-btn').addEventListener('click', function () {
      downloadTextFile('fieldnote-board-corrupt-backup.txt', corruptRaw || '', 'text/plain');
    });
    document.getElementById('recovery-reset-btn').addEventListener('click', function () {
      var ok = window.confirm('Reset the board? This permanently erases the unreadable saved data and starts a fresh seeded board. This cannot be undone.');
      if (!ok) return;
      tasks = seedTasks();
      persist(tasks);
      corruptRaw = null;
      hideRecoveryBanner();
      renderProjectFilterOptions();
      renderBoard();
    });

    document.getElementById('conflict-reload-btn').addEventListener('click', function () {
      hideConflictBanner();
      loadBoardFromStorage();
      renderProjectFilterOptions();
      renderBoard();
    });

    window.addEventListener('storage', function (e) {
      if (e.key !== STORAGE_KEY) return;
      showConflictBanner();
    });
  }

  function init() {
    loadBoardFromStorage();
    bindEvents();
    document.getElementById('app').hidden = false;
    renderProjectFilterOptions();
    renderBoard();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
