import numpy as np
from scipy.optimize import minimize, linprog
import importlib.util, sys, math

spec = importlib.util.spec_from_file_location("solution", "solution.py")
solution = importlib.util.module_from_spec(spec)
spec.loader.exec_module(solution)
solve = solution.solve


def f(v, t):
    x, y, z = v
    return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t) * x + 5 * y + z


def grad_f(v, t):
    x, y, z = v
    return np.array([2*x + y + (2 - 2*t), x + 4*y - z + 5, -y + 6*z + 1])


cons_defs = [
    ("x>=0", lambda v: v[0]),
    ("y>=0", lambda v: v[1]),
    ("z>=0", lambda v: v[2]),
    ("x<=3/5", lambda v: 0.6 - v[0]),
    ("2y+z>=1/2", lambda v: 2*v[1] + v[2] - 0.5),
]


def scipy_solve(t, n_restarts=12, seed=0):
    rng = np.random.default_rng(seed)
    constraints = [{"type": "eq", "fun": lambda v: v[0] + v[1] + v[2] - 1.0}]
    for _, fn in cons_defs:
        constraints.append({"type": "ineq", "fun": fn})
    best = None
    starts = [
        np.array([0.2, 0.2, 0.6]),
        np.array([0.0, 0.5, 0.5]),
        np.array([0.5, 0.0, 0.5]),
        np.array([0.6, 0.1, 0.3]),
        np.array([1/3, 1/3, 1/3]),
    ]
    for _ in range(n_restarts):
        w = rng.dirichlet(np.ones(3))
        starts.append(w)
    for x0 in starts:
        res = minimize(f, x0, args=(t,), jac=grad_f, method="SLSQP",
                        constraints=constraints, bounds=[(0, 1)]*3,
                        options={"maxiter": 500, "ftol": 1e-14})
        if res.success:
            if best is None or res.fun < best.fun - 1e-12:
                best = res
    return best


def feasible(v, tol=1e-7):
    x, y, z = v
    return (x >= -tol and y >= -tol and z >= -tol and x <= 0.6 + tol
            and 2*y + z >= 0.5 - tol and abs(x + y + z - 1) < 1e-6)


breakpoints = [-2, -1.5, -1.0, -0.5, 0.0, 1.8, 4.0]
eps = 1e-6
test_ts = list(breakpoints)
for b in breakpoints:
    test_ts.append(b - eps)
    test_ts.append(b + eps)
rng = np.random.default_rng(42)
test_ts += list(rng.uniform(-2, 4, size=40))
test_ts = [t for t in test_ts if -2 - 1e-9 <= t <= 4 + 1e-9]

max_x_err = max_y_err = max_z_err = max_v_err = 0.0
n_checked = 0
failures = []

for t in test_ts:
    sol = solve(t)
    x, y, z, val = sol["x"], sol["y"], sol["z"], sol["value"]

    # 1. feasibility of our formula's point
    if not feasible((x, y, z)):
        failures.append((t, "infeasible", sol))
        continue

    # 2. value consistency
    if abs(f((x, y, z), t) - val) > 1e-9:
        failures.append((t, "value mismatch", sol))

    # 3. independent numeric optimum via SLSQP multi-start
    best = scipy_solve(t)
    if best is None:
        failures.append((t, "scipy failed", sol))
        continue
    xs, ys, zs = best.x
    ex, ey, ez = abs(x - xs), abs(y - ys), abs(z - zs)
    ev = abs(val - best.fun)
    max_x_err = max(max_x_err, ex)
    max_y_err = max(max_y_err, ey)
    max_z_err = max(max_z_err, ez)
    max_v_err = max(max_v_err, ev)
    n_checked += 1
    tol = 5e-4  # SLSQP numerical tolerance
    if ex > tol or ey > tol or ez > tol or ev > tol:
        failures.append((t, "mismatch vs scipy", sol, (xs, ys, zs, best.fun)))

print(f"checked {n_checked} points against scipy SLSQP multi-start")
print(f"max |x-x*| = {max_x_err:.3e}, max |y-y*| = {max_y_err:.3e}, "
      f"max |z-z*| = {max_z_err:.3e}, max |val-val*| = {max_v_err:.3e}")
print(f"failures: {len(failures)}")
for fail in failures[:20]:
    print(fail)

# 4. continuity across breakpoints (left/right limits match closed form value)
print("\ncontinuity check at breakpoints:")
for b in breakpoints[1:-1]:
    left = solve(b - 1e-9)
    right = solve(b + 1e-9)
    at = solve(b)
    d = max(abs(left["x"] - right["x"]), abs(left["y"] - right["y"]),
            abs(left["z"] - right["z"]), abs(left["value"] - right["value"]))
    print(f"  t={b}: max jump left/right = {d:.3e}, regimes: {left['regime']} | {at['regime']} | {right['regime']}")

sys.exit(0 if not failures else 1)
