# Exact solution of the parametric QP for all $t \in [-2,4]$

## 0. Problem statement

For every real $t \in [-2,4]$, minimize

$$f_t(x,y,z) = x^2 + 2y^2 + 3z^2 + xy - yz + (2-2t)x + 5y + z$$

subject to

$$x+y+z=1,\quad x\ge 0,\quad y\ge 0,\quad z\ge 0,\quad x\le \tfrac35,\quad 2y+z\ge \tfrac12 .$$

## 1. The problem is a strictly convex QP on a fixed compact polytope

Write $f_t(x,y,z)=\tfrac12 v^\top Q v + c(t)^\top v$ with $v=(x,y,z)^\top$,

$$Q=\begin{pmatrix}2&1&0\\1&4&-1\\0&-1&6\end{pmatrix},\qquad c(t)=\begin{pmatrix}2-2t\\5\\1\end{pmatrix}.$$

$Q$ is symmetric with leading principal minors $2,\ 2\cdot4-1^2=7,\ \det Q = 2(24-1)-1(6-0)+0=46-6=40$, all positive, so $Q\succ0$. Hence for **every fixed $t$**, $f_t$ is strictly convex on $\mathbb R^3$, and a fortiori on the feasible set. The feasible set

$$P=\{(x,y,z): x+y+z=1,\ x,y,z\ge0,\ x\le\tfrac35,\ 2y+z\ge\tfrac12\}$$

does not depend on $t$; it is a closed, bounded (hence compact), convex polytope (it is nonempty: e.g. $(0.5,0,0.5)\in P$). A strictly convex function on a nonempty compact convex set attains a minimum at a **unique** point. So for every $t\in[-2,4]$ the problem has one and only one minimizer $(x(t),y(t),z(t))$, and the KKT conditions below are both necessary **and sufficient** for global optimality (Slater's condition holds trivially since all constraints are affine — no constraint qualification issue ever arises).

## 2. Reduction to two variables

Eliminate $z=1-x-y$ using the equality constraint. Substituting,

$$g(x,y,t) := f_t(x,y,1-x-y) = 4x^2+8xy+6y^2 -2tx-5x-3y+4 .$$

(Direct expansion, confirmed symbolically.) The remaining constraints become, in the $(x,y)$-plane:

$$c_1: x\ge0,\quad c_2: y\ge0,\quad c_3: 1-x-y\ge0\ (\text{i.e. } x+y\le1),\quad c_4: \tfrac35-x\ge0,\quad c_5: y-x+\tfrac12\ge0 .$$

($c_5$ is $2y+z\ge\tfrac12 \Leftrightarrow 2y+(1-x-y)\ge\tfrac12 \Leftrightarrow y-x\ge-\tfrac12$.)

The Hessian of $g$ in $(x,y)$ is $H=\begin{pmatrix}8&8\\8&12\end{pmatrix}$, $\det H = 96-64=32>0$, trace $>0$, so $H\succ0$: $g$ is an exact (no higher‑order terms) strictly convex quadratic,
$$g(x,y,t) = \tfrac12 (v-v_0(t))^\top H (v-v_0(t)) + g(v_0(t),t),\qquad v=(x,y)^\top,$$
where $v_0(t)$ is the unconstrained minimizer of $g(\cdot,\cdot,t)$ over all of $\mathbb R^2$. This means: **the constrained minimizer is the $H$-metric (elliptical) projection of $v_0(t)$ onto the feasible pentagon** described below. This geometric fact is used only as intuition; the proof itself is the KKT verification in §4, which is self-contained.

## 3. The feasible region is a pentagon; its vertices are exact

The set $\{(x,y): c_1,\dots,c_5\ge 0\}$ is an intersection of 5 half-planes, hence a convex polygon. Enumerating the $\binom52=10$ pairwise line intersections and testing all 5 constraints at each (exact rational arithmetic) gives exactly 5 feasible vertices:

$$A=(0,0),\quad B=(\tfrac12,0),\quad C=(\tfrac35,\tfrac1{10}),\quad D=(\tfrac35,\tfrac25),\quad E=(0,1).$$

(The other 5 pairwise intersections — $(0,-\tfrac12)$, $(1,0)$, $(\tfrac35,0)$, $(\tfrac34,\tfrac14)$ — each violate at least one of the 5 constraints and are discarded.) Walking around the boundary:

| edge | equation | binding constraint | range |
|---|---|---|---|
| $AB$ | $y=0$ | $c_2=0$ | $x\in[0,\tfrac12]$ |
| $BC$ | $y=x-\tfrac12$ | $c_5=0$ | $x\in[\tfrac12,\tfrac35]$ |
| $CD$ | $x=\tfrac35$ | $c_4=0$ | $y\in[\tfrac1{10},\tfrac25]$ |
| $DE$ | $x+y=1$ | $c_3=0$ | $x\in[0,\tfrac35]$ |
| $EA$ | $x=0$ | $c_1=0$ | $y\in[0,1]$ |

This is a convex pentagon with exactly 5 edges and 5 vertices — **every** face of $P$ (interior, 5 edges, 5 vertices) is accounted for; no other active-set combination is geometrically possible for a convex polygon (two non-adjacent edges cannot be simultaneously active at a feasible point of a convex polygon, and three constraints cannot be simultaneously active at a generic vertex here since no three of the five lines are concurrent — verified by the vertex enumeration above, which found exactly the 5 expected points).

## 4. KKT system and the unconstrained (equality-only) minimizer

$$g_x = 8x+8y-5-2t,\qquad g_y = 8x+12y-3 .$$

Setting both to zero gives the unconstrained minimizer of $g(\cdot,\cdot,t)$:

$$x_0(t)=\tfrac98+\tfrac34 t,\qquad y_0(t)=-\tfrac12-\tfrac12 t,\qquad z_0(t)=1-x_0-y_0=\tfrac38-\tfrac14 t .$$

For the full 3-variable problem we use multipliers $\nu$ (equality $x+y+z=1$) and $\mu_1,\dots,\mu_5\ge0$ for $c_1,\dots,c_5$ (written as $x\ge0,\ y\ge0,\ z\ge0,\ \tfrac35-x\ge0,\ 2y+z-\tfrac12\ge0$), with **sign convention**

$$\nabla f_t(x,y,z) = \nu(1,1,1) + \mu_1(1,0,0)+\mu_2(0,1,0)+\mu_3(0,0,1)+\mu_4(-1,0,0)+\mu_5(0,2,1),$$
$$\mu_i\ge 0,\qquad \mu_i\cdot(\text{value of }c_i)=0\ \ (i=1,\dots,5),$$

i.e. $\mu_i$ is the (nonnegative) rate at which the optimal value would increase if the corresponding right-hand side were tightened. Explicitly, with $\nabla f_t=(2x+y+2-2t,\ x+4y-z+5,\ -y+6z+1)$, stationarity reads

$$2x+y+2-2t=\nu+\mu_1-\mu_4,\qquad x+4y-z+5=\nu+\mu_2+2\mu_5,\qquad -y+6z+1=\nu+\mu_3+\mu_5. \tag{$\star$}$$

For **strictly convex** $f_t$ on convex $P$, satisfying ($\star$) together with primal feasibility, $\mu_i\ge0$ and complementary slackness is necessary *and sufficient* for $(x,y,z)$ to be **the** global minimizer (this is standard convex KKT sufficiency, applicable here with no constraint qualification issue since all constraints are affine). So each regime below is verified, not just guessed, once the sign checks pass.

We now go around the pentagon (interior $\to$ $EA$ $\to$ interior $\to$ $AB$ $\to$ $B$ $\to$ $BC$ $\to$ $C$) matching where $v_0(t)$ (or its projection) lands, using $t$ increasing from $-2$ to $4$. This order is forced because $x_0(t)=\tfrac98+\tfrac34t$ is strictly increasing in $t$ while $y_0(t)=-\tfrac12-\tfrac12t$ is strictly decreasing, i.e. as $t$ grows the unconstrained target point moves monotonically in the direction $(\tfrac34,-\tfrac12)$ — down and to the right — sweeping across the pentagon from the $EA$ edge, through the interior, along the bottom, and up to vertex $C$; it never returns to a previously-left face, which is why the six regimes below partition $[-2,4]$ into six **consecutive, non-overlapping, jointly exhaustive** intervals with no case missed.

### Regime R1 — edge $EA$ ($x=0$): $t\in[-2,-\tfrac32]$

Only $c_1$ possibly active ($\mu_2=\mu_3=\mu_4=\mu_5=0$). With $x=0$, stationarity in $y$ gives $g_y=12y-3=0\Rightarrow y=\tfrac14\in[0,1]$ (always inside edge $EA$, so this really is an interior point of the edge, not a vertex). Then $z=\tfrac34$.

Solving ($\star$): $\nu=\tfrac{21}4$, $\mu_1=-2t-3$.

- Primal feasibility: $x=0,y=\tfrac14,z=\tfrac34$ satisfy all constraints ($2y+z=\tfrac54\ge\tfrac12$, $x\le\tfrac35$) for every $t$ — the point itself does not depend on $t$.
- Dual feasibility: $\mu_1=-2t-3\ge0 \iff t\le-\tfrac32$.

So R1 is KKT-valid exactly for $t\in[-2,-\tfrac32]$ (at $t=-2$, $\mu_1=1>0$; at $t=-\tfrac32$, $\mu_1=0$, the boundary where $c_1$ is about to go slack).

$$\boxed{x=0,\ y=\tfrac14,\ z=\tfrac34}\qquad V(t)=\tfrac{29}{8}\ \text{(constant)}.$$

### Regime R2 — interior: $t\in[-\tfrac32,-1]$

All $\mu_i=0$; $(x,y,z)=(x_0(t),y_0(t),z_0(t))$ as above, $\nu=\tfrac{15}4-t$ (from ($\star$) with all $\mu_i=0$).

Feasibility of $v_0(t)$ requires simultaneously:
$$x_0\ge0\iff t\ge-\tfrac32;\quad y_0\ge0\iff t\le-1;\quad z_0\ge0\iff t\le\tfrac32;$$
$$x_0\le\tfrac35\iff t\le-\tfrac7{10};\quad c_5: y_0-x_0+\tfrac12\ge0\iff t\le-\tfrac9{10}.$$
Intersection: $t\in[-\tfrac32,-1]$ (the binding pair is $x_0\ge0$ and $y_0\ge0$; the other three are slack throughout, e.g. at $t=-1$: $c_5=\tfrac98>0$, $x_0\le\tfrac35$ gives $\tfrac38\le\tfrac35$ true).

$$\boxed{x=\tfrac98+\tfrac34t,\ \ y=-\tfrac12-\tfrac12t,\ \ z=\tfrac38-\tfrac14t}\qquad V(t)=-\tfrac34t^2-\tfrac94t+\tfrac{31}{16}.$$

### Regime R3 — edge $AB$ ($y=0$): $t\in[-1,-\tfrac12]$

Only $c_2$ active. With $y=0$, stationarity in $x$: $g_x=8x-5-2t=0\Rightarrow x=\tfrac{5+2t}8$, $z=1-x$.

($\star$) gives $\nu=\tfrac{13}4-\tfrac32t$, $\mu_2=2t+2$.

- Edge membership needs $x\in[0,\tfrac12]$: $x\ge0$ always here ($t\ge-1\Rightarrow 5+2t\ge3>0$); $x\le\tfrac12\iff 5+2t\le4\iff t\le-\tfrac12$.
- $\mu_2=2t+2\ge0\iff t\ge-1$.

Valid for $t\in[-1,-\tfrac12]$.

$$\boxed{x=\tfrac{5+2t}8,\ \ y=0,\ \ z=\tfrac{3-2t}8}\qquad V(t)=-\tfrac14t^2-\tfrac54t+\tfrac{39}{16}.$$

### Regime R4 — vertex $B=(\tfrac12,0,\tfrac12)$: $t\in[-\tfrac12,0]$

Both $c_2$ ($y=0$) and $c_5$ ($2y+z=\tfrac12$) active. Solving ($\star$) at this point:
$$\nu=3-2t,\qquad \mu_2=-2t,\qquad \mu_5=2t+1,$$
(with $\mu_1=\mu_3=\mu_4=0$).

- $\mu_2\ge0\iff t\le0$; $\mu_5\ge0\iff t\ge-\tfrac12$.

Valid for $t\in[-\tfrac12,0]$.

$$\boxed{x=\tfrac12,\ y=0,\ z=\tfrac12}\qquad V(t)=\tfrac52-t.$$

### Regime R5 — edge $BC$ ($2y+z=\tfrac12$, i.e. $y=x-\tfrac12$): $t\in[0,\tfrac95]$

Only $c_5$ active. Substituting $y=x-\tfrac12$ into $g_x+g_y=0$ (the condition $\mu_5=g_y=-g_x$ forces $g_x+g_y=0$ along this edge, from ($\star$) restricted to the line, since $\nabla c_5=(-1,1)$ in $(x,y)$ so the stationarity components combine this way):
$$g_x+g_y=16x+20y-8-2t=0 \ \Rightarrow\ 36x-18-2t=0\ \Rightarrow\ x=\tfrac{9+t}{18},\quad y=\tfrac{t}{18}.$$

($\star$) gives $\mu_5=20x-9=\tfrac{10}9t+1$, $\nu=3-\tfrac{11}6t$ (with $\mu_1=\mu_2=\mu_3=\mu_4=0$).

- Edge membership needs $x\in[\tfrac12,\tfrac35]$: $x\ge\tfrac12\iff t\ge0$ (equivalently, $\mu_2$ from R4's formula would go negative below $t=0$ — consistent); $x\le\tfrac35\iff 9+t\le\tfrac{54}5=10.8\iff t\le\tfrac95$.
- $\mu_5=\tfrac{10}9t+1\ge0$ holds throughout ($\ge1$ for $t\ge0$).

Valid for $t\in[0,\tfrac95]$.

$$\boxed{x=\tfrac{9+t}{18},\ \ y=\tfrac t{18},\ \ z=\tfrac{9-2t}{18}}\qquad V(t)=-\tfrac1{18}t^2-t+\tfrac52.$$

### Regime R6 — vertex $C=(\tfrac35,\tfrac1{10},\tfrac3{10})$: $t\in[\tfrac95,4]$

Both $c_4$ ($x=\tfrac35$) and $c_5$ active. First note that **edge $CD$ ($x=\tfrac35$ fixed, $y$ free in $[\tfrac1{10},\tfrac25]$) is never itself the optimal face**: along it $g_y=8(\tfrac35)+12y-3=\tfrac95+12y$, which is $\ge\tfrac95+12(\tfrac1{10})=3>0$ for every $y\ge\tfrac1{10}$ in range and does **not depend on $t$**; since $g_y>0$ throughout $CD$, $g$ is strictly increasing in $y$ along that edge, so the minimum over $CD$ is always attained at its lower end $y=\tfrac1{10}$, i.e. at vertex $C$, for every $t$ once $x=\tfrac35$ is forced. This is what makes $C$ (not an interior point of $CD$) the correct face for all $t\ge\tfrac95$.

Solving ($\star$) at $C$: $\nu=-\tfrac3{10}$, $\mu_4=2t-\tfrac{18}5$, $\mu_5=3$ (with $\mu_1=\mu_2=\mu_3=0$).

- $\mu_4\ge0\iff t\ge\tfrac95$; $\mu_5=3\ge0$ always.

Valid for $t\in[\tfrac95,4]$ (checked up to the right endpoint of the domain; at $t=4$, $\mu_4=4.4>0$, still valid, and $x+y+z=1$, $2y+z=\tfrac12$ exactly — the point sits on the boundary of $P$ at the far end of the domain but remains strictly feasible in $x,y,z\ge0$).

$$\boxed{x=\tfrac35,\ y=\tfrac1{10},\ z=\tfrac3{10}}\qquad V(t)=\tfrac{67}{25}-\tfrac65t.$$

## 5. Summary table (all six regimes cover $[-2,4]$ exactly once, endpoints shared)

| $t$-range | active constraints | $x(t)$ | $y(t)$ | $z(t)$ | $V(t)$ |
|---|---|---|---|---|---|
| $[-2,-\tfrac32]$ | $x\ge0$ | $0$ | $\tfrac14$ | $\tfrac34$ | $\tfrac{29}8$ |
| $[-\tfrac32,-1]$ | none | $\tfrac98+\tfrac34t$ | $-\tfrac12-\tfrac12t$ | $\tfrac38-\tfrac14t$ | $-\tfrac34t^2-\tfrac94t+\tfrac{31}{16}$ |
| $[-1,-\tfrac12]$ | $y\ge0$ | $\tfrac{5+2t}8$ | $0$ | $\tfrac{3-2t}8$ | $-\tfrac14t^2-\tfrac54t+\tfrac{39}{16}$ |
| $[-\tfrac12,0]$ | $y\ge0,\ 2y{+}z\ge\tfrac12$ | $\tfrac12$ | $0$ | $\tfrac12$ | $\tfrac52-t$ |
| $[0,\tfrac95]$ | $2y{+}z\ge\tfrac12$ | $\tfrac{9+t}{18}$ | $\tfrac t{18}$ | $\tfrac{9-2t}{18}$ | $-\tfrac1{18}t^2-t+\tfrac52$ |
| $[\tfrac95,4]$ | $x\le\tfrac35,\ 2y{+}z\ge\tfrac12$ | $\tfrac35$ | $\tfrac1{10}$ | $\tfrac3{10}$ | $\tfrac{67}{25}-\tfrac65t$ |

At every one of the five interior breakpoints $t=-\tfrac32,-1,-\tfrac12,0,\tfrac95$, the two adjacent formulas for $x,y,z$ agree exactly (verified symbolically, e.g. at $t=-\tfrac32$: R1 gives $(0,\tfrac14,\tfrac34)$ and R2 gives the same; at $t=\tfrac95$: R5 gives $(\tfrac35,\tfrac1{10},\tfrac3{10})$ and R6 gives the same), and the corresponding multiplier that is about to become active/inactive passes through exactly $0$ there (e.g. $\mu_1=0$ at $t=-\tfrac32$, $\mu_2=0$ at both $t=-1$ (from R3) and $t=0$ (from R4), $\mu_5=0$ at $t=-\tfrac12$ (from R4), $\mu_4=0$ at $t=\tfrac95$). This is exactly the complementary-slackness handoff expected in parametric QP and confirms there is no gap or overlap between regimes.

## 6. Optimal value function: continuity and $C^1$ smoothness

$V(t)$ is continuous on $[-2,4]$ by the matching at breakpoints shown above (also confirmed numerically to $10^{-9}$ in `verification.md`). Moreover $V$ is **continuously differentiable**, not merely continuous: differentiating each piece and evaluating at the five interior breakpoints,

$$V'(-\tfrac32^-)=0=V'(-\tfrac32^+),\quad V'(-1^-)=-\tfrac34=V'(-1^+),\quad V'(-\tfrac12^-)=-1=V'(-\tfrac12^+),$$
$$V'(0^-)=-1=V'(0^+),\quad V'(\tfrac95^-)=-\tfrac65=V'(\tfrac95^+).$$

This is not a coincidence: by Danskin's / the envelope theorem for parametric convex programs, $V'(t)=\partial f_t/\partial t$ evaluated at the (unique, continuous) optimizer $=-2x(t)$, and $x(t)$ itself is continuous across every breakpoint (shown above), so $V'(t)=-2x(t)$ is automatically continuous — this is a clean independent check of every transition computed above. Explicitly: $V'=-2\cdot0=0$ near $t=-\tfrac32$ ✓, $-2\cdot\tfrac38=-\tfrac34$ near $t=-1$ ✓, $-2\cdot\tfrac12=-1$ near $t=-\tfrac12$ and $t=0$ ✓, $-2\cdot\tfrac35=-\tfrac65$ near $t=\tfrac95$ ✓. $V$ is piecewise quadratic/linear (real-analytic on each open subinterval) and only fails to be twice differentiable at the five breakpoints (where the active set, hence the coefficient of $t^2$, changes: $-\tfrac34\to0\to-\tfrac14\to0\to-\tfrac1{18}\to0$).

## 7. Why no case was missed

1. **Convexity + compactness** (§1) guarantees existence and uniqueness of the minimizer for every $t$, so the object being sought is well-defined everywhere on $[-2,4]$; we are not at risk of an "empty" regime.
2. **Exhaustive face enumeration** (§3): the feasible set is a polygon; a convex polygon's faces are exactly its interior, its (finitely many, here 5) edges, and its (finitely many, here 5) vertices — nothing else is possible. We derived the vertex list from *all* $\binom52=10$ pairwise line intersections and kept only the feasible ones, so no vertex was assumed or guessed.
3. **Monotone sweep argument** (start of §4): $v_0(t)=(x_0(t),y_0(t))$ moves along a straight line, strictly monotonically in both coordinates, as $t$ ranges over $[-2,4]$ (indeed over all of $\mathbb R$). A monotone straight-line sweep across a fixed convex polygon crosses the polygon's normal-fan regions (interior, then a sequence of edges/vertices, exiting through the opposite side) in a well-defined cyclic order with no repeats, which is exactly the R1→R2→R3→R4→R5→R6 order we verified face-by-face with explicit multiplier sign windows that are each closed intervals partitioning $[-2,4]$ with shared endpoints and no gaps (§5 table; every point of $[-2,4]$ lies in at least one of the six closed intervals, and adjacent intervals overlap only at the single shared breakpoint where both regimes agree). Since the six windows already cover $[-2,4]$ completely by direct interval arithmetic (not merely by the qualitative sweep picture), the sweep argument is corroborating intuition, not a load-bearing step of the proof.
4. **Sufficiency, not just necessity**: because $f_t$ is strictly convex and $P$ is convex with affine constraints (Slater/affine constraint qualification holds automatically), any point satisfying primal feasibility, dual feasibility ($\mu_i\ge0$) and complementary slackness is *automatically* the unique global minimizer — we do not need to separately rule out other local minima or other feasible faces once one KKT point is exhibited for a given $t$. Since we exhibited exactly one KKT-valid regime for every $t\in[-2,4]$ (the six windows are pairwise non-overlapping except at shared boundary points, where both formulas agree, so there is never ambiguity or contradiction), that regime's point is *the* answer for that $t$, for the entire closed interval, with nothing left unchecked.

## 8. KKT multiplier reference table (sign convention as in §4)

| Regime | $\nu$ | $\mu_1$ | $\mu_2$ | $\mu_3$ | $\mu_4$ | $\mu_5$ |
|---|---|---|---|---|---|---|
| R1 | $\tfrac{21}4$ | $-2t-3$ | $0$ | $0$ | $0$ | $0$ |
| R2 | $\tfrac{15}4-t$ | $0$ | $0$ | $0$ | $0$ | $0$ |
| R3 | $\tfrac{13}4-\tfrac32t$ | $0$ | $2t+2$ | $0$ | $0$ | $0$ |
| R4 | $3-2t$ | $0$ | $-2t$ | $0$ | $0$ | $2t+1$ |
| R5 | $3-\tfrac{11}6t$ | $0$ | $0$ | $0$ | $0$ | $\tfrac{10}9t+1$ |
| R6 | $-\tfrac3{10}$ | $0$ | $0$ | $0$ | $2t-\tfrac{18}5$ | $3$ |

All listed nonzero multipliers are confirmed nonnegative throughout their stated $t$-range (§4), and $\mu_3$ (for $z\ge0$) is identically $0$ everywhere on $[-2,4]$ because $z(t)>0$ strictly throughout (the minimum value of $z(t)$ over the whole interval is $\tfrac3{10}$, attained on the R6 vertex-$C$ regime $t\in[\tfrac95,4]$), so that constraint is never active — consistent with it not appearing in any active-set column of §5.
