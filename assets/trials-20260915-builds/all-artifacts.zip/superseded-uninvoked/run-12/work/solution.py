"""
Exact closed-form solver for the parametric QP:

    minimize   f_t(x, y, z) = x^2 + 2y^2 + 3z^2 + xy - yz + (2 - 2t)x + 5y + z
    subject to x + y + z = 1,  x >= 0,  y >= 0,  z >= 0,
               x <= 3/5,  2y + z >= 1/2

for real parameter t in [-2, 4].

The closed form below is derived and proved optimal/unique in solution.md via
KKT conditions for a strictly convex quadratic program.  Six regimes in t
partition [-2, 4]; the optimizer (x(t), y(t), z(t)) and optimal value V(t)
are each piecewise-quadratic-or-linear and C^1 across every regime boundary.

Importing this module has no side effects (no CLI, no printing, no I/O).
"""

# Regime breakpoints (exact rationals as floats; all denominators are
# small powers of 2/5/9 so these are either exact or accurate to full
# double precision).
_T1 = -1.5   # -3/2
_T2 = -1.0
_T3 = -0.5
_T4 = 0.0
_T5 = 1.8    # 9/5


def solve(t):
    """Solve the parametric QP for a single value of t in [-2, 4].

    Parameters
    ----------
    t : int or float
        Parameter value, expected in [-2, 4] (the formulas below are the
        analytic continuation of each polynomial piece and remain finite
        for any real t, but optimality is only proved on [-2, 4]).

    Returns
    -------
    dict with keys:
        x, y, z : float   -- the unique optimal point
        value   : float   -- f_t(x, y, z)
        regime  : str     -- label of the active-set regime used
        active  : tuple   -- names of the active inequality constraints
    """
    t = float(t)

    if t <= _T1:
        # Regime 1: x = 0 active (edge x=0 of the feasible pentagon).
        x, y, z = 0.0, 0.25, 0.75
        regime, active = "R1_x=0", ("x>=0",)
    elif t <= _T2:
        # Regime 2: interior of the feasible pentagon (only x+y+z=1 active).
        x = 9.0 / 8.0 + 0.75 * t
        y = -0.5 - 0.5 * t
        z = 0.375 - 0.25 * t
        regime, active = "R2_interior", ()
    elif t <= _T3:
        # Regime 3: y = 0 active (edge AB).
        x = (5.0 + 2.0 * t) / 8.0
        y = 0.0
        z = (3.0 - 2.0 * t) / 8.0
        regime, active = "R3_y=0", ("y>=0",)
    elif t <= _T4:
        # Regime 4: vertex B = (1/2, 0, 1/2); y=0 and 2y+z=1/2 both active.
        x, y, z = 0.5, 0.0, 0.5
        regime, active = "R4_vertexB", ("y>=0", "2y+z>=1/2")
    elif t <= _T5:
        # Regime 5: 2y + z = 1/2 active (edge BC).
        x = (9.0 + t) / 18.0
        y = t / 18.0
        z = (9.0 - 2.0 * t) / 18.0
        regime, active = "R5_2y+z=1/2", ("2y+z>=1/2",)
    else:
        # Regime 6: vertex C = (3/5, 1/10, 3/10); x=3/5 and 2y+z=1/2 both active.
        x, y, z = 0.6, 0.1, 0.3
        regime, active = "R6_vertexC", ("x<=3/5", "2y+z>=1/2")

    value = x * x + 2 * y * y + 3 * z * z + x * y - y * z + (2 - 2 * t) * x + 5 * y + z

    return {
        "x": x,
        "y": y,
        "z": z,
        "value": value,
        "regime": regime,
        "active": active,
    }
