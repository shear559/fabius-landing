# Verification

This documents the checks actually run to validate `solution.py` and the
closed-form derivation in `solution.md`. All work was done offline with the
Python standard library plus locally available `numpy`/`scipy`/`sympy`
(no network access, no external files).

## Environment used

```
$ python3 -c "import sympy, numpy, scipy; print(sympy.__version__, numpy.__version__, scipy.__version__)"
1.14.0 2.0.2 1.13.1
```

## 1. Symbolic derivation checks (sympy)

- Expanded $f_t(x,y,1-x-y)$ symbolically and solved $\nabla=0$ to get the
  unconstrained minimizer $x_0(t),y_0(t)$ analytically (matches §4 of
  `solution.md`).
- Enumerated all $\binom52=10$ pairwise intersections of the five boundary
  lines of the feasible set and evaluated all five constraints (as exact
  `sympy.Rational`s) at each intersection to find the exact vertex set
  $\{A,B,C,D,E\}$ used in `solution.md` §3 — reproduced by:

  ```
  python3 -c "
  import sympy as sp
  from itertools import combinations
  x,y = sp.symbols('x y')
  constraints = [x, y, 1-x-y, sp.Rational(3,5)-x, y-x+sp.Rational(1,2)]
  lines = [sp.Eq(x,0), sp.Eq(y,0), sp.Eq(x+y,1), sp.Eq(x,sp.Rational(3,5)), sp.Eq(y,x-sp.Rational(1,2))]
  for a,b in combinations(lines,2):
      sol = sp.solve([a,b],[x,y], dict=True)
      if sol:
          p = sol[0]
          feas = all(sp.simplify(c.subs(p))>=0 for c in constraints)
          if feas: print(p)
  "
  ```
- For each of the six regimes, solved the full 3-variable KKT stationarity
  system $(\star)$ for $(\nu,\mu_i)$ symbolically as a function of $t$ (exact
  rational coefficients), and confirmed algebraically that every nonzero
  multiplier is $\ge 0$ on its claimed $t$-interval (endpoints included,
  where the relevant multiplier hits exactly $0$).
- Confirmed **continuity** of $(x(t),y(t),z(t))$ and $V(t)$ at all five
  interior breakpoints by symbolic substitution and simplification
  (difference simplifies to exactly `0`).
- Confirmed $V(t)$ is **$C^1$** (not just continuous) by symbolically
  differentiating each of the six polynomial pieces and checking left/right
  derivatives agree at each breakpoint (all five checks: `True`).

All of the above sympy computations are reproduced in the ad hoc commands
used during development; the essential ones (vertex enumeration, KKT solves,
continuity/derivative checks) are summarized as asserted facts in
`solution.md` and were verified interactively before writing the final
formulas into `solution.py`.

## 2. Independent numerical cross-check (`verify.py`)

`verify.py` (included in this directory) is a self-contained, reproducible
script. Run it with:

```
python3 verify.py
```

It performs, for `solve(t)` imported directly from `solution.py`:

1. **Feasibility** of the returned $(x,y,z)$ against all five inequality
   constraints and the equality constraint, to tolerance $10^{-6}$–$10^{-7}$.
2. **Value consistency**: recomputes $f_t(x,y,z)$ from scratch and checks it
   matches the returned `value` field to $10^{-9}$.
3. **Independent optimum**: for the same $t$, solves the QP from scratch
   with `scipy.optimize.minimize` (SLSQP, exact analytic Jacobian supplied),
   using 5 fixed feasible starting points plus 12 random Dirichlet-sampled
   feasible starting points per $t$ (SLSQP is a local method; since the
   problem is convex, any of its converged solutions that satisfies its own
   KKT residual is the unique global optimum, so multi-start is used only as
   an extra safety net against solver noise, not because multiple optima
   could exist). The best (lowest-objective) converged run is compared
   against `solve(t)`'s $(x,y,z,\text{value})$.
4. **Continuity across breakpoints**: evaluates `solve(b - 1e-9)` and
   `solve(b + 1e-9)` at every interior breakpoint
   $b\in\{-1.5,-1,-0.5,0,1.8\}$ and checks the jump in $(x,y,z,\text{value})$
   is at the level of floating-point noise.

Test points: all 7 domain/regime breakpoints $\{-2,-1.5,-1,-0.5,0,1.8,4\}$,
each perturbed by $\pm10^{-6}$ (14 more points), and 40 points drawn
uniformly at random from $[-2,4]$ (fixed seed `42`) — 59 points checked in
total against independent SLSQP solves, plus a separate continuity pass at
the 5 interior breakpoints.

### Actual output obtained

```
checked 59 points against scipy SLSQP multi-start
max |x-x*| = 8.464e-09, max |y-y*| = 8.464e-09, max |z-z*| = 3.375e-09, max |val-val*| = 2.436e-13
failures: 0

continuity check at breakpoints:
  t=-1.5: max jump left/right = 7.500e-10, regimes: R1_x=0 | R1_x=0 | R2_interior
  t=-1.0: max jump left/right = 1.500e-09, regimes: R2_interior | R2_interior | R3_y=0
  t=-0.5: max jump left/right = 2.000e-09, regimes: R3_y=0 | R3_y=0 | R4_vertexB
  t=0.0: max jump left/right = 2.000e-09, regimes: R4_vertexB | R4_vertexB | R5_2y+z=1/2
  t=1.8: max jump left/right = 2.400e-09, regimes: R5_2y+z=1/2 | R5_2y+z=1/2 | R6_vertexC
```

Zero failures out of 59 independent-solver comparisons; worst-case
disagreement with SLSQP is $\approx 8\times10^{-9}$ in the primal variables
and $\approx 2\times10^{-13}$ in the objective value — well within SLSQP's
own numerical tolerance (`ftol=1e-14` was requested; actual attained
precision is solver-dependent, hence the looser $5\times10^{-4}$ comparison
tolerance used by the script, which every point cleared by 4–5 orders of
magnitude).

## 3. Module hygiene check

```
$ python3 -c "import solution; print('no output above this line means no CLI/print side effects')"
no output above this line means no CLI/print side effects
$ python3 -c "import solution; print(solution.solve(1.8-1e-9)); print(solution.solve(1.8+1e-9))"
```
confirms `solution.py` has no import-time side effects and that `solve`
accepts plain floats (including values on either side of a breakpoint,
returning matching results) and plain ints (checked separately with
`solution.solve(0)`, `solution.solve(-2)`, `solution.solve(4)`).

## 4. Known limitations

- The numerical cross-check in step 2 relies on SLSQP, a local NLP solver;
  because the problem is proven convex in `solution.md` §1, any of its
  locally-optimal, KKT-satisfying solutions is automatically globally
  optimal, so this is not a limitation for correctness — but SLSQP itself
  has finite floating-point precision (~$10^{-8}$–$10^{-9}$), which is the
  dominant source of the tiny nonzero errors reported above.
- Random sampling (40 uniform points, seed 42) does not exhaustively cover
  $[-2,4]$; the six breakpoints and their $\pm10^{-6}$ neighborhoods are
  covered exactly (not randomly), which is where a piecewise formula is
  most likely to have an off-by-one or open/closed interval bug, so this is
  considered adequate coverage rather than a gap.
- No test was run against the hidden evaluation oracle mentioned in
  `BRIEF.md`; all checks above are self-constructed and independent of it.

## Reproduce everything

```
cd <this directory>
python3 verify.py
```

Expected: `failures: 0` and all five continuity jumps at the $10^{-9}$
level or smaller.
