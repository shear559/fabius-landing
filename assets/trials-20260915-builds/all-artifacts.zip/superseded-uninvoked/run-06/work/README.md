# Fieldnote Board

A local-first, single-team task board. Fictional demo data, no backend, no network calls, no build step.

## Running it

Serve this directory with any static file server and open `index.html` (or the served URL) in a browser. It works from a nested URL path because `index.html` links to `styles.css` and `app.js` with relative paths. Examples:

```
python3 -m http.server 8080
# then open http://localhost:8080/
```

or simply double-click `index.html` to open it via `file://` (localStorage still works per-origin in most browsers for local files, though a static server is recommended for consistent behavior).

## Data model

Board data lives in `localStorage` under the key `fieldnote-board:v1` as:

```json
{ "schemaVersion": 1, "tasks": [ { "id": "...", "title": "...", "project": "...", "status": "todo|doing|done", "priority": "low|medium|high", "dueDate": "YYYY-MM-DD or \"\"", "tags": ["..."] } ] }
```

- IDs are generated with `crypto.randomUUID()` (falls back to a timestamp+random string).
- Tags are parsed from comma-separated input, trimmed, deduplicated case-insensitively (first-seen casing wins), capped at 8 tags of ≤24 characters.
- Title ≤120 chars, project ≤80 chars, both trimmed and required.
- On genuinely empty storage (key absent), the app seeds 8 fictional tasks across 2 projects covering all 3 statuses. Seeding never happens if the key exists, even if its contents are invalid — see "Error handling" below.

## Error handling and safety design

- **Corrupt storage**: on startup, the raw value is parsed and schema-validated. If it fails either check, the app enters recovery mode: the exact original bytes are kept in memory (never rewritten), a visible notice explains the situation, and the user can download the original bytes as a `.txt` file or explicitly reset (native `confirm()`) to a fresh sample board. The task UI is hidden until resolved.
- **Storage write failures** (e.g. quota exceeded): every write goes through a `try/catch`. On failure the in-memory state is left unchanged, an error toast/message says the change was not saved, and — for the task form — the modal stays open with the user's entered values intact so nothing is lost.
- **Cross-tab conflicts**: the app listens for the `storage` event (which only fires in *other* tabs). Any external write to the board key raises a visible "changed in another tab" notice and disables create/edit/delete/status/import controls until the user clicks "Reload board," which re-reads storage fresh and clears the flag. This guarantees a stale tab can never silently clobber newer data written elsewhere.
- **Delete/undo**: deleting persists immediately (so a crash right after delete can't resurrect it unexpectedly) and keeps the removed record plus its original index in memory. The visible Undo control re-inserts and persists it; because this is a normal persisted write, the restored record survives a reload.
- **Import**: validated fully (schema version, per-task shape/enums/dates/tag rules, duplicate IDs, 1 MiB size cap, JSON parse) *before* anything is written — so any single invalid task rejects the entire file and leaves the current board completely untouched (atomic). A valid file triggers a native `confirm()` describing the replacement before the board is overwritten.
- **XSS safety**: all task-derived text (title, project, tags) is rendered via `textContent`, never `innerHTML`, so imported or typed HTML/script content is always treated as plain text.

## Accessibility and keyboard support

- Every input/select has an associated `<label>`; icon-only buttons use `aria-label` naming the task they act on (e.g. "Delete Draft trailhead signage copy").
- The task form is a modal dialog (`role="dialog"`, `aria-modal="true"`) that traps Tab focus, closes on Escape, and restores focus to whatever control opened it.
- Live regions (`aria-live="polite"`) announce notices, toasts, and the matching-task count.
- `@media (prefers-reduced-motion: reduce)` collapses all transitions/animations to near-zero duration.
- A `<noscript>` banner explains the app requires JavaScript when it's disabled.

## Checks actually executed

Using a headless Chromium session (Playwright) against a local static server, including a nested URL path to confirm relative assets resolve correctly:

- Seed data: ≥6 tasks, ≥2 projects, all 3 statuses present on first load.
- Create/edit/delete/undo flows, including tag dedup ("One, one, Two , three" → `["One","Two","three"]`) and that undo survives a page reload.
- Status control updates persist to storage.
- Blank-title validation shows a visible inline error and blocks submission.
- Search and status/project/priority filters narrow results; a no-results state renders; a live "N of M tasks shown" count updates.
- Export downloads a schema-valid JSON file containing the *entire* board (verified equal to the full stored task count, independent of active filters).
- Import: invalid JSON, and a file with duplicate task IDs, are both rejected with the prior board left byte-for-byte untouched (verified via `localStorage` before/after); a valid file shows a native confirmation dialog, replaces the board, and the replacement survives reload.
- Corrupt `localStorage` value: recovery notice appears, the corrupt bytes are read back unchanged from storage (not silently overwritten), and the explicit reset path produces a fresh valid board.
- Escape closes the task modal and returns keyboard focus to the button that opened it.
- Two-tab conflict: a write from a second simulated tab shows the conflict notice and disables `create-task` in the first tab; clicking "Reload board" clears the notice and picks up the other tab's data.
- `prefers-reduced-motion: reduce` collapses CSS transition durations to ~0.
- A task titled with an HTML/script payload renders as inert text (no injected DOM element).
- Manual screenshot review at 360px and 1440px viewports for layout correctness (an initial bug — the search field stretching to fill vertical space once the mobile toolbar switched to a column layout — was found this way and fixed).

Not separately automated: screen-reader-specific behavior (verified structurally via ARIA attributes/labels, not with an actual screen reader), and the `file://`-protocol launch path (static-server path was used for testing; relative asset paths make both equivalent).

## Limitations

- No multi-user merge/CRDT logic — the cross-tab story is "detect and block until reload," not automatic reconciliation, by design (safer default for a local-only demo).
- No pagination/virtualization; fine for a small team's board, not built for thousands of tasks.
- Date input uses the browser's native `<input type="date">` picker/format; validation additionally enforces a real calendar date server-side-equivalent (in-app) via manual leap-year-aware checking.
