(function () {
  'use strict';

  var STORAGE_KEY = 'fieldnote-board:v1';
  var MAX_IMPORT_BYTES = 1024 * 1024;
  var STATUSES = ['todo', 'doing', 'done'];
  var PRIORITIES = ['low', 'medium', 'high'];
  var STATUS_LABELS = { todo: 'To do', doing: 'Doing', done: 'Done' };
  var PRIORITY_LABELS = { low: 'Low', medium: 'Medium', high: 'High' };

  var state = {
    tasks: [],
    corrupt: false,
    corruptRaw: null,
    conflict: false,
    lastDeleted: null,
    editingId: null,
    lastOpener: null,
    filters: { search: '', status: 'all', project: 'all', priority: 'all' }
  };

  // ---------------- utilities ----------------

  function genId() {
    if (window.crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function isValidDateString(s) {
    if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    var parts = s.split('-');
    var y = Number(parts[0]), m = Number(parts[1]), d = Number(parts[2]);
    if (m < 1 || m > 12 || d < 1 || d > 31) return false;
    var dt = new Date(Date.UTC(y, m - 1, d));
    return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
  }

  function normalizeTags(input) {
    var seen = {};
    var out = [];
    input.split(',').forEach(function (raw) {
      var t = raw.trim();
      if (!t) return;
      var key = t.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      out.push(t);
    });
    return out;
  }

  function escapeText(s) { return String(s); } // textContent is used everywhere; kept for clarity at call sites

  function validateStoredTask(t, existingIds) {
    var errs = [];
    if (!t || typeof t !== 'object' || Array.isArray(t)) return ['not an object'];
    if (typeof t.id !== 'string' || !t.id.trim() || t.id.length > 80) errs.push('invalid id');
    else if (existingIds && existingIds[t.id]) errs.push('duplicate id');
    if (typeof t.title !== 'string' || !t.title.trim() || t.title.length > 120) errs.push('invalid title');
    if (typeof t.project !== 'string' || !t.project.trim() || t.project.length > 80) errs.push('invalid project');
    if (STATUSES.indexOf(t.status) === -1) errs.push('invalid status');
    if (PRIORITIES.indexOf(t.priority) === -1) errs.push('invalid priority');
    if (typeof t.dueDate !== 'string' || (t.dueDate !== '' && !isValidDateString(t.dueDate))) errs.push('invalid dueDate');
    if (!Array.isArray(t.tags) || t.tags.length > 8) {
      errs.push('invalid tags');
    } else {
      var seenTags = {};
      for (var i = 0; i < t.tags.length; i++) {
        var tag = t.tags[i];
        if (typeof tag !== 'string' || !tag.trim() || tag.trim() !== tag || tag.length > 24) { errs.push('invalid tag'); break; }
        var k = tag.toLowerCase();
        if (seenTags[k]) { errs.push('duplicate tag'); break; }
        seenTags[k] = true;
      }
    }
    return errs;
  }

  function validateBoardDocument(doc) {
    if (!doc || typeof doc !== 'object' || Array.isArray(doc)) return 'Not a valid JSON object.';
    if (doc.schemaVersion !== 1) return 'Unsupported or missing schemaVersion (expected 1).';
    if (!Array.isArray(doc.tasks)) return 'Missing "tasks" array.';
    var ids = {};
    for (var i = 0; i < doc.tasks.length; i++) {
      var errs = validateStoredTask(doc.tasks[i], ids);
      if (errs.length) return 'Task ' + (i + 1) + ' is invalid (' + errs.join(', ') + ').';
      ids[doc.tasks[i].id] = true;
    }
    return null;
  }

  function persist(tasks) {
    try {
      var json = JSON.stringify({ schemaVersion: 1, tasks: tasks });
      localStorage.setItem(STORAGE_KEY, json);
      return true;
    } catch (e) {
      return false;
    }
  }

  function buildSeedTasks() {
    return [
      { id: genId(), title: 'Draft trailhead signage copy', project: 'Riverwalk Signage', status: 'doing', priority: 'high', dueDate: '2026-09-22', tags: ['copywriting', 'signage'] },
      { id: genId(), title: 'Source weatherproof sign posts', project: 'Riverwalk Signage', status: 'todo', priority: 'medium', dueDate: '2026-09-30', tags: ['procurement'] },
      { id: genId(), title: 'Get city permit approval', project: 'Riverwalk Signage', status: 'done', priority: 'high', dueDate: '', tags: ['permits'] },
      { id: genId(), title: 'Book festival main stage', project: 'Harvest Festival', status: 'done', priority: 'high', dueDate: '2026-09-10', tags: ['logistics', 'stage'] },
      { id: genId(), title: 'Confirm vendor booth list', project: 'Harvest Festival', status: 'doing', priority: 'medium', dueDate: '2026-09-25', tags: ['vendors'] },
      { id: genId(), title: 'Design festival poster', project: 'Harvest Festival', status: 'todo', priority: 'low', dueDate: '', tags: ['design'] },
      { id: genId(), title: 'Recruit volunteer marshals', project: 'Harvest Festival', status: 'todo', priority: 'medium', dueDate: '2026-10-01', tags: ['volunteers', 'ops'] },
      { id: genId(), title: 'Install trail marker signs', project: 'Riverwalk Signage', status: 'todo', priority: 'low', dueDate: '2026-10-15', tags: ['installation'] }
    ];
  }

  // ---------------- DOM references ----------------

  var el = {
    noticesRegion: document.getElementById('notices'),
    toastRegion: document.getElementById('toast-region'),
    stats: document.getElementById('stats'),
    search: document.getElementById('search-input'),
    filterStatus: document.getElementById('filter-status'),
    filterProject: document.getElementById('filter-project'),
    filterPriority: document.getElementById('filter-priority'),
    resultCount: document.getElementById('result-count'),
    taskList: document.getElementById('task-list'),
    emptyState: document.getElementById('empty-state'),
    createBtn: document.getElementById('create-task-btn'),
    exportBtn: document.getElementById('export-btn'),
    importFile: document.getElementById('import-file'),
    modalOverlay: document.getElementById('modal-overlay'),
    modal: document.querySelector('#modal-overlay .modal'),
    modalTitle: document.getElementById('modal-title'),
    form: document.getElementById('task-form'),
    fieldId: document.getElementById('task-id'),
    fieldTitle: document.getElementById('task-title'),
    fieldProject: document.getElementById('task-project'),
    fieldStatus: document.getElementById('task-status'),
    fieldPriority: document.getElementById('task-priority'),
    fieldDue: document.getElementById('task-due'),
    fieldTags: document.getElementById('task-tags'),
    errTitle: document.getElementById('err-title'),
    errProject: document.getElementById('err-project'),
    errDue: document.getElementById('err-due'),
    errTags: document.getElementById('err-tags'),
    errForm: document.getElementById('err-form'),
    cancelBtn: document.getElementById('cancel-btn')
  };

  // ---------------- notices / toasts ----------------

  function showToast(message, type) {
    var t = document.createElement('div');
    t.className = 'toast notice-' + (type || 'info');
    t.textContent = message;
    el.toastRegion.appendChild(t);
    setTimeout(function () {
      if (t.parentNode) t.parentNode.removeChild(t);
    }, 5000);
  }

  function clearNotices() {
    el.noticesRegion.innerHTML = '';
  }

  function addNotice(message, type, actions) {
    var n = document.createElement('div');
    n.className = 'notice notice-' + type;
    var span = document.createElement('span');
    span.textContent = message;
    n.appendChild(span);
    if (actions && actions.length) {
      var wrap = document.createElement('div');
      wrap.className = 'notice-actions';
      actions.forEach(function (a) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'btn btn-small';
        b.textContent = a.label;
        if (a.testId) b.setAttribute('data-testid', a.testId);
        b.addEventListener('click', a.onClick);
        wrap.appendChild(b);
      });
      n.appendChild(wrap);
    }
    el.noticesRegion.appendChild(n);
  }

  function renderPersistentNotices() {
    clearNotices();

    if (state.corrupt) {
      addNotice(
        'Stored board data on this device could not be read. Your original data has not been modified. You can download the original bytes or reset to a fresh board.',
        'error',
        [
          { label: 'Download original bytes', testId: 'download-corrupt', onClick: downloadCorruptBytes },
          { label: 'Reset board', testId: 'reset-board', onClick: resetCorruptBoard }
        ]
      );
      return;
    }

    if (state.conflict) {
      addNotice(
        'This board was changed in another tab. Editing is paused to avoid overwriting the newer data. Reload to see the latest board.',
        'warn',
        [{ label: 'Reload board', testId: 'reload-board', onClick: reloadBoard }]
      );
    }

    if (state.lastDeleted) {
      addNotice(
        'Task "' + state.lastDeleted.task.title + '" was deleted.',
        'info',
        [{ label: 'Undo', testId: 'undo-delete', onClick: undoDelete }]
      );
    }
  }

  // ---------------- storage load / corrupt / conflict ----------------

  function enterCorruptMode(raw) {
    state.corrupt = true;
    state.corruptRaw = raw;
    state.tasks = [];
  }

  function downloadCorruptBytes() {
    if (state.corruptRaw === null) return;
    var blob = new Blob([state.corruptRaw], { type: 'text/plain' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'fieldnote-board-corrupt-backup.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function resetCorruptBoard() {
    var confirmed = window.confirm('Reset will replace the unreadable stored data with a fresh sample board. This cannot be undone. Continue?');
    if (!confirmed) return;
    var seeded = buildSeedTasks();
    var ok = persist(seeded);
    state.corrupt = false;
    state.corruptRaw = null;
    state.tasks = seeded;
    if (!ok) showToast('Reset board is in memory only — storage write failed.', 'error');
    else showToast('Board reset to a fresh sample board.', 'success');
    render();
  }

  function loadFromStorage() {
    var raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) {
      var seeded = buildSeedTasks();
      var ok = persist(seeded);
      state.tasks = seeded;
      state.corrupt = false;
      state.corruptRaw = null;
      if (!ok) showToast('Could not save the sample board to storage — this session may not persist.', 'error');
      return;
    }
    var doc;
    try {
      doc = JSON.parse(raw);
    } catch (e) {
      enterCorruptMode(raw);
      return;
    }
    var err = validateBoardDocument(doc);
    if (err) {
      enterCorruptMode(raw);
      return;
    }
    state.tasks = doc.tasks;
    state.corrupt = false;
    state.corruptRaw = null;
  }

  function reloadBoard() {
    state.conflict = false;
    state.lastDeleted = null;
    loadFromStorage();
    render();
    showToast('Board reloaded from storage.', 'info');
  }

  window.addEventListener('storage', function (e) {
    if (e.key !== STORAGE_KEY) return;
    if (state.corrupt) return;
    state.conflict = true;
    render();
  });

  // ---------------- filtering / rendering ----------------

  function getUniqueProjects() {
    var seen = {};
    var out = [];
    state.tasks.forEach(function (t) {
      if (!seen[t.project]) { seen[t.project] = true; out.push(t.project); }
    });
    out.sort(function (a, b) { return a.localeCompare(b); });
    return out;
  }

  function renderProjectFilterOptions() {
    var current = el.filterProject.value || 'all';
    var projects = getUniqueProjects();
    el.filterProject.innerHTML = '';
    var allOpt = document.createElement('option');
    allOpt.value = 'all';
    allOpt.textContent = 'All projects';
    el.filterProject.appendChild(allOpt);
    projects.forEach(function (p) {
      var opt = document.createElement('option');
      opt.value = p;
      opt.textContent = p;
      el.filterProject.appendChild(opt);
    });
    if (current !== 'all' && projects.indexOf(current) === -1) current = 'all';
    el.filterProject.value = current;
    state.filters.project = current;
  }

  function getFilteredTasks() {
    var q = state.filters.search.trim().toLowerCase();
    return state.tasks.filter(function (t) {
      if (state.filters.status !== 'all' && t.status !== state.filters.status) return false;
      if (state.filters.project !== 'all' && t.project !== state.filters.project) return false;
      if (state.filters.priority !== 'all' && t.priority !== state.filters.priority) return false;
      if (q) {
        var haystack = (t.title + ' ' + t.project + ' ' + t.tags.join(' ')).toLowerCase();
        if (haystack.indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function renderStats() {
    el.stats.innerHTML = '';
    var counts = { total: state.tasks.length, todo: 0, doing: 0, done: 0 };
    state.tasks.forEach(function (t) { counts[t.status]++; });
    var tiles = [
      { label: 'Total tasks', value: counts.total },
      { label: 'To do', value: counts.todo },
      { label: 'Doing', value: counts.doing },
      { label: 'Done', value: counts.done }
    ];
    tiles.forEach(function (tile) {
      var d = document.createElement('div');
      d.className = 'stat-tile';
      var v = document.createElement('span');
      v.className = 'stat-value';
      v.textContent = String(tile.value);
      var l = document.createElement('span');
      l.className = 'stat-label';
      l.textContent = tile.label;
      d.appendChild(v);
      d.appendChild(l);
      el.stats.appendChild(d);
    });
  }

  function formatDue(dueDate) {
    if (!dueDate) return '';
    return 'Due ' + dueDate;
  }

  function createTaskCard(task) {
    var card = document.createElement('article');
    card.className = 'task-card';
    card.setAttribute('data-testid', 'task-card');
    card.setAttribute('data-task-id', task.id);

    var h3 = document.createElement('h3');
    h3.textContent = task.title;
    card.appendChild(h3);

    var meta = document.createElement('div');
    meta.className = 'task-meta';

    var project = document.createElement('span');
    project.textContent = task.project;
    meta.appendChild(project);

    var priority = document.createElement('span');
    priority.className = 'badge priority-' + task.priority;
    priority.textContent = PRIORITY_LABELS[task.priority];
    meta.appendChild(priority);

    if (task.dueDate) {
      var due = document.createElement('span');
      due.textContent = formatDue(task.dueDate);
      meta.appendChild(due);
    }

    card.appendChild(meta);

    if (task.tags.length) {
      var tagsWrap = document.createElement('div');
      tagsWrap.className = 'tags';
      task.tags.forEach(function (tag) {
        var chip = document.createElement('span');
        chip.className = 'tag';
        chip.textContent = tag;
        tagsWrap.appendChild(chip);
      });
      card.appendChild(tagsWrap);
    }

    var actions = document.createElement('div');
    actions.className = 'task-card-actions';

    var statusSelect = document.createElement('select');
    statusSelect.setAttribute('data-action', 'status');
    statusSelect.setAttribute('aria-label', 'Status for ' + task.title);
    STATUSES.forEach(function (s) {
      var opt = document.createElement('option');
      opt.value = s;
      opt.textContent = STATUS_LABELS[s];
      if (s === task.status) opt.selected = true;
      statusSelect.appendChild(opt);
    });
    statusSelect.disabled = state.conflict;
    actions.appendChild(statusSelect);

    var editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn-small';
    editBtn.setAttribute('data-action', 'edit');
    editBtn.setAttribute('aria-label', 'Edit ' + task.title);
    editBtn.textContent = 'Edit';
    editBtn.disabled = state.conflict;
    actions.appendChild(editBtn);

    var deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'btn btn-small btn-danger';
    deleteBtn.setAttribute('data-action', 'delete');
    deleteBtn.setAttribute('aria-label', 'Delete ' + task.title);
    deleteBtn.textContent = 'Delete';
    deleteBtn.disabled = state.conflict;
    actions.appendChild(deleteBtn);

    card.appendChild(actions);
    return card;
  }

  function renderTaskList(filtered) {
    el.taskList.innerHTML = '';
    if (state.corrupt) {
      el.taskList.hidden = true;
      el.emptyState.hidden = true;
      return;
    }
    el.taskList.hidden = false;

    if (state.tasks.length === 0) {
      el.emptyState.hidden = false;
      el.emptyState.textContent = 'No tasks yet. Click "New task" to create your first one.';
      return;
    }
    if (filtered.length === 0) {
      el.emptyState.hidden = false;
      el.emptyState.textContent = 'No tasks match your search or filters. Try clearing them.';
      return;
    }
    el.emptyState.hidden = true;
    filtered.forEach(function (t) {
      el.taskList.appendChild(createTaskCard(t));
    });
  }

  function renderResultCount(matching, total) {
    el.resultCount.textContent = matching + ' of ' + total + ' task' + (total === 1 ? '' : 's') + ' shown';
  }

  function updateControlsDisabled() {
    el.createBtn.disabled = state.corrupt || state.conflict;
    el.importFile.disabled = state.corrupt || state.conflict;
  }

  function render() {
    renderPersistentNotices();
    if (state.corrupt) {
      el.stats.innerHTML = '';
      el.taskList.innerHTML = '';
      el.taskList.hidden = true;
      el.emptyState.hidden = false;
      el.emptyState.textContent = 'Board unavailable until the corrupt data is resolved above.';
      el.resultCount.textContent = '';
      updateControlsDisabled();
      return;
    }
    renderProjectFilterOptions();
    renderStats();
    var filtered = getFilteredTasks();
    renderTaskList(filtered);
    renderResultCount(filtered.length, state.tasks.length);
    updateControlsDisabled();
  }

  // ---------------- CRUD operations ----------------

  function findIndexById(id) {
    for (var i = 0; i < state.tasks.length; i++) if (state.tasks[i].id === id) return i;
    return -1;
  }

  function deleteTask(id) {
    if (state.conflict || state.corrupt) return;
    var idx = findIndexById(id);
    if (idx === -1) return;
    var removed = state.tasks[idx];
    var newTasks = state.tasks.slice();
    newTasks.splice(idx, 1);
    var ok = persist(newTasks);
    if (!ok) {
      showToast('Delete failed — storage error. Task was not removed.', 'error');
      return;
    }
    state.tasks = newTasks;
    state.lastDeleted = { task: removed, index: idx };
    render();
  }

  function undoDelete() {
    if (!state.lastDeleted) return;
    var newTasks = state.tasks.slice();
    var idx = Math.min(state.lastDeleted.index, newTasks.length);
    newTasks.splice(idx, 0, state.lastDeleted.task);
    var ok = persist(newTasks);
    if (!ok) {
      showToast('Undo failed — storage error.', 'error');
      return;
    }
    state.tasks = newTasks;
    state.lastDeleted = null;
    render();
    showToast('Task restored.', 'success');
  }

  function changeStatus(id, newStatus, revert) {
    if (state.conflict || state.corrupt) { revert(); return; }
    var idx = findIndexById(id);
    if (idx === -1) { revert(); return; }
    var newTasks = state.tasks.slice();
    newTasks[idx] = Object.assign({}, newTasks[idx], { status: newStatus });
    var ok = persist(newTasks);
    if (!ok) {
      showToast('Status change failed — storage error.', 'error');
      revert();
      return;
    }
    state.tasks = newTasks;
    render();
  }

  // ---------------- form / modal ----------------

  var modalOpen = false;
  var focusTrapHandler = null;

  function clearFormErrors() {
    [el.errTitle, el.errProject, el.errDue, el.errTags, el.errForm].forEach(function (n) { n.textContent = ''; });
  }

  function openModal(mode, task) {
    state.editingId = task ? task.id : null;
    el.modalTitle.textContent = mode === 'edit' ? 'Edit task' : 'New task';
    clearFormErrors();
    el.fieldId.value = task ? task.id : '';
    el.fieldTitle.value = task ? task.title : '';
    el.fieldProject.value = task ? task.project : '';
    el.fieldStatus.value = task ? task.status : 'todo';
    el.fieldPriority.value = task ? task.priority : 'medium';
    el.fieldDue.value = task ? task.dueDate : '';
    el.fieldTags.value = task ? task.tags.join(', ') : '';

    state.lastOpener = document.activeElement;
    el.modalOverlay.hidden = false;
    modalOpen = true;
    el.fieldTitle.focus();

    focusTrapHandler = function (e) {
      if (e.key === 'Escape') {
        e.preventDefault();
        closeModal();
        return;
      }
      if (e.key === 'Tab') {
        var focusable = el.modal.querySelectorAll('input, select, button, [href]');
        if (!focusable.length) return;
        var first = focusable[0];
        var last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', focusTrapHandler);
  }

  function closeModal() {
    el.modalOverlay.hidden = true;
    modalOpen = false;
    state.editingId = null;
    el.form.reset();
    clearFormErrors();
    if (focusTrapHandler) {
      document.removeEventListener('keydown', focusTrapHandler);
      focusTrapHandler = null;
    }
    if (state.lastOpener && typeof state.lastOpener.focus === 'function') {
      state.lastOpener.focus();
    }
  }

  function validateForm(values) {
    var errors = {};
    var title = values.title.trim();
    var project = values.project.trim();

    if (!title) errors.title = 'Title is required.';
    else if (title.length > 120) errors.title = 'Title must be 120 characters or fewer.';

    if (!project) errors.project = 'Project is required.';
    else if (project.length > 80) errors.project = 'Project must be 80 characters or fewer.';

    if (values.dueDate && !isValidDateString(values.dueDate)) {
      errors.dueDate = 'Enter a valid calendar date (YYYY-MM-DD).';
    }

    var tags = normalizeTags(values.tags);
    if (tags.length > 8) errors.tags = 'Use at most 8 tags.';
    else {
      for (var i = 0; i < tags.length; i++) {
        if (tags[i].length > 24) { errors.tags = 'Each tag must be 24 characters or fewer.'; break; }
      }
    }

    return { errors: errors, title: title, project: project, tags: tags };
  }

  el.form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (state.conflict) {
      el.errForm.textContent = 'This board changed in another tab. Reload the board before saving.';
      return;
    }

    var values = {
      title: el.fieldTitle.value,
      project: el.fieldProject.value,
      status: el.fieldStatus.value,
      priority: el.fieldPriority.value,
      dueDate: el.fieldDue.value,
      tags: el.fieldTags.value
    };
    var result = validateForm(values);
    clearFormErrors();

    if (Object.keys(result.errors).length) {
      if (result.errors.title) el.errTitle.textContent = result.errors.title;
      if (result.errors.project) el.errProject.textContent = result.errors.project;
      if (result.errors.dueDate) el.errDue.textContent = result.errors.dueDate;
      if (result.errors.tags) el.errTags.textContent = result.errors.tags;
      var firstInvalid = result.errors.title ? el.fieldTitle : result.errors.project ? el.fieldProject : result.errors.dueDate ? el.fieldDue : el.fieldTags;
      firstInvalid.focus();
      return;
    }

    var isEdit = !!state.editingId;
    var taskId = isEdit ? state.editingId : genId();
    var task = {
      id: taskId,
      title: result.title,
      project: result.project,
      status: values.status,
      priority: values.priority,
      dueDate: values.dueDate,
      tags: result.tags
    };

    var newTasks = state.tasks.slice();
    if (isEdit) {
      var idx = findIndexById(taskId);
      if (idx === -1) { el.errForm.textContent = 'This task no longer exists.'; return; }
      newTasks[idx] = task;
    } else {
      newTasks.push(task);
    }

    var ok = persist(newTasks);
    if (!ok) {
      el.errForm.textContent = 'Could not save — storage error. Your entries are preserved below; please try again.';
      return;
    }

    state.tasks = newTasks;
    closeModal();
    render();
    showToast(isEdit ? 'Task updated.' : 'Task created.', 'success');
  });

  el.cancelBtn.addEventListener('click', closeModal);
  el.createBtn.addEventListener('click', function () { openModal('create', null); });
  el.modalOverlay.addEventListener('click', function (e) {
    if (e.target === el.modalOverlay) closeModal();
  });

  // ---------------- task list delegated events ----------------

  el.taskList.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-action="edit"], [data-action="delete"]');
    if (!btn) return;
    var card = e.target.closest('[data-testid="task-card"]');
    if (!card) return;
    var id = card.getAttribute('data-task-id');
    var action = btn.getAttribute('data-action');
    if (action === 'edit') {
      if (state.conflict) return;
      var task = state.tasks[findIndexById(id)];
      if (task) openModal('edit', task);
    } else if (action === 'delete') {
      deleteTask(id);
    }
  });

  el.taskList.addEventListener('change', function (e) {
    var select = e.target.closest('[data-action="status"]');
    if (!select) return;
    var card = e.target.closest('[data-testid="task-card"]');
    if (!card) return;
    var id = card.getAttribute('data-task-id');
    var previous = state.tasks[findIndexById(id)] ? state.tasks[findIndexById(id)].status : select.value;
    changeStatus(id, select.value, function () { select.value = previous; });
  });

  // ---------------- search / filters ----------------

  el.search.addEventListener('input', function () {
    state.filters.search = el.search.value;
    render();
  });
  el.filterStatus.addEventListener('change', function () {
    state.filters.status = el.filterStatus.value;
    render();
  });
  el.filterProject.addEventListener('change', function () {
    state.filters.project = el.filterProject.value;
    render();
  });
  el.filterPriority.addEventListener('change', function () {
    state.filters.priority = el.filterPriority.value;
    render();
  });

  // ---------------- export / import ----------------

  el.exportBtn.addEventListener('click', function () {
    var json = JSON.stringify({ schemaVersion: 1, tasks: state.tasks }, null, 2);
    var blob = new Blob([json], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'fieldnote-board-export.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Board exported.', 'success');
  });

  el.importFile.addEventListener('change', function (e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;

    function resetInput() { el.importFile.value = ''; }

    if (file.size > MAX_IMPORT_BYTES) {
      showToast('Import failed: file exceeds the 1 MiB limit.', 'error');
      resetInput();
      return;
    }

    var reader = new FileReader();
    reader.onload = function () {
      var text = String(reader.result);
      var doc;
      try {
        doc = JSON.parse(text);
      } catch (err) {
        showToast('Import failed: file is not valid JSON.', 'error');
        resetInput();
        return;
      }
      var validationError = validateBoardDocument(doc);
      if (validationError) {
        showToast('Import failed: ' + validationError, 'error');
        resetInput();
        return;
      }
      var confirmed = window.confirm(
        'Replace the current board (' + state.tasks.length + ' task(s)) with ' + doc.tasks.length + ' task(s) from this file? This cannot be undone.'
      );
      if (!confirmed) {
        showToast('Import cancelled — board unchanged.', 'info');
        resetInput();
        return;
      }
      var ok = persist(doc.tasks);
      if (!ok) {
        showToast('Import failed: could not save to storage. Board unchanged.', 'error');
        resetInput();
        return;
      }
      state.tasks = doc.tasks.slice();
      state.lastDeleted = null;
      render();
      showToast('Board imported successfully.', 'success');
      resetInput();
    };
    reader.onerror = function () {
      showToast('Import failed: could not read the file.', 'error');
      resetInput();
    };
    reader.readAsText(file);
  });

  // ---------------- init ----------------

  loadFromStorage();
  render();
})();
