# Lattice — fictional product landing page

A static marketing landing page for **Lattice**, a fictional local-first
research notebook. Built for a design/engineering demonstration — there is no
real product, backend, account system or payment behind it.

## Files

- `index.html` — all markup and content
- `styles.css` — visual design system (custom properties, layout, responsive rules)
- `app.js` — progressive-enhancement interactivity (mobile nav, feature tabs, billing toggle)
- `BRIEF.md` — the original task brief (untouched)

## Running it

No build step or dependencies. Any static file server works, including from a
nested path, because every asset reference (`styles.css`, `app.js`, in-page
`#anchors`) is relative.

```sh
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

Opening `index.html` directly via `file://` also works.

## Implementation decisions

- **Visual system**: a warm paper background with a subtle dot-grid texture
  (echoing the "lattice" motif), a serif display face for headings paired
  with the system UI sans-serif for body text, a teal/amber accent pair, and
  generous whitespace. All fonts are system stacks — no remote font loads.
- **Hero illustration**: an original inline SVG mockup of the (fictional) app
  window — a notebook list, an open note with a source-link chip, and a small
  node-and-line "lattice" diagram — built entirely from SVG shapes, not an
  imported asset.
- **Progressive enhancement / no-JS baseline**: the feature panels and the
  mobile navigation are visible by default in the raw HTML. A tiny inline
  script in `<head>` adds a `.js` class to `<html>`; only CSS/JS gated by that
  class collapses the mobile nav or hides inactive tab panels. With
  JavaScript disabled, all three feature panels, both prices, and every nav
  link remain in the page and readable — nothing depends on script execution
  to be discoverable.
- **Feature tabs**: real ARIA tab/tabpanel semantics (`role="tablist"`,
  roving `tabindex`, `aria-selected`, `aria-controls`/`aria-labelledby`), with
  Left/Right/Up/Down/Home/End arrow-key support that moves both focus and
  selection.
- **Mobile nav**: `data-testid="menu-toggle"` toggles `aria-expanded` and
  shows/hides `data-testid="mobile-nav"`. Escape closes it and returns focus
  to the toggle button; clicking a nav link closes it. Desktop navigation is
  a separate always-visible `<nav>` shown above the mobile breakpoint.
- **Billing toggle**: `billing-monthly` / `billing-yearly` buttons use
  `aria-pressed` and rewrite the text of `price-solo` / `price-studio`
  ($12/$29 monthly, $108/$264 yearly) plus a separate "/month" or "/year"
  label next to each price. Switching back to monthly restores the exact
  original values (no drift, values are looked up from a fixed table, not
  computed/rounded).
- **FAQ**: four native `<details>/<summary>` elements (no ARIA needed —
  semantics are native), answering exactly the four topics in the brief:
  local-only storage, Markdown export, manual export-based backup (no
  automatic cloud backup claimed), and cancellation not affecting already
  exported files.
- **Fictional framing**: a persistent banner at the very top of the page
  states this is a fictional demonstration, and the hero/footer/pricing copy
  reiterate it. No invented customers, reviews, ratings, or performance
  numbers appear anywhere — only the pricing figures specified in the brief.
- **Accessibility**: visible `:focus-visible` outlines on all interactive
  elements, a skip-to-content link, labelled landmarks/nav regions, and a
  `prefers-reduced-motion` block that collapses transition/animation
  durations to near-zero.
- **Responsive layout**: mobile-first CSS with a single breakpoint (~760px)
  switching header nav and workflow/pricing grids between stacked and
  multi-column layouts; verified at 360px and 1440px (see Checks below).

## Checks actually executed

Using headless Chromium via the Playwright library (`chromium.launch()`),
served over local `http.server` instances (root path and a nested
`/sub/` path):

- Feature tabs: default panel visibility, click-to-switch panel visibility,
  `aria-selected` updates, and `ArrowRight` roving focus/selection — all
  passed.
- Billing toggle: initial monthly values ($12/$29), switching to yearly
  ($108/$264), and switching back to monthly (exact restoration) — all
  passed.
- All four FAQ `<details>` open on clicking their `data-testid` summary.
- Primary CTA (`.btn-primary`) resolves to `href="#workflow"`.
- Mobile viewport (360×800): menu toggle starts with `aria-expanded="false"`,
  opening sets it to `"true"` and shows the mobile nav, `Escape` closes it
  and returns focus to the toggle, and clicking a nav link inside the open
  menu closes it. No horizontal overflow at 360px width (`scrollWidth`
  equalled `clientWidth`).
- JavaScript-disabled context (`javaScriptEnabled: false`): all three feature
  panels are visible/discoverable, the Solo price is present in the static
  HTML, and — at a 360px mobile viewport with JS off — the mobile nav is
  visible without needing the toggle.
- Nested-path context (page served from `/sub/index.html` on a second static
  server rooted one directory up): `styles.css` applied (computed background
  color on the primary button was non-transparent) and `app.js` executed
  (the `.js` class was present on `<html>`), confirming relative asset URLs
  resolve correctly away from the site root.
- Manual visual review via full-page screenshots at 1440×900 and 360×780,
  covering the hero, feature tabs, and pricing sections, to sanity-check
  hierarchy, spacing and no obvious overlap/clipping.

All of the above were run against this exact artifact in this directory
during development; no evaluation fixtures or files outside this directory
were read or used.

## Known limitations

- The hero illustration and dot-grid background are decorative approximations
  of a notebook UI, not a functioning application — this is a marketing page,
  not the product itself.
- No automated axe-core or Lighthouse audit was run (not available in this
  offline environment); accessibility was checked manually against the
  brief's specific requirements (focus visibility, labels, semantics, ARIA
  tab pattern, reduced motion) rather than against a full automated ruleset.
- Only one CSS breakpoint (~760px) is used; layouts between the two tested
  widths (360px and 1440px) are fluid but were not individually screenshotted
  at every intermediate size.
- Color contrast was chosen deliberately (dark ink on light paper, white text
  on the teal/dark buttons) but was not run through an automated contrast
  checker — only visual inspection.
