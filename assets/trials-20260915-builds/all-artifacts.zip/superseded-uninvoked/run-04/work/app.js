(function () {
  "use strict";

  /* ---------- Mobile navigation ---------- */
  var menuToggle = document.querySelector('[data-testid="menu-toggle"]');
  var mobileNav = document.querySelector('[data-testid="mobile-nav"]');

  if (menuToggle && mobileNav) {
    // Progressive enhancement: collapse the mobile nav only once JS can drive it.
    mobileNav.classList.add('is-collapsed');
    menuToggle.setAttribute('aria-expanded', 'false');

    function openMenu() {
      mobileNav.classList.remove('is-collapsed');
      menuToggle.setAttribute('aria-expanded', 'true');
    }

    function closeMenu(returnFocus) {
      mobileNav.classList.add('is-collapsed');
      menuToggle.setAttribute('aria-expanded', 'false');
      if (returnFocus) {
        menuToggle.focus();
      }
    }

    menuToggle.addEventListener('click', function () {
      var expanded = menuToggle.getAttribute('aria-expanded') === 'true';
      if (expanded) {
        closeMenu(false);
      } else {
        openMenu();
      }
    });

    mobileNav.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        closeMenu(true);
      }
    });

    mobileNav.addEventListener('click', function (event) {
      var link = event.target.closest('a');
      if (link) {
        closeMenu(false);
      }
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && menuToggle.getAttribute('aria-expanded') === 'true') {
        closeMenu(true);
      }
    });
  }

  /* ---------- Feature tabs ---------- */
  var tabIds = ['feature-capture', 'feature-connect', 'feature-export'];
  var tabs = tabIds.map(function (id) {
    return document.querySelector('[data-testid="' + id + '"]');
  }).filter(Boolean);

  function panelForTab(tab) {
    var panelId = tab.getAttribute('aria-controls');
    return document.getElementById(panelId);
  }

  function selectTab(tab, moveFocus) {
    tabs.forEach(function (t) {
      var selected = t === tab;
      t.setAttribute('aria-selected', selected ? 'true' : 'false');
      t.setAttribute('tabindex', selected ? '0' : '-1');
      var panel = panelForTab(t);
      if (panel) {
        panel.hidden = !selected;
      }
    });
    if (moveFocus) {
      tab.focus();
    }
  }

  if (tabs.length) {
    // Hide non-selected panels only after JS confirms it can drive selection.
    tabs.forEach(function (t) {
      var panel = panelForTab(t);
      if (panel) {
        panel.hidden = t.getAttribute('aria-selected') !== 'true';
      }
    });

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function () {
        selectTab(tab, false);
      });

      tab.addEventListener('keydown', function (event) {
        var newIndex = null;
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
          newIndex = (index + 1) % tabs.length;
        } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
          newIndex = (index - 1 + tabs.length) % tabs.length;
        } else if (event.key === 'Home') {
          newIndex = 0;
        } else if (event.key === 'End') {
          newIndex = tabs.length - 1;
        }
        if (newIndex !== null) {
          event.preventDefault();
          selectTab(tabs[newIndex], true);
        }
      });
    });
  }

  /* ---------- Billing toggle ---------- */
  var monthlyBtn = document.querySelector('[data-testid="billing-monthly"]');
  var yearlyBtn = document.querySelector('[data-testid="billing-yearly"]');
  var priceSolo = document.querySelector('[data-testid="price-solo"]');
  var priceStudio = document.querySelector('[data-testid="price-studio"]');

  var PRICES = {
    monthly: { solo: '$12', studio: '$29', period: '/month' },
    yearly: { solo: '$108', studio: '$264', period: '/year' }
  };

  function setBilling(period) {
    var data = PRICES[period];
    if (!data) return;

    if (priceSolo) priceSolo.textContent = data.solo;
    if (priceStudio) priceStudio.textContent = data.studio;

    document.querySelectorAll('.price-period').forEach(function (el) {
      el.textContent = data.period;
    });

    if (monthlyBtn) monthlyBtn.setAttribute('aria-pressed', period === 'monthly' ? 'true' : 'false');
    if (yearlyBtn) yearlyBtn.setAttribute('aria-pressed', period === 'yearly' ? 'true' : 'false');
  }

  if (monthlyBtn && yearlyBtn) {
    monthlyBtn.addEventListener('click', function () { setBilling('monthly'); });
    yearlyBtn.addEventListener('click', function () { setBilling('yearly'); });
  }
})();
