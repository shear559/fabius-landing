#!/usr/bin/env python3
"""Headless paired runs: bare Claude Code (user settings excluded, no plugins, no memory, no hooks) versus the same plus the
installed Fabius 3.1.0 plugin tree loaded with --plugin-dir. Identical prompt, model, tools, cwd layout and time guidance."""
import json,os,subprocess,sys,time,threading,datetime
H='[study]'
B='[user]/.antigravity-ide/extensions/anthropic.claude-code-2.1.260-darwin-x64/resources/native-binary/claude'
PLUGIN='[user]/.claude/plugins/cache/fabius/fabius/3.1.0'
CAP=1500  # seconds of wall clock per run; the artifact present at the cap is retained
CONC=int(sys.argv[1]) if len(sys.argv)>1 else 4
plan=json.load(open(f'{H}/runs/plan.json'))
ONLY=set(os.environ.get('ONLY','').split(',')) - {''}
if ONLY: plan=[r for r in plan if r['id'] in ONLY]
PROMPT=('The user\'s request is the file BRIEF.md in the current directory. Read it first, then deliver exactly what it asks, inside this directory. '
        'Do not modify or delete BRIEF.md. Write only inside this directory and do not read files outside it. Do not use the network. '
        'You may run local commands (for example node, python3, or a headless Chrome at "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"; '
        'the Playwright library is available to CommonJS scripts via NODE_PATH=[playwright-qa]/node_modules) to check your own work. '
        'Aim to finish within about fifteen minutes of work. Return only your final message to the user.')
env={k:v for k,v in os.environ.items() if k not in ('CLAUDECODE','CLAUDE_CODE_ENTRYPOINT')}
def run(r):
    d=f'{H}/runs/{r["id"]}'; work=f'{d}/work'
    cmd=[B,'-p',PROMPT,'--model','claude-sonnet-5','--setting-sources','project','--strict-mcp-config','--permission-mode','bypassPermissions','--no-session-persistence','--output-format','stream-json','--verbose','--disallowedTools','WebFetch','WebSearch']
    if r['arm']=='fabius': cmd+=['--plugin-dir',PLUGIN]; cmd[2]='/fabius '+PROMPT+' Before you start, load the fabius specialist skills this task calls for with the Skill tool and follow their contracts.'  # the router via its slash command, plus the router's own instruction to route, restated
    started=datetime.datetime.utcnow().isoformat()+'Z'; t0=time.time()
    with open(f'{d}/stream.jsonl','w') as out, open(f'{d}/stderr.txt','w') as err, open(os.devnull) as devnull:
        p=subprocess.Popen(cmd,cwd=work,stdin=devnull,stdout=out,stderr=err,env=env)
        try: code=p.wait(timeout=CAP); capped=False
        except subprocess.TimeoutExpired: p.kill(); code=None; capped=True
    meta={'id':r['id'],'task':r['task'],'repeat':r['repeat'],'arm':r['arm'],'started':started,'ended':datetime.datetime.utcnow().isoformat()+'Z','wall_seconds':round(time.time()-t0,1),'exit_code':code,'capped':capped,'command':[('/fabius <PROMPT> + route instruction' if c.startswith('/fabius') else ('<PROMPT>' if c==PROMPT else c)) for c in cmd]}
    json.dump(meta,open(f'{d}/launch.json','w'),indent=1)
    print(r['id'],r['task'],r['arm'],'r'+str(r['repeat']),'done',meta['wall_seconds'],'s exit',code,'capped',capped,flush=True)
pending=list(plan); lock=threading.Lock()
def worker():
    while True:
        with lock:
            if not pending: return
            r=pending.pop(0)
        run(r)
threads=[threading.Thread(target=worker) for _ in range(CONC)]
[t.start() for t in threads]; [t.join() for t in threads]
print('ALL DONE',flush=True)
