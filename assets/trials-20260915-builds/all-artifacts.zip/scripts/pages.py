#!/usr/bin/env python3
"""Protocol page, report page and archive for the September 14 build study, from the assembled results.json."""
import re,json,os,html,subprocess,shutil,glob,hashlib
ID='trials-20260915-builds'; OUT=f'[user]/Desktop/Workspace/03-Personal/fabius-landing/assets/{ID}'; BASE=f'/assets/{ID}'
S='[study]'
d=json.load(open(f'{OUT}/results.json')); m=d['meta']; E=html.escape
HEAD=lambda title:f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>{E(title)} · Fabius build trials</title><link rel="stylesheet" href="/styles.css?v=2026-09-14"><link rel="stylesheet" href="{BASE}/evidence.css"></head><body class="evidence-page"><main class="evidence"><a class="evidence-home" href="/#trials">← Fabius · three real tasks</a>'
FOOT='</main></body></html>'
ARM={'baseline':'Without Fabius','fabius':'With Fabius'}
# ── report
rows=''
for t in d['tasks']:
    for p in t['runs']:
        for arm in ('baseline','fabius'):
            a=p[arm]; rid=a['artifactUrl'].split('/')[-2]
            extra=f"{a['scenarios']['passed']}/{a['scenarios']['executed']}" if a.get('scenarios') else ('1233/1233' if t['id']=='math' and a['checks'][0]['passed'] else '')
            rows+=f"<tr><td>{E(t['title'])}</td><td>{p['repeat']}</td><td>{ARM[arm]}</td><td><a href=\"{BASE}/runs/{rid}/checks.html\">{rid}</a></td><td>{a['passed']}/{a['total']}</td><td>{extra}</td><td>{a['seconds']}</td><td>{a['tokens']}</td><td>{a.get('toolCalls','')}</td></tr>"
detail=''
for t in d['tasks']:
    detail+=f"<h2>{E(t['title'])}</h2><div class=\"evidence-scroll\"><table><thead><tr><th>Check</th>"
    for p in t['runs']:
        for arm in ('baseline','fabius'): detail+=f"<th>{ARM[arm]} · r{p['repeat']}</th>"
    detail+='</tr></thead><tbody>'
    for i,c in enumerate(t['runs'][0]['baseline']['checks']):
        detail+=f"<tr><td>{E(c['label'])}</td>"
        for p in t['runs']:
            for arm in ('baseline','fabius'):
                cc=p[arm]['checks'][i]; detail+=f"<td>{'met' if cc['passed'] else 'missed'}</td>"
        detail+='</tr>'
    detail+='</tbody></table></div>'
    for p in t['runs']:
        for arm in ('baseline','fabius'):
            a=p[arm]; rid=a['artifactUrl'].split('/')[-2]
            detail+=f"<details><summary>{ARM[arm]}, run {p['repeat']} ({rid}): every check with its recorded detail</summary><ul>"+''.join(f"<li><strong>{E(c['label'])}</strong> — {'met' if c['passed'] else 'missed'}. {E(c['detail'])}</li>" for c in a['checks'])+f"</ul><p><a href=\"{a['artifactUrl']}\">source ZIP</a> · <a href=\"{a['proofUrl']}\">check record</a> · <a href=\"{BASE}/runs/{rid}/answer.md\">final message</a> · <a href=\"{BASE}/runs/{rid}/trace.json\">tool trace</a></p></details>"
corr=[]
for rid in ('run-05','run-06','run-07','run-08'):
    g=f'{S}/eval-out/{rid}/grade/results.json'
    if not os.path.exists(g): continue
    cur=json.load(open(g)); by=cur['summary']['byCheck']
    for c in cur.get('runnerCorrections',[]):
        pre=f'{S}/eval-out/{rid}/'+c['original']
        if os.path.exists(pre):
            a=json.load(open(pre))['summary']['byCheck']; ch=[k for k in c['groups'] if a.get(k,{}).get('passed')!=by[k]['passed']]
            if ch: corr.append(f"{rid}: {', '.join(ch)} changed by {c['id']}")
corr_text=('Runner corrections (see the protocol; the oracle self-test still matched its 13 controls; regraded for every application run): '+'; '.join(corr)+'. Runs not listed were unchanged. Original results are kept in each run\'s record.') if corr else 'The runner corrections changed no result on this set.'
report=HEAD('Results, including ties and misses')+'<h1>Results, including ties and misses</h1><p>'+E(corr_text)+'</p><p>All twelve runs are shown: three tasks, two conditions, two fresh runs each, on one model. Checks met counts the recorded groups (browser scenario groups for the page and the app; the numeric probe set plus eight proof criteria for the mathematics). Browser scenarios are the individual executions behind the groups. No aggregate improvement is claimed.</p><div class="evidence-scroll"><table><thead><tr><th>Task</th><th>Repeat</th><th>Condition</th><th>Run</th><th>Checks met</th><th>Scenarios / probes</th><th>Seconds</th><th>Output tokens</th><th>Tool calls</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+detail+f'<h2>Files</h2><p><a href="{BASE}/protocol.html">How the trials were run</a> · <a href="{BASE}/all-artifacts.zip">All artifacts (ZIP)</a> · <a href="{BASE}/results.json">results.json</a></p>'+FOOT
open(f'{OUT}/report.html','w',encoding='utf-8').write(report)
# ── protocol
C=d['contracts']
contracts=''.join(f"<details><summary>{'Page and app runs' if k=='ui' else 'Mathematics runs'}: {len(v)} files read first</summary><ul>"+''.join(f"<li><code>{E(c['path'])}</code> <small>sha256 {E(c['sha256'][:16])}…</small></li>" for c in v)+'</ul></details>' for k,v in C.items())
P=HEAD('How the build trials were run')+'<h1>How the build trials were run</h1>'
P+='<p>This study records what one model produced on three briefs, twice in a bare session and twice in the same session with the Fabius plugin installed, each run in its own fresh context. It replaces the first September 14 set on the front page: that set was generated by subagents inside the maintainer&#x27;s own session, whose context carried the session&#x27;s skill catalogue and the maintainer&#x27;s memory notes, so its baseline was not bare even though it never invoked a skill. That set stays published for the record; this one was run with the isolation below.</p>'
P+='<h2>The twelve runs</h2>'
P+=f'<p>The briefs are the September 10 briefs, byte for byte (hashes in the manifest inside the archive): the Lattice landing page, the Fieldnote Board application and the parametric constrained optimization problem. Every run is a headless Claude Code session ({E(m["model"])}) started in its own empty directory holding only BRIEF.md, with the same prompt: read the brief, deliver inside the directory, write nowhere else, use no network, check your own work with the local tools named, aim for about fifteen minutes. User settings were excluded, so no user-level skills, plugins, hooks, memory files or project instructions were loaded; no MCP servers; web tools disallowed. A wall-clock cap of twenty-five minutes retained whatever was in the directory at the cap. Runs were dispatched four at a time on one shared machine on {E(m["date"])}; no run was retried, repaired or re-prompted.</p>'
P+='<h2>What changes between conditions</h2>'
P+='<p>Without Fabius means exactly the session above: Claude Code&#x27;s own system prompt, its built-in tools and built-in skills, nothing else. The init record of each transcript lists the skills the session could see; the baseline lists none from Fabius.</p>'
P+=f'<p>With Fabius means the identical session with the installed Fabius {E(m["version"])} plugin loaded from its plugin directory (commit {E(m["fabiusCommit"][:7])}, the tree the maintainer uses), invoked the documented way: the plugin&#x27;s own slash command, /fabius, in front of the otherwise identical prompt, which places the router&#x27;s contract in the session, followed by one sentence restating the router&#x27;s own instruction to load the specialist skills the task calls for. Which specialists each session then loaded is recorded from its transcript and shown next to the run&#x27;s status. The plugin&#x27;s files are hashed in the manifest.</p>'
P+='<p>Two earlier treatment attempts are kept in the archive as superseded and are not scored on the page. In the first, the plugin was loaded without its command: in six of six sessions the model never invoked it, so those runs demonstrate an installed but unused plugin. In the second, the command loaded the router (the transcripts&#x27; first-turn token counts show it) but in six of six sessions the model did not go on to load any specialist. The published treatment is the third attempt. This is reported because it is also a finding: in a headless session the routing that the plugin relies on the model to perform did not happen unprompted.</p>'
P+='<h2>Evaluation</h2>'
P+='<p>The page and app artifacts were graded by the September 10 browser oracle: the frozen rubric (seven groups for the page, sixteen for the app), each group exercised in Chromium and WebKit at 360 and 1440 pixels, 28 scenario executions per page and 68 per app; a group counts as met only when every execution passes. The runner carries the one symmetric correction documented in the previous set (a native alert stating an import error counts as visible feedback), applied to every run here. The same capture helper recorded the six walkthrough states per artifact in fresh contexts with external requests blocked; published images are lossless WebP conversions. The mathematics artifacts were scored by the exact geometric oracle at its 1,233 parameter probes and sampled at 127 parameters for the plot; the eight proof criteria were graded by two independent blind claude-opus-5 judges per submission from masked copies, a criterion counting as met only when both judges independently returned pass.</p>'
P+='<h2>Runner corrections, applied symmetrically</h2>'
P+='<p>Two defects of the September 10 browser runner were demonstrated on these artifacts and corrected; each time the original results were kept in the run&#x27;s record, the oracle self-test was rerun and still matched its thirteen controls, and the affected groups were regraded for every application run with the corrected runner. First, a native alert stating an import error now counts as visible feedback (the runner only read page text and form validity, so an app that refused a bad file correctly and said so in an alert was recorded as silent). Second, the runner&#x27;s search for a custom confirm control skips the import file input itself (a visually hidden file input labelled Import JSON carries the button role and a matching name, so the search resolved to it, the click was intercepted by its label, and the whole import group failed by exception before any observation was made). The report states which runs changed. No candidate file was touched.</p>'
P+='<h2>What was found, in one paragraph</h2>'
diffs=[]
for t in d['tasks']:
    for p in t['runs']:
        b,f=p['baseline'],p['fabius']; diffs.append(f"{t['title']} run {p['repeat']}: {b['passed']}/{b['total']} without, {f['passed']}/{f['total']} with")
P+='<p>'+E('; '.join(diffs))+'. The page and the mathematics are ties on every check. The application shows where the runs differed; the report lists every missed group with the failing observation, and the live previews on the front page show the products themselves.</p>'
P+='<h2>Limits</h2>'
P+='<p>Two runs per condition, one model, one host, no human judges, no cross-model replication, no statistical claim. The briefs and the check rubric come from the September 10 study and were written by the maintainer of the rules; the checks measure the supplied contract, not visual quality or production readiness. The baseline carries the harness&#x27;s own system prompt, which already asks for care. Time and token differences include the contract reading and are reported as costs of the treatment, not as a finding. Generated JavaScript runs on this site only inside sandboxed frames with an opaque origin; the products path carries a byte-identical copy of each artifact plus, for the applications, a one-line wrapper that loads an in-memory storage stand-in. No candidate file was edited.</p>'
P+=f'<p><a href="{BASE}/landing.md">landing brief</a> · <a href="{BASE}/app.md">app brief</a> · <a href="{BASE}/math.md">math brief</a> · <a href="{BASE}/report.html">Results</a> · <a href="{BASE}/all-artifacts.zip">All artifacts (ZIP)</a></p>'+FOOT
open(f'{OUT}/protocol.html','w',encoding='utf-8').write(P)
# ── archive
ST=f'{S}/_zip'; shutil.rmtree(ST,ignore_errors=True); os.makedirs(ST)
def norm(s):
    s=re.sub(r'[study][0-9a-f-]*(?:/scratchpad/builds3)?','[study]',s)
    s=re.sub(r'[session][A-Za-z0-9-]*','[session]',s)
    return s.replace(S,'[study]').replace('[study]','[session]').replace('[fabius]/','[fabius]/').replace('[playwright-qa]','[playwright-qa]').replace('[user]','[user]')
def put(src,dst,text=True):
    os.makedirs(os.path.dirname(f'{ST}/{dst}'),exist_ok=True)
    if text: open(f'{ST}/{dst}','w',encoding='utf-8').write(norm(open(src,encoding='utf-8',errors='ignore').read()))
    else: shutil.copy(src,f'{ST}/{dst}')
put(f'{OUT}/results.json','results.json')
for b in ('landing.md','app.md','math.md'): put(f'{S}/briefs/{b}',f'briefs/{b}')
put(f'{S}/contracts/manifest.json','contracts/manifest.json'); put(f'{S}/runs/plan.json','runs/plan.json'); put(f'{S}/judged.json','judging/proof-judges-raw.json')
put(f'{S}/eval/web-oracle/grade.pre-alert-feedback.mjs','evaluation/web-oracle/grade.pre-alert-feedback.mjs')
put(f'{S}/run3.py','scripts/run.py'); put(f'{S}/pipeline3.py','scripts/pipeline.py'); put(f'{S}/assemble3.py','scripts/assemble.py'); put(f'{S}/pages3.py','scripts/pages.py')
for f in ('web-oracle/grade.mjs','web-oracle/rubric.json','web-oracle/README.md','capture.mjs','math-oracle/oracle.py','math-oracle/score.py','math-oracle/candidate_runner.py','math-oracle/proof-rubric.json','math-oracle/reference.md'): put(f'{S}/eval/{f}',f'evaluation/{f}')
for sup in ('superseded-uninvoked','superseded-router-only'):
    for rd in sorted(glob.glob(f'{S}/{sup}/runs/run-*')):
        rid=os.path.basename(rd)
        for f in ('launch.json','stream.jsonl'):
            if os.path.exists(f'{rd}/{f}'): put(f'{rd}/{f}',f'{sup}/{rid}/{f}')
        for f in os.listdir(f'{rd}/work'):
            if f!='BRIEF.md' and os.path.isfile(f'{rd}/work/{f}'): put(f'{rd}/work/{f}',f'{sup}/{rid}/work/{f}',text=f.endswith(('.md','.py','.js','.css','.html','.json','.txt')))
for rd in sorted(glob.glob(f'{OUT}/runs/run-*')):
    rid=os.path.basename(rd)
    for f in os.listdir(rd): put(f'{rd}/{f}',f'runs/{rid}/{f}',text=f.endswith(('.md','.json','.html')))
open(f'{ST}/READ-FIRST.md','w').write('# Fabius build trials, 2026-09-14\n\nTwelve runs of claude-sonnet-5 on the three September 10 briefs: two runs with the Fabius 3.1.0 contracts read first, two without, per task. Graded by the unchanged September 10 browser oracle (Chromium + WebKit, 360/1440), its capture helper, its exact mathematics oracle (1,233 probes) and two blind claude-opus-5 judges for the eight proof criteria.\n\n- `results.json` — the published data; `briefs/`, `contracts/manifest.json` (Fabius commit and file hashes), `runs/plan.json`.\n- `runs/run-NN/` — `source.zip` (every file the run left, brief excluded), `answer.md`, `trace.json`, `checks.json` (raw grade or score plus judge verdicts), `checks.html`, captures as lossless WebP.\n- `judging/proof-judges-raw.json` — both judges\' verdicts as returned.\n- `evaluation/` — the oracle, capture and scoring code as run (paths normalized); `scripts/` — the driver, pipeline, assembler and page generator.\n- `superseded-uninvoked/` and `superseded-router-only/` — the two earlier treatment attempts (plugin loaded but never invoked; router loaded but no specialist), transcripts and files, kept for the record and not scored.\n\nPaths are normalized: `[fabius]/` is the Fabius repository at the recorded commit, `[study]` the study directory, `[user]` the home directory. Protocol: https://fabius-landing.vercel.app'+BASE+'/protocol.html\n')
zp=f'{OUT}/all-artifacts.zip'
if os.path.exists(zp): os.remove(zp)
subprocess.run(['zip','-q','-r','-X',zp,'.'],cwd=ST,check=True); shutil.rmtree(ST)
left=subprocess.run(['grep','-rl','[user]\\|/private/tmp/claude-501',OUT],capture_output=True,text=True).stdout.strip()
print('pages written; archive bytes',os.path.getsize(zp),'; private paths left:',left or 'none')
