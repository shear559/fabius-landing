# Lattice — fictional product landing page

A static marketing landing page for **Lattice**, a fictional local-first
research notebook. Built as a design/engineering demonstration. Vanilla
HTML/CSS/JS only — no build step, no frameworks, no network calls.

## Run it

Serve the folder with any static file server and open `index.html`. It
uses only relative URLs (`./styles.css`, `./app.js`), so it works from a
nested path too, e.g.:

```
python3 -m http.server 8000
# then visit http://localhost:8000/index.html
```

or, to confirm nested-path behavior specifically:

```
# from the parent of this folder
python3 -m http.server 8000
# then visit http://localhost:8000/<this-folder-name>/index.html
```

Opening `index.html` directly via `file://` also works.

## Files

- `index.html` — all markup and content.
- `styles.css` — design system (custom properties) and responsive layout.
- `app.js` — mobile nav, feature tabs, and billing toggle behavior.

## Implementation decisions

- **Visual system**: warm paper background, ink/serif headings (Georgia
  stack) paired with a system-UI sans body font, one teal accent
  (`--accent`) and one amber accent used sparingly for emphasis (badges,
  focus ring). No remote fonts — system font stacks only.
- **Hero illustration**: an original SVG mock of the Lattice UI (notes
  sidebar, an open note with a source chip, and a small connection graph),
  built entirely from `rect`/`line`/`circle` primitives styled with CSS
  variables so it matches the page's palette. The single pulsing graph
  node is disabled under `prefers-reduced-motion: reduce`.
- **Progressive enhancement without JavaScript**: an inline one-line
  script adds a `js` class to `<html>` as the only thing that runs before
  CSS paints. CSS then keys off `html.js` / `html:not(.js)`:
  - Without JS, the mobile nav is shown inline (no collapsible behavior)
    and the menu-toggle button (which would do nothing) is hidden. All
    three feature panels render in normal document flow instead of only
    one. Prices show their default (monthly) values in plain HTML.
  - With JS, the mobile nav collapses behind the toggle, and the feature
    panels behave as a real single-visible-panel tab interface.
  - The four FAQ entries use native `<details>/<summary>`, which need no
    JavaScript at all.
- **Tabs**: implemented with `role="tablist"`/`role="tab"`/`role="tabpanel"`,
  `aria-selected`, roving `tabindex`, and Arrow/Home/End key support, per
  the WAI-ARIA tabs pattern.
- **Billing toggle**: a two-button group (not a checkbox) so the current
  period is explicit via `aria-pressed` and visible label text ("/ month"
  vs "/ year"), rather than relying on an ambiguous single toggle icon.
- **Focus visibility**: a single consistent `:focus-visible` outline
  (amber, 3px, offset) is applied to every interactive element instead of
  relying on default browser outlines, which vary in visibility on the
  paper background.
- **No invented business claims**: no customer names, reviews, ratings, or
  adoption/performance figures anywhere in the copy. A fictional-product
  disclaimer banner is shown at the very top of the page and repeated in
  the footer.

## Checks actually executed

Using headless Chrome via Playwright (`chromium.launch` pointed at the
local Chrome binary) against the page served over
`python3 -m http.server`, including a nested path
(`/work/index.html`) to confirm relative asset URLs resolve correctly. I
wrote and ran a throwaway verification script (not committed — the
deliverable is only the three source files plus this README) that
checked, all passing:

- `data-testid="menu-toggle"` starts with `aria-expanded="false"` and
  `data-testid="mobile-nav"` hidden at 360px width; clicking opens it and
  flips `aria-expanded` to `true`; `Escape` closes it and returns focus to
  the toggle button; clicking a nav link inside it closes the menu and
  navigates to the target section (`#features`).
- Feature tabs: `feature-capture` selected by default with
  `panel-capture` the only visible panel; `ArrowRight` from the capture
  tab moves selection and visibility to `feature-connect`/`panel-connect`;
  clicking `feature-export` shows `panel-export`; each panel's text
  content is distinct.
- Billing toggle: default monthly prices read `$12` / `$29`; clicking
  `billing-yearly` updates them to `$108` / `$264`; clicking
  `billing-monthly` again restores exactly `$12` / `$29`.
- All four FAQ `<summary>` elements (`faq-0`…`faq-3`) are visible, start
  closed, and open on click.
- The "Explore the workflow" primary CTA navigates to `#workflow`.
- With JavaScript disabled (a fresh browser context with
  `javaScriptEnabled: false`): the menu-toggle button is hidden, the
  mobile nav links are visible and reachable directly, the default
  ($12) price is present in plain HTML, and the Connect/Export panel
  content is present and visible (not tab-hidden) — confirming the page
  stays useful without JS.
- Desktop nav is visible at 1440px and hidden at 360px (and vice versa
  for the mobile toggle); no horizontal scroll overflow at either 360px
  or 1440px viewport width.
- Visual review via full-page screenshots at 1440px and 360px (hero,
  feature tabs, pricing, FAQ) to sanity-check hierarchy, spacing, and
  contrast.

I did not run an automated axe/contrast-ratio audit or a screen-reader
pass — those are the main gaps below.

## Known limitations

- No automated accessibility audit tool (e.g. axe-core) was run; ARIA
  roles and focus behavior were checked manually and via the interaction
  tests above, but contrast ratios and screen-reader announcement
  wording have not been independently verified with assistive tech.
- Only Chromium was tested; Firefox/Safari-specific rendering was not
  checked.
- The hero illustration is a static SVG mock, not a functioning demo of
  the product.
- No automated test suite ships with the deliverable (per the brief's
  no-build/no-library constraint) — the verification script used during
  development was a throwaway and was not retained.
