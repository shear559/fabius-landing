(function () {
  "use strict";

  /* ---------- Mobile navigation ---------- */
  var menuToggle = document.querySelector('[data-testid="menu-toggle"]');
  var mobileNav = document.querySelector('[data-testid="mobile-nav"]');

  function openMobileNav() {
    mobileNav.classList.add("is-open");
    menuToggle.setAttribute("aria-expanded", "true");
  }

  function closeMobileNav(returnFocus) {
    mobileNav.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    if (returnFocus) {
      menuToggle.focus();
    }
  }

  if (menuToggle && mobileNav) {
    menuToggle.addEventListener("click", function () {
      var isOpen = mobileNav.classList.contains("is-open");
      if (isOpen) {
        closeMobileNav(false);
      } else {
        openMobileNav();
      }
    });

    mobileNav.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        closeMobileNav(true);
      }
    });

    mobileNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        closeMobileNav(false);
      });
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && mobileNav.classList.contains("is-open")) {
        closeMobileNav(true);
      }
    });
  }

  /* ---------- Feature tabs ---------- */
  var tabs = Array.prototype.slice.call(document.querySelectorAll('[role="tab"]'));

  function selectTab(tab, moveFocus) {
    tabs.forEach(function (t) {
      var selected = t === tab;
      t.setAttribute("aria-selected", selected ? "true" : "false");
      t.tabIndex = selected ? 0 : -1;
      var panel = document.getElementById(t.getAttribute("aria-controls"));
      if (panel) {
        panel.classList.toggle("is-active", selected);
      }
    });
    if (moveFocus) {
      tab.focus();
    }
  }

  tabs.forEach(function (tab, index) {
    tab.addEventListener("click", function () {
      selectTab(tab, false);
    });

    tab.addEventListener("keydown", function (event) {
      var newIndex = null;
      if (event.key === "ArrowRight" || event.key === "ArrowDown") {
        newIndex = (index + 1) % tabs.length;
      } else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
        newIndex = (index - 1 + tabs.length) % tabs.length;
      } else if (event.key === "Home") {
        newIndex = 0;
      } else if (event.key === "End") {
        newIndex = tabs.length - 1;
      }
      if (newIndex !== null) {
        event.preventDefault();
        selectTab(tabs[newIndex], true);
      }
    });
  });

  /* ---------- Billing toggle ---------- */
  var monthlyBtn = document.querySelector('[data-testid="billing-monthly"]');
  var yearlyBtn = document.querySelector('[data-testid="billing-yearly"]');
  var priceSolo = document.querySelector('[data-testid="price-solo"]');
  var priceStudio = document.querySelector('[data-testid="price-studio"]');
  var periodLabels = document.querySelectorAll("[data-price-period-for]");

  var PRICES = {
    monthly: { solo: "$12", studio: "$29", period: "/ month" },
    yearly: { solo: "$108", studio: "$264", period: "/ year" }
  };

  function setBilling(period) {
    var data = PRICES[period];
    priceSolo.textContent = data.solo;
    priceStudio.textContent = data.studio;
    periodLabels.forEach(function (el) {
      el.textContent = data.period;
    });
    monthlyBtn.classList.toggle("is-active", period === "monthly");
    monthlyBtn.setAttribute("aria-pressed", period === "monthly" ? "true" : "false");
    yearlyBtn.classList.toggle("is-active", period === "yearly");
    yearlyBtn.setAttribute("aria-pressed", period === "yearly" ? "true" : "false");
  }

  if (monthlyBtn && yearlyBtn) {
    monthlyBtn.addEventListener("click", function () {
      setBilling("monthly");
    });
    yearlyBtn.addEventListener("click", function () {
      setBilling("yearly");
    });
  }
})();
