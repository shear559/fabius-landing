# Fieldnote Board

A local-first task board for a small project team. Fictional demo data only. No backend, no network calls, no build step, no dependencies.

## Running it

Serve the three files (`index.html`, `styles.css`, `app.js`) from any static file server, at the root or any nested path — all asset references are relative.

```
python3 -m http.server 8000
# then open http://127.0.0.1:8000/index.html
```

Opening `index.html` directly via `file://` also works in most browsers, since there is no fetch/XHR involved. All I/O is `localStorage` and the File API.

## Data model

Stored under `localStorage["fieldnote-board:v1"]` as `{schemaVersion: 1, tasks: [...]}`. Each task has exactly: `id`, `title`, `project`, `status` (`todo`/`doing`/`done`), `priority` (`low`/`medium`/`high`), `dueDate` (`""` or `YYYY-MM-DD`), `tags` (array, ≤8 entries, each ≤24 chars). On genuinely empty storage (key absent) the app seeds 8 sample tasks across 2 fictional projects covering all 3 statuses, then writes them. Existing data — valid or not — is never overwritten by the seed.

Tag input is comma-separated free text; entries are trimmed, empty entries dropped, and duplicates collapsed case-insensitively (first-seen casing wins). Tags over 24 characters, or more than 8 unique tags, are rejected with a visible form error rather than silently truncated, since that would quietly discard user input.

## Error handling & recovery design

- **Corrupt storage on startup**: if the stored value fails to `JSON.parse` or fails schema/enum/date validation, the app does **not** touch storage. It shows a recovery banner offering (a) a download of the exact original bytes as a `.json` file, and (b) an explicit, confirmed reset that seeds a fresh board only after the user agrees. The corrupt bytes stay in `localStorage` untouched until the user acts.
- **Write failures**: every `localStorage.setItem` call is wrapped in try/catch. On failure, no in-memory state is advanced to "saved" — a banner or toast says the change was not saved, and (for the task form) the entered values stay in the open form instead of being discarded, so nothing is lost silently.
- **Cross-tab conflicts**: a `storage` event listener detects when another tab/window writes the same key. It shows a persistent banner and blocks status/edit/delete/save actions (they show a message instead of writing) until the user clicks "Reload board," which re-reads storage and clears the block. This favors losing a redundant click over silently clobbering another tab's newer write.
- **Import**: validated fully before anything is written — schema version, size (≤1 MiB, checked both via `File.size` and decoded text length), JSON well-formedness, per-task field/enum/date validation, and duplicate-ID detection within the file. Any single invalid task rejects the whole import with a specific error and the prior board is provably untouched (verified in testing by diffing storage before/after a rejected import). A valid import still requires an explicit `confirm()` before replacing the board.
- **Delete/undo**: delete persists immediately (so it survives a reload on its own), and a toast offers "Undo" for ~8 seconds, which restores the exact record at its original position and persists that restoration.

## Accessibility & interaction

- All controls are real `<button>`/`<select>`/`<input>` elements with labels or `aria-label`s (per-task status selects and edit/delete buttons are labelled with the task title).
- The task form is a modal dialog (`role="dialog"`, `aria-modal`): opening moves focus into the first field, `Escape` closes it and returns focus to whatever opened it (the "New task" button or a card's "Edit" button), and `Tab`/`Shift+Tab` are trapped inside the dialog while open.
- Field errors are in `aria-live` regions tied to their inputs via `aria-describedby`, with `aria-invalid` set on failing fields.
- `@media (prefers-reduced-motion: reduce)` collapses all transition/animation durations to near-zero.
- A `<noscript>` block explains the app needs JavaScript when it's disabled (the main `#app` container stays `hidden` until script runs, so nothing broken is shown either way).
- Imported/typed text is only ever set via `textContent`, never `innerHTML`, so titles/tags/projects containing HTML/script-like text render as inert text.

## Checks actually executed

Verified with a scripted Playwright run against a local static server (mobile 360×800 and desktop 1440×900 viewports), covering: seed generation (8 tasks / 2 projects / 3 statuses) on empty storage; blank-title validation; task creation with tag dedupe and HTML-safe rendering; edit-preserves-other-records; status change persistence; delete → undo → reload persistence; search and each filter (including the no-results state and the "all" sentinel option); export producing a schema-valid JSON file containing filtered-out records; import rejecting malformed JSON, duplicate IDs, and invalid enums while leaving the prior board byte-for-byte untouched; a valid confirmed import replacing the board and surviving reload; corrupt-storage detection preserving the original bytes and offering download + confirmed reset; a second tab's write triggering the conflict banner; Escape closing the modal and restoring focus; and `prefers-reduced-motion` shortening transitions. Also confirmed the app renders correctly when served from a nested URL path (relative asset references only). This was self-directed verification, not an independent audit.

## Known limitations

- Reconciliation on a cross-tab conflict is reload-based, not merge-based: the app blocks further writes and asks the user to reload rather than attempting a three-way merge. This is the safer choice for a local demo but means concurrent edits in two tabs are not automatically combined.
- The undo toast is in-memory only; if the page is reloaded before clicking "Undo," the deletion (already persisted) stands — there's no persisted "trash."
- No automated test suite ships in this directory (no dependency installation is allowed); verification was performed with an ad hoc Playwright script run against the app during development, not included here.
