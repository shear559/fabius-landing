(function () {
  "use strict";

  var STORAGE_KEY = "fieldnote-board:v1";
  var MAX_IMPORT_BYTES = 1024 * 1024; // 1 MiB
  var STATUSES = ["todo", "doing", "done"];
  var PRIORITIES = ["low", "medium", "high"];

  // ---- In-memory application state -----------------------------------
  var state = {
    tasks: [],          // last-known-good, persisted board
    corruptRaw: null,   // raw string if storage failed validation on load
    staleConflict: false,
    filters: { search: "", status: "all", project: "all", priority: "all" },
    editingId: null,
    lastFocused: null,
    pendingDelete: null, // { task, index }
    saveBlocked: false
  };

  var undoTimer = null;

  // ---- DOM references ---------------------------------------------------
  var el = {};

  function cacheDom() {
    el.app = document.getElementById("app");
    el.banners = document.getElementById("banners");
    el.createBtn = document.getElementById("create-task-btn");
    el.exportBtn = document.getElementById("export-btn");
    el.importInput = document.getElementById("import-file");
    el.search = document.getElementById("search");
    el.filterStatus = document.getElementById("filter-status");
    el.filterProject = document.getElementById("filter-project");
    el.filterPriority = document.getElementById("filter-priority");
    el.taskCount = document.getElementById("task-count");
    el.taskList = document.getElementById("task-list");
    el.emptyState = document.getElementById("empty-state");
    el.toast = document.getElementById("toast");
    el.toastMessage = document.getElementById("toast-message");
    el.undoBtn = document.getElementById("undo-delete-btn");
    el.toastDismiss = document.getElementById("toast-dismiss");
    el.modalBackdrop = document.getElementById("modal-backdrop");
    el.modal = document.getElementById("task-modal");
    el.modalTitle = document.getElementById("task-form-title");
    el.modalCloseBtn = document.getElementById("modal-close-btn");
    el.form = document.getElementById("task-form");
    el.cancelBtn = document.getElementById("cancel-task-btn");
    el.fTitle = document.getElementById("title");
    el.fProject = document.getElementById("project");
    el.fStatus = document.getElementById("status");
    el.fPriority = document.getElementById("priority");
    el.fDueDate = document.getElementById("dueDate");
    el.fTags = document.getElementById("tags");
    el.errTitle = document.getElementById("title-error");
    el.errProject = document.getElementById("project-error");
    el.errDueDate = document.getElementById("dueDate-error");
    el.errTags = document.getElementById("tags-error");
    el.errForm = document.getElementById("form-error");
  }

  // ---- Utilities ---------------------------------------------------------

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function generateId(existingIds) {
    var id;
    do {
      id = "t-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
    } while (existingIds.indexOf(id) !== -1);
    return id;
  }

  function isValidDateString(str) {
    if (str === "" || str == null) return true;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
    var parts = str.split("-").map(Number);
    var y = parts[0], m = parts[1], d = parts[2];
    var date = new Date(Date.UTC(y, m - 1, d));
    return date.getUTCFullYear() === y && date.getUTCMonth() === m - 1 && date.getUTCDate() === d;
  }

  function parseTagsInput(raw) {
    if (!raw) return { tags: [], error: null };
    var parts = raw.split(",").map(function (t) { return t.trim(); }).filter(function (t) { return t.length > 0; });
    var seen = {};
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      var t = parts[i];
      if (t.length > 24) return { tags: null, error: "Each tag must be 24 characters or fewer (\"" + t + "\" is too long)." };
      var key = t.toLowerCase();
      if (!seen[key]) { seen[key] = true; out.push(t); }
    }
    if (out.length > 8) return { tags: null, error: "A task may have at most 8 tags (" + out.length + " provided)." };
    return { tags: out, error: null };
  }

  function formatDate(str) {
    if (!str) return "No due date";
    return "Due " + str;
  }

  // ---- Validation for storage/import documents ---------------------------

  function validateTaskShape(t, existingIdSet) {
    var errs = [];
    if (typeof t !== "object" || t === null) return ["Task is not an object."];
    if (typeof t.id !== "string" || t.id.trim() === "" || t.id.length > 80) errs.push("invalid id");
    else if (existingIdSet[t.id]) errs.push("duplicate id \"" + t.id + "\"");
    if (typeof t.title !== "string" || t.title.trim() === "" || t.title.length > 120) errs.push("invalid title");
    if (typeof t.project !== "string" || t.project.trim() === "" || t.project.length > 80) errs.push("invalid project");
    if (STATUSES.indexOf(t.status) === -1) errs.push("invalid status \"" + t.status + "\"");
    if (PRIORITIES.indexOf(t.priority) === -1) errs.push("invalid priority \"" + t.priority + "\"");
    if (typeof t.dueDate !== "string" || !isValidDateString(t.dueDate)) errs.push("invalid dueDate");
    if (!Array.isArray(t.tags) || t.tags.length > 8) errs.push("invalid tags");
    else {
      for (var i = 0; i < t.tags.length; i++) {
        var tag = t.tags[i];
        if (typeof tag !== "string" || tag.trim() === "" || tag !== tag.trim() || tag.length > 24) {
          errs.push("invalid tag at index " + i);
          break;
        }
      }
    }
    return errs;
  }

  function validateBoardDocument(doc) {
    if (typeof doc !== "object" || doc === null) return { ok: false, error: "Document is not a JSON object." };
    if (doc.schemaVersion !== 1) return { ok: false, error: "Unsupported schemaVersion (expected 1)." };
    if (!Array.isArray(doc.tasks)) return { ok: false, error: "\"tasks\" must be an array." };
    var idSet = {};
    for (var i = 0; i < doc.tasks.length; i++) {
      var errs = validateTaskShape(doc.tasks[i], idSet);
      if (errs.length) return { ok: false, error: "Task #" + (i + 1) + ": " + errs.join(", ") + "." };
      idSet[doc.tasks[i].id] = true;
    }
    return { ok: true, tasks: doc.tasks };
  }

  // ---- Seed data -----------------------------------------------------------

  function seedTasks() {
    var today = new Date();
    function iso(offsetDays) {
      var d = new Date(today.getTime() + offsetDays * 86400000);
      return d.toISOString().slice(0, 10);
    }
    var raw = [
      { title: "Draft trailhead survey questions", project: "Riverbend Trail Restoration", status: "todo", priority: "high", dueDate: iso(2), tags: ["survey", "fieldwork"] },
      { title: "Order replacement waders", project: "Riverbend Trail Restoration", status: "todo", priority: "medium", dueDate: "", tags: ["gear"] },
      { title: "Calibrate soil moisture sensors", project: "Riverbend Trail Restoration", status: "doing", priority: "high", dueDate: iso(1), tags: ["equipment", "sensors"] },
      { title: "Log Q3 rainfall totals", project: "Riverbend Trail Restoration", status: "done", priority: "low", dueDate: iso(-5), tags: ["data"] },
      { title: "Interview volunteer coordinators", project: "Coastal Bird Census", status: "todo", priority: "medium", dueDate: iso(7), tags: ["interviews", "volunteers"] },
      { title: "Tag shorebird nesting sites on map", project: "Coastal Bird Census", status: "doing", priority: "high", dueDate: iso(3), tags: ["mapping", "fieldwork"] },
      { title: "Reconcile May headcount spreadsheet", project: "Coastal Bird Census", status: "done", priority: "medium", dueDate: iso(-10), tags: ["data", "reporting"] },
      { title: "Print updated site safety signage", project: "Coastal Bird Census", status: "todo", priority: "low", dueDate: "", tags: ["safety"] }
    ];
    var idSet = {};
    var tasks = raw.map(function (r) {
      var id = generateId(Object.keys(idSet));
      idSet[id] = true;
      return {
        id: id, title: r.title, project: r.project, status: r.status,
        priority: r.priority, dueDate: r.dueDate, tags: r.tags
      };
    });
    return tasks;
  }

  // ---- Persistence ---------------------------------------------------------

  function readRaw() {
    return localStorage.getItem(STORAGE_KEY);
  }

  function loadBoard() {
    var raw = readRaw();
    if (raw === null) {
      var tasks = seedTasks();
      var ok = writeBoard(tasks);
      state.tasks = tasks;
      state.corruptRaw = null;
      if (!ok) {
        // Extremely unlikely on first run, but keep seed usable in memory.
        showBanner("save-fail", "banner-danger", "Could not write the initial board to storage. Your data will not persist between reloads.", []);
      }
      return;
    }
    var parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      state.corruptRaw = raw;
      state.tasks = [];
      return;
    }
    var result = validateBoardDocument(parsed);
    if (!result.ok) {
      state.corruptRaw = raw;
      state.tasks = [];
      return;
    }
    state.corruptRaw = null;
    state.tasks = result.tasks;
  }

  function writeBoard(tasks) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, tasks: tasks }));
      return true;
    } catch (e) {
      return false;
    }
  }

  function persist(tasks) {
    var success = writeBoard(tasks);
    if (success) {
      state.tasks = tasks;
      clearBanner("save-fail");
    } else {
      showBanner("save-fail", "banner-danger", "This change could not be saved to storage (it may be full or unavailable). Your edit was not persisted — keep this window open to avoid losing it.", []);
    }
    return success;
  }

  // ---- Banners ---------------------------------------------------------

  function showBanner(id, cls, message, actions) {
    var existing = document.getElementById("banner-" + id);
    if (existing) existing.remove();
    var div = document.createElement("div");
    div.id = "banner-" + id;
    div.className = "banner " + cls;
    div.setAttribute("role", "alert");
    var span = document.createElement("span");
    span.textContent = message;
    div.appendChild(span);
    if (actions && actions.length) {
      var actionsWrap = document.createElement("div");
      actionsWrap.className = "banner-actions";
      actions.forEach(function (a) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "btn btn-small " + (a.className || "btn-secondary");
        btn.textContent = a.label;
        btn.addEventListener("click", a.onClick);
        actionsWrap.appendChild(btn);
      });
      div.appendChild(actionsWrap);
    }
    el.banners.appendChild(div);
  }

  function clearBanner(id) {
    var existing = document.getElementById("banner-" + id);
    if (existing) existing.remove();
  }

  function renderCorruptBanner() {
    clearBanner("corrupt");
    if (!state.corruptRaw) return;
    showBanner("corrupt", "banner-danger",
      "Saved board data could not be read (it looks corrupted or is from an unsupported format). Your original data has been left untouched on disk.",
      [
        {
          label: "Download original data", className: "btn-secondary", onClick: function () {
            downloadText("fieldnote-board-corrupt-backup.json", state.corruptRaw);
          }
        },
        {
          label: "Reset board", className: "btn-danger", onClick: function () {
            if (window.confirm("Reset will replace the unreadable data with a fresh sample board. This cannot be undone. Continue?")) {
              var tasks = seedTasks();
              persist(tasks);
              state.corruptRaw = null;
              clearBanner("corrupt");
              refreshProjectFilterOptions();
              render();
            }
          }
        }
      ]
    );
  }

  function renderConflictBanner() {
    clearBanner("conflict");
    if (!state.staleConflict) return;
    showBanner("conflict", "banner-warn",
      "This board was changed in another tab or window. Reload to see the latest version before making more edits.",
      [
        {
          label: "Reload board", className: "btn-primary", onClick: function () {
            loadBoard();
            state.staleConflict = false;
            clearBanner("conflict");
            renderCorruptBanner();
            refreshProjectFilterOptions();
            render();
          }
        }
      ]
    );
  }

  function downloadText(filename, text) {
    var blob = new Blob([text], { type: "application/json" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  // ---- Toast / undo ---------------------------------------------------------

  function showToast(message, showUndo) {
    el.toastMessage.textContent = message;
    el.undoBtn.hidden = !showUndo;
    el.toast.hidden = false;
    if (undoTimer) clearTimeout(undoTimer);
    undoTimer = setTimeout(hideToast, 8000);
  }

  function hideToast() {
    el.toast.hidden = true;
    el.undoBtn.hidden = true;
    if (undoTimer) { clearTimeout(undoTimer); undoTimer = null; }
    if (!el.undoBtn.hidden) state.pendingDelete = null;
  }

  // ---- Filtering / rendering ---------------------------------------------------------

  function refreshProjectFilterOptions() {
    var projects = [];
    var seen = {};
    state.tasks.forEach(function (t) {
      if (!seen[t.project]) { seen[t.project] = true; projects.push(t.project); }
    });
    projects.sort(function (a, b) { return a.localeCompare(b); });
    var current = el.filterProject.value;
    el.filterProject.innerHTML = "";
    var allOpt = document.createElement("option");
    allOpt.value = "all";
    allOpt.textContent = "All projects";
    el.filterProject.appendChild(allOpt);
    projects.forEach(function (p) {
      var opt = document.createElement("option");
      opt.value = p;
      opt.textContent = p;
      el.filterProject.appendChild(opt);
    });
    if (projects.indexOf(current) !== -1 || current === "all") {
      el.filterProject.value = current;
    } else {
      el.filterProject.value = "all";
      state.filters.project = "all";
    }
  }

  function getFilteredTasks() {
    var f = state.filters;
    var q = f.search.trim().toLowerCase();
    return state.tasks.filter(function (t) {
      if (f.status !== "all" && t.status !== f.status) return false;
      if (f.project !== "all" && t.project !== f.project) return false;
      if (f.priority !== "all" && t.priority !== f.priority) return false;
      if (q) {
        var haystack = (t.title + " " + t.project + " " + t.tags.join(" ")).toLowerCase();
        if (haystack.indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function statusLabel(s) { return { todo: "To do", doing: "Doing", done: "Done" }[s] || s; }
  function priorityLabel(p) { return { low: "Low", medium: "Medium", high: "High" }[p] || p; }

  function buildCard(task) {
    var card = document.createElement("article");
    card.className = "task-card";
    card.setAttribute("data-testid", "task-card");
    card.setAttribute("data-task-id", task.id);

    var top = document.createElement("div");
    top.className = "task-card-top";

    var titleWrap = document.createElement("div");
    var h3 = document.createElement("h3");
    h3.textContent = task.title;
    var proj = document.createElement("div");
    proj.className = "task-project";
    proj.textContent = task.project;
    titleWrap.appendChild(h3);
    titleWrap.appendChild(proj);

    var badge = document.createElement("span");
    badge.className = "priority-badge priority-" + task.priority;
    badge.textContent = priorityLabel(task.priority);

    top.appendChild(titleWrap);
    top.appendChild(badge);
    card.appendChild(top);

    var meta = document.createElement("div");
    meta.className = "task-meta";
    var due = document.createElement("span");
    due.textContent = formatDate(task.dueDate);
    meta.appendChild(due);
    card.appendChild(meta);

    if (task.tags.length) {
      var ul = document.createElement("ul");
      ul.className = "task-tags";
      task.tags.forEach(function (tag) {
        var li = document.createElement("li");
        li.className = "task-tag";
        li.textContent = tag;
        ul.appendChild(li);
      });
      card.appendChild(ul);
    }

    var actions = document.createElement("div");
    actions.className = "task-card-actions";

    var statusLabelEl = document.createElement("label");
    statusLabelEl.className = "visually-hidden-input";
    statusLabelEl.htmlFor = "status-select-" + task.id;
    statusLabelEl.textContent = "Status for " + task.title;

    var select = document.createElement("select");
    select.id = "status-select-" + task.id;
    select.className = "status-select";
    select.setAttribute("data-action", "status");
    select.setAttribute("aria-label", "Status for " + task.title);
    STATUSES.forEach(function (s) {
      var opt = document.createElement("option");
      opt.value = s;
      opt.textContent = statusLabel(s);
      if (s === task.status) opt.selected = true;
      select.appendChild(opt);
    });

    var buttons = document.createElement("div");
    buttons.className = "task-card-buttons";

    var editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "btn btn-small btn-secondary";
    editBtn.setAttribute("data-action", "edit");
    editBtn.setAttribute("aria-label", "Edit " + task.title);
    editBtn.textContent = "Edit";

    var deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "btn btn-small btn-danger";
    deleteBtn.setAttribute("data-action", "delete");
    deleteBtn.setAttribute("aria-label", "Delete " + task.title);
    deleteBtn.textContent = "Delete";

    buttons.appendChild(editBtn);
    buttons.appendChild(deleteBtn);

    actions.appendChild(select);
    actions.appendChild(buttons);
    card.appendChild(actions);

    return card;
  }

  function render() {
    var filtered = getFilteredTasks();
    el.taskList.innerHTML = "";

    if (state.tasks.length === 0) {
      el.taskList.hidden = true;
      el.emptyState.hidden = false;
      el.emptyState.innerHTML = "";
      var p = document.createElement("p");
      p.textContent = "No tasks yet. Create your first task to get started.";
      el.emptyState.appendChild(p);
    } else if (filtered.length === 0) {
      el.taskList.hidden = true;
      el.emptyState.hidden = false;
      el.emptyState.innerHTML = "";
      var p2 = document.createElement("p");
      p2.textContent = "No tasks match your search or filters. Try clearing a filter.";
      el.emptyState.appendChild(p2);
    } else {
      el.taskList.hidden = false;
      el.emptyState.hidden = true;
      filtered.forEach(function (t) {
        el.taskList.appendChild(buildCard(t));
      });
    }

    el.taskCount.textContent = "Showing " + filtered.length + " of " + state.tasks.length + " task" + (state.tasks.length === 1 ? "" : "s");
  }

  // ---- Form / modal ---------------------------------------------------------

  function clearFormErrors() {
    el.errTitle.textContent = "";
    el.errProject.textContent = "";
    el.errDueDate.textContent = "";
    el.errTags.textContent = "";
    el.errForm.textContent = "";
    [el.fTitle, el.fProject, el.fDueDate, el.fTags].forEach(function (f) { f.removeAttribute("aria-invalid"); });
  }

  function openForm(task, trigger) {
    state.lastFocused = trigger || document.activeElement;
    clearFormErrors();
    el.form.reset();
    if (task) {
      state.editingId = task.id;
      el.modalTitle.textContent = "Edit task";
      el.fTitle.value = task.title;
      el.fProject.value = task.project;
      el.fStatus.value = task.status;
      el.fPriority.value = task.priority;
      el.fDueDate.value = task.dueDate;
      el.fTags.value = task.tags.join(", ");
    } else {
      state.editingId = null;
      el.modalTitle.textContent = "New task";
      el.fPriority.value = "medium";
      el.fStatus.value = "todo";
    }
    el.modalBackdrop.hidden = false;
    el.fTitle.focus();
    document.addEventListener("keydown", onModalKeydown, true);
  }

  function closeForm() {
    el.modalBackdrop.hidden = true;
    document.removeEventListener("keydown", onModalKeydown, true);
    state.editingId = null;
    if (state.lastFocused && typeof state.lastFocused.focus === "function") {
      state.lastFocused.focus();
    }
  }

  function onModalKeydown(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      closeForm();
      return;
    }
    if (e.key === "Tab") {
      var focusables = el.modal.querySelectorAll("input, select, button, textarea, [tabindex]:not([tabindex='-1'])");
      if (!focusables.length) return;
      var first = focusables[0];
      var last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  }

  function handleFormSubmit(e) {
    e.preventDefault();
    clearFormErrors();

    if (state.staleConflict) {
      el.errForm.textContent = "This board changed in another tab. Reload the board before saving.";
      return;
    }

    var title = el.fTitle.value.trim();
    var project = el.fProject.value.trim();
    var status = el.fStatus.value;
    var priority = el.fPriority.value;
    var dueDate = el.fDueDate.value.trim();
    var tagsRaw = el.fTags.value;

    var hasError = false;
    if (!title) { el.errTitle.textContent = "Title is required."; el.fTitle.setAttribute("aria-invalid", "true"); hasError = true; }
    else if (title.length > 120) { el.errTitle.textContent = "Title must be 120 characters or fewer."; el.fTitle.setAttribute("aria-invalid", "true"); hasError = true; }

    if (!project) { el.errProject.textContent = "Project is required."; el.fProject.setAttribute("aria-invalid", "true"); hasError = true; }
    else if (project.length > 80) { el.errProject.textContent = "Project must be 80 characters or fewer."; el.fProject.setAttribute("aria-invalid", "true"); hasError = true; }

    if (dueDate && !isValidDateString(dueDate)) {
      el.errDueDate.textContent = "Enter a real calendar date (YYYY-MM-DD).";
      el.fDueDate.setAttribute("aria-invalid", "true");
      hasError = true;
    }

    var tagsResult = parseTagsInput(tagsRaw);
    if (tagsResult.error) {
      el.errTags.textContent = tagsResult.error;
      el.fTags.setAttribute("aria-invalid", "true");
      hasError = true;
    }

    if (hasError) return;

    var nextTasks;
    if (state.editingId) {
      nextTasks = state.tasks.map(function (t) {
        if (t.id !== state.editingId) return t;
        return { id: t.id, title: title, project: project, status: status, priority: priority, dueDate: dueDate, tags: tagsResult.tags };
      });
    } else {
      var id = generateId(state.tasks.map(function (t) { return t.id; }));
      var newTask = { id: id, title: title, project: project, status: status, priority: priority, dueDate: dueDate, tags: tagsResult.tags };
      nextTasks = state.tasks.concat([newTask]);
    }

    var ok = persist(nextTasks);
    if (!ok) {
      el.errForm.textContent = "This task could not be saved to storage. Your entries are still in the form — try again or copy them elsewhere.";
      return;
    }
    refreshProjectFilterOptions();
    render();
    closeForm();
    showToast(state.editingId ? "Task updated." : "Task created.", false);
  }

  // ---- Delete / undo ---------------------------------------------------------

  function handleDelete(taskId) {
    if (state.staleConflict) {
      showToast("Board changed in another tab. Reload before deleting.", false);
      return;
    }
    var index = state.tasks.findIndex(function (t) { return t.id === taskId; });
    if (index === -1) return;
    var task = state.tasks[index];
    var nextTasks = state.tasks.slice(0, index).concat(state.tasks.slice(index + 1));
    var ok = persist(nextTasks);
    if (!ok) {
      showToast("Delete could not be saved to storage.", false);
      return;
    }
    state.pendingDelete = { task: task, index: index };
    refreshProjectFilterOptions();
    render();
    showToast("Deleted \"" + task.title + "\".", true);
  }

  function handleUndo() {
    if (!state.pendingDelete) return;
    if (state.staleConflict) {
      showToast("Board changed in another tab. Reload before restoring.", false);
      return;
    }
    var task = state.pendingDelete.task;
    var index = Math.min(state.pendingDelete.index, state.tasks.length);
    var nextTasks = state.tasks.slice(0, index).concat([task], state.tasks.slice(index));
    var ok = persist(nextTasks);
    state.pendingDelete = null;
    hideToast();
    if (!ok) {
      showToast("Restore could not be saved to storage.", false);
      return;
    }
    refreshProjectFilterOptions();
    render();
    showToast("Task restored.", false);
  }

  // ---- Status change ---------------------------------------------------------

  function handleStatusChange(taskId, newStatus) {
    if (state.staleConflict) {
      showToast("Board changed in another tab. Reload before making changes.", false);
      render(); // revert visual select back to persisted value
      return;
    }
    if (STATUSES.indexOf(newStatus) === -1) return;
    var nextTasks = state.tasks.map(function (t) {
      if (t.id !== taskId) return t;
      return Object.assign({}, t, { status: newStatus });
    });
    var ok = persist(nextTasks);
    if (!ok) {
      showToast("Status change could not be saved to storage.", false);
      render();
      return;
    }
    render();
  }

  // ---- Export / import ---------------------------------------------------------

  function handleExport() {
    var doc = { schemaVersion: 1, tasks: state.tasks };
    downloadText("fieldnote-board-export.json", JSON.stringify(doc, null, 2));
  }

  function handleImportFile(file) {
    if (!file) return;
    if (file.size > MAX_IMPORT_BYTES) {
      showToast("Import failed: file exceeds the 1 MiB limit.", false);
      el.importInput.value = "";
      return;
    }
    var reader = new FileReader();
    reader.onload = function () {
      var text = String(reader.result);
      if (text.length > MAX_IMPORT_BYTES) {
        showToast("Import failed: file exceeds the 1 MiB limit.", false);
        el.importInput.value = "";
        return;
      }
      var parsed;
      try {
        parsed = JSON.parse(text);
      } catch (e) {
        showToast("Import failed: the file is not valid JSON.", false);
        el.importInput.value = "";
        return;
      }
      var result = validateBoardDocument(parsed);
      if (!result.ok) {
        showToast("Import failed: " + result.error, false);
        el.importInput.value = "";
        return;
      }
      var count = result.tasks.length;
      var confirmed = window.confirm(
        "Import " + count + " task" + (count === 1 ? "" : "s") + " and replace the current board of " +
        state.tasks.length + " task" + (state.tasks.length === 1 ? "" : "s") + "? This cannot be undone."
      );
      el.importInput.value = "";
      if (!confirmed) return;
      var ok = persist(result.tasks);
      if (!ok) {
        showToast("Import could not be saved to storage.", false);
        return;
      }
      state.corruptRaw = null;
      clearBanner("corrupt");
      state.pendingDelete = null;
      refreshProjectFilterOptions();
      render();
      showToast("Board replaced with " + count + " imported task" + (count === 1 ? "" : "s") + ".", false);
    };
    reader.onerror = function () {
      showToast("Import failed: could not read the file.", false);
      el.importInput.value = "";
    };
    reader.readAsText(file);
  }

  // ---- Cross-tab sync ---------------------------------------------------------

  function onStorageEvent(e) {
    if (e.key !== STORAGE_KEY) return;
    state.staleConflict = true;
    renderConflictBanner();
  }

  // ---- Event wiring ---------------------------------------------------------

  function wireEvents() {
    el.createBtn.addEventListener("click", function () { openForm(null, el.createBtn); });
    el.modalCloseBtn.addEventListener("click", closeForm);
    el.cancelBtn.addEventListener("click", closeForm);
    el.modalBackdrop.addEventListener("mousedown", function (e) {
      if (e.target === el.modalBackdrop) closeForm();
    });
    el.form.addEventListener("submit", handleFormSubmit);

    el.exportBtn.addEventListener("click", handleExport);
    el.importInput.addEventListener("change", function () {
      handleImportFile(el.importInput.files[0]);
    });

    el.search.addEventListener("input", function () {
      state.filters.search = el.search.value;
      render();
    });
    el.filterStatus.addEventListener("change", function () {
      state.filters.status = el.filterStatus.value;
      render();
    });
    el.filterProject.addEventListener("change", function () {
      state.filters.project = el.filterProject.value;
      render();
    });
    el.filterPriority.addEventListener("change", function () {
      state.filters.priority = el.filterPriority.value;
      render();
    });

    el.taskList.addEventListener("click", function (e) {
      var target = e.target.closest("[data-action]");
      if (!target) return;
      var card = e.target.closest("[data-task-id]");
      if (!card) return;
      var taskId = card.getAttribute("data-task-id");
      var action = target.getAttribute("data-action");
      if (action === "edit") {
        var task = state.tasks.find(function (t) { return t.id === taskId; });
        if (task) openForm(task, target);
      } else if (action === "delete") {
        handleDelete(taskId);
      }
    });

    el.taskList.addEventListener("change", function (e) {
      var target = e.target.closest("[data-action='status']");
      if (!target) return;
      var card = e.target.closest("[data-task-id]");
      if (!card) return;
      handleStatusChange(card.getAttribute("data-task-id"), target.value);
    });

    el.undoBtn.addEventListener("click", handleUndo);
    el.toastDismiss.addEventListener("click", hideToast);

    window.addEventListener("storage", onStorageEvent);
  }

  // ---- Init ---------------------------------------------------------

  function init() {
    cacheDom();
    wireEvents();
    loadBoard();
    renderCorruptBanner();
    refreshProjectFilterOptions();
    render();
    el.app.hidden = false;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
