# Fieldnote Board

A local-first task board for a small (fictional) field-research team. Pure
vanilla HTML/CSS/JS — no build step, no dependencies, no network calls.

## Running it

Serve the folder with any static file server and open `index.html`, e.g.:

```
python3 -m http.server 8000
```

then visit `http://localhost:8000/`. It also works when the folder is served
from a nested path (e.g. `/some/sub/dir/index.html`) because every asset
reference (`./styles.css`, `./app.js`) is relative. Opening the file directly
via `file://` also works in Chrome.

## Data model

Stored in `localStorage` under key `fieldnote-board:v1` as:

```json
{ "schemaVersion": 1, "tasks": [ { "id": "...", "title": "...", "project": "...",
  "status": "todo|doing|done", "priority": "low|medium|high",
  "dueDate": "YYYY-MM-DD or \"\"", "tags": ["..."] } ] }
```

On genuinely empty storage the app seeds 7 fictional tasks across 2 projects
("Riverbend Survey", "Canopy Watch") covering all three statuses. Existing
data — valid or corrupt — is never overwritten by the seed.

## Error handling & safety design

- **Validation** — every create/edit and every imported task is run through
  the same validator: trimmed non-empty title (≤120)/project (≤80), a real
  enum for status/priority, `""` or a real calendar `YYYY-MM-DD` date, and
  ≤8 tags of ≤24 chars each. Comma-separated tag input is trimmed and
  deduplicated case-insensitively. Failures show inline, visible errors and
  never touch stored data.
- **Corrupt storage** — if the stored value isn't parseable JSON or doesn't
  pass full schema validation, the app leaves the raw bytes untouched, shows
  a recovery banner, and offers "download raw data" and an explicit,
  confirmed "reset board" (which reseeds fresh data only after user
  confirmation).
- **Write failures** — every `localStorage.setItem` is wrapped in try/catch.
  On failure the in-memory/form state is kept (nothing is lost) and a
  visible "Not saved" banner appears instead of silently claiming success.
- **Cross-tab conflicts** — a `storage` event from another tab shows a
  visible conflict banner and blocks destructive actions (create/edit/
  delete/status/undo/import) until the user clicks "Reload board", which
  does a full reload so the freshest data always wins. Own writes are
  suppressed from re-triggering this banner.
- **Import** — validated as a whole document before anything changes
  (schemaVersion, ≤1 MiB size, well-formed JSON, unique ids, valid enums/
  dates/lengths). Any single invalid task rejects the entire import with an
  error message and the prior board is untouched (atomic). A valid import
  requires an explicit `confirm()` before replacing the board, and the
  result is persisted immediately, surviving reload.
- **Delete/undo** — delete removes the exact record from storage immediately
  but keeps it in memory; "Undo delete" reinserts the exact record at its
  original position and re-persists it.
- **XSS** — all task text (including imported/search text) is rendered via
  `textContent`, never `innerHTML`, so it's always treated as plain text.

## Accessibility & UX

- Every control has a real `<label>` or accessible name (icon-free buttons
  use visible text; per-card status selects have a visually-hidden label
  naming the task).
- The task form is a native `<dialog>`: `Escape` closes it and focus returns
  to whichever button opened it (New task / Edit).
- `prefers-reduced-motion: reduce` disables the app's (minimal) transitions.
- A `<noscript>` banner tells users JavaScript is required if it's disabled.
- Layout is a responsive 3-column board (To do / Doing / Done) that stacks
  to a single column on narrow screens; verified at 360px and 1440px.
- Search + all three filters combine (AND) and always show a live
  "N of M tasks shown" count plus a dedicated empty/no-results message.

## Checks actually executed

Using a headless Chrome (Playwright) against the served files, including
from a nested directory path, I verified: seed data on first load; blank/
invalid form submissions rejected with visible errors; create, edit
(re-opens with existing values), status change, delete, and undo
(including persistence of the undo across a reload); tag dedup
(case-insensitive); search filtering and the no-results state; JSON export
producing a valid `schemaVersion: 1` document; corrupt-JSON storage
producing the recovery notice while leaving the raw bytes byte-for-byte
untouched; an invalid import being rejected with the prior board fully
intact; a valid import requiring confirmation, replacing the board, and
surviving reload; and `Escape` closing the task dialog with focus returned
to the triggering button. Desktop (1440px) and mobile (360px) screenshots
were reviewed visually during this pass (not persisted in this folder).

## Known limitations

- Cross-tab reconciliation is reload-based (simplest safe option), not a
  live merge — by design, since a merge could silently discard the other
  tab's intent.
- No automated test suite ships in this folder (per the brief, no build
  step/dependencies); verification was done with an ad hoc local script
  during development and then removed.
- Reduced-motion is honored via `prefers-reduced-motion`; there is no
  in-app toggle since the app has no meaningful animation to begin with.
