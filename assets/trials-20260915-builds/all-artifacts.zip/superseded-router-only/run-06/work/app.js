(function () {
  "use strict";

  var STORAGE_KEY = "fieldnote-board:v1";
  var STATUSES = ["todo", "doing", "done"];
  var PRIORITIES = ["low", "medium", "high"];
  var MAX_IMPORT_BYTES = 1024 * 1024; // 1 MiB

  // ---------- state ----------
  var state = { schemaVersion: 1, tasks: [] };
  var isCorrupt = false;
  var corruptRawText = null;
  var isBlocked = false; // another tab wrote storage; block destructive edits
  var lastDeleted = null; // { task, index }
  var editingId = null;
  var lastFocusedBeforeDialog = null;
  var filters = { status: "all", project: "all", priority: "all", search: "" };

  // ---------- elements ----------
  var el = {
    board: document.getElementById("board"),
    emptyState: document.getElementById("empty-state"),
    countDisplay: document.getElementById("count-display"),
    search: document.getElementById("search-input"),
    filterStatus: document.getElementById("filter-status"),
    filterProject: document.getElementById("filter-project"),
    filterPriority: document.getElementById("filter-priority"),
    createBtn: document.getElementById("create-task-btn"),
    exportBtn: document.getElementById("export-btn"),
    importInput: document.getElementById("import-file"),
    dialog: document.getElementById("task-dialog"),
    dialogTitle: document.getElementById("task-dialog-title"),
    form: document.getElementById("task-form"),
    formError: document.getElementById("dialog-form-error"),
    cancelBtn: document.getElementById("cancel-task-btn"),
    corruptNotice: document.getElementById("corrupt-notice"),
    downloadCorruptBtn: document.getElementById("download-corrupt-btn"),
    resetBoardBtn: document.getElementById("reset-board-btn"),
    conflictNotice: document.getElementById("conflict-notice"),
    reloadBtn: document.getElementById("reload-btn"),
    saveErrorNotice: document.getElementById("save-error-notice"),
    undoBanner: document.getElementById("undo-banner"),
    undoText: document.getElementById("undo-text"),
    undoBtn: document.getElementById("undo-delete-btn"),
    importError: document.getElementById("import-error"),
  };

  // ---------- utilities ----------
  function genId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return window.crypto.randomUUID();
    }
    return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
  }

  function isValidDateString(str) {
    if (str === "" || str == null) return true;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
    var parts = str.split("-");
    var y = Number(parts[0]), m = Number(parts[1]), d = Number(parts[2]);
    if (m < 1 || m > 12 || d < 1 || d > 31) return false;
    var dt = new Date(Date.UTC(y, m - 1, d));
    return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
  }

  function parseTagsInput(text) {
    if (!text) return [];
    var seen = {};
    var out = [];
    text.split(",").forEach(function (raw) {
      var t = raw.trim();
      if (!t) return;
      var key = t.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      out.push(t);
    });
    return out;
  }

  // ---------- validation ----------
  // Returns array of error strings; empty array = valid.
  function validateTask(t, opts) {
    opts = opts || {};
    var errors = [];
    if (typeof t.id !== "string" || t.id.length === 0 || t.id.length > 80) {
      errors.push("id must be a non-empty string of at most 80 characters.");
    }
    if (typeof t.title !== "string" || t.title.trim().length === 0) {
      errors.push("Title is required.");
    } else if (t.title.trim().length > 120) {
      errors.push("Title must be at most 120 characters.");
    }
    if (typeof t.project !== "string" || t.project.trim().length === 0) {
      errors.push("Project is required.");
    } else if (t.project.trim().length > 80) {
      errors.push("Project must be at most 80 characters.");
    }
    if (STATUSES.indexOf(t.status) === -1) {
      errors.push("Status must be one of todo, doing, done.");
    }
    if (PRIORITIES.indexOf(t.priority) === -1) {
      errors.push("Priority must be one of low, medium, high.");
    }
    if (typeof t.dueDate !== "string" || !isValidDateString(t.dueDate)) {
      errors.push("Due date must be blank or a real YYYY-MM-DD date.");
    }
    if (!Array.isArray(t.tags)) {
      errors.push("Tags must be a list.");
    } else {
      if (t.tags.length > 8) errors.push("At most 8 tags are allowed.");
      t.tags.forEach(function (tag) {
        if (typeof tag !== "string" || tag.trim().length === 0 || tag !== tag.trim() || tag.length > 24) {
          errors.push("Each tag must be a trimmed, non-empty string of at most 24 characters.");
        }
      });
    }
    return errors;
  }

  function validateBoardDocument(doc) {
    var errors = [];
    if (!doc || typeof doc !== "object") return ["Document is not an object."];
    if (doc.schemaVersion !== 1) errors.push("Unsupported schemaVersion.");
    if (!Array.isArray(doc.tasks)) {
      errors.push("tasks must be an array.");
      return errors;
    }
    var ids = {};
    doc.tasks.forEach(function (t, i) {
      var taskErrors = validateTask(t);
      if (taskErrors.length) {
        errors.push("Task " + (i + 1) + ": " + taskErrors.join(" "));
      }
      if (t && typeof t.id === "string") {
        if (ids[t.id]) errors.push("Duplicate id: " + t.id);
        ids[t.id] = true;
      }
    });
    return errors;
  }

  // ---------- seed data ----------
  function seedBoard() {
    var today = new Date();
    function iso(offsetDays) {
      var d = new Date(today.getTime() + offsetDays * 86400000);
      return d.toISOString().slice(0, 10);
    }
    return {
      schemaVersion: 1,
      tasks: [
        { id: genId(), title: "Draft trail signage copy", project: "Riverbend Survey", status: "todo", priority: "medium", dueDate: iso(5), tags: ["writing", "signage"] },
        { id: genId(), title: "Calibrate soil moisture sensors", project: "Riverbend Survey", status: "todo", priority: "high", dueDate: iso(1), tags: ["hardware"] },
        { id: genId(), title: "Interview local ranger about access roads", project: "Riverbend Survey", status: "doing", priority: "medium", dueDate: "", tags: ["research", "interview"] },
        { id: genId(), title: "Compile bird sighting log for Q3", project: "Canopy Watch", status: "doing", priority: "low", dueDate: iso(10), tags: ["data"] },
        { id: genId(), title: "Repair weatherproof camera housing", project: "Canopy Watch", status: "todo", priority: "high", dueDate: iso(-2), tags: ["hardware", "urgent"] },
        { id: genId(), title: "Publish May fieldnotes summary", project: "Canopy Watch", status: "done", priority: "medium", dueDate: iso(-7), tags: ["writing"] },
        { id: genId(), title: "Map new observation points", project: "Riverbend Survey", status: "done", priority: "low", dueDate: iso(-14), tags: ["mapping"] },
      ],
    };
  }

  // ---------- storage ----------
  function loadFromStorage() {
    var raw;
    try {
      raw = window.localStorage.getItem(STORAGE_KEY);
    } catch (e) {
      raw = null;
    }
    if (raw === null) {
      state = seedBoard();
      persist(); // best-effort; ignore failure on first run
      return;
    }
    var parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      isCorrupt = true;
      corruptRawText = raw;
      state = { schemaVersion: 1, tasks: [] };
      return;
    }
    var errors = validateBoardDocument(parsed);
    if (errors.length > 0) {
      isCorrupt = true;
      corruptRawText = raw;
      state = { schemaVersion: 1, tasks: [] };
      return;
    }
    state = { schemaVersion: 1, tasks: parsed.tasks };
  }

  var suppressNextStorageEvent = false;

  function persist() {
    try {
      suppressNextStorageEvent = true;
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      hide(el.saveErrorNotice);
      return true;
    } catch (e) {
      show(el.saveErrorNotice);
      return false;
    }
  }

  // ---------- visibility helpers ----------
  function show(node) { node.hidden = false; }
  function hide(node) { node.hidden = true; }

  // ---------- filtering ----------
  function getFilteredTasks() {
    var q = filters.search.trim().toLowerCase();
    return state.tasks.filter(function (t) {
      if (filters.status !== "all" && t.status !== filters.status) return false;
      if (filters.project !== "all" && t.project !== filters.project) return false;
      if (filters.priority !== "all" && t.priority !== filters.priority) return false;
      if (q) {
        var hay = (t.title + " " + t.project + " " + t.tags.join(" ")).toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function getProjects() {
    var set = {};
    state.tasks.forEach(function (t) { set[t.project] = true; });
    return Object.keys(set).sort(function (a, b) { return a.localeCompare(b); });
  }

  // ---------- rendering ----------
  function renderProjectFilterOptions() {
    var projects = getProjects();
    var current = el.filterProject.value || "all";
    el.filterProject.innerHTML = "";
    var allOpt = document.createElement("option");
    allOpt.value = "all";
    allOpt.textContent = "All projects";
    el.filterProject.appendChild(allOpt);
    projects.forEach(function (p) {
      var opt = document.createElement("option");
      opt.value = p;
      opt.textContent = p;
      el.filterProject.appendChild(opt);
    });
    if (projects.indexOf(current) !== -1 || current === "all") {
      el.filterProject.value = current;
    } else {
      el.filterProject.value = "all";
      filters.project = "all";
    }
  }

  function formatDate(iso) {
    if (!iso) return "";
    var parts = iso.split("-");
    var d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  }

  function isOverdue(t) {
    if (!t.dueDate || t.status === "done") return false;
    var todayIso = new Date().toISOString().slice(0, 10);
    return t.dueDate < todayIso;
  }

  function buildCard(t) {
    var card = document.createElement("article");
    card.className = "task-card";
    card.setAttribute("data-testid", "task-card");
    card.setAttribute("data-task-id", t.id);

    var h3 = document.createElement("h3");
    h3.textContent = t.title;
    card.appendChild(h3);

    var proj = document.createElement("p");
    proj.className = "task-project";
    proj.textContent = t.project;
    card.appendChild(proj);

    var meta = document.createElement("div");
    meta.className = "task-meta";

    var badge = document.createElement("span");
    badge.className = "badge badge-" + t.priority;
    badge.textContent = t.priority;
    meta.appendChild(badge);

    var due = document.createElement("span");
    due.className = "due-date" + (isOverdue(t) ? " overdue" : "");
    due.textContent = t.dueDate ? ("Due " + formatDate(t.dueDate) + (isOverdue(t) ? " (overdue)" : "")) : "No due date";
    meta.appendChild(due);

    card.appendChild(meta);

    if (t.tags.length) {
      var tagsWrap = document.createElement("div");
      tagsWrap.className = "tags";
      t.tags.forEach(function (tag) {
        var span = document.createElement("span");
        span.className = "tag";
        span.textContent = tag;
        tagsWrap.appendChild(span);
      });
      card.appendChild(tagsWrap);
    }

    var controls = document.createElement("div");
    controls.className = "card-controls";

    var statusLabel = document.createElement("label");
    statusLabel.className = "visually-hidden";
    var statusSelId = "status-" + t.id;
    statusLabel.setAttribute("for", statusSelId);
    statusLabel.textContent = "Status for " + t.title;
    controls.appendChild(statusLabel);

    var statusSel = document.createElement("select");
    statusSel.id = statusSelId;
    statusSel.setAttribute("data-action", "status");
    STATUSES.forEach(function (s) {
      var opt = document.createElement("option");
      opt.value = s;
      opt.textContent = s === "todo" ? "To do" : s.charAt(0).toUpperCase() + s.slice(1);
      if (s === t.status) opt.selected = true;
      statusSel.appendChild(opt);
    });
    statusSel.addEventListener("change", function () { onStatusChange(t.id, statusSel.value); });
    controls.appendChild(statusSel);

    var editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.setAttribute("data-action", "edit");
    editBtn.setAttribute("aria-label", "Edit " + t.title);
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", function () { openEditDialog(t.id); });
    controls.appendChild(editBtn);

    var delBtn = document.createElement("button");
    delBtn.type = "button";
    delBtn.setAttribute("data-action", "delete");
    delBtn.setAttribute("aria-label", "Delete " + t.title);
    delBtn.textContent = "Delete";
    delBtn.addEventListener("click", function () { onDelete(t.id); });
    controls.appendChild(delBtn);

    card.appendChild(controls);
    return card;
  }

  function render() {
    renderProjectFilterOptions();

    var filtered = getFilteredTasks();
    var columns = { todo: [], doing: [], done: [] };
    filtered.forEach(function (t) { columns[t.status].push(t); });

    STATUSES.forEach(function (s) {
      var list = el.board.querySelector('.card-list[data-column="' + s + '"]');
      list.innerHTML = "";
      columns[s].forEach(function (t) { list.appendChild(buildCard(t)); });
      var countEl = el.board.querySelector('[data-col-count="' + s + '"]');
      countEl.textContent = "(" + columns[s].length + ")";
    });

    el.countDisplay.textContent = filtered.length + " of " + state.tasks.length + " task" + (state.tasks.length === 1 ? "" : "s") + " shown";

    if (isCorrupt) {
      show(el.emptyState);
      el.emptyState.textContent = "Your board can't be shown because the saved data is corrupted. Use the recovery options above.";
      el.board.hidden = true;
      show(el.corruptNotice);
    } else {
      hide(el.corruptNotice);
      if (state.tasks.length === 0) {
        show(el.emptyState);
        el.emptyState.textContent = "No tasks yet. Click “New task” to add your first fieldnote.";
        el.board.hidden = true;
      } else if (filtered.length === 0) {
        show(el.emptyState);
        el.emptyState.textContent = "No tasks match your search or filters. Try clearing them.";
        el.board.hidden = true;
      } else {
        hide(el.emptyState);
        el.board.hidden = false;
      }
    }
  }

  // ---------- multi-tab conflict ----------
  window.addEventListener("storage", function (e) {
    if (e.key !== STORAGE_KEY) return;
    if (suppressNextStorageEvent) {
      suppressNextStorageEvent = false;
      return;
    }
    isBlocked = true;
    show(el.conflictNotice);
  });

  el.reloadBtn.addEventListener("click", function () {
    window.location.reload();
  });

  function guardBlocked() {
    if (isBlocked) {
      show(el.conflictNotice);
      return true;
    }
    return false;
  }

  // ---------- delete / undo ----------
  function onDelete(id) {
    if (guardBlocked()) return;
    var idx = state.tasks.findIndex(function (t) { return t.id === id; });
    if (idx === -1) return;
    var task = state.tasks[idx];
    state.tasks.splice(idx, 1);
    lastDeleted = { task: task, index: idx };
    persist();
    render();
    el.undoText.textContent = 'Deleted "' + task.title + '".';
    show(el.undoBanner);
    el.undoBtn.focus();
  }

  el.undoBtn.addEventListener("click", function () {
    if (!lastDeleted) return;
    if (guardBlocked()) return;
    var idx = Math.min(lastDeleted.index, state.tasks.length);
    state.tasks.splice(idx, 0, lastDeleted.task);
    lastDeleted = null;
    persist();
    render();
    hide(el.undoBanner);
  });

  // ---------- status change ----------
  function onStatusChange(id, newStatus) {
    if (guardBlocked()) { render(); return; }
    var task = state.tasks.find(function (t) { return t.id === id; });
    if (!task) return;
    task.status = newStatus;
    persist();
    render();
  }

  // ---------- create / edit dialog ----------
  function openCreateDialog() {
    editingId = null;
    el.dialogTitle.textContent = "New task";
    el.form.reset();
    document.getElementById("task-status").value = "todo";
    document.getElementById("task-priority").value = "medium";
    hide(el.formError);
    lastFocusedBeforeDialog = document.activeElement;
    el.dialog.showModal();
    document.getElementById("task-title").focus();
  }

  function openEditDialog(id) {
    var task = state.tasks.find(function (t) { return t.id === id; });
    if (!task) return;
    editingId = id;
    el.dialogTitle.textContent = "Edit task";
    document.getElementById("task-id").value = task.id;
    document.getElementById("task-title").value = task.title;
    document.getElementById("task-project").value = task.project;
    document.getElementById("task-status").value = task.status;
    document.getElementById("task-priority").value = task.priority;
    document.getElementById("task-due").value = task.dueDate;
    document.getElementById("task-tags").value = task.tags.join(", ");
    hide(el.formError);
    lastFocusedBeforeDialog = document.activeElement;
    el.dialog.showModal();
    document.getElementById("task-title").focus();
  }

  el.createBtn.addEventListener("click", function () {
    if (guardBlocked()) return;
    openCreateDialog();
  });

  el.cancelBtn.addEventListener("click", function () {
    el.dialog.close();
  });

  el.dialog.addEventListener("close", function () {
    editingId = null;
    if (lastFocusedBeforeDialog && typeof lastFocusedBeforeDialog.focus === "function") {
      lastFocusedBeforeDialog.focus();
    }
  });

  el.form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (guardBlocked()) return;

    var title = document.getElementById("task-title").value.trim();
    var project = document.getElementById("task-project").value.trim();
    var status = document.getElementById("task-status").value;
    var priority = document.getElementById("task-priority").value;
    var dueDate = document.getElementById("task-due").value.trim();
    var tags = parseTagsInput(document.getElementById("task-tags").value);

    var candidate = {
      id: editingId || genId(),
      title: title,
      project: project,
      status: status,
      priority: priority,
      dueDate: dueDate,
      tags: tags,
    };

    var errors = validateTask(candidate);
    if (errors.length) {
      el.formError.textContent = errors.join(" ");
      show(el.formError);
      return;
    }

    if (editingId) {
      var idx = state.tasks.findIndex(function (t) { return t.id === editingId; });
      if (idx !== -1) state.tasks[idx] = candidate;
    } else {
      state.tasks.push(candidate);
    }

    var ok = persist();
    render();
    if (ok) {
      el.dialog.close();
    } else {
      el.formError.textContent = "Task kept in memory, but could not be saved to storage.";
      show(el.formError);
    }
  });

  // ---------- search / filters ----------
  el.search.addEventListener("input", function () {
    filters.search = el.search.value;
    render();
  });
  el.filterStatus.addEventListener("change", function () {
    filters.status = el.filterStatus.value;
    render();
  });
  el.filterProject.addEventListener("change", function () {
    filters.project = el.filterProject.value;
    render();
  });
  el.filterPriority.addEventListener("change", function () {
    filters.priority = el.filterPriority.value;
    render();
  });

  // ---------- export ----------
  el.exportBtn.addEventListener("click", function () {
    var data = JSON.stringify(state, null, 2);
    var blob = new Blob([data], { type: "application/json" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = "fieldnote-board-export.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  });

  // ---------- import ----------
  el.importInput.addEventListener("change", function () {
    hide(el.importError);
    var file = el.importInput.files && el.importInput.files[0];
    if (!file) return;
    if (guardBlocked()) { el.importInput.value = ""; return; }
    if (file.size > MAX_IMPORT_BYTES) {
      el.importError.textContent = "Import failed: file is larger than 1 MiB.";
      show(el.importError);
      el.importInput.value = "";
      return;
    }
    var reader = new FileReader();
    reader.onload = function () {
      var text = String(reader.result);
      var parsed;
      try {
        parsed = JSON.parse(text);
      } catch (e) {
        el.importError.textContent = "Import failed: file is not valid JSON.";
        show(el.importError);
        el.importInput.value = "";
        return;
      }
      var errors = validateBoardDocument(parsed);
      if (errors.length) {
        el.importError.textContent = "Import failed: " + errors.slice(0, 3).join(" ");
        show(el.importError);
        el.importInput.value = "";
        return;
      }
      var proceed = window.confirm(
        "Importing will replace your current board (" + state.tasks.length + " task(s)) with " +
        parsed.tasks.length + " task(s) from this file. Continue?"
      );
      el.importInput.value = "";
      if (!proceed) return;
      state = { schemaVersion: 1, tasks: parsed.tasks };
      isCorrupt = false;
      corruptRawText = null;
      var ok = persist();
      render();
      if (!ok) {
        el.importError.textContent = "Import applied in memory, but could not be saved to storage.";
        show(el.importError);
      }
    };
    reader.onerror = function () {
      el.importError.textContent = "Import failed: could not read the file.";
      show(el.importError);
      el.importInput.value = "";
    };
    reader.readAsText(file);
  });

  // ---------- corrupt storage recovery ----------
  el.downloadCorruptBtn.addEventListener("click", function () {
    var blob = new Blob([corruptRawText || ""], { type: "text/plain" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = "fieldnote-board-corrupt-backup.txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  });

  el.resetBoardBtn.addEventListener("click", function () {
    var proceed = window.confirm("Reset the board? This discards the unreadable stored data and starts a fresh seeded board.");
    if (!proceed) return;
    isCorrupt = false;
    corruptRawText = null;
    state = seedBoard();
    persist();
    render();
  });

  // ---------- keyboard: Escape handled natively by <dialog>; ensure focus restore already wired via 'close' ----------

  // ---------- reduced motion ----------
  function applyReducedMotionPreference() {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      document.documentElement.classList.add("reduced-motion");
    }
  }

  // ---------- init ----------
  function init() {
    applyReducedMotionPreference();
    loadFromStorage();
    render();
  }

  init();
})();
