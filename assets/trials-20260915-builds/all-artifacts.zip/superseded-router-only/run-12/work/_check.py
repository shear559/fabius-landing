import math, random
from solution import solve

def f(t,x,y,z):
    return x*x+2*y*y+3*z*z+x*y-y*z+(2-2*t)*x+5*y+z

def feasible(x,y,z,tol=1e-7):
    return (x>=-tol and y>=-tol and z>=-tol and abs(x+y+z-1)<1e-6
            and x<=0.6+tol and 2*y+z>=0.5-tol)

# 1. Feasibility of solve(t) across a fine grid, including exact breakpoints.
bps = [-2, -1.5, -1, -0.5, 0, 1.8, 4]
ts = [ -2 + 0.001*i for i in range(6001)]
for bp in bps:
    for d in (-1e-6,0,1e-6):
        ts.append(bp+d)
random.seed(0)
ts += [random.uniform(-2,4) for _ in range(2000)]

bad = 0
for t in ts:
    if t < -2 or t > 4: continue
    r = solve(t)
    x,y,z = r["x"], r["y"], r["z"]
    if not feasible(x,y,z):
        bad += 1
        print("INFEASIBLE", t, r)
print("feasibility check: ", "OK" if bad==0 else f"{bad} FAILURES")

# 2. Continuity of x,y,z,value across breakpoints
for bp in bps[1:-1]:
    lo = solve(bp-1e-7); hi = solve(bp+1e-7)
    dx = abs(lo['x']-hi['x']); dy=abs(lo['y']-hi['y']); dz=abs(lo['z']-hi['z']); dv=abs(lo['value']-hi['value'])
    print(f"t={bp}: dx={dx:.2e} dy={dy:.2e} dz={dz:.2e} dv={dv:.2e}")

# 3. Brute-force verification: for a set of t values, grid/random search the
#    feasible pentagon (in reduced x,y coords) and confirm solve(t) attains
#    the minimum (within numerical tolerance), and that it's the unique
#    minimizer (strict convexity => any near-optimal point is close to it).
def brute_min(t, n=400000):
    best = None
    random.seed(1)
    # feasible region in (x,y): x in [0,0.6], y in [max(0,x-0.5), 1-x]
    for _ in range(n):
        x = random.uniform(0,0.6)
        ylo = max(0.0, x-0.5)
        yhi = 1-x
        if yhi < ylo: continue
        y = random.uniform(ylo,yhi)
        z = 1-x-y
        val = f(t,x,y,z)
        if best is None or val < best[0]:
            best = (val,x,y,z)
    return best

worst_gap = 0
for t in [-2,-1.7,-1.5,-1.3,-1,-0.8,-0.5,-0.3,0,0.5,1,1.8,2,3,4]:
    r = solve(t)
    v_formula = r["value"]
    bv, bx, by, bz = brute_min(t, 200000)
    gap = bv - v_formula  # should be >= -tiny (brute force can't beat true min)
    worst_gap = min(worst_gap, gap)
    dist = math.dist((r['x'],r['y']), (bx,by))
    print(f"t={t:>5}: formula_val={v_formula:.6f} brute_best={bv:.6f} gap={gap:.2e} point_dist={dist:.4f}")

print("worst (most negative) gap over all t:", worst_gap)

# 4. Envelope theorem check: d(value)/dt should equal -2*x*(t)
for t in [-1.9,-1.6,-1.2,-0.9,-0.6,-0.2,0.3,1.0,1.79,1.81,2.5,3.9]:
    h = 1e-6
    v1 = solve(t-h)["value"]; v2 = solve(t+h)["value"]
    num_deriv = (v2-v1)/(2*h)
    x_t = solve(t)["x"]
    print(f"t={t}: numeric dV/dt={num_deriv:.6f}  -2x*={-2*x_t:.6f}  diff={abs(num_deriv+2*x_t):.2e}")

# 5. Value formula matches original (non-reduced) objective directly (already
#    used inside solve()), and matches reduced formula 4x^2+8xy+6y^2-(5+2t)x-3y+4
for t in [-2,-1,0,1,4]:
    r = solve(t)
    x,y = r['x'], r['y']
    reduced = 4*x*x+8*x*y+6*y*y-(5+2*t)*x-3*y+4
    print(f"t={t}: value={r['value']:.6f} reduced_formula={reduced:.6f} diff={abs(r['value']-reduced):.2e}")

# 6. Module import has no side effects / no CLI — checked structurally in verification.md.
print("ALL CHECKS RAN")
