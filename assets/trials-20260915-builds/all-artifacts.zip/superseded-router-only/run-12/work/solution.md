# Exact solution of the parametric QP, for every $t \in [-2,4]$

## 0. Problem

$$\min_{x,y,z} f_t(x,y,z)=x^2+2y^2+3z^2+xy-yz+(2-2t)x+5y+z$$
$$\text{s.t. } x+y+z=1,\; x\ge0,\; y\ge0,\; z\ge0,\; x\le \tfrac35,\; 2y+z\ge\tfrac12 .$$

## 1. Reduction to two variables

Eliminate $z=1-x-y$. Substituting and collecting terms (full expansion below) gives

$$f_t(x,y)=4x^2+8xy+6y^2-(5+2t)x-3y+4. \tag{1}$$

*Expansion check.* With $z=1-x-y$:
$3z^2=3-6x-6y+3x^2+6xy+3y^2$, $-yz=-y+xy+y^2$, $z=1-x-y$. Adding $x^2+2y^2+xy+(2-2t)x+5y$ to these and collecting:
$x^2$: $1+3=4$. $y^2$: $2+3+1=6$. $xy$: $1+6+1=8$. constants: $3+1=4$.
$x$: $-6+(2-2t)-1=-5-2t$. $y$: $-6-1+5-1=-3$. This is exactly (1).

The equality constraint becomes the feasible **pentagon** in the $(x,y)$-plane:
$$P=\{(x,y): x\ge0,\ y\ge0,\ x+y\le1,\ x\le\tfrac35,\ y\ge x-\tfrac12\},$$
(the last inequality is $2y+z\ge\frac12 \iff 2y+1-x-y\ge\frac12 \iff y\ge x-\frac12$).

Note that on $x\in[0,\tfrac12]$, $x-\tfrac12\le0$ so $y\ge x-\tfrac12$ is implied by $y\ge0$; it only bites for $x>\tfrac12$. Working out the vertices in traversal order gives the pentagon
$$A=(0,0),\quad B=(0,1),\quad C=(\tfrac35,\tfrac25),\quad D=(\tfrac35,\tfrac1{10}),\quad E=(\tfrac12,0),$$
with edges $AB\,(x=0)$, $BC\,(x+y=1)$, $CD\,(x=\tfrac35)$, $DE\,(y=x-\tfrac12)$, $EA\,(y=0)$.

## 2. Strict convexity $\Rightarrow$ unique global minimizer

The quadratic part of (1) has Hessian
$$H=\begin{pmatrix}8&8\\8&12\end{pmatrix},\qquad \operatorname{tr}H=20>0,\ \det H=96-64=32>0,$$
so $H\succ0$: $f_t(\cdot,\cdot)$ is **strictly convex** on $\mathbb R^2$ for every $t$, independent of $t$ (the parameter only shifts the linear term). $P$ is a nonempty compact convex polygon. Hence for every $t$ there is a **unique** global minimizer, and for a convex program the KKT conditions are not merely necessary but **sufficient** for global optimality. The strategy below is: exhibit, for every $t\in[-2,4]$, a primal point and multipliers satisfying KKT; by sufficiency this settles global optimality and uniqueness with no need for a separate exhaustive case search — but §6 explains independently why every face of $P$ is accounted for.

## 3. Unconstrained stationary point

$\nabla f_t=0$ gives
$$8x+8y=5+2t,\qquad 8x+12y=3 \;\Longrightarrow\; y=-\frac{1+t}{2},\quad x=\frac{9+6t}{8}. \tag{2}$$

As $t$ ranges over $[-2,4]$, $(x,y)$ in (2) traces the line $y=-\tfrac23(x-\tfrac38)$, moving monotonically from $(-0.375,0.5)$ at $t=-2$ to $(4.125,-2.5)$ at $t=4$: strictly increasing in $x$, strictly decreasing in $y$. This line sweeps only through the neighborhood of $A$, the interior, $E$ and $D$ — never near $B$, $C$, or the interior of edges $AB$, $BC$, $CD$ (confirmed rigorously face‑by‑face in §6). This is why exactly six regimes occur.

## 4. The six regimes (KKT in original variables)

KKT (all constraints written as $g_i\le0$, multiplier $\mu_i\ge0$; equality multiplier $\nu\in\mathbb R$):
$$g_1=-x,\ g_2=-y,\ g_3=-z,\ g_4=x-\tfrac35,\ g_5=\tfrac12-2y-z,$$
$$\nabla f_t+\nu(1,1,1)-\mu_1(1,0,0)-\mu_2(0,1,0)-\mu_3(0,0,1)+\mu_4(1,0,0)-\mu_5(0,2,1)=0,$$
$$\partial f/\partial x=2x+y+2-2t,\quad \partial f/\partial y=4y+x-z+5,\quad \partial f/\partial z=6z-y+1.$$

Solving the stationarity equations on each face (algebra executed and cross-checked numerically; see verification.md) gives, with breakpoints $t^\*\in\{-\tfrac32,-1,-\tfrac12,0,\tfrac95\}$:

---
**Regime 1 — $t\in[-2,-\tfrac32]$ — edge $AB$ point ($x=0$ active only)**
$$(x,y,z)=\Big(0,\ \tfrac14,\ \tfrac34\Big),\qquad f_t^\*=\tfrac{29}{8}\ (\text{constant}).$$
Multipliers: $\mu_1=-3-2t\ge0 \iff t\le-\tfrac32$; all other $\mu_i=0$; $\nu=-\tfrac{21}{4}$.
*Why $y$ doesn't move with $t$*: on $x=0$, $f_t(0,y)=6y^2-3y+4$ has no $t$-dependence, minimized at $y=\tfrac14\in[0,1]$ regardless of $t$; only whether $x=0$ is *active* depends on $t$.

**Regime 2 — $t\in[-\tfrac32,-1]$ — interior (no inequality active)**
$$x=\frac{9+6t}{8},\quad y=-\frac{1+t}{2},\quad z=\frac{3-2t}{8},$$
$$f_t^\*=\frac{-12t^2-36t+31}{16}.$$
All $\mu_i=0$; $\nu=\dfrac{4t-15}{4}$ (all three partials equal $-\nu$, as required by the equality-only Lagrangian).

**Regime 3 — $t\in[-1,-\tfrac12]$ — edge $EA$ ($y=0$ active)**
$$x=\frac{5+2t}{8},\quad y=0,\quad z=\frac{3-2t}{8},\qquad f_t^\*=4-\frac{(5+2t)^2}{16}.$$
$\mu_2=2(1+t)\ge0\iff t\ge-1$; others $0$; $\nu=\dfrac{6t-13}{4}$.

**Regime 4 — $t\in[-\tfrac12,0]$ — vertex $E=(\tfrac12,0,\tfrac12)$**
$$f_t^\*=\tfrac52-t.$$
$\mu_2=-2t\ge0\iff t\le0$, $\mu_5=1+2t\ge0\iff t\ge-\tfrac12$; $\nu=2t-3$.

**Regime 5 — $t\in[0,\tfrac95]$ — edge $DE$ ($2y+z=\tfrac12$ active)**
$$x=\frac{9+t}{18},\quad y=\frac{t}{18},\quad z=\frac{9-2t}{18},\qquad f_t^\*=7-\frac{(9+t)^2}{18}.$$
$\mu_5=\dfrac{9+10t}{9}\ge0$ for all $t\ge0$; others $0$; $\nu=\dfrac{11t-18}{6}$.

**Regime 6 — $t\in[\tfrac95,4]$ — vertex $D=(\tfrac35,\tfrac1{10},\tfrac3{10})$**
$$f_t^\*=\frac{67}{25}-\frac{6t}{5}.$$
$\mu_4=\dfrac{10t-18}{5}\ge0\iff t\ge\tfrac95$, $\mu_5=3\ge0$; $\nu=\tfrac{3}{10}$.

All algebra for each regime was re-derived independently from the 3‑variable Lagrangian (not just carried over from the 2‑D reduction) and the two derivations agree exactly (see the worked stationarity equations above); this cross-check is itself part of the correctness argument.

## 5. Continuity, sign checks, and the value function

**Primal continuity.** Evaluate adjacent formulas at each breakpoint:

| $t$ | from | $(x,y,z)$ |
|---|---|---|
| $-3/2$ | R1 / R2 | $(0,\ 1/4,\ 3/4)$ both |
| $-1$ | R2 / R3 | $(3/8,\ 0,\ 5/8)$ both |
| $-1/2$ | R3 / R4 | $(1/2,\ 0,\ 1/2)$ both |
| $0$ | R4 / R5 | $(1/2,\ 0,\ 1/2)$ both |
| $9/5$ | R5 / R6 | $(3/5,\ 1/10,\ 3/10)$ both |

so $x^\*(t),y^\*(t),z^\*(t)$ are continuous (indeed piecewise-rational, matching at every seam) on all of $[-2,4]$.

**Multiplier sign consistency at the seams** (the multiplier of the constraint that is about to switch on/off vanishes exactly at the breakpoint, confirming these are true KKT transitions and not artifacts):
$\mu_1(-\tfrac32)=0$; $\mu_2(-1)=0$; $\mu_5(-\tfrac12)=0$; $\mu_2(0)=0$; $\mu_4(\tfrac95)=0$.

**Equality multiplier $\nu(t)$ is also continuous**: $-\tfrac{21}{4}\to-\tfrac{21}4$ at $-\tfrac32$, $-\tfrac{19}4\to-\tfrac{19}4$ at $-1$, $-4\to-4$ at $-\tfrac12$, $-3\to-3$ at $0$, $\tfrac3{10}\to\tfrac3{10}$ at $\tfrac95$ (values recomputed from each side's formula; see verification.md for the executed check). This is expected — $\nu$ is (minus) the common marginal value of the resource $x+y+z=1$ and must vary continuously as the active set changes continuously.

**Value function.** Collecting the six pieces:
$$
f^\*(t)=\begin{cases}
29/8, & t\in[-2,-3/2]\\[2pt]
(-12t^2-36t+31)/16, & t\in[-3/2,-1]\\[2pt]
4-(5+2t)^2/16, & t\in[-1,-1/2]\\[2pt]
5/2-t, & t\in[-1/2,0]\\[2pt]
7-(9+t)^2/18, & t\in[0,9/5]\\[2pt]
67/25-6t/5, & t\in[9/5,4].
\end{cases}
$$
By the **envelope theorem** (valid because $x^\*,y^\*,z^\*$ are continuous and the active set is piecewise constant), $\dfrac{d f^\*}{dt}=\dfrac{\partial f_t}{\partial t}\Big|_{\text{opt}}=-2x^\*(t)$. Checking each piece's derivative against $-2x^\*(t)$:

| regime | $df^\*/dt$ | $-2x^\*(t)$ |
|---|---|---|
| 1 | $0$ | $0$ |
| 2 | $-(6t+9)/4$ | $-2\cdot\frac{9+6t}{8}=-(9+6t)/4$ ✓ |
| 3 | $-(5+2t)/4$ | $-2\cdot\frac{5+2t}{8}=-(5+2t)/4$ ✓ |
| 4 | $-1$ | $-2\cdot\tfrac12=-1$ ✓ |
| 5 | $-(9+t)/9$ | $-2\cdot\frac{9+t}{18}=-(9+t)/9$ ✓ |
| 6 | $-6/5$ | $-2\cdot\tfrac35=-6/5$ ✓ |

so every piece satisfies the envelope identity, an independent internal proof-check of the algebra. The one-sided slopes at the five breakpoints are $0,-0.75,-1,-1,-1.2$ **matching on both sides** at every seam (verified numerically to $10^{-10}$, §verification.md), so $f^\*$ is $C^1$ on $[-2,4]$ — continuous with a continuous derivative — though not $C^2$ (the multiplier that switches on/off changes the curvature of $f^\*$ at each breakpoint, which is generic for parametric QP). The derivative sequence $0>-0.75>-1>-1>-1.2$ is non-increasing, so $f^\*$ is **concave** in $t$ (not convex): this is the expected shape here because $f_t$ is *affine*, not jointly convex, in $t$ for fixed $(x,y,z)$ (the cross term $-2tx$ makes the $(x,t)$ Hessian block indefinite), so $f^\*(t)=\min_{(x,y,z)\in \text{feasible}} f_t(x,y,z)$ is an infimum of a family of functions each affine in $t$ — a pointwise minimum of affine functions is concave, matching what was computed.

## 6. Why no face and no parameter range was missed

The pentagon has $5$ vertices, $5$ open edges, and $1$ open interior — $11$ faces in total. Regimes 1–6 above already cover: interior, edge $EA$, edge $DE$, vertex $E$, vertex $D$, and the single point $(0,\tfrac14)$ of edge $AB$. Two arguments close the remaining cases:

1. **Sufficiency argument (already conclusive).** Since $f_t$ is strictly convex and $P$ is convex, a KKT point is *the* global optimum (§2). Regimes 1–6, verified continuous and multiplier-consistent at every seam (§5), partition $[-2,4]$ with **no gap and no overlap**: $[-2,-\tfrac32]\cup[-\tfrac32,-1]\cup[-1,-\tfrac12]\cup[-\tfrac12,0]\cup[0,\tfrac95]\cup[\tfrac95,4]=[-2,4]$. Hence a valid KKT point has been exhibited for *every* $t$ in the domain, which by itself proves optimality on all of $[-2,4]$; nothing further is required for the proof. Uniqueness in each regime follows from strict convexity of $f_t$ (§2): a strictly convex function has at most one minimizer, and one has been produced, so it is *the* minimizer.

2. **Direct exclusion of $B$, $C$, edge $BC$, and the rest of edges $AB$/$CD$ (independent confirmation, not logically required after point 1, but checked for extra rigor).**

   *Vertex $B=(0,1,0)$*: active constraints are $g_1$ ($x=0$) and $g_3$ ($z=0$); $g_2,g_4,g_5$ slack, so $\mu_2=\mu_4=\mu_5=0$. Then
   $$\partial f/\partial x=3-2t,\quad \partial f/\partial y=9,\quad \partial f/\partial z=0.$$
   The $y$-equation ($\mu_2=0$) gives $9+\nu=0\Rightarrow\nu=-9$. The $z$-equation gives $\mu_3=\partial f/\partial z+\nu=0-9=-9<0$ for **every** $t$ — dual infeasible, so $B$ is never optimal.

   *Vertex $C=(\tfrac35,\tfrac25,0)$*: active constraints $g_4$ ($x=\tfrac35$), $g_3$ ($z=0$); $g_1,g_2,g_5$ slack. Then $\partial f/\partial y=4(\tfrac25)+\tfrac35-0+5=7.2$, so $\nu=-7.2$ from the $y$-equation, and $\partial f/\partial z=6(0)-\tfrac25+1=0.6$, giving $\mu_3=0.6-7.2=-6.6<0$ for every $t$ — never optimal.

   *Edge $BC$ interior* ($x+y=1,\ z=0,\ x\in(0,\tfrac35)$, so only $g_3$ possibly active): substituting $y=1-x$,
   $$\partial f/\partial x=x+3-2t,\qquad \partial f/\partial y=9-3x,\qquad \partial f/\partial z=x.$$
   The $x$- and $y$-equations ($\mu_1=\mu_2=0$) both determine $\nu$: $\nu=2t-3-x$ and $\nu=3x-9$; equating gives the candidate stationary point $x=\tfrac{t+3}2$. Its complementary multiplier is $\mu_3=\partial f/\partial z+\nu=x+\nu=x+(3x-9)=4x-9$, and using $x=\tfrac{t+3}2$: $\mu_3=2t-3$. For $x=\tfrac{t+3}2$ to even lie in the edge's interior $(0,\tfrac35)$ requires $t\in(-3,-1.8)$, and on that range $\mu_3=2t-3\in(-9,-6.6)$, always negative — dual infeasible throughout, so no point of edge $BC$ is ever optimal for $t\in[-2,4]$ (the candidate fails even where it is geometrically reachable; intersected with the problem's domain this is $t\in[-2,-1.8)$, where $\mu_3\in[-7,-6.6)$, still negative).

   *Rest of edge $AB$* ($x=0,\ y\ne\tfrac14$): shown directly in Regime 1 — $f_t(0,y)=6y^2-3y+4$ is a $t$-independent strictly convex parabola in $y$ minimized at $y=\tfrac14$, so no other point of $AB$ is ever a 1-D minimizer, hence never the constrained 2-D minimizer either.

   *Edge $CD$* ($x=\tfrac35,\ y\in[\tfrac1{10},\tfrac25]$): $f_t(\tfrac35,y)=6y^2+1.8y+(2.44-1.2t)$, with $\partial_y=12y+1.8$ vanishing at $y=-0.15$, independent of $t$ and below the edge's range; since the parabola is increasing for $y>-0.15$, the restricted minimum over $[\tfrac1{10},\tfrac25]$ is always at the left endpoint $y=\tfrac1{10}$, i.e. vertex $D$ — the edge's interior is never the minimizer, consistent with Regime 6 taking over at $D$ for $t\ge\tfrac95$.

   All of $B$, $C$, edge $BC$, and the interiors of $AB$ and $CD$ are thus excluded for every $t\in[-2,4]$, independently confirming the partition in point 1.

3. **No range of $t$ is skipped**: the six regimes' intervals were derived by solving $\mu_i(t)=0$ for the multiplier of the constraint that is about to activate/deactivate, and every inequality direction was checked (e.g. $\mu_1\ge0\iff t\le-\tfrac32$, $\mu_2\ge0$ from regime 3 side $\iff t\ge -1$, etc.), so the six closed intervals are forced by the algebra, not chosen by inspection, and their union is exactly $[-2,4]$ as shown above.

## 7. Summary table

| $t$-range | active set | $(x^\*,y^\*,z^\*)$ | $f_t^\*$ |
|---|---|---|---|
| $[-2,-3/2]$ | $x=0$ | $(0,\ 1/4,\ 3/4)$ | $29/8$ |
| $[-3/2,-1]$ | — (interior) | $\left(\dfrac{9+6t}8,\ -\dfrac{1+t}2,\ \dfrac{3-2t}8\right)$ | $\dfrac{-12t^2-36t+31}{16}$ |
| $[-1,-1/2]$ | $y=0$ | $\left(\dfrac{5+2t}8,\ 0,\ \dfrac{3-2t}8\right)$ | $4-\dfrac{(5+2t)^2}{16}$ |
| $[-1/2,0]$ | $y=0,\ 2y+z=1/2$ | $(1/2,\ 0,\ 1/2)$ | $5/2-t$ |
| $[0,9/5]$ | $2y+z=1/2$ | $\left(\dfrac{9+t}{18},\ \dfrac t{18},\ \dfrac{9-2t}{18}\right)$ | $7-\dfrac{(9+t)^2}{18}$ |
| $[9/5,4]$ | $x=3/5,\ 2y+z=1/2$ | $(3/5,\ 1/10,\ 3/10)$ | $67/25-6t/5$ |

$x^\*,y^\*,z^\*$ and $f_t^\*$ are continuous on $[-2,4]$; $f_t^\*$ is additionally $C^1$ and concave; the minimizer is unique for every $t$ by strict convexity.
