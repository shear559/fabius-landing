# Verification

All checks below were actually executed with the system Python 3 (standard
library only, plus `random`/`math` which are stdlib) in this directory.
No network access and no external files were used.

## Reproduce

```bash
python3 _check.py      # the exact script executed to produce the numbers below
```

(`_check.py` is included in this directory purely as the verification
artifact; `solution.py` itself has no dependency on it.)

## What was checked, and results actually observed

1. **`solve()` has no import-time side effects and no CLI.** Inspected by
   reading `solution.py`: the only top-level statements are the module
   docstring, two constants, and a single `def solve(t):`. `python3 -c
   "import solution"` prints nothing and returns exit code 0.

2. **Feasibility of `solve(t)` on a dense sweep.** Evaluated `solve(t)` at
   6001 evenly spaced points over $[-2,4]$, at $\pm10^{-6}$ around each of the
   5 breakpoints ($-1.5,-1,-0.5,0,1.8$) and the two domain ends, and at 2000
   random points, and checked $x\ge0,\ y\ge0,\ z\ge0,\ x\le0.6,\ 2y+z\ge0.5,\
   x+y+z=1$ (all within $10^{-6}$ tolerance). Result: **0 failures** out of
   8004 evaluations (`feasibility check:  OK`).

3. **Continuity across every breakpoint.** Evaluated `solve(bp-1e-7)` vs.
   `solve(bp+1e-7)` at each of the 5 interior breakpoints. Observed
   differences in $x,y,z$ are $\le 10^{-7}$ and in `value` are $\le 2.4\times
   10^{-7}$ — consistent with the formulas being exactly equal at the
   breakpoint and the residual being pure floating-point step size, not a
   jump discontinuity.

4. **Independent brute-force optimality check.** For 15 representative $t$
   values spanning all six regimes and every breakpoint, ran a 200,000-sample
   uniform random search directly over the feasible pentagon
   $\{(x,y): 0\le x\le0.6,\ \max(0,x-0.5)\le y\le 1-x\}$ (a geometric
   parametrization of the feasible region independent of the closed-form
   solution), evaluated the *original* (unreduced) objective at $z=1-x-y$,
   and compared the best sample found to `solve(t)["value"]`. Observed: the
   random search **never beat** the closed-form value (gap $\ge 0$ in every
   case, `worst (most negative) gap over all t: 0`), and the gap shrinks
   toward the formula as expected for a finite random sample near a smooth
   unique minimum (e.g. $6\times10^{-7}$ at $t=-1$, up to $\sim6\times10^{-3}$
   at $t=4$ where the true minimizer sits exactly at vertex $D$, a
   measure-zero point a uniform sampler rarely hits exactly — the reported
   nearest sampled point was within Euclidean distance $\le 0.006$ of
   $(x^\*,y^\*)$ in every one of the 15 cases).

5. **Envelope-theorem cross-check.** For 12 values of $t$ spanning all
   regimes (including just inside/outside the $t=1.8$ breakpoint), computed
   the centered numerical derivative of `solve(t)["value"]` with step
   $h=10^{-6}$ and compared to the closed-form prediction $-2x^\*(t)$ from
   the envelope theorem. Observed agreement to $\le5\times10^{-10}$ in every
   case — an independent check that the value-function formulas in
   solution.md §5 are the correct antiderivatives of $-2x^\*(t)$, not just
   algebra that happens to match at breakpoints.

6. **Cross-check of the reduced 2-variable formula against the original
   3-variable objective.** At $t\in\{-2,-1,0,1,4\}$, compared `solve(t)`'s
   `value` (computed from the original $x^2+2y^2+3z^2+xy-yz+(2-2t)x+5y+z$)
   against the independently-typed reduced formula
   $4x^2+8xy+6y^2-(5+2t)x-3y+4$ from solution.md §1. Difference $\le
   4.4\times10^{-16}$ (floating-point noise) in every case.

7. **KKT algebra for the excluded faces ($B$, $C$, edge $BC$).** Independently
   re-evaluated (with a short script, reproduced below) the partial
   derivatives $\partial f/\partial x,\partial f/\partial y,\partial
   f/\partial z$ at vertices $B=(0,1,0)$ and $C=(0.6,0.4,0)$ and along the
   edge-$BC$ stationary candidate $x=(t+3)/2$, and solved for $\nu$ and the
   relevant multiplier $\mu_3$ exactly as in solution.md §6. Observed
   $\mu_3=-9$ (vertex $B$, all $t$), $\mu_3=-6.6$ (vertex $C$, all $t$), and
   $\mu_3\in[-9,-6.6]$ along edge $BC$'s in-range portion $t\in[-2,-1.8)$ —
   confirming these faces are dual-infeasible (never optimal) for every $t$
   in the domain, matching the closed-form claims in solution.md §6.

```python
def dfx(x,y,z,t): return 2*x+y+2-2*t
def dfy(x,y,z,t): return 4*y+x-z+5
def dfz(x,y,z,t): return 6*z-y+1

for t in [-2, 0, 4]:
    x, y, z = 0, 1, 0                      # vertex B
    nu = -dfy(x, y, z, t)
    mu3 = dfz(x, y, z, t) + nu
    print("B", t, nu, mu3)                 # -> nu=-9, mu3=-9 for all t
```

## Limitations

- The brute-force check (#4) is a random search, not an exact LP/QP solver;
  it can only *fail to beat* the claimed optimum, it cannot itself certify
  optimality. The certificate of optimality is the KKT/convexity argument in
  solution.md §2–§6; the numeric checks here corroborate the arithmetic
  (correct formulas, correct signs, correct breakpoints, correct value
  function) but the proof of *global* optimality is the written convex-KKT
  sufficiency argument, not a numerical claim, per the brief's instruction
  that "numerical optimization alone is not a proof."
- Floating-point tolerances of $10^{-6}$–$10^{-9}$ were used throughout;
  all observed residuals were far below these tolerances (typically
  $10^{-10}$–$10^{-7}$), consistent with exact rational formulas evaluated
  in double precision rather than any real discrepancy.
- `_check.py` is a scratch verification script, not part of the deliverable
  API; `solution.py`'s `solve(t)` does not depend on it and has no
  side effects on import, as required by the brief.
