"""
Exact closed-form solver for the parametric QP:

    minimize f_t(x,y,z) = x^2 + 2y^2 + 3z^2 + xy - yz + (2-2t)x + 5y + z
    s.t.  x+y+z=1, x>=0, y>=0, z>=0, x<=3/5, 2y+z>=1/2

for real t in [-2,4].  See solution.md for the full derivation and proof.

Standard library only.  Importing this module has no side effects.
"""

# Exact rational breakpoints of the optimal solution path (as floats,
# each is an exact binary-representable value or exactly reproduced by
# the comparisons below): -3/2, -1, -1/2, 0, 9/5.

_T_LO = -2.0
_T_HI = 4.0


def solve(t):
    """Return the unique global minimizer/value of f_t on the feasible set.

    Parameters
    ----------
    t : int or float, must lie in [-2, 4] (small floating tolerance allowed).

    Returns
    -------
    dict with keys:
        x, y, z   : exact optimal point (floats)
        value     : f_t(x,y,z) (float)
        regime    : label of the active face (str)
        active_set: tuple of active inequality-constraint names (str)
        multipliers: dict of the (nonnegative) KKT multipliers that are
                      nonzero on this regime, plus the equality multiplier nu
    """
    t = float(t)
    eps = 1e-9
    if t < _T_LO - eps or t > _T_HI + eps:
        raise ValueError("t must lie in [-2, 4]")

    if t <= -1.5:
        x, y, z = 0.0, 0.25, 0.75
        regime = "vertex/edge x=0 (AB), y=1/4 fixed"
        active_set = ("x>=0",)
        mult = {"mu_x>=0": -3.0 - 2.0 * t, "nu": -21.0 / 4.0}
    elif t <= -1.0:
        x = (9.0 + 6.0 * t) / 8.0
        y = -(1.0 + t) / 2.0
        z = (3.0 - 2.0 * t) / 8.0
        regime = "interior (no inequality active)"
        active_set = ()
        mult = {"nu": (4.0 * t - 15.0) / 4.0}
    elif t <= -0.5:
        x = (5.0 + 2.0 * t) / 8.0
        y = 0.0
        z = (3.0 - 2.0 * t) / 8.0
        regime = "edge y=0 (AE)"
        active_set = ("y>=0",)
        mult = {"mu_y>=0": 2.0 * (1.0 + t), "nu": (6.0 * t - 13.0) / 4.0}
    elif t <= 0.0:
        x, y, z = 0.5, 0.0, 0.5
        regime = "vertex E = (1/2, 0, 1/2)"
        active_set = ("y>=0", "2y+z>=1/2")
        mult = {
            "mu_y>=0": -2.0 * t,
            "mu_2y+z>=1/2": 1.0 + 2.0 * t,
            "nu": 2.0 * t - 3.0,
        }
    elif t <= 1.8:
        x = (9.0 + t) / 18.0
        y = t / 18.0
        z = (9.0 - 2.0 * t) / 18.0
        regime = "edge 2y+z=1/2 (ED)"
        active_set = ("2y+z>=1/2",)
        mult = {"mu_2y+z>=1/2": (9.0 + 10.0 * t) / 9.0, "nu": (11.0 * t - 18.0) / 6.0}
    else:
        x, y, z = 0.6, 0.1, 0.3
        regime = "vertex D = (3/5, 1/10, 3/10)"
        active_set = ("x<=3/5", "2y+z>=1/2")
        mult = {
            "mu_x<=3/5": (10.0 * t - 18.0) / 5.0,
            "mu_2y+z>=1/2": 3.0,
            "nu": 0.3,
        }

    value = x * x + 2.0 * y * y + 3.0 * z * z + x * y - y * z + (2.0 - 2.0 * t) * x + 5.0 * y + z

    return {
        "x": x,
        "y": y,
        "z": z,
        "value": value,
        "regime": regime,
        "active_set": active_set,
        "multipliers": mult,
    }
