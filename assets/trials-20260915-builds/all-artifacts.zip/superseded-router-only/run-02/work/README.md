# Lattice — landing page (fictional product demo)

A static marketing landing page for **Lattice**, a fictional local-first research notebook.
Built with plain HTML, CSS and JavaScript — no build step, no frameworks, no remote fonts,
no network calls, no backend.

## Run it

Serve the folder with any static file server and open `index.html`, e.g.:

```
python3 -m http.server 8080
# then visit http://localhost:8080/index.html
```

All asset references (`styles.css`, `app.js`) are relative paths with no leading slash, and
internal navigation uses in-page fragment links (`#features`, `#workflow`, …), so the page
works unmodified when served from a nested path (e.g. `/some/sub/dir/index.html`) — verified
by copying the three files into a nested subdirectory and serving from the parent.

## Files

- `index.html` — markup and content
- `styles.css` — design tokens, layout, responsive rules, focus states, reduced-motion rules
- `app.js` — mobile nav, feature tabs, billing toggle behavior (progressive enhancement)
- `README.md` — this file

## Implementation decisions

- **Visual system**: warm paper background, deep teal accent, a serif display face for
  headings (system serif stack) paired with system sans-serif body text — no remote fonts,
  only OS-provided font stacks.
- **Hero illustration**: an original "app window" mockup (sidebar + note + source chip) built
  from HTML/CSS boxes plus a couple of small inline SVGs (search icon, link icon, decorative
  squiggle) — no external images.
- **Mobile nav**: `#mobile-nav` is present in the DOM and unhidden by default in markup, so it
  is reachable without JavaScript at narrow widths. `app.js` hides it on load and then drives
  the open/close toggle, `aria-expanded` sync, Escape-to-close-and-refocus, and close-on-link-
  select. Desktop navigation is a separate always-visible `<nav>` shown above the mobile
  breakpoint.
- **Feature tabs**: real `role="tablist"`/`role="tab"`/`role="tabpanel"` semantics with
  `aria-selected`, roving `tabindex`, and Left/Right/Home/End arrow-key movement. All three
  panels are visible in markup by default (JS-off fallback); `app.js` hides the non-active
  panels once it runs, so exactly one panel is visible when scripting is available.
- **Billing toggle**: prices are stored as a static lookup table (`monthly`/`yearly`) rather
  than computed, so switching back to monthly always restores the exact original strings
  ($12 / $29) with no rounding risk. The billing period is labeled in text next to the toggle,
  not just implied by button state.
- **FAQ**: native `<details>/<summary>` elements — no JS required, keyboard- and
  screen-reader-accessible by default.
- **No-JS baseline**: with JavaScript disabled, the mobile nav, all three feature panels, and
  both prices remain present and readable in the page flow; only the interactive
  show/hide/arrow-key affordances are unavailable.
- **Motion**: the only motion is `scroll-behavior: smooth` and short hover/focus transitions;
  both are disabled under `prefers-reduced-motion: reduce`.
- **Fiction labeling**: a persistent banner at the top of the page, plus fine print in the hero
  and footer, state that Lattice is a fictional product demo and that prices/figures are
  illustrative only. No customers, reviews, ratings, or performance claims are included.

## Checks actually executed

Using a headless Chromium instance driven by Playwright, against the page served over
`python3 -m http.server` from a nested subdirectory (to validate the nested-path requirement):

- 360px viewport: `menu-toggle` opens/closes `mobile-nav` with `aria-expanded` synced; Escape
  closes the menu and returns focus to the toggle button; clicking a nav link closes the menu.
- Feature tabs: `panel-capture` visible and others hidden by default; ArrowRight moves focus
  and selection from Capture → Connect → Export with `aria-selected` updating and only the
  active panel visible; clicking a tab also switches panels.
- Billing toggle: clicking yearly sets `price-solo` to `$108` and `price-studio` to `$264`;
  clicking back to monthly restores `$12` / `$29` exactly matching the initial values.
- All four FAQ `<summary>` elements (`faq-0`–`faq-3`) open their `<details>` on click.
- The primary "Explore the workflow" CTA has `href="#workflow"`.
- 1440px viewport: desktop nav is visible and `menu-toggle` is hidden.
- JavaScript-disabled context at 360px: mobile nav links, both prices, and the text content of
  the Connect and Export panels are all present in the rendered page.
- Visual review via full-page screenshots at 360px and 1440px to check layout, spacing, and
  hierarchy.

All of the above passed (21/21 automated assertions). Automated checks did not include a
screen-reader pass with an actual assistive-technology tool, or cross-browser testing beyond
Chromium.

## Known limitations

- Only Chromium (via Playwright) was used for verification; behavior in Firefox/Safari was not
  independently tested, though only broadly-supported HTML/CSS/JS features (`<details>`,
  `hidden` attribute, flex/grid, CSS custom properties) are used.
- No automated axe-core/Lighthouse accessibility audit was run; accessibility was addressed by
  construction (semantic roles, labels, focus-visible styles, skip link) and spot-checked
  manually, not machine-scored.
- The hero illustration is a stylized mockup, not a functioning app — it is explicitly
  decorative (`aria-hidden="true"`).
