(function () {
  "use strict";

  /* ---------- Mobile navigation ---------- */
  var menuToggle = document.querySelector('[data-testid="menu-toggle"]');
  var mobileNav = document.getElementById("mobile-nav");

  if (menuToggle && mobileNav) {
    // Start collapsed once JS is available; without JS the nav stays visible.
    mobileNav.hidden = true;

    function openMenu() {
      mobileNav.hidden = false;
      menuToggle.setAttribute("aria-expanded", "true");
    }

    function closeMenu(returnFocus) {
      mobileNav.hidden = true;
      menuToggle.setAttribute("aria-expanded", "false");
      if (returnFocus) {
        menuToggle.focus();
      }
    }

    menuToggle.addEventListener("click", function () {
      var isOpen = menuToggle.getAttribute("aria-expanded") === "true";
      if (isOpen) {
        closeMenu(false);
      } else {
        openMenu();
      }
    });

    mobileNav.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        closeMenu(true);
      }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && menuToggle.getAttribute("aria-expanded") === "true") {
        closeMenu(true);
      }
    });

    mobileNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        closeMenu(false);
      });
    });
  }

  /* ---------- Feature tabs ---------- */
  var tablist = document.querySelector('.tablist[role="tablist"]');
  var tabs = tablist ? Array.prototype.slice.call(tablist.querySelectorAll('[role="tab"]')) : [];

  function selectTab(tab, moveFocus) {
    tabs.forEach(function (t) {
      var panel = document.getElementById(t.getAttribute("aria-controls"));
      var isSelected = t === tab;
      t.setAttribute("aria-selected", isSelected ? "true" : "false");
      t.tabIndex = isSelected ? 0 : -1;
      t.classList.toggle("is-active", isSelected);
      if (panel) {
        panel.hidden = !isSelected;
      }
    });
    if (moveFocus) {
      tab.focus();
    }
  }

  if (tabs.length) {
    // Ensure only the active tab's panel is visible once JS runs.
    var activeTab = tabs.filter(function (t) {
      return t.getAttribute("aria-selected") === "true";
    })[0] || tabs[0];
    selectTab(activeTab, false);

    tabs.forEach(function (tab, index) {
      tab.addEventListener("click", function () {
        selectTab(tab, false);
      });

      tab.addEventListener("keydown", function (event) {
        var newIndex = null;
        if (event.key === "ArrowRight" || event.key === "ArrowDown") {
          newIndex = (index + 1) % tabs.length;
        } else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
          newIndex = (index - 1 + tabs.length) % tabs.length;
        } else if (event.key === "Home") {
          newIndex = 0;
        } else if (event.key === "End") {
          newIndex = tabs.length - 1;
        }
        if (newIndex !== null) {
          event.preventDefault();
          selectTab(tabs[newIndex], true);
        }
      });
    });
  }

  /* ---------- Billing toggle ---------- */
  var monthlyBtn = document.querySelector('[data-testid="billing-monthly"]');
  var yearlyBtn = document.querySelector('[data-testid="billing-yearly"]');
  var priceSolo = document.querySelector('[data-testid="price-solo"]');
  var priceStudio = document.querySelector('[data-testid="price-studio"]');
  var soloSuffix = document.querySelector('[data-testid="price-solo-suffix"]');
  var studioSuffix = document.querySelector('[data-testid="price-studio-suffix"]');
  var periodLabel = document.querySelector('[data-testid="billing-period-label"]');

  var PRICES = {
    monthly: { solo: "$12", studio: "$29", suffix: "/ month", label: "Billed monthly" },
    yearly: { solo: "$108", studio: "$264", suffix: "/ year", label: "Billed yearly" }
  };

  function setBilling(period) {
    var values = PRICES[period];
    if (!values) return;

    if (priceSolo) priceSolo.textContent = values.solo;
    if (priceStudio) priceStudio.textContent = values.studio;
    if (soloSuffix) soloSuffix.textContent = values.suffix;
    if (studioSuffix) studioSuffix.textContent = values.suffix;
    if (periodLabel) periodLabel.textContent = values.label;

    var monthlyActive = period === "monthly";
    if (monthlyBtn) {
      monthlyBtn.classList.toggle("is-active", monthlyActive);
      monthlyBtn.setAttribute("aria-pressed", monthlyActive ? "true" : "false");
    }
    if (yearlyBtn) {
      yearlyBtn.classList.toggle("is-active", !monthlyActive);
      yearlyBtn.setAttribute("aria-pressed", !monthlyActive ? "true" : "false");
    }
  }

  if (monthlyBtn && yearlyBtn) {
    monthlyBtn.addEventListener("click", function () { setBilling("monthly"); });
    yearlyBtn.addEventListener("click", function () { setBilling("yearly"); });
  }
})();
