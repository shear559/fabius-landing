# Solution

## 1. Problem

For every real $t \in [-2,4]$, solve

$$\min_{x,y,z}\; f_t(x,y,z) = x^2+2y^2+3z^2+xy-yz+(2-2t)x+5y+z$$
$$\text{s.t. } x+y+z=1,\quad x\ge 0,\ y\ge0,\ z\ge0,\quad x\le \tfrac35,\quad 2y+z\ge\tfrac12 .$$

## 2. Reduction to two variables

Eliminate $z=1-x-y$ using the equality constraint. Substituting and expanding (full expansion checked by computer algebra, see `verification.md`):

$$g_t(x,y) := f_t(x,y,1-x-y) = 4x^2+8xy+6y^2-(5+2t)x-3y+4. \tag{$\star$}$$

The remaining constraints become the polygon $P\subset\mathbb R^2$:

$$x\ge0,\quad y\ge0,\quad x+y\le1\ (\Leftrightarrow z\ge0),\quad x\le\tfrac35,\quad y\ge x-\tfrac12\ (\Leftrightarrow 2y+z\ge\tfrac12).$$

**$P$ is a fixed pentagon, independent of $t$.** Its edges are the five lines above; intersecting them pairwise and discarding infeasible intersections gives exactly five vertices (each other pairwise intersection violates some constraint, checked below):

$$V_1=(0,0),\ V_2=(\tfrac12,0),\ V_3=(\tfrac35,\tfrac1{10}),\ V_4=(\tfrac35,\tfrac25),\ V_5=(0,1),$$

connected in this cyclic order by the edges $y=0$ ($V_1V_2$), $y=x-\tfrac12$ ($V_2V_3$), $x=\tfrac35$ ($V_3V_4$), $x+y=1$ ($V_4V_5$), $x=0$ ($V_5V_1$). $P$ is convex (intersection of five half-planes) and has nonempty interior (e.g. $(0.3,0.3)$ satisfies all five constraints strictly), so **Slater's condition holds and no constraint qualification issue can arise anywhere on $P$.**

*Why these are the only vertices:* the $\binom52=10$ pairwise line intersections are $(0,0),(0,1),(0,-\tfrac12),(\tfrac35,0),(1,0),(\tfrac12,0),(\tfrac35,\tfrac25),(\tfrac34,\tfrac14),(\tfrac35,\tfrac1{10})$, and one pair of parallel lines ($x=0,x=\tfrac35$) which never meet. Checking each candidate against all five constraints eliminates $(0,-\tfrac12)$ [$y<0$], $(\tfrac35,0)$ [$z=\tfrac25$, so $2y+z=\tfrac25<\tfrac12$ fails], $(1,0)$ [$x>\tfrac35$], $(\tfrac34,\tfrac14)$ [$x>\tfrac35$] — leaving exactly the five vertices listed.

## 3. The problem is a strictly convex QP for every $t$

The Hessian of $g_t$ (independent of $t$) is
$$H=\begin{pmatrix}8&8\\8&12\end{pmatrix},\qquad \det H = 96-64=32>0,\quad \operatorname{tr}H=20>0,$$
so $H\succ0$: $g_t$ is **strictly convex** for every $t$. $P$ is convex and compact. Hence for every $t$:

* a minimizer exists (continuous function on a nonempty compact set),
* it is **unique** (strict convexity: if $u\ne v$ both minimized $g_t$ on the convex set $P$, the midpoint would give a strictly smaller value, contradiction),
* KKT conditions are both **necessary and sufficient** for global optimality (convex objective, linear/affine constraints ⇒ no duality gap, Slater holds).

So it suffices to exhibit, for each $t$, a point of $P$ and multipliers satisfying KKT; uniqueness and global optimality then follow automatically from the argument above — no case can be "missed" because KKT sufficiency covers the entire feasible set, not just a checked subset.

## 4. KKT system

Write the five inequality constraints as $c_i\ge0$ with gradients (in $(x,y,z)$):
$$c_1=x,\ \nabla c_1=(1,0,0);\quad c_2=y,\ \nabla c_2=(0,1,0);\quad c_3=z,\ \nabla c_3=(0,0,1);$$
$$c_4=\tfrac35-x,\ \nabla c_4=(-1,0,0);\quad c_5=2y+z-\tfrac12,\ \nabla c_5=(0,2,1).$$

**Sign convention.** Lagrangian $L=f_t-\nu(x+y+z-1)-\sum_{i=1}^5\lambda_i c_i$, multipliers $\lambda_i\ge0$ for inequalities, $\nu\in\mathbb R$ free for the equality, complementary slackness $\lambda_i c_i=0$. Stationarity:
$$\nabla f_t = \nu(1,1,1)+\lambda_1\nabla c_1+\lambda_2\nabla c_2+\lambda_3\nabla c_3+\lambda_4\nabla c_4+\lambda_5\nabla c_5,$$
i.e. componentwise, with $\nabla f_t=(2x+y+2-2t,\ 4y+x-z+5,\ 6z-y+1)$:
$$2x+y+2-2t=\nu+\lambda_1-\lambda_4,\qquad 4y+x-z+5=\nu+\lambda_2+2\lambda_5,\qquad 6z-y+1=\nu+\lambda_3+\lambda_5.$$

## 5. Solving the parametric family

**Unconstrained stationary point.** Minimizing $(\star)$ freely over $\mathbb R^2$ (no multipliers): $\nabla g_t=0$ gives
$$8x+8y=5+2t,\qquad 8x+12y=3\ \Longrightarrow\ x=\tfrac{9+6t}8,\quad y=-\tfrac{1+t}2. \tag{U}$$
(Equation $8x+12y=3$ does not involve $t$: the unconstrained minimizer always lies on this fixed line as $t$ varies.) Requiring $(x,y)\in P$ from (U) forces simultaneously $t\ge-\tfrac32$ ($x\ge0$), $t\le-1$ ($y\ge0$), $t\le\tfrac32$ ($x+y\le1$), $t\le-0.7$ ($x\le\tfrac35$), $t\le-0.9$ ($y\ge x-\tfrac12$); the binding pair is $t\in[-\tfrac32,-1]$, all other bounds looser. So (U) is feasible **exactly** on $t\in[-\tfrac32,-1]$, touching $x=0$ at $t=-\tfrac32$ and $y=0$ at $t=-1$ — this identifies the two breakpoints adjacent to the unconstrained regime and shows no other constraint can bind before those two.

For $t<-\tfrac32$ track how the optimum leaves through $x=0$; for $t>-1$ track it leaving through $y=0$, then further constraints as $t$ grows. Each candidate below is checked by substituting into $(\star)$, minimizing along the active edge/vertex, and verifying the KKT multiplier signs; each region's multiplier sign condition is an inequality in $t$ that is solved exactly, so the resulting $t$-ranges partition $[-2,4]$ with no gap and no overlap (confirmed in the table of §6).

### Region A: $t\in[-2,-\tfrac32]$ — face $x=0$
Set $x=0$: $g_t(0,y)=6y^2-3y+4$, minimized at $y=\tfrac14\in(0,1)$ (interior of the edge, so $\lambda_2=\lambda_3=\lambda_4=\lambda_5=0$, and the $y$-stationarity is exact, needing no multiplier). Only $\lambda_1$ (for $x\ge0$) can be nonzero. From the $x$-row of §4 with $y=\tfrac14,\nu=\lambda_2=\lambda_4=0$ eliminated via the $z$-row (full 3×3 solve; see `verify.py`):
$$\lambda_1=-3-2t,\qquad \lambda_1\ge0 \iff t\le-\tfrac32.$$
Point: $(x,y,z)=\left(0,\ \tfrac14,\ \tfrac34\right)$, constant on this interval.

### Region B: $t\in[-\tfrac32,-1]$ — interior
$(x,y,z)=\left(\dfrac{9+6t}8,\ -\dfrac{1+t}2,\ \dfrac{3-2t}8\right)$, all multipliers $0$ (shown feasible above; interior since all five constraints strict in the open interval, e.g. at $t=-1.25$: $x=0.1875,y=0.125,z=0.6875$, all strictly interior — and by linearity of $(x(t),y(t))$ in $t$ and the exact endpoint computation, the constraint values change monotonically between the two endpoints, so no other constraint can cross zero inside the open interval).

### Region C: $t\in[-1,-\tfrac12]$ — face $y=0$
Set $y=0$: $g_t(x,0)=4x^2-(5+2t)x+4$, minimized at $x=\tfrac{5+2t}8$. This lies in $\left(0,\tfrac12\right)$ for $t\in(-1,-\tfrac12)$ (endpoints $x=\tfrac38,\tfrac12$), interior of the edge $V_1V_2$ (needs $x\le\tfrac12$ to keep $y\ge x-\tfrac12$, and $x\le\tfrac35$ a fortiori). Multiplier for $y\ge0$:
$$\lambda_2=2t+2,\qquad \lambda_2\ge0\iff t\ge-1.$$
Point: $\left(\dfrac{5+2t}8,\ 0,\ \dfrac{3-2t}8\right)$.

### Region V: $t\in[-\tfrac12,0]$ — vertex $V_2=(\tfrac12,0)$
Both $y=0$ and $y=x-\tfrac12$ active. Solving the $3\times3$ system with $\lambda_1=\lambda_3=\lambda_4=0$:
$$\lambda_2=-2t,\qquad \lambda_5=2t+1,\qquad \text{both}\ge0 \iff -\tfrac12\le t\le0.$$
Point: $\left(\tfrac12,\ 0,\ \tfrac12\right)$, constant.

### Region D: $t\in[0,\tfrac95]$ — face $2y+z=\tfrac12$ (i.e. $y=x-\tfrac12$)
Substitute $y=x-\tfrac12$ into $(\star)$: $g_t(x,x-\tfrac12)=18x^2-(18+2t)x+7$, minimized at $x=\dfrac{9+t}{18}$, which lies in $\left(\tfrac12,\tfrac35\right)$ for $t\in(0,\tfrac95)$ — interior of edge $V_2V_3$. Multiplier:
$$\lambda_5=\frac{10t+9}9,\qquad \lambda_5\ge0\iff t\ge-\tfrac9{10}\ (\text{always true here}).$$
Point: $\left(\dfrac{9+t}{18},\ \dfrac t{18},\ \dfrac{9-2t}{18}\right)$.

### Region F: $t\in[\tfrac95,4]$ — vertex $V_3=(\tfrac35,\tfrac1{10})$
Both $x=\tfrac35$ and $2y+z=\tfrac12$ active. Solving the $3\times3$ system with $\lambda_1=\lambda_2=\lambda_3=0$:
$$\lambda_4=2t-\tfrac{18}5,\qquad \lambda_5=3,\qquad \lambda_4\ge0\iff t\ge\tfrac95,\quad\lambda_5\ge0\ \text{always}.$$
Point: $\left(\tfrac35,\ \tfrac1{10},\ \tfrac3{10}\right)$, constant. Since $\lambda_4$ only grows with $t$ for $t>\tfrac95$, this stays optimal through $t=4$ — no further face is ever entered, so the interval $[\tfrac95,4]$ needs no further subdivision.

**$z\ge0$ never binds.** Across every region above the reported $z$ value is checked $>0$ (values range from $\tfrac3{10}$ to $\tfrac34$), so $\lambda_3=0$ throughout $[-2,4]$; this is consistent with every displayed multiplier system, where $\lambda_3$ was never needed.

## 6. Complete piecewise closed form

| $t$-range | $x(t)$ | $y(t)$ | $z(t)$ | Active set (nonzero $\lambda$'s) |
|---|---|---|---|---|
| $[-2,-\tfrac32]$ | $0$ | $\tfrac14$ | $\tfrac34$ | $x=0$ |
| $[-\tfrac32,-1]$ | $\tfrac98+\tfrac34t$ | $-\tfrac12-\tfrac12t$ | $\tfrac38-\tfrac14t$ | none (interior) |
| $[-1,-\tfrac12]$ | $\tfrac58+\tfrac14t$ | $0$ | $\tfrac38-\tfrac14t$ | $y=0$ |
| $[-\tfrac12,0]$ | $\tfrac12$ | $0$ | $\tfrac12$ | $y=0,\ 2y{+}z=\tfrac12$ |
| $[0,\tfrac95]$ | $\tfrac12+\tfrac t{18}$ | $\tfrac t{18}$ | $\tfrac12-\tfrac t9$ | $2y{+}z=\tfrac12$ |
| $[\tfrac95,4]$ | $\tfrac35$ | $\tfrac1{10}$ | $\tfrac3{10}$ | $x=\tfrac35,\ 2y{+}z=\tfrac12$ |

At every one of the five interior breakpoints ($t=-\tfrac32,-1,-\tfrac12,0,\tfrac95$) the two adjoining formulas for $(x,y,z)$ agree exactly (substitute the breakpoint value into both neighboring rows), and the multiplier that becomes active is exactly $0$ there (e.g. $\lambda_1=-3-2t=0$ at $t=-\tfrac32$; $\lambda_2=2t+2=0$ at $t=-1$; $\lambda_2=-2t=0$ at $t=0$; $\lambda_5=\tfrac{10t+9}9=0$ at $t=-\tfrac9{10}$ is *not* a breakpoint — the true transition at $t=0$ is $\lambda_2=0$ turning off while $\lambda_5=2t+1=1>0$ stays on, matching Region D's start; and $\lambda_4=2t-\tfrac{18}5=0$ at $t=\tfrac95$). Hence $x(t),y(t),z(t)$ are continuous, piecewise-affine, on all of $[-2,4]$, and the six regions cover $[-2,4]$ with shared endpoints and no gap — this rules out any missed regime: the case analysis was driven by the *complete* list of sign conditions on all five multipliers (§5), and each transition $t$-value was solved for exactly, not guessed.

## 7. Optimal value function

Since $z=1-x-y$, $f_t^\*(t):=g_t(x(t),y(t))$ evaluates to:

$$f_t^\* = \begin{cases}
\dfrac{29}8, & t\in[-2,-\tfrac32]\\[4pt]
-\dfrac34t^2-\dfrac94t+\dfrac{31}{16}, & t\in[-\tfrac32,-1]\\[4pt]
-\dfrac14t^2-\dfrac54t+\dfrac{39}{16}, & t\in[-1,-\tfrac12]\\[4pt]
\dfrac52-t, & t\in[-\tfrac12,0]\\[4pt]
-\dfrac1{18}t^2-t+\dfrac52, & t\in[0,\tfrac95]\\[4pt]
\dfrac{67}{25}-\dfrac65t, & t\in[\tfrac95,4]
\end{cases}$$

(Each piece obtained by substituting the region's $(x(t),y(t))$ into $(\star)$ and simplifying; independently re-derived and confirmed by computer algebra, see `verification.md`.)

**Continuity ($C^0$).** Evaluating adjacent pieces at each breakpoint gives equal values: $t=-\tfrac32\Rightarrow\tfrac{29}8$ both sides; $t=-1\Rightarrow\tfrac{55}{16}$ both sides; $t=-\tfrac12\Rightarrow3$ both sides; $t=0\Rightarrow\tfrac52$ both sides; $t=\tfrac95\Rightarrow\tfrac{13}{25}$ both sides. So $f_t^\*$ is continuous on $[-2,4]$.

**Differentiability ($C^1$, but not $C^2$).** By the envelope theorem, since $t$ enters $f_t$ only through the term $(2-2t)x$, $\dfrac{d}{dt}f_t^\* = \dfrac{\partial f_t}{\partial t}\Big|_{\text{optimum}} = -2\,x(t)$ at every $t$ where $x(\cdot)$ is differentiable (true on the interior of each region; the envelope theorem extends to the breakpoints too because $x(t)$ itself is continuous there, matching one-sided derivatives of $f_t^\*$ computed directly from each piece — e.g. at $t=-\tfrac32$: left piece $\frac{d}{dt}\tfrac{29}8=0$, right piece $-\tfrac32t-\tfrac94\big|_{t=-3/2}=0$; at $t=-1$: $-\tfrac32t-\tfrac94\big|_{-1}=-\tfrac34$, and $-\tfrac12t-\tfrac54\big|_{-1}=-\tfrac34$; at $t=-\tfrac12$: $-\tfrac12t-\tfrac54\big|_{-1/2}=-1$, and slope of $\tfrac52-t$ is $-1$; at $t=0$: slope $-1$ matches $-\tfrac19t-1\big|_0=-1$; at $t=\tfrac95$: $-\tfrac19t-1\big|_{9/5}=-\tfrac65$, matches slope $-\tfrac65$ of the last piece). So $f_t^\*\in C^1[-2,4]$. It is **not** $C^2$: $x(t)$ is piecewise-affine with a different slope in each region ($0,\ \tfrac34,\ \tfrac14,\ 0,\ \tfrac1{18},\ 0$), so $x'(t)$ — and hence $(f_t^\*)''=-2x'(t)$ — jumps at every breakpoint. This is the expected behavior for the value function of a parametric strictly-convex QP: $C^1$ always (envelope theorem, valid because the minimizer is continuous and unique), with kinks in the derivative exactly where the active set changes.

## 8. Summary answer

For $t\in[-2,4]$ the unique global minimizer is:

$$(x,y,z)(t)=\begin{cases}
(0,\ \tfrac14,\ \tfrac34) & t\in[-2,-1.5]\\
\left(\tfrac98+\tfrac34t,\ -\tfrac12-\tfrac12t,\ \tfrac38-\tfrac14t\right) & t\in[-1.5,-1]\\
\left(\tfrac58+\tfrac14t,\ 0,\ \tfrac38-\tfrac14t\right) & t\in[-1,-0.5]\\
(\tfrac12,\ 0,\ \tfrac12) & t\in[-0.5,0]\\
\left(\tfrac12+\tfrac t{18},\ \tfrac t{18},\ \tfrac12-\tfrac t9\right) & t\in[0,1.8]\\
(\tfrac35,\ \tfrac1{10},\ \tfrac3{10}) & t\in[1.8,4]
\end{cases}$$

with optimal value $f_t^\*$ as in §7. Both are single-valued, continuous functions of $t$ on the whole interval, and $(x,y,z)(t)$ is the *unique* minimizer at every $t$ (§3).
