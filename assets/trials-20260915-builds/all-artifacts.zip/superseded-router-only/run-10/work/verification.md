# Verification

All checks were executed locally (no network, no files outside this directory). Python 3, with SciPy 1.13.1 and SymPy 1.14.0 available and used only for cross-checking — `solution.py` itself imports nothing beyond the standard library.

## What was checked, and how

1. **Algebraic reduction $(\star)$ is correct.** The substitution $z=1-x-y$ into $f_t$ was expanded independently by hand and with SymPy (`sympy.expand`); both give
   $g_t(x,y)=4x^2+8xy+6y^2-(5+2t)x-3y+4$. Spot-checked at three explicit points against the *original* 3-variable formula ($(x,y,z,t)=(1,0,0,0)\to3$; $(0,1,0,1)\to7$; $(0,0,1,-1)\to4$) — matched exactly.

2. **Per-region formulas.** For each of the six regions, SymPy independently (a) solved $\partial g_t/\partial x=\partial g_t/\partial y=0$ or the reduced 1-D stationarity condition on the active edge, and (b) simplified the resulting value $g_t(x(t),y(t))$. The results were compared term-by-term against the by-hand derivation in `solution.md` §5–7 and are identical.

3. **Full 3×3 KKT system.** For each region, the $3\times3$ linear system in $(\nu,\lambda_i,\lambda_j)$ from §4 of `solution.md` was solved symbolically with SymPy at the candidate point, confirming the exact multiplier formulas quoted in §5 (e.g. $\lambda_1=-3-2t$, $\lambda_2=2t+2$, $\lambda_5=\tfrac{10t+9}9$, $\lambda_4=2t-\tfrac{18}5$), and that $\nu$ itself is continuous across every breakpoint (additional consistency check, not required for the proof but a strong sanity signal).

4. **Numerical cross-check against an independent solver.** `verify.py` calls `scipy.optimize.minimize` (SLSQP) on the *original* 6-constrained 3-variable problem, from 6 different starting points per $t$, keeping the best result, for 42 values of $t$: the 5 interior breakpoints, both endpoints $-2,4$, points $\pm10^{-6}$ on either side of every interior breakpoint (continuity / regime-boundary check), and 25 uniform random points in $[-2,4]$. Maximum observed discrepancy between `solution.solve(t)` and the SciPy oracle, over all 42 points:
   ```
   x:     1.4e-08
   y:     8.3e-09
   z:     1.7e-08
   value: 2.8e-13
   ```
   (SLSQP-level numerical noise; not evidence of a formula error given the symbolic derivation above.)

5. **Feasibility.** All 42 returned points satisfy $x+y+z=1$ (to $10^{-9}$), $x,y,z\ge0$, $x\le0.6$, $2y+z\ge0.5$ — 0 violations.

6. **Continuity at breakpoints.** `solve(t)` evaluated at each breakpoint $b\in\{-1.5,-1,-0.5,0,1.8\}$ and at $b\pm10^{-9}$: max discrepancy in $(x,y,z,\text{value})$ across the jump was $2.4\times10^{-9}$ — consistent with the $C^0$ (and, per the envelope-theorem argument in `solution.md` §7, $C^1$) claim, up to floating-point rounding of the breakpoint constants themselves.

7. **KKT stationarity residual, independent of the value derivation.** For 23 values of $t$ (13 fixed representative points plus 10 random), `verify.py` recomputes $\nabla f_t$ at the point returned by `solve(t)` from the *original* 3-variable formula, forms the claimed active-constraint combination with the closed-form multipliers, eliminates the free multiplier $\nu$ by differencing the $x$- and $z$-rows and the $y$- and $z$-rows of the stationarity system, and checks the residual is 0. Result: max residual $8.9\times10^{-16}$ (floating-point roundoff only). All multipliers observed were $\ge0$ (min observed value across all sampled $t$: $0.0$, occurring exactly at a breakpoint where a multiplier turns off).

8. **Standard-library-only / silent import.** Verified `import solution` with stdout captured produces no output, and `solve` takes `int` or `float` and returns a `dict` with finite `x,y,z,value` (checked at $t=-2,0,4$ and elsewhere in the SciPy comparison loop above).

## Reproducing

```
cd <this directory>
python3 verify.py
```
Expected final line: `ALL CHECKS PASSED`. (Requires `scipy` for the cross-check in step 4/7's baseline; `solution.py` alone requires nothing beyond the standard library.)

```python
from solution import solve
solve(2.7)   # -> {'x': ..., 'y': ..., 'z': ..., 'value': ..., 't': 2.7, 'regime': '...'}
```

## Limitations

- The SciPy cross-check (step 4) is itself a numerical optimizer (SLSQP with multi-start), not an independent *exact* oracle — it corroborates but does not by itself constitute the proof. The proof of global optimality and uniqueness is the KKT-sufficiency argument in `solution.md` §3–6 (strict convexity of the reduced quadratic + convex compact feasible polygon ⇒ KKT necessary and sufficient, and a complete, non-overlapping partition of $[-2,4]$ by exact multiplier sign conditions).
- Floating-point breakpoint constants (e.g. `1.8` for $9/5$) are exactly representable to double precision in the sense that Python parses `1.8` and computes `9/5` to the same nearest double, so no boundary ambiguity arises in `solution.py`; this was not separately re-derived for every other rational breakpoint but all are simple dyadic-adjacent fractions with no observed rounding issue in the checks above.
- No internet access, external files, or hidden evaluation material were used; all checks above were run against `solution.py` and the original problem statement in `BRIEF.md` only.
