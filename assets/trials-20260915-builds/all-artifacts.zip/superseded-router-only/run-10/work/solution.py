"""
Closed-form solver for:

    minimize   f_t(x,y,z) = x^2 + 2y^2 + 3z^2 + xy - yz + (2-2t)x + 5y + z
    subject to x + y + z = 1,  x,y,z >= 0,  x <= 3/5,  2y + z >= 1/2

for real parameter t. See solution.md for the derivation and proof.

The unique global minimizer (x(t), y(t)) is piecewise-affine in t, split at
the six breakpoints t = -2, -3/2, -1, -1/2, 0, 9/5, 4. Standard library only.
"""


def solve(t):
    t = float(t)

    if t <= -1.5:
        regime = "x=0 (interior in y)"
        x, y = 0.0, 0.25
    elif t <= -1.0:
        regime = "interior (unconstrained minimizer)"
        x, y = 1.125 + 0.75 * t, -0.5 - 0.5 * t
    elif t <= -0.5:
        regime = "y=0 (interior in x)"
        x, y = 0.625 + 0.25 * t, 0.0
    elif t <= 0.0:
        regime = "vertex x=1/2, y=0"
        x, y = 0.5, 0.0
    elif t <= 1.8:
        regime = "2y+z=1/2 (interior along that edge)"
        x, y = 0.5 + t / 18.0, t / 18.0
    else:
        regime = "vertex x=3/5, y=1/10"
        x, y = 0.6, 0.1

    z = 1.0 - x - y
    value = x * x + 2 * y * y + 3 * z * z + x * y - y * z + (2 - 2 * t) * x + 5 * y + z

    return {
        "x": x,
        "y": y,
        "z": z,
        "value": value,
        "t": t,
        "regime": regime,
    }
