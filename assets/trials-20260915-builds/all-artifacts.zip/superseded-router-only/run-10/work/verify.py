"""
Verification script for solution.py.

Checks, for many values of t in [-2, 4]:
  1. Feasibility of (x, y, z) returned by solve(t).
  2. Agreement of solve(t) with an independent numerical solver (SciPy SLSQP,
     multi-start) on x, y, z and the objective value.
  3. Continuity of solve(t) across the six regime breakpoints, approaching
     from both sides.
  4. KKT stationarity: at the reported point, the objective gradient equals
     a non-negative combination of the gradients of the active constraints
     (checked against the closed-form multipliers derived in solution.md).

Run:  python3 verify.py
Requires scipy (only used here, for cross-checking; solution.py itself has
no dependency beyond the standard library).
"""
import random

from solution import solve

TOL = 1e-6


def f_orig(x, y, z, t):
    return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z


def feasible(x, y, z, tol=1e-9):
    checks = {
        "x+y+z=1": abs(x + y + z - 1) <= tol,
        "x>=0": x >= -tol,
        "y>=0": y >= -tol,
        "z>=0": z >= -tol,
        "x<=3/5": x <= 0.6 + tol,
        "2y+z>=1/2": 2*y + z >= 0.5 - tol,
    }
    return checks


def scipy_solve(t):
    from scipy.optimize import minimize
    cons = [
        {"type": "eq", "fun": lambda v: v[0] + v[1] + v[2] - 1},
        {"type": "ineq", "fun": lambda v: v[0]},
        {"type": "ineq", "fun": lambda v: v[1]},
        {"type": "ineq", "fun": lambda v: v[2]},
        {"type": "ineq", "fun": lambda v: 0.6 - v[0]},
        {"type": "ineq", "fun": lambda v: 2*v[1] + v[2] - 0.5},
    ]
    starts = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (0.3, 0.3, 0.4), (0.6, 0.1, 0.3), (0.5, 0, 0.5)]
    best = None
    for x0 in starts:
        res = minimize(lambda v: f_orig(v[0], v[1], v[2], t), x0, constraints=cons,
                        method="SLSQP", options={"ftol": 1e-14, "maxiter": 2000})
        if res.success and (best is None or res.fun < best.fun):
            best = res
    return best


def check_feasibility_and_oracle():
    random.seed(0)
    ts = [-2, -1.5, -1, -0.5, 0, 1.8, 4]
    ts += [b + eps for b in [-1.5, -1, -0.5, 0, 1.8] for eps in (-1e-6, 1e-6)]
    ts += [random.uniform(-2, 4) for _ in range(25)]

    max_err = {"x": 0.0, "y": 0.0, "z": 0.0, "value": 0.0}
    n_infeasible = 0
    for t in ts:
        r = solve(t)
        checks = feasible(r["x"], r["y"], r["z"])
        if not all(checks.values()):
            n_infeasible += 1
            print(f"INFEASIBLE at t={t}: {checks}")

        best = scipy_solve(t)
        for key, val in (("x", r["x"]), ("y", r["y"]), ("z", r["z"]), ("value", r["value"])):
            oracle_val = val if key == "value" else best.x[{"x": 0, "y": 1, "z": 2}[key]]
        ox, oy, oz = best.x
        ov = best.fun
        max_err["x"] = max(max_err["x"], abs(r["x"] - ox))
        max_err["y"] = max(max_err["y"], abs(r["y"] - oy))
        max_err["z"] = max(max_err["z"], abs(r["z"] - oz))
        max_err["value"] = max(max_err["value"], abs(r["value"] - ov))

    print("feasibility violations:", n_infeasible, "out of", len(ts))
    print("max |solve - scipy_oracle| per field:", max_err)
    assert n_infeasible == 0
    assert all(e < 1e-4 for e in max_err.values())


def check_continuity():
    breakpoints = [-1.5, -1, -0.5, 0, 1.8]
    max_jump = 0.0
    for b in breakpoints:
        left = solve(b - 1e-9)
        right = solve(b + 1e-9)
        at = solve(b)
        for k in ("x", "y", "z", "value"):
            max_jump = max(max_jump, abs(left[k] - right[k]), abs(at[k] - right[k]))
    print("max discontinuity across breakpoints:", max_jump)
    assert max_jump < 1e-6


def check_kkt_stationarity():
    # Active-constraint gradients (as functions of (x,y,z)); grad f must equal
    # nu*(1,1,1) + sum(lambda_i * grad h_i) with lambda_i >= 0 on active ones.
    import itertools

    def grad_f(x, y, z, t):
        return (2*x + y + (2 - 2*t), 4*y + x - z + 5, 6*z - y + 1)

    # closed-form multipliers by regime, from solution.md
    def multipliers(t):
        if t <= -1.5:
            return {"l1": -3 - 2*t}  # x>=0
        elif t <= -1.0:
            return {}
        elif t <= -0.5:
            return {"l2": 2*t + 2}  # y>=0
        elif t <= 0.0:
            return {"l2": -2*t, "l5": 2*t + 1}  # y>=0, 2y+z>=1/2
        elif t <= 1.8:
            return {"l5": 10*t/9 + 1}  # 2y+z>=1/2
        else:
            return {"l4": 2*t - 3.6, "l5": 3.0}  # x<=3/5, 2y+z>=1/2

    grads = {
        "l1": (1, 0, 0),    # x >= 0
        "l2": (0, 1, 0),    # y >= 0
        "l3": (0, 0, 1),    # z >= 0
        "l4": (-1, 0, 0),   # 3/5 - x >= 0
        "l5": (0, 2, 1),    # 2y + z - 1/2 >= 0
    }

    random.seed(1)
    ts = [-2, -1.7, -1.5, -1.25, -1, -0.7, -0.5, -0.2, 0, 0.9, 1.8, 2.5, 4]
    ts += [random.uniform(-2, 4) for _ in range(10)]

    max_resid = 0.0
    min_mult = float("inf")
    for t in ts:
        r = solve(t)
        mults = multipliers(t)
        for name, lam in mults.items():
            min_mult = min(min_mult, lam)
        gx, gy, gz = grad_f(r["x"], r["y"], r["z"], t)
        # nu is free (equality constraint multiplier); eliminate it by taking
        # differences of the stationarity equations (x-eq minus z-eq, y-eq minus z-eq)
        sx = sum(lam * grads[name][0] for name, lam in mults.items())
        sy = sum(lam * grads[name][1] for name, lam in mults.items())
        sz = sum(lam * grads[name][2] for name, lam in mults.items())
        # grad f - nu*1 - s = 0  =>  (grad f - s) must be constant across x,y,z (that constant is nu)
        c1 = (gx - sx) - (gz - sz)
        c2 = (gy - sy) - (gz - sz)
        max_resid = max(max_resid, abs(c1), abs(c2))

    print("max KKT stationarity residual:", max_resid)
    print("min multiplier value observed (should be >= 0):", min_mult)
    assert max_resid < 1e-9
    assert min_mult >= -1e-9


if __name__ == "__main__":
    check_feasibility_and_oracle()
    check_continuity()
    check_kkt_stationarity()
    print("ALL CHECKS PASSED")
