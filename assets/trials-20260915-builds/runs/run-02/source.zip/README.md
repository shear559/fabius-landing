# Lattice — fictional product landing page

A static, vanilla HTML/CSS/JS marketing page for **Lattice**, a fictional local-first
research notebook. Built for evaluation only — no real product, business, or backend
exists behind it.

## Run it

No build step. Serve the three files (`index.html`, `styles.css`, `app.js`) from any
static file server, at the root or a nested path, since all asset references are
relative:

```sh
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

Opening `index.html` directly via `file://` also works.

## Implementation decisions

- **Visual system**: a single accent (deep teal-green `#2a5d50`), a warm off-white
  canvas, one type ladder, an 8px spacing unit, and two radius grammars (pill for
  controls, rounded-rect for cards). Sections alternate canvas/off-white surfaces
  instead of using dividers.
- **Hero illustration**: an original inline SVG mock of the Lattice UI (a note list,
  a source panel, and a small linked-notes graph) rather than a screenshot or stock
  art, built from the same design tokens via CSS custom properties inside the SVG.
- **Mobile nav progressive enhancement**: the mobile nav is always present in the
  DOM. An inline `<script>` in `<head>` adds a `js` class to `<html>`; CSS only
  hides/shows the mobile nav via that class. With JavaScript disabled, the class is
  never added, so the nav renders inline and stays discoverable instead of being
  stuck behind an inert toggle.
- **Feature tabs progressive enhancement**: all three panels ship visible in the
  markup (no `hidden` attribute in HTML). `app.js` hides the non-selected panels at
  runtime. With JavaScript disabled, all three feature panels are readable in a
  stacked layout.
- **Pricing**: the monthly figures ($12 / $29) are in the HTML by default, so prices
  are visible with JavaScript disabled. The yearly button ($108 / $264) requires
  JavaScript to switch the displayed values, which is disclosed as expected static
  behavior in Known limitations.
- **FAQ**: native `<details>/<summary>`, so expand/collapse needs no JavaScript.
- **Reduced motion**: a `prefers-reduced-motion: reduce` query collapses all
  transition/animation durations to near-zero; the only motion in the default case
  is a small button-press scale and a smooth-scroll on anchor links.

## Checks actually executed

Using a headless Chromium (Playwright) driving a local `python3 -m http.server`, with
a disposable test script that was removed after use (not part of the delivered
artifact):

- Mobile menu (360px viewport): toggle opens `mobile-nav` and sets
  `aria-expanded="true"`; `Escape` closes it, sets `aria-expanded="false"`, and
  returns focus to the toggle button; clicking a nav link inside `mobile-nav` closes
  it.
- Feature tabs: `panel-capture` visible and others hidden by default after JS runs;
  clicking `feature-connect` selects it (`aria-selected="true"`) and swaps visible
  panels; `ArrowRight` from a focused tab moves focus to the next tab in sequence
  (capture → connect → export).
- Billing toggle: initial prices read `$12` / `$29`; clicking `billing-yearly`
  updates them to `$108` / `$264`; clicking `billing-monthly` restores the exact
  original `$12` / `$29` values.
- FAQ: all four `faq-0`..`faq-3` summaries exist and a `<details>` element opens on
  click.
- Primary CTA `"Explore the workflow"` has `href="#workflow"`.
- JavaScript-disabled context: mobile nav links, the monthly price, and both feature
  panels remain visible/discoverable.
- Nested path: copied the three files into a subdirectory two levels deep, served
  from a separate port, and confirmed `index.html`, `styles.css`, and `app.js` all
  return HTTP 200 via their relative references.
- Rendered full-page screenshots at 360px and 1440px viewports and visually reviewed
  layout, spacing, and hierarchy at both sizes.
- Computed WCAG contrast ratios for the color pairs actually used (accent-on-canvas,
  accent-on-white, body text, muted text, button text-on-accent): all ≥ 5.1:1,
  clearing the 4.5:1 AA text threshold.
- During this pass, found and fixed a CSS cascade bug where the `.btn` class
  (defined later in the stylesheet) overrode `.desktop-only`'s `display: none` at
  mobile widths because both rules had equal specificity — the desktop "See
  pricing" button was incorrectly showing on a 360px viewport. Fixed by scoping the
  hide/show rule to `.header-actions .desktop-only` and re-verified.

Not executed: no automated axe/Lighthouse accessibility audit, no screen-reader
pass, no cross-browser testing beyond Chromium, no visual regression tooling.

## Known limitations

- Billing period switching (monthly ↔ yearly) requires JavaScript; without it, the
  page shows monthly pricing only, which is still a real, correct price for the
  product as marketed on the static page.
- The hero illustration is a static, non-interactive SVG mockup, not a functional
  preview of an actual application.
- No automated accessibility scanner (e.g. axe-core) was run; contrast was checked
  manually via WCAG relative-luminance formulas for the specific color pairs in use,
  and keyboard/focus behavior was checked via the interaction script above, not a
  full manual screen-reader pass.
- Content, prices, and the "fictional demonstration" framing are fictional and
  supplied by the brief; no real customers, reviews, or performance figures are
  represented, invented, or implied anywhere on the page.
