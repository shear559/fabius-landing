"""
Independent numerical verification of solution.py's solve(t) against:
  (1) an independent numerical solver (scipy SLSQP) over many t values,
      including all five breakpoints and points arbitrarily close on
      either side;
  (2) feasibility of the returned point for every constraint;
  (3) that solve(t) actually returns the stationary point of f_t restricted
      to the returned active set (residual of the reduced gradient);
  (4) continuity of x(t),y(t),z(t),value(t) on a dense grid;
  (5) non-negativity of all KKT multipliers returned by solve(t);
  (6) the envelope-theorem identity v'(t) = -2 x(t) via a finite-difference
      check of the value function;
  (7) that importing solution.py produces no stdout output.

Requires: numpy, scipy (only for this independent check -- solution.py
itself uses only the standard library). Run with:
    python3 verify.py
"""
import io
import contextlib
import random
import sys

import numpy as np
from scipy.optimize import minimize, LinearConstraint, Bounds

from solution import solve, T_MIN, T_MAX


def f(v, t):
    x, y, z = v
    return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z


def grad(v, t):
    x, y, z = v
    return np.array([2*x + y + (2 - 2*t), 4*y + x - z + 5, 6*z - y + 1])


def independent_scipy_solve(t):
    lc_eq = LinearConstraint([[1, 1, 1]], 1, 1)
    lc_x = LinearConstraint([[1, 0, 0]], -np.inf, 3/5)
    lc_yz = LinearConstraint([[0, 2, 1]], 0.5, np.inf)
    bounds = Bounds([0, 0, 0], [np.inf, np.inf, np.inf])
    best = None
    for x0 in ([0.2, 0.2, 0.6], [0.0, 0.5, 0.5], [0.6, 0.0, 0.4], [0.3, 0.3, 0.4]):
        res = minimize(f, np.array(x0), args=(t,), jac=grad, method='SLSQP',
                        constraints=[lc_eq, lc_x, lc_yz], bounds=bounds,
                        options={'ftol': 1e-15, 'maxiter': 2000})
        if best is None or res.fun < best.fun:
            best = res
    return best


def check_import_is_silent():
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        import importlib
        import solution as _s
        importlib.reload(_s)
    out = buf.getvalue()
    assert out == '', f"import produced output: {out!r}"
    print("[OK] import solution -> no stdout output")


def check_against_scipy():
    random.seed(0)
    breakpoints = [-2, -1.5, -1, -0.5, 0, 1.8, 4]
    near = []
    for b in breakpoints:
        near += [b - 1e-3, b - 1e-6, b + 1e-6, b + 1e-3]
    ts = breakpoints + [t for t in near if T_MIN <= t <= T_MAX]
    ts += [round(random.uniform(T_MIN, T_MAX), 5) for _ in range(80)]

    worst_x, worst_v = 0.0, 0.0
    for t in ts:
        res = independent_scipy_solve(t)
        mine = solve(t)
        err_x = abs(res.x[0]-mine['x']) + abs(res.x[1]-mine['y']) + abs(res.x[2]-mine['z'])
        err_v = abs(res.fun - mine['value'])
        worst_x, worst_v = max(worst_x, err_x), max(worst_v, err_v)
        assert err_x < 1e-4, (t, res.x, mine)
        assert err_v < 1e-4, (t, res.fun, mine['value'])
    print(f"[OK] {len(ts)} points agree with independent scipy SLSQP solve "
          f"(max coord err {worst_x:.2e}, max value err {worst_v:.2e})")


def check_feasibility_and_value_dense():
    n = 6001
    bad_feas = bad_val = 0
    for i in range(n):
        t = T_MIN + (T_MAX - T_MIN) * i / (n - 1)
        r = solve(t)
        x, y, z = r['x'], r['y'], r['z']
        feasible = (abs(x + y + z - 1) < 1e-9 and x >= -1e-9 and y >= -1e-9
                    and z >= -1e-9 and x <= 0.6 + 1e-9 and 2*y + z >= 0.5 - 1e-9)
        if not feasible:
            bad_feas += 1
        if abs(f((x, y, z), t) - r['value']) > 1e-9:
            bad_val += 1
    assert bad_feas == 0, bad_feas
    assert bad_val == 0, bad_val
    print(f"[OK] {n} grid points: all feasible, f_t(x,y,z) == returned value")


def check_continuity_dense():
    n = 4001
    prev = None
    max_jump = 0.0
    step = (T_MAX - T_MIN) / (n - 1)
    for i in range(n):
        t = T_MIN + step * i
        r = solve(t)
        cur = (r['x'], r['y'], r['z'], r['value'])
        if prev is not None:
            max_jump = max(max_jump, max(abs(a - b) for a, b in zip(cur, prev)))
        prev = cur
    # a continuous, piecewise-Lipschitz function can only jump by ~O(step);
    # slopes here are bounded by a small constant, so this bounds max_jump tightly.
    assert max_jump < 10 * step, max_jump
    print(f"[OK] continuity: max change between adjacent grid points "
          f"(step={step:.6f}) is {max_jump:.6f}")


def check_kkt_multipliers_nonnegative():
    n = 4001
    for i in range(n):
        t = T_MIN + (T_MAX - T_MIN) * i / (n - 1)
        r = solve(t)
        for k, v in r['multipliers'].items():
            if k.startswith('alpha'):
                assert v >= -1e-8, (t, k, v)
    print(f"[OK] {n} grid points: all KKT inequality multipliers alpha_i >= 0")


def check_envelope_theorem():
    h = 1e-6
    random.seed(2)
    pts = [random.uniform(T_MIN + h, T_MAX - h) for _ in range(40)]
    worst = 0.0
    for t in pts:
        v_plus = solve(t + h)['value']
        v_minus = solve(t - h)['value']
        dv = (v_plus - v_minus) / (2 * h)
        x_t = solve(t)['x']
        worst = max(worst, abs(dv - (-2 * x_t)))
    assert worst < 1e-3, worst
    print(f"[OK] envelope theorem v'(t) = -2 x(t) holds numerically "
          f"(max finite-difference error {worst:.2e})")


def check_reduced_stationarity():
    # At the reported optimum, the projected gradient onto the affine hull of
    # the active constraints (other than the equality) must vanish -- i.e.
    # solve(t) is truly a stationary point of f_t restricted to the active set,
    # not just "close" to the scipy answer.
    n = 200
    for i in range(n):
        t = T_MIN + (T_MAX - T_MIN) * i / (n - 1)
        r = solve(t)
        x, y, z = r['x'], r['y'], r['z']
        g = grad((x, y, z), t)
        active = r['active_set']
        # Build the equality-constraint normal (1,1,1) plus one normal per
        # active inequality, then check g lies in their span (i.e. is
        # orthogonal to the null space of the active constraint normals).
        normals = [np.array([1., 1., 1.])]
        for a in active:
            if a == 'x=0':
                normals.append(np.array([1., 0., 0.]))
            elif a == 'y=0':
                normals.append(np.array([0., 1., 0.]))
            elif a == 'x=3/5':
                normals.append(np.array([1., 0., 0.]))
            elif a == '2y+z=1/2':
                normals.append(np.array([0., 2., 1.]))
        N = np.array(normals)
        # least-squares residual of g against span(N): g - N^T (N N^T)^+ N g
        NNt_pinv = np.linalg.pinv(N @ N.T)
        proj = N.T @ (NNt_pinv @ (N @ g))
        resid = np.linalg.norm(g - proj)
        assert resid < 1e-6, (t, resid, active)
    print(f"[OK] {n} points: gradient of f_t lies in span of active constraint "
          f"normals (true KKT stationarity, not just numerical proximity)")


if __name__ == "__main__":
    check_import_is_silent()
    check_feasibility_and_value_dense()
    check_continuity_dense()
    check_kkt_multipliers_nonnegative()
    check_reduced_stationarity()
    check_envelope_theorem()
    check_against_scipy()
    print("\nAll verification checks passed.")
