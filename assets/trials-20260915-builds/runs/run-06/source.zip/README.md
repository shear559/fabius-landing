# Fieldnote Board

A local-first task board for a small project team. Fictional demonstration app — no backend, no auth, no network calls.

## Run it

No build step and no dependencies. Serve the folder with any static file server and open `index.html`, or open the file directly in a browser. Works from any path depth (all asset references are relative), for example:

```
python3 -m http.server 8080
# then visit http://localhost:8080/index.html
```

## Data model

Stored in `localStorage` under key `fieldnote-board:v1` as `{ schemaVersion: 1, tasks: [...] }`. Each task has exactly: `id`, `title`, `project`, `status` (`todo`/`doing`/`done`), `priority` (`low`/`medium`/`high`), `dueDate` (`""` or `YYYY-MM-DD`), `tags` (≤8 trimmed strings, ≤24 chars each). On genuinely empty storage the app seeds 7 fictional tasks across 2 projects and all 3 statuses. Comma-separated tag input is trimmed and deduplicated case-insensitively before saving.

## Error handling and resilience

- **Corrupt storage** — if the stored value fails to parse or doesn't match the schema, the app never overwrites it. It shows a recovery notice, lets you download the original bytes, and offers an explicit, confirmed reset that seeds a fresh board.
- **Write failures** — if `localStorage.setItem` throws (e.g. quota exceeded), a banner explains the change wasn't saved. The task form stays open with your entered data intact rather than claiming a false success.
- **Cross-tab conflicts** — a `storage` event from another tab shows a conflict banner and blocks status changes, deletes, saves and imports until you explicitly reload the board, so a stale tab can't silently clobber newer data.
- **Delete** is reversible via an "Undo delete" banner that restores the exact record (including its id) and persists across reload once restored.
- **Import** validates schema version, size (≤1 MiB), field shapes, enums, dates and duplicate ids before asking for confirmation; any invalid task rejects the whole file and leaves the current board completely untouched (atomic replace). Imported/typed text is rendered via `textContent`, never `innerHTML`.
- **No JavaScript** — a `<noscript>` banner explains the app needs JavaScript to run.

## Accessibility

- Every control has a real label or `aria-label` (search, filters, per-card status select, edit/delete buttons).
- The task form is a native `<dialog>` opened with `showModal()`: Escape closes it and focus returns to the control that opened it, using the dialog's built-in focus-restore behavior.
- Touch targets are ≥44px; focus rings are visible (`:focus-visible`) and never suppressed.
- `prefers-reduced-motion: reduce` disables all transitions/animations.

## Checks actually run

Verified with headless Chrome (Playwright) against both files opened via `file://` and via a local HTTP server at a nested path (`/nested/deep/path/index.html`) to confirm relative-asset resolution. Covered: seed data shape/counts, create/edit/delete/undo (incl. persistence across reload), status changes, search + all three filters, no-results and empty states, export contents, import validation (malformed JSON, atomic rejection on duplicate id, valid confirmed replace + persistence), corrupt-storage detection/preservation/reset, simulated `localStorage.setItem` throwing, cross-tab conflict detection/blocking/reload-recovery, keyboard Escape + focus restore, and mobile (360px) / desktop (1440px) screenshots. All checks passed at time of delivery; no grader or hidden test file was consulted.

## Known limitations

- Cross-tab reconciliation is block-and-reload rather than automatic merge — the simpler, safer option per the contract, at the cost of an extra click when two tabs are open at once.
- No automated test suite ships in this folder (verification scripts were run locally and discarded); manual re-verification would need to be re-written if desired.
- Corrupt-storage reset re-seeds the sample board rather than leaving storage empty, so recovery always leaves you with a usable board.
