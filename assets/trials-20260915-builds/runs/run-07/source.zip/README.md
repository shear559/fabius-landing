# Fieldnote Board

A local-first task board for a small (fictional) field-research team. No build step, no
dependencies, no network calls, no backend — everything lives in `localStorage` in the
current browser.

## Running it

Serve the three files (`index.html`, `styles.css`, `app.js`) from any static file server,
at the site root or any nested path — all asset references are relative (`./styles.css`,
`./app.js`), so it also works unpacked from a zip or opened directly (`file://`).

```
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

Opening `index.html` directly via `file://` also works (verified during testing).

## Data model

Stored under `localStorage["fieldnote-board:v1"]` as:

```json
{ "schemaVersion": 1, "tasks": [ { "id": "...", "title": "...", "project": "...",
  "status": "todo|doing|done", "priority": "low|medium|high",
  "dueDate": "" | "YYYY-MM-DD", "tags": ["..."] } ] }
```

- `id`: unique, non-empty, ≤80 chars, generated with `crypto.randomUUID()` (fallback
  timestamp+random string if unavailable).
- `title`/`project`: trimmed, non-empty, ≤120/≤80 chars.
- `dueDate`: `""` or a real calendar date (rejects e.g. `2026-02-30` via a UTC round-trip
  check, not just a regex).
- `tags`: ≤8 entries, each trimmed, non-empty, ≤24 chars; comma-separated input is
  split, trimmed, and deduplicated case-insensitively (first-seen casing kept).
- On genuinely empty storage (`localStorage.getItem(...) === null`) the app seeds 7
  fictional tasks across 2 projects (Riverside Trailhead, Harvest Almanac) covering all
  three statuses. Any other value (even `"[]"` or corrupt text) is treated as real data
  and never overwritten by seeding.

## Error handling & recovery design

- **Save failures**: every mutation writes-then-renders. If `localStorage.setItem`
  throws (quota exceeded, storage disabled in a private context, etc.), the in-memory
  task list is *not* updated, a banner says the change was not saved, and the edit form
  (if open) stays open with the user's input intact so nothing is lost — the UI never
  claims a change persisted when it didn't.
- **Corrupt storage on startup**: if the stored value fails `JSON.parse` or fails schema
  validation (bad `schemaVersion`, missing/malformed fields, duplicate ids, etc.), the
  app enters a read-only recovery mode: the raw bytes are kept in memory untouched (nothing
  is written back), a visible banner explains the problem, and two explicit actions are
  offered — **Download original data** (saves the exact raw bytes as a `.json` file) and
  **Reset board** (native `confirm()`, then seeds a fresh valid board and saves it). All
  mutating controls (new task, import) are disabled while in this state so nothing can
  silently paper over the unreadable data.
- **Cross-tab conflicts**: a `storage` event on the board's key (fired only for *other*
  tabs' writes) shows a non-destructive banner and blocks create/edit/delete/status/import
  actions with an explanatory message until the user clicks **Reload board**, which
  re-reads storage from scratch. This guarantees a stale tab can never clobber newer data
  written elsewhere.
- **Import**: validated fully (JSON parse, ≤1 MiB by both `File.size` and re-measured
  decoded byte length, `schemaVersion === 1`, every task's shape/enums/dates, and
  duplicate-id detection across the whole file) *before* anything is written — an invalid
  file leaves the current board completely untouched (atomic replace-or-reject). A valid
  file requires an explicit native `confirm()` naming how many tasks will be replaced.
- **XSS**: all task-derived text (title, project, tags, imported data) is inserted via
  `textContent`/DOM properties, never `innerHTML`, so HTML/script-looking text is always
  rendered as literal text.

## Accessibility & UX

- Every control has a real `<label>` or `aria-label` (per-card status selects are
  labelled "Status for `<task title>`", edit/delete similarly).
- The task form is a modal dialog (`role="dialog"`, `aria-modal`) that traps `Tab`
  focus, closes on `Escape`, and restores focus to whatever opened it.
- Field-level errors use `role="alert"` and are re-validated per submission (blank
  title, overlong text, invalid dates, invalid/too many tags all block submit with a
  visible message).
- `@media (prefers-reduced-motion: reduce)` disables all transitions/animations.
- A `<noscript>` banner explains the app needs JavaScript when it's disabled.
- Layout is mobile-first with explicit breakpoints (single column at 360px, a
  multi-column toolbar and 2–3 column task grid from 720px up, extra breathing room past
  1200px) — verified with 360×800 and 1440×900 screenshots during development.

## Checks actually executed

Using a local Playwright/Chromium script (removed after use — not part of the delivered
app) driving the real `index.html` over `file://`, including a copy placed at a nested
path to confirm relative assets resolve correctly. All 32 checks passed, covering:
seeding (task/project/status counts, schemaVersion), create/edit/delete/undo (including
persistence across reload and that XSS-looking text renders as text), status changes via
the native select, blank-title validation, search + no-results state, export contents,
import atomicity/rejection (duplicate ids) and a confirmed valid import replacing and
surviving reload, startup corruption (banner shown, bytes preserved untouched, controls
disabled, reset produces a valid seeded board), cross-tab conflict detection and blocking
of a destructive edit until reload, Escape-to-close with focus restoration, and
mobile/desktop screenshots.

Not automated: manual verification of dedicated screen-reader output, Safari/Firefox
cross-browser behavior, and true `localStorage` quota-exceeded conditions (the save-failure
path was code-reviewed rather than triggered live, since reliably forcing a quota error
is environment-dependent).

## Known limitations

- Undo is available only for the most recent delete and only within the same page
  session (reloading before clicking Undo makes the deletion final, matching "persists
  across reload once restored").
- Cross-tab reconciliation is block-and-reload rather than automatic merging — chosen
  because silent merging risks losing one tab's edits, whereas an explicit reload is
  always safe and the contract allows either approach.
- No drag-and-drop reordering or bulk actions — out of scope for the stated contract.
