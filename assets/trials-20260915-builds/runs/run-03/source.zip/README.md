# Lattice — fictional landing page demo

A static marketing landing page for **Lattice**, a fictional local-first research
notebook. Built with vanilla HTML, CSS and JavaScript only — no build step, no
frameworks, no remote fonts, no network calls, no backend.

## Running it

Serve the folder with any static file server and open `index.html`, for example:

```
python3 -m http.server 8000
# then visit http://localhost:8000/index.html
```

The page uses only relative asset URLs (`./styles.css`, `./app.js`), so it also
works when served from a nested path (e.g. `http://localhost:8000/some/sub/path/index.html`).
Opening `index.html` directly via `file://` also works.

## Implementation decisions

- **Progressive enhancement for the required test seams.** `app.js` adds a
  `js` class to `<html>` the moment it runs. CSS only hides the mobile nav
  (`[data-testid="mobile-nav"]`) and the inactive feature panels
  (`[data-testid="panel-*"]`) when that class is present. With JavaScript
  disabled, the mobile nav renders as a plain visible list and all three
  feature panels render stacked and readable — so navigation, prices and
  core content stay discoverable per the brief, while the interactive
  toggle/tab behavior only exists when JS can actually drive it.
- **Feature tabs** use proper ARIA tab semantics (`role="tablist"/"tab"/"tabpanel"`,
  `aria-selected`, roving `tabindex`), with Left/Right/Up/Down/Home/End arrow
  support that wraps around and moves focus, matching the WAI-ARIA tabs pattern.
- **Mobile nav** is a real `<button>` (`menu-toggle`) controlling a `<nav>`
  region (`mobile-nav`) via `aria-expanded` and `aria-controls`. Escape closes
  it and returns focus to the toggle button; clicking a nav link closes it.
  Desktop navigation is a separate, always-visible `<nav>` shown above the
  `860px` breakpoint (mobile nav/toggle hidden at that width via CSS).
- **Billing toggle** stores both monthly and yearly strings as `data-monthly`/
  `data-yearly` attributes on the price elements, so switching is a pure
  lookup with no computation drift, and switching back to monthly always
  restores the exact original string (`$12/mo` / `$29/mo`).
- **Pricing/FAQ copy** sticks strictly to the supplied fictional facts
  (on-device storage, Markdown export, source links, reusable templates,
  optional local full-text search, export-based backup, cancellation not
  affecting already-exported files). No invented customers, reviews,
  ratings, or performance numbers. A dismiss-free banner and repeated
  footer text mark the page as a fictional demo.
- **Hero illustration** is an original CSS/SVG mock of a notebook UI (project
  sidebar, search field, note editor with a source-link pill) — not a copy
  of any real product's interface.
- **Visual system**: warm paper background, a single deep-teal accent,
  a 4-step spacing/radius scale, and the system font stack (no remote
  fonts). Focus states use a visible `:focus-visible` outline distinct from
  hover states. `prefers-reduced-motion: reduce` collapses all transitions/
  animations and disables smooth scrolling.
- **Layout** is mobile-first with breakpoints at `760px` (steps/plans grids),
  `860px` (nav switch) and `960px` (hero two-column). Verified usable at
  360px and 1440px (see checks below).

## Checks actually executed

All checks were run locally against the files in this folder, served via
`python3 -m http.server` and driven with Playwright's Chromium (including once
from a nested URL path, e.g. `/nested/path/site/index.html`, to confirm
relative asset URLs work):

- `node --check app.js` — confirms the script parses without syntax errors.
- Automated Playwright script (written for this task, not kept in the final
  deliverable) exercising, and all passing:
  - Mobile (360px): menu toggle opens/closes `mobile-nav`, `aria-expanded`
    stays in sync, Escape closes the nav and returns focus to the toggle
    button, and clicking a nav link closes the nav.
  - Desktop (1440px): desktop nav visible and mobile toggle hidden; feature
    tabs default to Capture selected/visible with the other two panels
    hidden; clicking a tab updates `aria-selected` and swaps the visible
    panel; ArrowRight moves selection/focus tab-to-tab and wraps around from
    Export back to Capture.
  - Billing toggle: default prices are `$12/mo` and `$29/mo`; switching to
    yearly shows `$108/yr` and `$264/yr`; switching back to monthly restores
    the exact original strings.
  - All four FAQ `<details>` elements are closed by default and open on
    clicking their `summary` (`faq-0`–`faq-3`).
  - The primary CTA link resolves to `href="#workflow"`.
  - With `javaScriptEnabled: false`, confirmed the mobile nav's four links,
    the Connect panel's text content, and the Solo price are all present and
    visible in the rendered DOM (no-JS fallback).
- Manual visual review of full-page screenshots at 360px and 1440px viewports
  to check layout, spacing and readability.

Not executed: no automated accessibility audit tool (e.g. axe) was run —
ARIA roles/states and focus behavior were checked manually and via the
Playwright script above, not exhaustively audited. No cross-browser testing
beyond Chromium. No testing with a screen reader.

## Known limitations

- Only Chromium was used for testing; no manual verification in WebKit/Firefox
  or on real touch devices.
- No automated accessibility audit (axe-core or similar) was run; accessibility
  was addressed by following established ARIA patterns and manual checks only.
- The hero illustration is a static CSS/SVG mock, not an interactive demo of
  the product.
