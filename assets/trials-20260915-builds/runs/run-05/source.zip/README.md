# Fieldnote Board

A local-first, no-build task board for a small project team. Pure `index.html` +
`styles.css` + `app.js` — no dependencies, no network calls, no backend.

## Running it

Serve the three files from any static file server (they use relative `./` paths,
so the app also works from a nested URL, e.g. `/some/sub/path/index.html`):

```sh
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Opening `index.html` directly via `file://` also works in most browsers, though a
static server is the supported path per the brief.

## Data model

Board state lives in `localStorage["fieldnote-board:v1"]` as:

```json
{ "schemaVersion": 1, "tasks": [ { "id": "...", "title": "...", "project": "...",
  "status": "todo|doing|done", "priority": "low|medium|high",
  "dueDate": "" | "YYYY-MM-DD", "tags": ["..."] } ] }
```

- A fresh (key absent) browser is seeded with 8 sample tasks across 2 fictional
  projects ("Harborview Renovation", "Riverside Sensor Deploy") covering all
  three statuses.
- Every mutation (create, edit, delete, undo, status change, import, reset)
  writes the *entire* tasks array back with `localStorage.setItem`, wrapped in
  try/catch. On success the in-memory state and the UI are updated together; on
  failure the write is rolled back to the last known-good state, an inline
  "not saved" banner appears, and — for the create/edit form specifically — the
  form stays open with the user's input intact instead of being discarded.

## Validation & error handling

- Form validation (blank title, length limits, malformed calendar dates,
  too many/too-long tags) is enforced in `app.js` and surfaced as inline,
  per-field error text (not just native browser validation), since the due
  date field is a plain text input so that intentionally-invalid dates like
  `2023-02-30` can actually reach the app's own validator instead of being
  silently sanitized by a native `<input type="date">`.
- The same validator (`validateBoardDocument` / `validateTaskObject`) is reused
  for both startup integrity checking and file import, so both paths reject
  the same things: wrong `schemaVersion`, duplicate ids, unsupported enum
  values, invalid dates, malformed tags, and non-object/non-array shapes.
- Import additionally enforces a 1 MiB file-size ceiling (checked before the
  file is even parsed) and is atomic: the file is fully parsed and validated
  in memory first, and the board is only replaced — after an explicit native
  `confirm()` — if every task in the file is valid. Any failure leaves the
  current board completely untouched and shows a visible error banner.
- Imported/typed/pasted text is only ever inserted via `textContent`
  (never `innerHTML`), so HTML-looking input (e.g. a title of
  `<img src=x onerror=...>`) always renders as literal text.
- If `localStorage.getItem(...)` returns a value that isn't valid JSON or
  doesn't pass the schema validator, the app **does not** touch storage or
  seed over it. It shows a dedicated recovery screen that offers (a)
  downloading the exact original bytes as a file, and (b) an explicit,
  confirmed reset that reseeds a fresh sample board. The corrupt bytes are
  left in `localStorage` untouched unless the user chooses reset.

## Cross-tab conflicts

The app listens for the `storage` event. Because that event only fires in
*other* tabs/windows than the one that wrote the value, any observed event for
this key means another tab changed the board. The app then shows a persistent
banner ("Reload board") and disables every mutating control (new task, edit,
delete, status select, save, import) so a stale in-memory copy in this tab can
never silently clobber newer data written elsewhere. The only way forward is an
explicit reload, which re-reads the authoritative state from storage.

## Accessibility & interaction

- All controls are native `<button>`/`<select>`/`<input>` elements with
  associated `<label>`s or `aria-label`s, so keyboard and screen-reader
  support comes largely for free.
- The task form is a modal dialog (`role="dialog"`, `aria-modal="true"`):
  opening it moves focus to the title field, `Tab`/`Shift+Tab` are trapped
  inside it, `Escape` closes it, and focus returns to whatever control opened
  it (the "New task" button or a card's "Edit" button).
- `prefers-reduced-motion: reduce` is detected via `matchMedia` and adds a
  class that zeroes out all transition/animation durations.
- A `<noscript>` banner explains that JavaScript is required, for the case
  where it's disabled.

## Checks actually run

Using a locally-copied build served from a nested path
(`/nested/path/index.html`) under a plain `python3 -m http.server`, driven with
Playwright + local headless Chrome, covering:

- Seeding on empty storage (≥6 tasks, 2 projects, all 3 statuses) and the
  visible matching/total count.
- Create with a blank-title validation error, then a successful create;
  comma-separated tag trimming/case-insensitive de-duplication.
- Rejection of an invalid calendar date (`2023-02-30`) with a visible,
  field-level error.
- Edit-in-place preserving all other records and the task's id.
- Delete → visible undo → restore, including that the restored record
  survives a full page reload.
- Status change via the card's native select moving a card between columns.
- Search + the no-results empty state; HTML-like input rendered as inert text.
- Export producing a `schemaVersion: 1` document containing every task,
  including ones hidden by the current filters.
- Import rejection (with the board left unchanged) for: malformed JSON,
  duplicate ids, an unsupported status enum, an invalid date, and an
  oversized (>1 MiB) file — plus a confirmed valid import that replaces the
  board and survives reload.
- Corrupt `localStorage` on startup: recovery screen shown, original bytes left
  untouched, a downloaded backup byte-for-byte matches the corrupt value, and
  reset reseeds a working board.
- A second tab writing the storage key triggers the conflict banner and
  disables mutating controls in the first tab.
- Modal keyboard behavior (initial focus, `Escape` to close, focus restoration).
- `prefers-reduced-motion` applied as a document class.
- JavaScript-disabled `<noscript>` fallback text.
- Mobile (360px) and desktop (1440px) full-page screenshots, reviewed visually
  (this caught and led to fixing two real CSS bugs: the corrupt-recovery view
  rendering on top of the normal board because a `.recovery-view` class rule
  beat the `[hidden]` UA rule at equal specificity, and the mobile search field
  stretching to fill the toolbar's cross axis once it switched to a column
  layout).

Simulating an actual `localStorage.setItem` quota/exception failure was not
separately scripted (would require exhausting real quota or monkeypatching
storage), but the try/catch handling around every write path was written and
manually reasoned through, and the corrupt-storage and conflict-lockdown paths
were both exercised end-to-end.

## Known limitations

- Single-level undo: deleting a second task before undoing the first discards
  the ability to undo the first one.
- Cross-tab reconciliation is "reload to resolve," not automatic merge — this
  is the simplest safe behavior per the brief (never silently overwrite newer
  external state) but means concurrent edits in two tabs require a manual
  reload in the stale tab.
- Date formatting uses the browser's default locale via `toLocaleDateString`;
  no timezone handling is needed since dates are stored/compared as plain
  `YYYY-MM-DD` strings.
