# Fieldnote Board

A local-first task board for a small field-project team. Fictional demo data only; no backend, no network calls, no build step.

## Run it

Serve the three files (`index.html`, `styles.css`, `app.js`) from any static file server, at the root or a nested path — all asset references are relative.

```
python3 -m http.server 8000
# open http://localhost:8000/index.html
```

Opening `index.html` directly via `file://` also works in most browsers, but a static server is the supported path (matches the brief and avoids browser-specific `file://` quirks with `localStorage`).

## Data model

- Storage key: `fieldnote-board:v1`, value `{ schemaVersion: 1, tasks: [...] }`.
- Task fields: `id`, `title`, `project`, `status` (`todo`/`doing`/`done`), `priority` (`low`/`medium`/`high`), `dueDate` (`""` or `YYYY-MM-DD`, validated as a real calendar date), `tags` (≤8 trimmed strings, ≤24 chars each).
- On genuinely empty storage, an 8-task fictional seed is written (2 projects, all 3 statuses, mixed priorities/tags/due dates).
- Comma-separated tag input is trimmed and de-duplicated case-insensitively before saving.

## Error handling and edge cases

- **Corrupt storage** (unparseable JSON or a document that fails schema validation) is never overwritten or reseeded. The app shows a recovery banner with a button to download the original bytes and an explicit, confirmed "Reset board" action.
- **Failed writes** (e.g. `localStorage.setItem` throws) never claim success: create/edit keeps the entered data in the open form and shows an inline error; delete/status-change/import roll back and show a dismissible error banner. Nothing in memory is lost.
- **Cross-tab conflicts**: a `storage` event for the board key that doesn't match what this tab last wrote shows a persistent banner and blocks further saves/deletes/status changes/imports until the user clicks "Reload".
- **Import** is atomic: the whole file is parsed and fully validated (schema version, size ≤1 MiB, enum values, dates, tag shape, duplicate IDs) before anything changes; any failure leaves the existing board untouched and reports why. A valid file requires an explicit confirm before it replaces the board.
- **Delete** shows an undo banner (`data-testid="undo-delete"`) that restores the exact record at its original position; undo persists like any other change.
- User-entered text (titles, projects, tags) is rendered with `textContent` only — never interpreted as HTML.

## Accessibility and interaction

- All controls are native `button`/`select`/`input` elements with associated `<label>`s or `aria-label`s (e.g. per-card status selects and edit/delete buttons are labeled with the task title).
- The task form is a native `<dialog>`: opening focuses the title field, `Escape` closes it, and focus returns to whichever control opened it.
- `@media (prefers-reduced-motion: reduce)` collapses all transitions/animations to effectively instant.
- `<noscript>` shows a plain-language message; the interactive app itself is hidden (via a `no-js` body class removed by `app.js`) until script runs.
- Layout is responsive: single-column board at 360px, three-column Kanban board at 1440px+.

## Checks actually run

Using headless Chrome via Playwright against a local static server (`python3 -m http.server`), scripted end to end:

- Seed renders ≥6 cards across 2 projects/3 statuses; 360px and 1440px screenshots reviewed.
- Create, validate (blank title), edit-prefill, tag dedupe, search, status-change persistence, delete+undo, reload persistence, export (downloaded file re-parsed and checked), no-results state.
- XSS attempt in a title is not rendered as markup.
- Corrupt `localStorage` value on load: recovery banner shown, original bytes left untouched.
- Valid import replaces the board and survives reload; import with duplicate IDs is rejected and leaves the prior board untouched.
- A second tab writing the storage key triggers the conflict banner in the first tab.
- Serving the same three files from a nested directory path loads correctly (relative asset paths).

All of the above passed in the final run. `node --check app.js` confirms the script parses cleanly.

## Known limitations

- Storage-quota-exceeded and multi-tab reconciliation-by-merge are not separately scripted beyond the generic write-failure and conflict-banner paths described above (the contract permits blocking stale edits instead of merging, which is what's implemented).
- No automated test covers the `file://` protocol directly; a static server is the documented and tested run method.
- Keyboard-only full-app walkthrough was exercised for the modal (open/Escape/focus-return); a dedicated full-page tab-order sweep was not scripted, though every control is a native focusable element.
