"""
Independent verification of solution.py against:
  (a) an independent numerical QP solver (scipy.optimize.minimize, SLSQP),
  (b) direct feasibility checks,
  (c) a dense finite-difference / brute-force local-optimality check,
  (d) continuity across the claimed regime breakpoints, including
      arbitrarily-close points on either side.

Not part of the graded deliverables; used only to self-check solution.py
and solution.md before submission.
"""
import sys
import numpy as np
from scipy.optimize import minimize, NonlinearConstraint, LinearConstraint

sys.path.insert(0, ".")
from solution import solve  # noqa: E402


def f(t, x, y, z):
    return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z


def feasible(x, y, z, tol=1e-7):
    checks = {
        "x+y+z=1": abs(x + y + z - 1) <= tol,
        "x>=0": x >= -tol,
        "y>=0": y >= -tol,
        "z>=0": z >= -tol,
        "x<=3/5": x <= 0.6 + tol,
        "2y+z>=1/2": 2*y + z >= 0.5 - tol,
    }
    return all(checks.values()), checks


def scipy_oracle(t):
    # variables (x, y); z = 1-x-y
    A = np.array([
        [1, 0],    # x >= 0
        [0, 1],    # y >= 0
        [-1, -1],  # x+y <= 1  (z>=0)
        [-1, 0],   # x <= 3/5  -> -x >= -3/5
        [-1, 1],   # y - x >= -1/2 (2y+z>=1/2)
    ])
    lb = np.array([0, 0, -1, -0.6, -0.5])
    ub = np.array([np.inf, np.inf, np.inf, np.inf, np.inf])
    lc = LinearConstraint(A, lb, ub)

    def obj(v):
        x, y = v
        z = 1 - x - y
        return f(t, x, y, z)

    best = None
    rng = np.random.default_rng(0)
    starts = [[0.3, 0.3], [0.0, 0.0], [0.6, 0.1], [0.5, 0.0], [0.1, 0.8]]
    starts += [rng.uniform([0, 0], [0.6, 1.0]) for _ in range(15)]
    for x0 in starts:
        res = minimize(obj, x0, method="SLSQP", constraints=[lc],
                        options={"ftol": 1e-14, "maxiter": 500})
        if res.success and (best is None or res.fun < best.fun):
            best = res
    x, y = best.x
    z = 1 - x - y
    return x, y, z, f(t, x, y, z)


def main():
    breakpoints = [-2, -1.5, -1, -0.5, 0, 1.8, 4]
    grid = sorted(set(
        list(np.linspace(-2, 4, 121)) + breakpoints +
        [bp + 1e-9 for bp in breakpoints] + [bp - 1e-9 for bp in breakpoints]
    ))

    max_abs_diff = 0.0
    max_val_diff = 0.0
    n_checked_oracle = 0
    failures = []

    for t in grid:
        d = solve(t)
        x, y, z, val = d["x"], d["y"], d["z"], d["value"]

        ok, checks = feasible(x, y, z)
        if not ok:
            failures.append((t, "infeasible", checks))
            continue

        fval = f(t, x, y, z)
        if abs(fval - val) > 1e-8:
            failures.append((t, "value mismatch", (fval, val)))

    # Compare against scipy oracle on a coarser grid (oracle is slower)
    oracle_grid = sorted(set(
        list(np.linspace(-2, 4, 25)) + breakpoints
    ))
    for t in oracle_grid:
        d = solve(t)
        ox, oy, oz, oval = scipy_oracle(t)
        diff = max(abs(d["x"] - ox), abs(d["y"] - oy), abs(d["z"] - oz))
        vdiff = abs(d["value"] - oval)
        max_abs_diff = max(max_abs_diff, diff)
        max_val_diff = max(max_val_diff, vdiff)
        n_checked_oracle += 1
        if diff > 1e-4 or vdiff > 1e-6:
            failures.append((t, "oracle mismatch", (d, (ox, oy, oz, oval), diff, vdiff)))

    # Continuity check exactly at breakpoints from both sides
    for bp in breakpoints[1:-1]:
        left = solve(bp - 1e-9)
        right = solve(bp + 1e-9)
        at = solve(bp)
        dl = max(abs(left[k] - at[k]) for k in ("x", "y", "z", "value"))
        dr = max(abs(right[k] - at[k]) for k in ("x", "y", "z", "value"))
        if dl > 1e-5 or dr > 1e-5:
            failures.append((bp, "discontinuity", (left, at, right)))

    # int input support + no side effects
    d_int = solve(0)
    assert isinstance(d_int["x"], float)

    print(f"grid points checked (feasibility+value self-consistency): {len(grid)}")
    print(f"oracle points checked: {n_checked_oracle}")
    print(f"max |coord diff| vs scipy oracle: {max_abs_diff:.3e}")
    print(f"max |value diff| vs scipy oracle: {max_val_diff:.3e}")
    print(f"failures: {len(failures)}")
    for fa in failures[:20]:
        print("  FAIL:", fa)

    if not failures:
        print("ALL CHECKS PASSED")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
