# Lattice — fictional landing page

A static marketing landing page for **Lattice**, a fictional local-first research
notebook. Built with vanilla HTML/CSS/JS only: no build step, no remote fonts,
no libraries, no network calls, no backend.

## Run it

Serve the three files (`index.html`, `styles.css`, `app.js`) from any static
file server, at the root or a nested path — all asset references are relative.

```
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Opening `index.html` directly via `file://` also works.

## Implementation decisions

- **Visual system**: warm paper canvas (`#f7f4ee`), near-black ink text, and a
  single teal accent (`#0f6e63`) reused for links, focus rings, the active tab,
  and both CTAs — chosen for 4.5:1+ contrast on white and to read as "ink on
  paper" for a notebook product. A serif display face (system `Georgia` stack)
  pairs with the system sans body font to separate headings from body text
  without loading any remote font.
- **Hero illustration** is an original CSS/SVG mock of the product UI (project
  sidebar, note with a source chip and tags, toolbar) — no bitmap assets.
- **Mobile nav progressive enhancement**: `mobile-nav` is a normal, visible
  block in the DOM/CSS by default. `app.js` only *adds* the collapsed state on
  load and wires the toggle, so with JavaScript disabled the panel stays in
  flow and all links remain reachable; the header CTA and desktop nav are
  hidden below 900px purely via CSS, independent of JS.
- **Feature tabs** use real `role="tab"`/`role="tabpanel"` semantics with
  roving `tabindex`, `aria-selected`, and arrow/Home/End key support; content
  differs meaningfully per panel (capture vs. connect vs. export).
- **Billing toggle** stores each plan's monthly/yearly amount and period label
  in `data-*` attributes on the price element itself, so switching back to
  monthly always restores the exact original markup rather than recomputing a
  value.
- **FAQ** uses native `<details>/<summary>` — no JS required, keyboard and
  screen-reader accessible by default.
- Fictional-product disclaimer appears twice: a persistent top banner and a
  repeated line in the footer. No customers, reviews, ratings, or performance
  figures are stated anywhere.

## Checks actually executed

Verified with Playwright (Chromium, via the local `NODE_PATH`) against a local
`python3 -m http.server`, plus a manual look at the rendered screenshots:

- 1440px viewport: desktop nav visible, hamburger hidden, feature tabs switch
  panels on click and on `ArrowRight`, billing toggle updates
  `price-solo`/`price-studio` to $108/$264 yearly and back to the exact
  original $12/$29 monthly text, all four FAQ `summary` elements exist and
  `faq-0` opens on click, the hero primary CTA links to `#workflow`.
- 360px viewport: desktop nav and header CTA hidden, mobile nav starts
  collapsed with `aria-expanded="false"`, the toggle opens it and flips
  `aria-expanded="true"`, `Escape` closes it and returns focus to the toggle,
  clicking a nav link inside the panel closes it and navigates to the real
  `#features` section, no horizontal overflow.
- JavaScript disabled (`javaScriptEnabled: false`): mobile nav content, hero
  heading, and monthly prices are all still visible/discoverable.
- Nested path: copied the three files into a `nested/sub/` subdirectory served
  from the same origin and confirmed the stylesheet and script both still
  loaded via their relative URLs.
- Found and fixed one real bug this way: a CSS specificity issue where `.btn`'s
  `display: inline-flex` (declared after `.nav-cta`'s `display: none` in the
  cascade) was overriding the mobile hide rule for the header CTA button;
  re-checked after the fix.
- All 31 automated assertions above passed on the final build. I did not run
  an automated accessibility audit tool (e.g. axe) or test on an actual screen
  reader or real mobile device — only Chromium via Playwright and manual
  screenshot review at 360px and 1440px.

## Known limitations

- Colors and spacing were checked by eye against the design tokens and with
  screenshots, not with a programmatic contrast-ratio scanner.
- No automated test for `prefers-reduced-motion`; the rule is a global
  transition/animation-duration override, not individually verified per
  component in a reduced-motion browser profile.
- Tested only in Chromium (via Playwright); not cross-checked in WebKit/Firefox.
- The hero, feature-tab illustrations, and pricing/FAQ copy are original but
  minimal — a production build would likely want more polish and more
  extensive content review.
