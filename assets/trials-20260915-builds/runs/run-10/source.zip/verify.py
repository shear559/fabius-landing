"""
Reproducible verification script for solution.py / solution.md.
Run: python3 verify.py
Uses only the Python standard library.
"""

import random
from fractions import Fraction
from solution import solve, T_MIN, T_MAX


def f(x, y, z, t):
    return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z


def feasible(x, y, z, eps=1e-7):
    return (x >= -eps and y >= -eps and z >= -eps and x <= 0.6 + eps
            and 2*y + z >= 0.5 - eps and abs(x + y + z - 1) <= 1e-6)


def grid_minimum(t, nx=600, ny=300):
    """Independent brute-force global minimum over the feasible polygon."""
    best = None
    for i in range(nx + 1):
        x = i / nx * 0.6
        ylo = max(0.0, x - 0.5)
        yhi = 1 - x
        if yhi < ylo:
            continue
        for j in range(ny + 1):
            y = ylo + (yhi - ylo) * j / ny
            z = 1 - x - y
            if not feasible(x, y, z):
                continue
            val = f(x, y, z, t)
            if best is None or val < best[0]:
                best = (val, x, y, z)
    return best


def check_feasibility_and_grid(ts):
    print("=== 1. Feasibility + independent grid-search agreement ===")
    worst = 0.0
    for t in ts:
        r = solve(t)
        x, y, z, v = r["x"], r["y"], r["z"], r["value"]
        assert feasible(x, y, z), f"solve({t}) infeasible: {r}"
        assert abs(f(x, y, z, t) - v) < 1e-9, "reported value mismatches f_t(x,y,z)"
        gv, gx, gy, gz = grid_minimum(t)
        diff = v - gv
        worst = max(worst, diff)
        assert diff < 5e-3, f"t={t}: formula {v} worse than grid best {gv} by {diff}"
        print(f"  t={t:>10}: value={v:.6f}  grid_best={gv:.6f}  diff={diff:.2e}")
    print(f"  worst (formula - grid_best) over all t tested: {worst:.2e}\n")


def check_continuity_across_breakpoints():
    print("=== 2. Continuity of x*,y*,z*,value at the 5 breakpoints ===")
    for bp in [Fraction(-3, 2), Fraction(-1), Fraction(-1, 2), Fraction(0), Fraction(9, 5)]:
        eps = 1e-6
        left = solve(float(bp) - eps)
        right = solve(float(bp) + eps)
        at = solve(float(bp))
        for k in ("x", "y", "z", "value"):
            assert abs(left[k] - at[k]) < 1e-4, (bp, k, left, at)
            assert abs(right[k] - at[k]) < 1e-4, (bp, k, right, at)
        print(f"  breakpoint t={float(bp):>6}: left={left['x']:.6f},{left['y']:.6f},{left['z']:.6f} "
              f"| at={at['x']:.6f},{at['y']:.6f},{at['z']:.6f} "
              f"| right={right['x']:.6f},{right['y']:.6f},{right['z']:.6f}  OK")
    print()


def check_kkt_sign_and_slackness(ts):
    print("=== 3. KKT multiplier signs & complementary slackness ===")
    for t in ts:
        r = solve(t)
        mu = r["multipliers"]
        for name, val in mu.items():
            assert val >= -1e-9, f"t={t}: multiplier {name}={val} negative"
        # complementary slackness: mu_x*x=0, mu_y*y=0, mu_xle*(0.6-x)=0, mu_v*(2y+z-0.5)=0
        x, y, z = r["x"], r["y"], r["z"]
        assert abs(mu["mu_x"] * x) < 1e-6
        assert abs(mu["mu_y"] * y) < 1e-6
        assert abs(mu["mu_xle"] * (0.6 - x)) < 1e-6
        assert abs(mu["mu_v"] * (2*y + z - 0.5)) < 1e-6
    print(f"  checked {len(ts)} values of t: all multipliers >= 0 and complementary slackness holds\n")


def check_exact_fraction_formulas():
    print("=== 4. Exact-rational spot checks against the closed forms in solution.md ===")
    cases = {
        Fraction(-2): (Fraction(0), Fraction(1, 4), Fraction(3, 4), Fraction(29, 8)),
        Fraction(-3, 2): (Fraction(0), Fraction(1, 4), Fraction(3, 4), Fraction(29, 8)),
        Fraction(-1): (Fraction(3, 8), Fraction(0), Fraction(5, 8), Fraction(55, 16)),
        Fraction(-1, 2): (Fraction(1, 2), Fraction(0), Fraction(1, 2), Fraction(3)),
        Fraction(0): (Fraction(1, 2), Fraction(0), Fraction(1, 2), Fraction(5, 2)),
        Fraction(9, 5): (Fraction(3, 5), Fraction(1, 10), Fraction(3, 10), Fraction(13, 25)),
        Fraction(4): (Fraction(3, 5), Fraction(1, 10), Fraction(3, 10), Fraction(-53, 25)),
    }
    for t, (xe, ye, ze, ve) in cases.items():
        r = solve(float(t))
        assert abs(r["x"] - float(xe)) < 1e-9
        assert abs(r["y"] - float(ye)) < 1e-9
        assert abs(r["z"] - float(ze)) < 1e-9
        assert abs(r["value"] - float(ve)) < 1e-9
        print(f"  t={str(t):>6}: ({xe},{ye},{ze}), value={ve}  matches solve()")
    print()


def check_type_and_error_handling():
    print("=== 5. Input contract: types, bounds, no side effects ===")
    assert solve(0) == solve(0.0) or all(
        abs(solve(0)[k] - solve(0.0)[k]) < 1e-12 for k in ("x", "y", "z", "value")
    )
    for bad in [T_MIN - 0.001, T_MAX + 0.001, -100, 100]:
        try:
            solve(bad)
            raise AssertionError(f"solve({bad}) should have raised ValueError")
        except ValueError:
            pass
    try:
        solve("nope")
        raise AssertionError("solve(str) should have raised TypeError")
    except TypeError:
        pass
    print("  int/float agreement OK; out-of-range -> ValueError; wrong type -> TypeError\n")


if __name__ == "__main__":
    random.seed(0)
    sample_ts = [-2, -1.9, -1.5, -1.3, -1, -0.7, -0.5, -0.3, 0, 0.5, 1, 1.8, 2, 3, 4] + \
        [-1.5 - 1e-6, -1.5 + 1e-6, -1 - 1e-6, -1 + 1e-6, -0.5 - 1e-6, -0.5 + 1e-6,
         -1e-6, 1e-6, 1.8 - 1e-6, 1.8 + 1e-6] + \
        [round(random.uniform(-2, 4), 4) for _ in range(30)]

    check_feasibility_and_grid(sample_ts)
    check_continuity_across_breakpoints()
    check_kkt_sign_and_slackness(sample_ts)
    check_exact_fraction_formulas()
    check_type_and_error_handling()
    print("ALL VERIFICATION CHECKS PASSED")
