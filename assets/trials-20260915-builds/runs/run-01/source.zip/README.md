# Lattice — fictional landing page demo

A static marketing landing page for **Lattice**, a fictional local-first research
notebook. Built for a benchmark/test exercise: vanilla HTML/CSS/JS only, no build
step, no network calls, no backend.

## Run it

Any static file server works, including from a nested path. From this directory:

```
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

All asset references (`./styles.css`, `./app.js`) are relative, so the three
files can also be copied into a subfolder (e.g. `/some/nested/path/`) and served
from there without edits — verified during testing (see below).

The page also works by opening `index.html` directly via `file://`.

## Files

- `index.html` — all markup and content
- `styles.css` — design tokens, layout, responsive rules, reduced-motion handling
- `app.js` — mobile nav, feature tabs, pricing toggle (progressive enhancement only)

## Implementation decisions

- **Visual system**: warm paper background with a faint dot grid, deep teal
  accent (`#1f6f5c`) plus a brass/amber secondary accent, serif display type
  (Georgia) for headings against a system sans-serif body face — no remote
  fonts. Meant to read as "notebook," not "generic SaaS."
- **Hero illustration** is an original app-window mockup built from nested
  `div`s (sidebar note list, note body with source chip, search row) plus a
  couple of small inline SVG icons/logomark — no external images or icon
  fonts.
- **Progressive enhancement / no-JS fallback**: `app.js` adds a `js` class to
  `<html>` on load. CSS only collapses the mobile nav and hides inactive tab
  panels when that class is present, so with JavaScript disabled: the mobile
  nav is always visible/reachable, all three feature panels render (stacked),
  and monthly prices are the static default in the markup. Core content,
  navigation, and pricing stay discoverable without JS, per the brief.
- **Mobile nav**: `data-testid="menu-toggle"` toggles `aria-expanded` and the
  `hidden` attribute on `data-testid="mobile-nav"`. Escape closes it and
  returns focus to the toggle; clicking any nav link closes it. Desktop nav
  (`.desktop-nav`) is shown ≥880px and is independent of the mobile nav markup.
- **Feature tabs**: real `role="tab"`/`role="tabpanel"` markup with a single
  roving `tabindex`, `aria-selected` sync, and Left/Right/Up/Down/Home/End
  arrow-key support per the standard tabs pattern. Only the selected panel is
  unhidden.
- **Pricing toggle**: buttons store `data-monthly`/`data-yearly` values
  directly on the price elements; `app.js` swaps `textContent` and the
  "/ month" vs "/ year" label, and toggles `aria-pressed`. Monthly is the
  default/static state so it's correct even without JS. Returning to Monthly
  restores the exact original strings ($12 / $29) since they're re-read from
  the `data-monthly` attributes rather than computed.
- **FAQ**: four native `<details>/<summary>` elements — no JS required, works
  and is keyboard-operable by default.
- **Accessibility**: visible `:focus-visible` outline (not suppressed
  globally), a skip link, `aria-controls`/`aria-expanded`/`aria-selected`
  wired to real state changes, and a `prefers-reduced-motion: reduce` block
  that removes transitions/animations/smooth-scroll.
- **Fiction disclosure**: a banner at the very top of the page plus a
  restated disclaimer in the footer both explicitly say Lattice is a
  fictional product demo. No invented customers, reviews, ratings, or
  performance stats are used anywhere in the copy.

## Checks actually executed

Using Playwright (Chromium) against the page served over `python3 -m
http.server`, including a copy served from a nested path
(`/nested/path/index.html`), and against the direct built files:

- Mobile (360px viewport): menu-toggle opens/closes `mobile-nav`,
  `aria-expanded` syncs, Escape closes and returns focus to the toggle,
  selecting a nav link closes the menu and navigates to the target section
  hash. No console/page errors observed.
- Desktop (1440px viewport): desktop nav visible and menu-toggle hidden;
  feature tabs default to Capture selected/visible; ArrowRight moves
  selection+focus to Connect and shows `panel-connect` while hiding the
  others; clicking Export selects it and hides the other panels.
- Pricing: default monthly values are exactly `$12` / `$29`; clicking
  `billing-yearly` updates to exactly `$108` / `$264` with a "/ year" label;
  clicking `billing-monthly` again restores exactly `$12` / `$29`.
- All four `data-testid="faq-0"`..`"faq-3"` `<summary>` elements exist and
  toggle their `<details>` open on click.
- Primary CTA text is exactly "Explore the workflow" and its `href` is
  `#workflow`; clicking it navigates to that section.
- JavaScript-disabled context (`javaScriptEnabled: false`): mobile nav links
  are present in the DOM, the monthly price is shown correctly, all three
  feature panels render their content, and FAQ summaries are present.
- Manual visual review via full-page screenshots at 360px and 1440px widths
  (including the open mobile-nav state and a close-up of the animated
  menu icon) to check layout, spacing, and hierarchy at both target widths.

Not executed: automated axe/Lighthouse audits, a real screen reader pass, or
cross-browser testing outside Chromium — only Chromium via Playwright was
available in this environment.

## Known limitations

- Only tested in Chromium (via Playwright); not verified in WebKit/Firefox,
  though only broadly-supported CSS/JS (flexbox, grid, `details/summary`,
  `:focus-visible`) is used.
- No automated accessibility audit tool (axe-core, Lighthouse) was run;
  accessibility was addressed by hand (semantics, focus management, contrast
  choices, reduced motion) and spot-checked, not machine-verified.
- The billing toggle and feature tabs have no `localStorage`/URL persistence
  — state resets on reload, which is intentional for a static demo with no
  backend.
- The hero illustration is a simplified, generic notebook UI mockup, not a
  pixel-accurate rendering of any real application.
