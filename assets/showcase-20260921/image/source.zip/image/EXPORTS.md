The PNG exports are published beside this archive under exports/ (the WebP set is included here). Rebuild everything from master.svg and formats/ with the scripts in tools/.
