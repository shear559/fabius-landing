The rendered films are published beside this archive as film.mp4 and film.webm. Rebuild them from source/ as described in source/README.md.
