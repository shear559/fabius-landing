# Experiment

A yeast culture was grown in two conditions: untreated (control) and exposed to a mild chemical stressor (treated), three biological replicates each. RNA was sequenced; `counts.csv` holds raw read counts per gene (2,000 genes, anonymous IDs) and sample. `metadata.csv` lists each sample's condition and the sequencing run it was processed in (two runs, A and B). Library sizes differ between samples.

The question: which genes respond to the treatment, in which direction, by how much, and how sure can we be?
