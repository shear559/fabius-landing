# RNA-seq explorer

Rerun the analysis from the CSV files:

```sh
python3 product/analysis.py   # Python 3.9+, numpy, scipy
```

It writes out/results.csv, out/stats.json and product/data.js. Then serve product/ with any static server and open index.html.

The data are synthetic. Fonts: Rubik, OFL (product/font/OFL.txt).
