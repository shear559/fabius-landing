# RNA-seq explorer

Rerun the analysis from the CSV files, from this folder:

```sh
python3 product/analysis.py   # Python 3.9+, numpy, scipy
```

It rewrites the files under out/ and product/data.js. Then serve product/ with any static server and open index.html.

The data are synthetic. Fonts: Rubik, OFL (product/font/OFL.txt).
