# Lattice — fictional landing page

A self-contained marketing landing page for **Lattice**, a fictional local-first
research notebook. Built with plain HTML, CSS and JavaScript — no build step,
no frameworks, no remote fonts, no network calls, and no backend.

This is a supplied-fiction demonstration product. The page states this clearly
in a banner at the top of every screen and again in the footer.

## Run it

Any static file server works, at any URL depth (all asset references are
relative, e.g. `href="styles.css"`, not absolute paths):

```bash
python3 -m http.server 8080
# then open http://localhost:8080/index.html
# or, from a parent directory, e.g. http://localhost:8080/some/nested/path/index.html
```

Opening `index.html` directly via `file://` also works.

## Files

- `index.html` — all markup, an inline SVG icon sprite (`<symbol>` defs), and the hero illustration.
- `styles.css` — the entire visual system (colors, type, layout, components, responsive rules, reduced-motion rules).
- `app.js` — progressive-enhancement behavior only: mobile nav, feature tabs, billing toggle, workflow demo.

## Design decisions

- **Visual system**: warm paper background, near-black ink text, a deep teal
  accent (`--accent`) and a terracotta secondary accent, with serif headings
  (system serif stack) over a sans body (system sans stack) for an editorial,
  non-generic feel. All colors are CSS custom properties in `:root`.
- **Original icon family**: one SVG sprite (`<symbol>` set) defines a small,
  consistent line-icon set (logo mark, menu/close, capture, connect, export,
  search, template, device, check, play/pause/restart, chevron, link) reused
  everywhere via `<use>`.
- **Hero illustration**: a hand-built SVG scene (not a stock asset) showing
  three note cards ("Capture"), dotted threads into a small node graph
  ("Connect"), and an arrow into a Markdown document ("Export") — the same
  three-step language used later in the Workflow section.
- **Progressive enhancement pattern used three times** (mobile nav, feature
  tabs, workflow demo): the no-JavaScript markup already contains the full,
  useful content (all nav links, all three feature panels, all three workflow
  steps stacked). `app.js` adds the `js` class to `<html>` and only then does
  CSS/JS collapse it into an interactive toggle/tablist/animated demo. This is
  why the page keeps working with JavaScript disabled.
- **Feature tabs** use real `role="tab"`/`role="tabpanel"` semantics, roving
  `tabindex`, `aria-selected`, and automatic-activation arrow key movement
  (Left/Right/Up/Down/Home/End), per the standard ARIA tabs pattern.
- **Billing toggle** is a two-button group with `aria-pressed`, updating the
  `data-testid="price-solo"`/`price-studio"` text nodes directly (e.g.
  `"$12/mo"` ↔ `"$108/yr"`) and an `aria-live` label announcing the active
  billing period.
- **Workflow demo**: the three workflow steps double as the animated,
  user-controlled demonstration (play/pause + restart) — no separate hidden
  content, no video. `prefers-reduced-motion: reduce` disables autoplay (demo
  opens paused) and removes the crossfade transition entirely, per the media
  query in `styles.css`.
- **Focus visibility**: a single, high-contrast `:focus-visible` outline is
  defined once and applies to every interactive element.
- **Responsive range**: laid out and checked at 360px and 1440px, with a few
  intermediate breakpoints (420, 700/760, 860/900, 1000) for the nav switch,
  tab/pricing grids, and demo layout.

## Checks I actually ran

Using a local static server (`python3 -m http.server`, served one directory
above `work/` so the page loaded from a nested path, e.g.
`/work/index.html`) and Playwright (Chromium via the system Chrome install)
driving the built page:

- Mobile viewport (360×800): `menu-toggle` starts with `aria-expanded="false"`;
  clicking it sets `aria-expanded="true"` and `mobile-nav`'s `data-open`
  attribute to `"true"`; `Escape` closes it and returns focus to the toggle
  button; clicking a link inside `mobile-nav` closes it.
- Desktop viewport (1440×900): desktop nav visible, mobile toggle hidden;
  `feature-capture`/`feature-connect`/`feature-export` show exactly one
  matching panel visible at a time; clicking `feature-connect` updates
  `aria-selected` and swaps the visible panel; Arrow-Right moves focus and
  selection from Capture → Connect → Export.
- Billing toggle: initial prices are `$12/mo` / `$29/mo`; clicking
  `billing-yearly` updates them to `$108/yr` / `$264/yr` and sets
  `aria-pressed="true"`; clicking `billing-monthly` restores the exact
  original monthly strings.
- All four `faq-0`…`faq-3` `<summary>` elements exist and open on click.
- The "Explore the workflow" CTA has `href="#workflow"`.
- Workflow demo's `demo-toggle` and `demo-restart` are present and the toggle
  correctly flips `aria-pressed` on click.
- With JavaScript disabled entirely (`javaScriptEnabled: false`): all four
  mobile nav links are present in the DOM and reachable, the monthly prices
  are visible without any toggle interaction, the Connect feature panel's
  content is visible (not just Capture), and FAQ summaries are visible.
- Visual review: full-page screenshots captured at 360×900 and 1440×1000 to
  confirm layout, spacing and hierarchy at both required widths.

I did not run an automated axe/Lighthouse accessibility audit or test in a
browser other than Chromium; those are the main known gaps below.

## Known limitations

- Accessibility was hand-checked (semantics, `aria-*` states, focus order,
  labels, reduced-motion) but not run through an automated auditing tool.
- Only tested in Chromium (via Playwright/local Chrome). Not verified in
  Firefox, Safari or WebKit-based mobile browsers.
- The billing toggle and feature tabs are plain custom widgets (buttons with
  ARIA attributes), not native form controls — this is standard practice for
  these patterns but means their behavior is entirely dependent on the
  attached JavaScript for the *interactive* switching (the underlying content
  is still present without JS, per the progressive-enhancement notes above).
- No automated cross-device testing beyond the two required widths (360px,
  1440px) plus a couple of intermediate breakpoints eyeballed during
  development.
