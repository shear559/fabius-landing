# Fieldnote Board

A local-first task board for a small research-publication team (fictional demo: the "Reef Resilience Study" and "Manuscript Production" projects). Pure vanilla HTML/CSS/JS, no build step, no dependencies, no network calls.

## Run instructions

Serve the three files (`index.html`, `styles.css`, `app.js`) from any static file server — they use only relative paths, so the app works from a nested URL (e.g. `/some/nested/path/index.html`). Example:

```sh
python3 -m http.server 8080
# open http://127.0.0.1:8080/index.html
```

Opening `index.html` directly via `file://` also works in most browsers since there are no external requests, but a static server is the supported path. JavaScript is required; a `<noscript>` banner explains this if it's disabled.

## Data design

- Storage key: `fieldnote-board:v1`, shape `{ schemaVersion: 1, tasks: [...] }`.
- Each task: `id`, `title`, `project`, `status` (`todo`/`doing`/`done`), `priority` (`low`/`medium`/`high`), `dueDate` (`""` or `YYYY-MM-DD`, checked against the real calendar so e.g. `2024-02-30` is rejected), `tags` (≤8 trimmed strings, ≤24 chars each, deduplicated case-insensitively from comma-separated input).
- On genuinely empty storage (`localStorage.getItem` returns `null`), the app seeds 7 realistic tasks across 2 projects and all 3 statuses, then persists them.
- All rendered task text (title, project, tags) is inserted via HTML-escaping, so imported or typed text — including HTML-looking strings — is always treated as text, never markup.

## Error handling

- **Corrupt storage**: if the stored value fails `JSON.parse` or doesn't match the schema (wrong `schemaVersion`, non-array `tasks`, invalid task, duplicate IDs), the app never seeds or overwrites it. It shows a recovery banner with a button to download the exact original bytes and an explicit, confirmed "Reset board" action (which reseeds the demo board).
- **Write failures**: every mutation (create/edit/delete/undo/status change/import/reset) first attempts `localStorage.setItem` and only updates in-memory state if that succeeds. If it throws (e.g. quota exceeded), a "Change not saved" banner appears and the in-progress edit stays in the open form (or the deletion is not applied) — nothing is lost and persistence is never falsely implied.
- **Cross-tab conflicts**: a `storage` event from another tab shows a visible conflict banner and disables destructive controls (delete, status change, save) until the user clicks "Reload board", which re-reads the current storage value. This avoids ever silently overwriting a newer external write.
- **Import**: validated up front — schemaVersion 1, ≤1 MiB, every task individually valid, no duplicate IDs. On any failure the board is left completely untouched (atomic) and a specific error is shown. On success, a native `confirm()` gates the replacement before the previous board is discarded.

## Views and interactions

- Board (3 status columns) and List (single sorted list) share the same search/filter state and the same `task-card` markup/test seams; only the active view's container is rendered/visible.
- The task-edit dialog is a native `<dialog>`: Escape closes it and focus returns to whatever opened it (New task button or a card's Edit button). Reduced-motion preference collapses the app's transition durations to 0.
- Deleting a task shows an undo toast (8s window) that restores the exact record, including after a reload once restored.

## Checks actually executed

Verified with Playwright (Chromium, headless-off via the local Chrome binary) against the app served over HTTP from a nested path (`/nested/path/index.html`), at both 1440×900 and 360×780 viewports:

- Seeding (7 tasks, 2 projects, all 3 statuses) and `localStorage` shape.
- Form validation (blank title, overlong title, overlong/duplicate/too-many tags) with visible errors.
- Create, edit-preserves-other-records, inline status change, all persisted and read back from storage.
- Search + status/project/priority filters, count text, no-results state.
- XSS-safety: a title containing `<img onerror=...>` renders as literal text, not markup.
- Delete → undo → reload → record still present with original fields.
- Export downloads a full-board JSON (schemaVersion 1, includes filtered-out tasks).
- Import rejects malformed JSON, duplicate IDs, unsupported status enum, invalid calendar date, and an oversized (>1 MiB) file — in every case leaving the existing board byte-for-byte untouched. A valid import (after confirmation) replaces the board and survives reload.
- Corrupt storage: recovery banner shown, original bytes preserved and downloadable exactly, explicit reset reseeds a usable board.
- Cross-tab conflict: a genuine second `Page` in the same browser context writes storage; the first tab shows the conflict banner, disables delete/status controls, and "Reload board" picks up the external state.
- Keyboard: Escape closes the modal and restores focus to the triggering button.
- View switch: List view shows the same `task-card` seams as Board view, with only the active view visible in the DOM.
- Screenshots captured and inspected at 1440px and 360px for the default board, the New Task form, and the no-results state — used to catch and fix two real layout bugs (a `[hidden]` specificity conflict that kept the inactive view visible, and filter `<select>` elements overflowing their grid column on narrow screens).
- No console/page errors during the full flow.

Not covered by automated checks (manual/visual judgment only): full WCAG contrast audit tooling, screen-reader-specific testing, `prefers-reduced-motion` behavior (visually confirmed via CSS variable design, not asserted in the automated run).

## Limitations

- The Board/List view choice is in-memory UI state only; it resets to Board on reload (filters and data are not lost, per the spec — only the view preference).
- The undo toast has an 8-second window; after it disappears the deletion can still be recovered via Import of a previously exported file, but not via the Undo button.
- No automated axe-core/contrast scan was run; token colors were chosen to meet WCAG AA visually (dark text on light surfaces, a single saturated accent) but this wasn't machine-verified.
