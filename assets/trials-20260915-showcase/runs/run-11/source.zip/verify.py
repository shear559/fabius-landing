"""
Standalone, reproducible verification script for solution.py / solution.md.

Runs two independent checks of solve(t) against a black-box / from-scratch
oracle, over a dense grid, random points, and points straddling every
regime boundary:

  1. If scipy is available: multi-start SLSQP on the *original* 3-variable
     problem (a completely black-box numerical optimizer, no knowledge of
     the derived formulas).
  2. Always: a from-scratch finite-candidate oracle that minimizes the
     reduced 2D quadratic g_t(x,y) = f_t(x,y,1-x-y) over the pentagon by
     evaluating it at the unconstrained minimizer (if feasible), at every
     vertex, and at the clipped stationary point of every edge -- i.e. the
     standard fact that the min of a strictly convex function over a convex
     polygon is attained at one of these O(1) candidates. This code path
     does not call solution.solve's internal regime logic; it only calls
     solution.solve(t) to get the answer being checked.

Usage:  python3 verify.py
"""

import itertools
import random
import sys

import solution


def f(x, y, z, t):
    return x*x + 2*y*y + 3*z*z + x*y - y*z + (2 - 2*t)*x + 5*y + z


def g(x, y, t):
    z = 1 - x - y
    return f(x, y, z, t)


PENTAGON_VERTICES = [
    (0.0, 0.0),
    (0.5, 0.0),
    (0.6, 0.1),
    (0.6, 0.4),
    (0.0, 1.0),
]
PENTAGON_EDGES = list(zip(PENTAGON_VERTICES, PENTAGON_VERTICES[1:] + PENTAGON_VERTICES[:1]))


def feasible(x, y, eps=1e-9):
    z = 1 - x - y
    return (x >= -eps and y >= -eps and z >= -eps and x <= 0.6 + eps
            and 2*y + z >= 0.5 - eps)


def unconstrained_min(t):
    # solves grad g_t = 0 :  8x+8y = 5+2t ;  8x+12y = 3
    y = (3 - (5 + 2*t)) / 4.0
    x = (5 + 2*t) / 8.0 - y
    return x, y


def edge_candidate(p, q, t):
    # minimize g_t along the segment p->q (parametrize x = p+s*(q-p), s in [0,1])
    # by sampling the closed-form 1D quadratic minimizer, clipped to [0,1].
    (x0, y0), (x1, y1) = p, q
    dx, dy = x1 - x0, y1 - y0

    # g_t(x0+s dx, y0+s dy) is a quadratic in s; minimize via derivative = 0.
    # Use a tiny numerical derivative-free ternary search (stdlib only, robust).
    lo, hi = 0.0, 1.0
    for _ in range(200):
        m1 = lo + (hi - lo) / 3
        m2 = hi - (hi - lo) / 3
        v1 = g(x0 + m1*dx, y0 + m1*dy, t)
        v2 = g(x0 + m2*dx, y0 + m2*dy, t)
        if v1 < v2:
            hi = m2
        else:
            lo = m1
    s = (lo + hi) / 2
    return x0 + s*dx, y0 + s*dy


def from_scratch_oracle(t):
    candidates = list(PENTAGON_VERTICES)
    xu, yu = unconstrained_min(t)
    if feasible(xu, yu):
        candidates.append((xu, yu))
    for p, q in PENTAGON_EDGES:
        candidates.append(edge_candidate(p, q, t))
    best = min(candidates, key=lambda xy: g(xy[0], xy[1], t))
    x, y = best
    z = 1 - x - y
    return x, y, z, g(x, y, t)


def run_stdlib_check(ts, tol=1e-6):
    max_err = 0.0
    max_pos_err = 0.0
    worst = None
    for t in ts:
        r = solution.solve(t)
        xo, yo, zo, fo = from_scratch_oracle(t)
        err = abs(r["value"] - fo)
        pos_err = max(abs(r["x"] - xo), abs(r["y"] - yo), abs(r["z"] - zo))
        if err > max_err:
            max_err = err
            worst = (t, r, (xo, yo, zo, fo))
        max_pos_err = max(max_pos_err, pos_err)
        # feasibility of solution.py's own answer
        assert feasible(r["x"], r["y"], 1e-7), (t, r)
        assert abs(r["x"] + r["y"] + r["z"] - 1) < 1e-9, (t, r)
    return max_err, max_pos_err, worst


def run_scipy_check(ts):
    try:
        import numpy as np
        from scipy.optimize import minimize
    except ImportError:
        return None

    cons = [
        {"type": "eq", "fun": lambda v: v[0] + v[1] + v[2] - 1},
        {"type": "ineq", "fun": lambda v: v[0]},
        {"type": "ineq", "fun": lambda v: v[1]},
        {"type": "ineq", "fun": lambda v: v[2]},
        {"type": "ineq", "fun": lambda v: 0.6 - v[0]},
        {"type": "ineq", "fun": lambda v: 2*v[1] + v[2] - 0.5},
    ]
    rng = random.Random(0)
    max_err = 0.0
    worst = None
    for t in ts:
        best = None
        for _ in range(6):
            x0 = [rng.random() for _ in range(3)]
            s = sum(x0)
            x0 = np.array([v/s for v in x0])
            res = minimize(lambda v: f(v[0], v[1], v[2], t), x0,
                            constraints=cons, method="SLSQP",
                            options={"ftol": 1e-14, "maxiter": 500})
            if res.success and (best is None or res.fun < best.fun):
                best = res
        r = solution.solve(t)
        err = abs(best.fun - r["value"])
        if err > max_err:
            max_err = err
            worst = (t, best.x.tolist(), r, best.fun)
    return max_err, worst


def main():
    boundaries = [-2, -1.5, -1, -0.5, 0, 1.8, 4]
    ts = set()
    n = 121
    for i in range(n):
        ts.add(-2 + 6.0 * i / (n - 1))
    rng = random.Random(42)
    for _ in range(150):
        ts.add(rng.uniform(-2, 4))
    for b in boundaries:
        for eps in (-1e-6, 0, 1e-6):
            ts.add(min(4.0, max(-2.0, b + eps)))
    ts = sorted(ts)

    # 0) import-cleanliness / type & bounds checks
    for bad_t in (-2.0000001, 4.0000001):
        try:
            solution.solve(bad_t)
            print("FAIL: out-of-range t was not rejected:", bad_t)
            sys.exit(1)
        except ValueError:
            pass
    try:
        solution.solve("0")
        print("FAIL: non-numeric t was not rejected")
        sys.exit(1)
    except TypeError:
        pass

    # 1) from-scratch finite-candidate oracle (always runs, stdlib only)
    max_err, max_pos_err, worst = run_stdlib_check(ts)
    print(f"[stdlib oracle] {len(ts)} points checked; "
          f"max |value error| = {max_err:.3e}; max |position error| = {max_pos_err:.3e}")
    if worst is not None:
        print("  worst case:", worst)
    assert max_err < 1e-6, "stdlib oracle disagreement exceeds tolerance"

    # 2) scipy black-box cross-check (if available)
    scipy_result = run_scipy_check(ts)
    if scipy_result is None:
        print("[scipy check] scipy not available in this environment; skipped.")
    else:
        max_err2, worst2 = scipy_result
        print(f"[scipy SLSQP]  {len(ts)} points checked; max |value error| = {max_err2:.3e}")
        if worst2 is not None:
            print("  worst case:", worst2)
        assert max_err2 < 1e-6, "scipy oracle disagreement exceeds tolerance"

    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
