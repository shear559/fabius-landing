"""
Reproducible verification script for solution.py / solution.md.
Run: python3 verify.py
Requires: numpy, scipy (both already used; standard scientific stack).
Uses no network access and reads no files outside this directory.
"""
import numpy as np
from scipy.optimize import minimize
from solution import solve


def f(v, t):
    x, y, z = v
    return x**2 + 2*y*y + 3*z*z + x*y - y*z + (2 - 2*t) * x + 5*y + z


def feasible(x, y, z, tol=1e-7):
    return {
        "x+y+z=1": abs(x + y + z - 1) < 1e-6,
        "x>=0": x >= -tol,
        "y>=0": y >= -tol,
        "z>=0": z >= -tol,
        "x<=3/5": x <= 0.6 + tol,
        "2y+z>=1/2": 2 * y + z >= 0.5 - tol,
    }


def scipy_oracle(t, restarts):
    cons = [
        {"type": "eq", "fun": lambda v: v[0] + v[1] + v[2] - 1},
        {"type": "ineq", "fun": lambda v: v[0]},
        {"type": "ineq", "fun": lambda v: v[1]},
        {"type": "ineq", "fun": lambda v: v[2]},
        {"type": "ineq", "fun": lambda v: 0.6 - v[0]},
        {"type": "ineq", "fun": lambda v: 2 * v[1] + v[2] - 0.5},
    ]
    best = None
    for x0 in restarts:
        res = minimize(f, x0, args=(t,), method="SLSQP", constraints=cons,
                        bounds=[(0, 0.6), (0, 1), (0, 1)],
                        options={"maxiter": 500, "ftol": 1e-14})
        if res.success and (best is None or res.fun < best.fun):
            best = res
    return best


def grid_oracle(t, n_x=900, n_y=400):
    best = None
    for x in np.linspace(0, 0.6, n_x):
        ylo, yhi = max(0.0, x - 0.5), 1 - x
        if yhi < ylo:
            continue
        ys = np.linspace(ylo, yhi, n_y)
        z = 1 - x - ys
        vals = f((x, ys, z), t)
        i = int(np.argmin(vals))
        if best is None or vals[i] < best[0]:
            best = (float(vals[i]), float(x), float(ys[i]))
    return best


def main():
    restarts = [
        np.array([0.0, 0.0, 1.0]), np.array([0.5, 0.0, 0.5]),
        np.array([0.6, 0.1, 0.3]), np.array([0.6, 0.4, 0.0]),
        np.array([0.0, 1.0, 0.0]), np.array([0.3, 0.3, 0.4]),
        np.array([0.1, 0.05, 0.85]),
    ]

    boundary = [-1.5, -1.0, -0.5, 0.0, 1.8]
    eps = 1e-7
    test_ts = [-2.0, -1.9, -1.75] + \
        [b + s for b in boundary for s in (-eps, 0.0, eps)] + \
        [-1.3, -0.8, -0.2, 0.5, 1.0, 2.5, 3.0, 3.9999, 4.0, -2, -1, 0, 1, 4]

    print("=== 1) Feasibility + internal consistency of solve(t) ===")
    for t in test_ts:
        d = solve(t)
        ch = feasible(d["x"], d["y"], d["z"])
        assert all(ch.values()), (t, ch, d)
        assert abs(f((d["x"], d["y"], d["z"]), float(t)) - d["value"]) < 1e-9
    print(f"  {len(test_ts)} t-values: all feasible, value matches direct evaluation")

    print("=== 2) Cross-check vs independent SLSQP solves (scipy) ===")
    max_val_diff = max_pt_diff = 0.0
    for t in test_ts:
        d = solve(t)
        best = scipy_oracle(float(t), restarts)
        assert best is not None
        vdiff = abs(best.fun - d["value"])
        pdiff = float(np.linalg.norm(best.x - np.array([d["x"], d["y"], d["z"]])))
        max_val_diff = max(max_val_diff, vdiff)
        max_pt_diff = max(max_pt_diff, pdiff)
        assert vdiff < 1e-4 and pdiff < 1e-3, (t, vdiff, pdiff)
    print(f"  max |value diff| = {max_val_diff:.2e}, max |point diff| = {max_pt_diff:.2e}")

    print("=== 3) Cross-check vs independent fine-grid oracle at representative t ===")
    for t in [-2, -1.5, -1, -0.5, 0, 0.9, 1.8, 2.5, 4]:
        d = solve(t)
        g = grid_oracle(float(t))
        vdiff = abs(g[0] - d["value"])
        print(f"  t={t:<6} grid_val={g[0]:.6f} closed_val={d['value']:.6f} diff={vdiff:.1e}")
        assert vdiff < 2e-4

    print("=== 4) Continuity (position, value) and C1 smoothness of f*(t) at all 5 transitions ===")
    for b in boundary:
        left, at, right = solve(b - eps), solve(b), solve(b + eps)
        pos_l = max(abs(left[k] - at[k]) for k in "xyz")
        pos_r = max(abs(right[k] - at[k]) for k in "xyz")
        dl = (at["value"] - solve(b - 1e-6)["value"]) / 1e-6
        dr = (solve(b + 1e-6)["value"] - at["value"]) / 1e-6
        print(f"  t={b}: pos-jump L={pos_l:.1e} R={pos_r:.1e}  f*'(left)={dl:.4f} f*'(right)={dr:.4f}")
        assert pos_l < 1e-5 and pos_r < 1e-5
        assert abs(dl - dr) < 1e-3

    print("=== 5) Envelope-theorem check: f*'(t) == -2 x*(t) on each regime ===")
    for t in [-1.9, -1.3, -0.8, -0.2, 0.9, 3.0]:
        d = solve(t)
        deriv = (solve(t + 1e-6)["value"] - solve(t - 1e-6)["value"]) / 2e-6
        expected = -2 * d["x"]
        print(f"  t={t:<6} f*'(t)={deriv:.6f}  -2x*(t)={expected:.6f}")
        assert abs(deriv - expected) < 1e-3

    print("\nALL VERIFICATION CHECKS PASSED")


if __name__ == "__main__":
    main()
