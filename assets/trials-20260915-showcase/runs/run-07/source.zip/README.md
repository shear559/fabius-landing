# Fieldnote Board

A local-first task board for a small research-publication team. Pure vanilla HTML/CSS/JS — no build step, no dependencies, no network calls, no backend. Everything lives in `localStorage` in the visiting browser.

## Running it

Serve the folder with any static file server and open `index.html` (directly opening the file also works, since only `localStorage` and `file`/`Blob` APIs are used — no `fetch`). It also works from a nested URL path (e.g. `/some/sub/path/index.html`) because `index.html` links `./styles.css` and `./app.js` with relative paths.

```
python3 -m http.server 8080
# then open http://localhost:8080/
```

## Files

- `index.html` — static shell: header, banner region, overview stat tiles, toolbar (search/filters/view switch/import-export), the task-form modal (`<template>`-driven), and a dedicated recovery screen for corrupt storage.
- `styles.css` — all styling, mobile-first with breakpoints for the 3-column board at ≥900px and a wider toolbar at ≥720px; a `prefers-reduced-motion` block disables transitions.
- `app.js` — all application logic (state, storage, validation, rendering, events). One coherent inline SVG icon set (`ICONS` object) is injected into `[data-icon]` placeholders instead of loading external icon fonts/images.

## Data & storage design

- Storage key: `fieldnote-board:v1`, value `{ schemaVersion: 1, tasks: [...] }`.
- Task shape is validated strictly in one place (`isValidTaskShape` / `isBoardValid`) and reused for (a) startup corruption detection, and (b) import validation, so the rules can't drift apart.
- **Seeding**: only happens when the storage key is entirely absent (`localStorage.getItem` returns `null`). Seed board: 8 tasks, 2 projects ("Reef Resilience Manuscript", "Spring Grant Report"), all 3 statuses, realistic research-publication content (drafting, data collection, stats, figures, submission, grant reporting).
- **Corruption**: if the stored value exists but fails JSON parsing or schema/shape validation, the app never seeds over it or rewrites it. It shows a full recovery screen with the reason, a "Download original data" button (downloads the exact original bytes as a `.txt` file), and a "Reset board" button that requires an explicit `confirm()` before replacing the data with a fresh seed.
- **Write failures**: every `localStorage.setItem` call is wrapped in `try/catch`. If it throws (e.g. quota exceeded, private-mode restrictions), the in-memory `state.tasks` still reflects the change (so the user's edit isn't lost from the screen/form), but a persistent error banner says the change was **not** saved to storage — the app never silently claims persistence it didn't achieve.
- **Cross-tab conflicts**: a `storage` event listener watches the board key. Since same-document writes never fire a `storage` event in that same document, any event received is guaranteed to originate from another tab/context. On such an event the app sets a conflict flag, shows a "Reload board" banner, and disables all destructive controls (New task, edit/delete/status per card, import) until the user explicitly clicks "Reload board", which re-reads storage and clears the flag. Read-only actions (search, filter, view switch, export) stay available.
- **Undo delete**: deleting keeps the removed record plus its original array index in memory and shows an "Undo" banner. Undo re-inserts at that index and persists immediately, so the restored task really is present after a reload — the button itself doesn't need to survive reload, the data does.
- **Import**: fully validated (schema version, every field/enum/date/tag rule, duplicate IDs) *before* touching state, so an invalid file leaves the previous board completely untouched (atomic). File size is checked against 1 MiB before reading. A valid file requires an explicit `window.confirm()` naming how many tasks will replace how many before the board is overwritten.
- **Tags**: comma-separated input is split, trimmed, emptied entries dropped, and deduplicated case-insensitively (first-seen casing wins), then capped at 8 tags of ≤24 characters each; violations are shown as an inline field error rather than silently truncated.
- Imported/typed text is only ever inserted via `textContent`/attribute APIs, never `innerHTML` with user data, so it's never interpreted as HTML.

## Views

A Board/List switch (`data-testid="view-board"` / `"view-list"`) re-renders `#main-region` from the same filtered task list and the same `buildCardElement` function, so only one view's set of `[data-testid="task-card"]` nodes exists in the DOM at a time, and switching preserves the current search/filter state.

## Accessibility

- All interactive controls are native `<button>`, `<select>`, `<input>` elements with associated `<label>`s or `aria-label`s (per-card status selects and edit/delete buttons get task-specific labels, e.g. "Edit Draft introduction section").
- The task-form modal: focus moves to the first field on open, `Escape` closes it and returns focus to whatever triggered it, `Tab`/`Shift+Tab` are trapped inside while open.
- `prefers-reduced-motion: reduce` disables the card hover transition and any other transitions/animations.
- `<noscript>` shows a clear message if JavaScript is disabled; the app root is `hidden` until JS successfully initializes, so a JS-disabled visitor never sees a broken, half-wired UI.
- Focus is deliberately moved after key actions (to the Undo button after a delete, back into the list after an undo, to the changed status `<select>` after a status change) instead of being dropped to `<body>`.

## Checks actually run

Using a local Playwright script (removed after use, not part of the deliverable) driving headless Chromium against a local static server, including a simulated nested URL path:

- Seed board renders 8 cards, 2+ projects, all 3 statuses, correct `schemaVersion`.
- Blank-title and too-many-tags validation errors render visibly; tag dedup (case-insensitive) verified end-to-end.
- Create, edit (with reload), delete, and undo-then-reload all verified against the persisted record count/content.
- Status `<select>` change persists to storage.
- Search-with-no-matches renders the no-results state; `filter-status` correctly restricts visible cards.
- Board/List switch preserves an active priority filter's result count.
- Export downloads the full board (including tasks hidden by an active filter).
- Import rejects malformed JSON, an invalid enum value, and duplicate IDs — in each case the board in storage is provably unchanged (atomicity); a valid file requires confirmation and survives reload.
- Corrupt storage (unparsable JSON) shows the recovery screen without altering the stored bytes; "Download original data" produces a file matching those exact bytes; "Reset board" reseeds after confirmation.
- A `storage` event from a second tab triggers the conflict banner and disables `create-task`; `reload-board` reconciles and un-blocks the UI.
- `Escape` closes the modal and returns focus to the triggering button.
- Screenshots captured and reviewed at 360px and 1440px (default board, modal open, list view, no-results state, full mobile scroll).

## Known limitations

- Drag-and-drop reordering between columns isn't implemented; status changes go through the per-card `<select>` (chosen deliberately for reliable keyboard/native accessibility over a drag interaction).
- The cross-tab conflict handling is "detect and block until reload" rather than field-level merge/reconciliation — simple and safe, but a concurrent edit in another tab is not auto-merged.
- No automated test suite ships in the deliverable folder (per the brief, verification was performed separately and isn't part of the app).
