# Lattice — fictional product landing page

A marketing landing page for **Lattice**, a fictional local-first research
notebook. Built for a design/engineering demonstration: vanilla HTML/CSS/JS
only, no build step, no network calls, no backend.

## Run it

Any static file server works, including a nested path. From this directory:

```sh
python3 -m http.server 8000
# open http://localhost:8000/index.html
```

Or open `index.html` directly in a browser (`file://`) — all asset URLs are
relative, so the page also works from a subpath like
`https://example.com/demos/lattice/`.

## Files

- `index.html` — structure and content
- `styles.css` — design tokens and all styling
- `app.js` — mobile nav, feature tabs, billing toggle, hero demo controls
- `verify.js` — the Playwright check script used during development (not
  required to run the site; kept as evidence of what was tested)

## Implementation decisions

- **Editorial identity**: a serif display face (system Georgia/Palatino
  stack, no webfonts) paired with a system sans body, warm paper canvas, a
  single rust/terracotta accent, and dark alternating sections for rhythm —
  meant to read like an annotated notebook rather than a generic SaaS page.
- **Original hero illustration**: a hand-built SVG scene (two source notes, a
  primary capture note, an export document, connecting paths) with three
  visual states — capture / connect / export — cross-faded by toggling
  `data-state` on the figure. User controls (`Play`/`Pause`, `Restart`) drive
  a `setInterval` cycle; no video or animation library.
- **Progressive enhancement for nav/tabs**: the mobile nav and the three
  feature panels are all present and visible in plain HTML/CSS. JavaScript
  adds a `js-enhanced` class that collapses the mobile nav behind the toggle
  and converts the feature panels into a proper tablist; with JS disabled,
  visitors get a stacked, fully readable page instead of missing content.
- **Icon family**: one hand-drawn stroke-icon set (`currentColor`, 1.75px
  stroke, round joins) reused across nav, tabs, steps and controls.
- **Pricing**: monthly/yearly toggle swaps text content only (`$12`/`$29`
  monthly, `$108`/`$264` yearly); no computed rounding drift, since the
  yearly figures are the literal supplied values.
- **Motion**: the only continuous animation is the user-controlled hero
  scene, off by default when `prefers-reduced-motion: reduce`; all other
  motion (buttons, tab underline) is a transform/opacity micro-interaction
  under 150ms, disabled globally under reduced motion via a CSS override.
- **Fictional-content disclosure**: a persistent top banner plus footer note
  state the product is a fictional demo; FAQ answers and feature copy stick
  to the supplied facts (device storage, Markdown export, source links,
  templates, local search) with no invented customers or metrics.

## Checks actually executed

Ran a Playwright script (`verify.js`, Chromium headless) against
`index.html` opened via `file://`, covering:

- Feature tabs: default selection, click switches `aria-selected` + visible
  panel, `ArrowRight` moves focus/selection to the next tab.
- Billing toggle: default monthly values (`$12`/`$29`), yearly values
  (`$108`/`$264`), and exact restoration on returning to monthly.
- All four FAQ `summary` elements present and open on click.
- Primary CTA `href="#workflow"` and target section presence.
- Mobile nav (360px viewport): `menu-toggle` starts `aria-expanded="false"`,
  opens the nav and shows a link, `Escape` closes it and returns focus to
  the toggle, selecting a nav link closes the menu and scrolls to the
  target section.
- Page loaded with **JavaScript disabled**: hero heading, the default price,
  and a mobile-nav link all remain visible.
- Page loaded with `prefers-reduced-motion: reduce`: the hero demo does not
  autoplay.
- No console/page errors on desktop load.
- Full-page screenshots captured and visually reviewed at 360px and 1440px
  (`verify.js` writes these to disk when run; not included in the final
  delivery — deleted after review).
- WCAG contrast ratios computed for every token text/background pairing
  (body, muted, accent, and on-dark variants): all are ≥ 5:1, clearing the
  4.5:1 AA text threshold.

All checks passed on the final version. Re-run with:

```sh
NODE_PATH=[playwright-qa]/node_modules node verify.js
```

## Known limitations

- Visual QA was automated assertions plus a manual look at two viewport
  screenshots (360px, 1440px); no cross-browser pass beyond Chromium and no
  screen-reader pass beyond semantic markup (tab/tabpanel roles, `aria-*`
  sync, focus management) was performed.
- The hero scene is a simplified illustrative diagram, not a literal product
  screenshot — it's meant to communicate the three-step workflow, not model
  a real UI.
- Contrast was checked with a small script against the WCAG relative
  luminance formula for the named color tokens, not a full automated
  accessibility audit (e.g. axe-core) of the rendered DOM.
