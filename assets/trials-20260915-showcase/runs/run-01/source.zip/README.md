# Lattice — fictional landing page demo

A static, vanilla HTML/CSS/JS marketing landing page for **Lattice**, a fictional
local-first research notebook. Built for a design/engineering demonstration —
not a real product, no purchases, no network calls, no build step.

## Run it

Any static file server works, including a nested path (all asset URLs are relative):

```
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

Or open `index.html` directly in a browser (no server required — no fetches,
fonts, or libraries are loaded).

## Files

- `index.html` — all markup and copy, including an inline SVG icon sprite (`<symbol>` defs) reused across the page for a consistent icon family.
- `styles.css` — the entire visual system (palette, type, layout, responsive rules, focus states, reduced-motion overrides).
- `app.js` — vanilla JS for the mobile nav, feature tabs, billing toggle, and hero demo controls. No dependencies.

## Design decisions

- **Visual system**: warm "paper" background with a serif display face (system
  serif stack, no remote fonts) for headings and a system sans stack for body
  text, a terracotta primary accent and a moss-green secondary accent (used for
  "connect"-related states), to read as an editorial research notebook rather
  than a generic SaaS template.
- **Icon family**: one inline SVG sprite (`#icon-*` symbols) — capture,
  connect, export, template, search, doc, play/pause/restart, menu/close,
  check — all sharing the same stroke weight and corner treatment, reused via
  `<use>` in the hero, tabs, workflow steps, and pricing lists.
- **Hero illustration + demo**: the hero's SVG illustration doubles as the
  "user-controlled product demonstration" required by the brief. It shows a
  fictional source panel, a note with an attached citation chip, a small
  relationship graph, and an export/Markdown card. Play/Pause/Restart buttons
  step through three states (`capture` → `connect` → `export`) via a
  `data-state` attribute; CSS shows/hides SVG layers and updates a caption.
  Autoplay advances every ~2.6s and can be paused or restarted at any time.
- **Reduced motion**: `@media (prefers-reduced-motion: reduce)` removes all
  CSS transitions (illustration layer fades, button transforms, smooth
  scrolling). State changes and autoplay still work, just as instant swaps
  instead of fades.
- **Feature tabs**: implemented with full ARIA tab/tabpanel semantics
  (`role="tab"`/`"tabpanel"`, `aria-selected`, roving `tabindex`, Arrow/Home/End
  key support). Each panel (`panel-capture`, `panel-connect`, `panel-export`)
  has distinct copy and a distinct colored visual swatch so the three states
  are visibly different, not just relabeled.
- **Pricing**: Solo ($12/mo, $108/yr) and Studio ($29/mo, $264/yr) are laid out
  as two directly comparable cards with matching structure (name, tagline,
  price, checklist, CTA) so scanning across them is easy. The billing toggle
  updates both prices and the visible "/month" or "/year" label together, and
  switching back to monthly restores the exact original values. No plan
  feature is invented beyond the product facts given (local storage, Markdown
  export, source links, templates, optional local search) — templates and
  local search are the two facts assigned to differentiate the tiers, and
  that's documented here rather than presented as a real business decision.
- **Content honesty**: no customers, reviews, ratings, or performance numbers
  are used anywhere. A dark banner at the very top of the page and a footer
  note both state plainly that this is a fictional product demonstration.
- **No-JS fallback**: navigation links, all section content, both prices, and
  all FAQ answers are present in the base HTML (FAQ uses native
  `<details>/<summary>`, which works without JavaScript). Only the mobile
  menu's open/close state, the tab-panel switching, the billing toggle's live
  update, and the hero demo's play/pause/restart require JS; with JS off the
  page remains fully readable and navigable via anchor links and open
  `<details>` elements.

## Checks actually executed

Ran a local Playwright script (Chromium, headless) against the built
`index.html` and confirmed, then deleted the script and its screenshots after
use (only the three deliverable files plus this README remain):

- Mobile nav: `menu-toggle` starts `aria-expanded="false"`; clicking it shows
  `mobile-nav` and sets `aria-expanded="true"`; `Escape` closes it and returns
  focus to the toggle button; clicking a nav link inside it closes the menu
  and navigates to the target section's hash.
- Feature tabs: only one panel is visible at a time; clicking
  `feature-connect` sets its `aria-selected="true"` and shows `panel-connect`
  while hiding the others; focusing a tab and pressing `ArrowRight` moves
  focus and selection to the next tab (wrapping to `feature-export`).
- Billing toggle: default prices are `12` / `29`; clicking
  `billing-yearly` updates them to `108` / `264` and switches the visible
  period label to "/year"; clicking `billing-monthly` restores exactly `12`
  and `29` with "/month".
- FAQ: all four `faq-0`…`faq-3` `<summary>` elements toggle their parent
  `<details open>` on click.
- Hero demo: default state is `capture`; clicking play sets
  `aria-pressed="true"` and the state advances automatically (observed
  reaching `connect`); clicking restart returns the state to `capture`.
- Primary CTA `a.btn-primary` with the text "Explore the workflow" has
  `href="#workflow"`.
- No-JS pass: loaded the page with JavaScript disabled and confirmed the body
  text still contains the prices, the nav labels, and the FAQ answer content.
- No `console.error` or uncaught page errors were logged during any of the
  above.
- Visual check: captured full-page screenshots at 360×900 and 1440×1000 and
  reviewed them for layout, spacing, and readability; also captured the open
  mobile-nav state at 360px.

I did not test with a screen reader, on real mobile hardware, or across
multiple browser engines (only Chromium via Playwright was available in this
environment).

## Known limitations

- Typography relies on system font stacks only (no remote fonts allowed by
  the brief), so exact heading appearance varies by OS.
- The hero illustration/demo is a simplified, stylized diagram, not a literal
  product screenshot — it's meant to communicate the workflow, not simulate a
  real UI pixel-for-pixel.
- Only manual/automated checks listed above were run; no automated
  cross-browser or assistive-technology testing was performed.
