# Fieldnote Board

A local-first task board for a small research team producing a fictional
publication, the "Trail Data Atlas". Pure HTML/CSS/JS — no build step, no
dependencies, no network calls, no backend.

## Running it

Serve the three files (`index.html`, `styles.css`, `app.js`) from any static
file server and open `index.html` in a browser. For example:

```
python3 -m http.server 8080
# then open http://127.0.0.1:8080/index.html
```

All asset references are relative (`./styles.css`, `./app.js`), so the app
also works when served from a nested path (e.g.
`http://host/some/nested/path/index.html`) — just point the server at the
folder containing these files. Opening `index.html` directly via `file://`
also works, since there are no ES module imports or CORS-sensitive fetches.

If JavaScript is disabled, a `<noscript>` banner explains that the app
requires it; the interactive app markup stays hidden until `app.js` runs.

## Data model & persistence

The board is stored in `localStorage` under the key `fieldnote-board:v1` as:

```json
{ "schemaVersion": 1, "tasks": [ { "id": "...", "title": "...", "project": "...",
  "status": "todo|doing|done", "priority": "low|medium|high",
  "dueDate": "YYYY-MM-DD or \"\"", "tags": ["..."] } ] }
```

- IDs are generated with `crypto.randomUUID()` (with a fallback) and checked
  for uniqueness against the in-memory board.
- Tags are split on commas, trimmed, deduplicated case-insensitively, capped
  at 8, and each tag is capped at 24 characters.
- On genuinely empty storage (key absent), the app seeds 8 realistic tasks
  across 3 projects and all 3 statuses, then persists that seed.
- Every mutation (create, edit, delete/undo, status change, import, reset)
  goes through one `commitTasks()` path that updates in-memory state, writes
  to `localStorage`, and re-renders — so a single source of truth is always
  reflected in the UI.

## Error handling & recovery design

- **Form validation**: blank/overlong titles or projects, malformed due
  dates, and tag violations (length/count) are rejected with inline,
  field-level error messages; the modal stays open and focus moves to the
  first invalid field. (Native `<input type="date">` also refuses to hold an
  impossible calendar date such as 2026-02-30, so that path is additionally
  covered by the import validator below.)
- **Corrupt storage**: on load, if the stored value isn't parseable JSON or
  doesn't match the schema (bad enum, bad date, oversized field, duplicate
  ID, etc.), the app never touches or rewrites that value. It shows a
  dismissal-free recovery banner with a **Download original data** action
  (saves the exact raw bytes as a `.txt` file) and a **Reset board** action
  that requires an explicit confirmation before it seeds a fresh board and
  finally overwrites storage. Task creation/editing/import are disabled
  while in this state so nothing can quietly clobber the unreadable bytes.
- **Storage write failures** (e.g. quota exceeded, private-mode
  restrictions): the attempted change is kept in memory and shown in the UI,
  but a persistent toast explains the change was **not saved** and will be
  lost on reload — the app never silently claims persistence it didn't
  achieve.
- **Cross-tab conflicts**: a `storage` event from another tab/window writing
  the same key shows an info banner ("Updated in another tab") and disables
  every destructive control (status changes, edit, delete, create, import)
  until the user clicks **Reload board**, which re-reads and re-validates
  storage (running the same corruption checks) before re-enabling editing.
  This is the simplest reconciliation that can never silently overwrite
  newer state written by the other tab.
- **Import**: files are read locally via `FileReader`; size is checked
  against 1 MiB before and after reading, JSON parsing is wrapped in
  `try/catch`, and the whole document is validated (schema version, per-task
  field shape/enum/length/date validity, duplicate IDs) *before* anything is
  changed or the user is asked to confirm — so a rejected import always
  leaves the previous board completely untouched (atomic). Only after a
  passing validation does `window.confirm()` ask the user to replace the
  board; accepting persists the new board immediately.
- All rendered task text (title, project, tags) is set via `textContent`,
  never `innerHTML`, so imported or typed text is always treated as plain
  text and can't inject markup.

## Design & interaction notes

- One coherent hand-drawn SVG icon set (plus, edit, trash, undo, search,
  export/import, board/list, warning, flag, calendar, tag, notes, reload,
  close) is defined once as an inline `<symbol>` sprite and reused via
  `<use>`.
- Board view groups tasks into three columns (To do / Doing / Done); List
  view shows one flat, denser list. Both read from the same filtered task
  set and render the same `data-testid="task-card"` markup — only the
  active view's container is populated, so there's never a duplicate card in
  the DOM. Switching views preserves all active filters, search text, and
  the underlying data.
- Distinct empty states: no tasks at all (with a "New task" call to action),
  no search/filter matches (with "Clear filters"), and a storage-recovery
  placeholder while a corruption banner is active.
- Keyboard/accessibility: every control has a real accessible name (buttons
  are labelled per-task, e.g. "Edit Draft chapter 2: methodology"); the task
  modal is a `role="dialog"` that traps Tab focus, closes on `Escape`, and
  returns focus to whatever triggered it; a skip link jumps to the board;
  `prefers-reduced-motion: reduce` disables non-essential transitions.
- No invented metrics — the overview tiles show literal counts (total,
  to do, doing, done) drawn directly from the task list.

## Checks actually executed

Verified interactively with a headless Chromium (Playwright) driving the
app over a local static server, then removed the scratch script/screenshots
before delivery:

- Seed data has ≥6 tasks, ≥2 projects, all 3 statuses.
- Create → persists across reload; editing one task leaves all others intact.
- Blank title / malformed due date rejected with visible, field-scoped errors;
  form stays open.
- `Escape` closes the modal and returns focus to the button that opened it.
- Delete removes the card; `data-testid="undo-delete"` restores the exact
  record, including after a reload.
- Search + all three filters combine correctly; a true no-results state
  renders; the visible "N of M tasks" count updates live.
- Board/List toggle preserves filters/data and never renders duplicate cards.
- Export downloads a `schemaVersion: 1` document containing every task
  (not just the filtered view).
- Import: a valid file replaces the board only after explicit confirmation
  and survives reload; unsupported status enum, duplicate IDs, an
  impossible calendar date, and an oversized (>1 MiB) file are each rejected
  *before* the confirmation dialog, leaving the prior board byte-for-byte
  unchanged in storage.
- Corrupt `localStorage` value (invalid JSON) is left untouched on disk, a
  recovery banner appears, and **Reset board** (after confirmation) seeds a
  working board again.
- Two tabs sharing the same origin: a write in tab A shows a conflict banner
  in tab B and disables its status/edit/delete controls until **Reload
  board** is clicked, after which tab B reflects tab A's change.
- Manual visual review of both a 360px mobile viewport and a 1440px desktop
  viewport (default board, list view, and the task modal).

## Known limitations

- Undo only remembers the single most recent delete; deleting a second task
  before undoing the first discards the earlier undo buffer.
- The cross-tab conflict/reload strategy favors safety over automatic
  merging: it never tries to reconcile concurrent edits field-by-field, it
  simply blocks destructive actions in the stale tab until the user
  reloads.
- Reduced-motion support relies on the OS/browser `prefers-reduced-motion`
  setting; the app has almost no motion to begin with, by design.
