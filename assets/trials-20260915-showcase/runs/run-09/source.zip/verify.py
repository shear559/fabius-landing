"""
Reproducible verification script for solution.py / solution.md.

Run with:  python3 verify.py

Requires: sympy, numpy, scipy (all present in this environment). Uses no
network access. Prints PASS/FAIL for each check and a summary at the end.
"""

import sys
import numpy as np
from fractions import Fraction as Fr

sys.path.insert(0, ".")
from solution import solve

failures = []


def check(name, cond):
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {name}")
    if not cond:
        failures.append(name)


# ---------------------------------------------------------------------------
# 1. Symbolic re-derivation of the reduced objective and Hessian (sympy)
# ---------------------------------------------------------------------------
import sympy as sp

x, y, z, t = sp.symbols("x y z t", real=True)
f = x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z
g = sp.expand(f.subs(z, 1 - x - y))
g_star = 4*x**2 + 8*x*y + 6*y**2 - (5 + 2*t)*x - 3*y + 4
check("reduced objective g_t(x,y) matches solution.md (*)",
      sp.simplify(g - g_star) == 0)

H = sp.hessian(g, (x, y))
check("Hessian [[8,8],[8,12]] is positive definite (strict convexity)",
      H.is_positive_definite)

# ---------------------------------------------------------------------------
# 2. Exact endpoint continuity at all 5 regime breakpoints (Fraction-exact)
# ---------------------------------------------------------------------------
breakpoints = [Fr(-3, 2), Fr(-1), Fr(-1, 2), Fr(0), Fr(9, 5)]
for b in breakpoints:
    rl = solve(float(b) - 0.0)  # value exactly at the breakpoint (both sides agree by construction)
    # approach from left and right with a tiny epsilon to check no jump
    eps = 1e-9
    r_left = solve(float(b) - eps)
    r_right = solve(float(b) + eps)
    ok = (abs(r_left["value"] - r_right["value"]) < 1e-6 and
          abs(r_left["x"] - r_right["x"]) < 1e-6 and
          abs(r_left["y"] - r_right["y"]) < 1e-6 and
          abs(r_left["z"] - r_right["z"]) < 1e-6)
    check(f"continuity of solve(t) across breakpoint t={b}", ok)

# ---------------------------------------------------------------------------
# 3. Feasibility of solve(t) over a dense grid
# ---------------------------------------------------------------------------
ts = np.linspace(-2, 4, 3001)
bad = 0
for tt in ts:
    r = solve(float(tt))
    xx, yy, zz = r["x"], r["y"], r["z"]
    ok = (abs(xx + yy + zz - 1) < 1e-9 and xx >= -1e-9 and yy >= -1e-9 and
          zz >= -1e-9 and xx <= 0.6 + 1e-9 and 2*yy + zz >= 0.5 - 1e-9)
    if not ok:
        bad += 1
check("solve(t) feasible on a 3001-point grid over [-2,4]", bad == 0)

# ---------------------------------------------------------------------------
# 4. Cross-check against an independent numeric QP solve (scipy SLSQP)
# ---------------------------------------------------------------------------
from scipy.optimize import minimize

def fval(v, tt):
    xx, yy, zz = v
    return xx**2 + 2*yy**2 + 3*zz**2 + xx*yy - yy*zz + (2 - 2*tt)*xx + 5*yy + zz

def fgrad(v, tt):
    xx, yy, zz = v
    return np.array([2*xx + yy + (2 - 2*tt), 4*yy + xx - zz + 5, 6*zz - yy + 1])

cons = [
    {"type": "eq", "fun": lambda v: v[0] + v[1] + v[2] - 1},
    {"type": "ineq", "fun": lambda v: v[0]},
    {"type": "ineq", "fun": lambda v: v[1]},
    {"type": "ineq", "fun": lambda v: v[2]},
    {"type": "ineq", "fun": lambda v: 0.6 - v[0]},
    {"type": "ineq", "fun": lambda v: 2*v[1] + v[2] - 0.5},
]
starts = [(0, 0, 1), (0.6, 0.1, 0.3), (0.5, 0, 0.5), (0, 1, 0), (0.3, 0.3, 0.4), (0.1, 0.4, 0.5)]

rng = np.random.default_rng(0)
sample_ts = list(np.linspace(-2, 4, 61))
for b in [-1.5, -1, -0.5, 0, 1.8]:
    for e in (1e-6, -1e-6):
        sample_ts.append(b + e)
sample_ts += list(rng.uniform(-2, 4, 40))

max_val_err = 0.0
max_pt_err = 0.0
for tt in sample_ts:
    tt = float(np.clip(tt, -2, 4))
    best = None
    for x0 in starts:
        res = minimize(fval, x0, args=(tt,), jac=fgrad, constraints=cons,
                        method="SLSQP", options={"maxiter": 500, "ftol": 1e-14})
        if res.success and (best is None or res.fun < best.fun):
            best = res
    r = solve(tt)
    val_err = abs(best.fun - r["value"])
    pt_err = max(abs(best.x[0] - r["x"]), abs(best.x[1] - r["y"]), abs(best.x[2] - r["z"]))
    max_val_err = max(max_val_err, val_err)
    max_pt_err = max(max_pt_err, pt_err)

print(f"    max |value - SLSQP value| over {len(sample_ts)} samples: {max_val_err:.3e}")
print(f"    max |point  - SLSQP point| over {len(sample_ts)} samples: {max_pt_err:.3e}")
check("solve(t) matches independent SLSQP solve to 1e-6", max_val_err < 1e-6 and max_pt_err < 1e-6)

# ---------------------------------------------------------------------------
# 5. KKT multiplier sign / complementary-slackness sanity sweep
# ---------------------------------------------------------------------------
bad_mult = 0
for tt in np.linspace(-2, 4, 601):
    r = solve(float(tt))
    for name, val in r["multipliers"].items():
        if val < -1e-9:
            bad_mult += 1
check("all reported KKT multipliers are >= 0 on a 601-point grid", bad_mult == 0)

# ---------------------------------------------------------------------------
# 6. Envelope-theorem identity v'(t) = -2 x*(t), via central finite differences
# ---------------------------------------------------------------------------
h = 1e-6
bad_envelope = 0
for tt in np.linspace(-1.999, 3.999, 400):
    v_p = solve(float(tt) + h)["value"]
    v_m = solve(float(tt) - h)["value"]
    dv = (v_p - v_m) / (2 * h)
    xstar = solve(float(tt))["x"]
    if abs(dv - (-2 * xstar)) > 1e-4:
        bad_envelope += 1
check("v'(t) ~= -2 x*(t) (envelope theorem) via finite differences", bad_envelope == 0)

# ---------------------------------------------------------------------------
# 7. Edge cases: ints, out-of-range, type errors, endpoint clamping
# ---------------------------------------------------------------------------
r_int = solve(-1)
check("solve accepts int input", isinstance(r_int, dict))

try:
    solve(5.0)
    ok_range = False
except ValueError:
    ok_range = True
check("solve rejects t outside [-2,4]", ok_range)

try:
    solve("1")
    ok_type = False
except TypeError:
    ok_type = True
check("solve rejects non-numeric t", ok_type)

r_lo = solve(-2)
r_hi = solve(4)
check("solve(-2) and solve(4) return finite numeric dicts",
      all(np.isfinite(r_lo[k]) for k in ("x", "y", "z", "value")) and
      all(np.isfinite(r_hi[k]) for k in ("x", "y", "z", "value")))

# ---------------------------------------------------------------------------
# 8. Import purity: importing the module prints nothing
# ---------------------------------------------------------------------------
import io
import contextlib
import importlib

buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    import solution as _reimport
    importlib.reload(_reimport)
check("importing solution.py produces no stdout output", buf.getvalue() == "")

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
print()
if failures:
    print(f"{len(failures)} check(s) FAILED:")
    for name in failures:
        print(" -", name)
    sys.exit(1)
else:
    print("All checks PASSED.")
