# Fieldnote Board

A local-first task board for a small research-publication team. Fictional demo — no
backend, no network calls, no auth, no build step.

## Run it

Serve this folder (or any parent of it) with any static file server and open
`index.html` — the app uses only relative paths (`./styles.css`, `./app.js`), so it
works from a nested URL path too. Example:

```sh
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Opening `index.html` directly via `file://` also works in most browsers, since
there are no fetch/module requests — everything is a classic `<script>` and
inline SVG sprite.

## Data model

`localStorage["fieldnote-board:v1"]` holds `{ schemaVersion: 1, tasks: [...] }`.
Each task has exactly: `id`, `title` (≤120 chars), `project` (≤80 chars),
`status` (`todo`/`doing`/`done`), `priority` (`low`/`medium`/`high`), `dueDate`
(`""` or `YYYY-MM-DD`, checked against real calendar rules — no Feb 30), and
`tags` (≤8 strings, each ≤24 chars, trimmed, de-duplicated case-insensitively).

On first run with **no** existing key, the app seeds 8 fictional tasks across two
projects ("Site Survey" and "Manuscript") covering all three statuses. If the key
exists but the JSON is malformed or fails schema validation, the app never seeds
or overwrites it — it shows a recovery banner instead (see below).

## Error handling & safety design

- **Corrupt storage** — the raw bytes are left untouched. A banner offers
  "Download original data" (exports the exact original text) and "Reset board"
  (requires an explicit confirm dialog before it clears the key and reseeds).
- **Storage write failures** (e.g. quota exceeded) — `localStorage.setItem` is
  wrapped in try/catch. On failure the in-memory state is **not** updated, a
  banner says the change wasn't saved, and for task create/edit the form stays
  open with the user's entered values intact.
- **Cross-tab conflicts** — a `storage` event listener detects writes from other
  tabs/windows. A banner appears and any further destructive action (status
  change, edit, delete, import) is refused with a "not saved" message until the
  user clicks "Reload board", which re-reads and re-validates storage.
- **Import** is fully validated before anything is written: JSON parse, size
  (≤1 MiB), schema version, per-task field/enum/date checks, and duplicate-id
  detection all run first; the very first invalid task aborts the whole import
  with the prior board completely untouched (atomic). A valid file still
  requires an explicit `confirm()` before it replaces the board.
- **Delete** is immediate but reversible: an in-memory "last deleted" record
  backs a visible Undo action in a toast; undoing re-persists the exact record
  at its original position.
- Imported/typed text is only ever placed via `textContent`/attribute APIs,
  never `innerHTML`, so it can't be interpreted as markup.

## Design

One accent color (terracotta) on an otherwise neutral, warm-paper palette;
status/priority are conveyed with text labels, not color alone. A 3-column
board (Todo/Doing/Done) is the desktop default; each column stacks full-width
on narrow screens instead of squeezing into columns. A List/Board switch keeps
the same filters, search and data, rendering task rows/cards through the same
`data-testid="task-card"` seam — only the active view is mounted in the DOM.
One custom monoline SVG icon sprite (`currentColor`, single stroke weight)
covers every icon in the app. Motion is a single button-press scale, suppressed
entirely under `prefers-reduced-motion`. All interactive controls are native
`button`/`select`/`input` elements with visible focus rings and accessible
names; the task-edit dialog closes on Escape and returns focus to its trigger.
A `<noscript>` banner explains the app needs JavaScript.

## Checks actually executed

Verified with a headless Chromium (Playwright) script against a local static
server, covering: seed shape (8 tasks / 2 projects / all statuses), create,
validation errors on blank title, edit (preserves sibling records), delete +
undo (persists across reload), search with no results, status/project/priority
filtering, quick status change from a card, Board/List view switch using the
same test seams, export contents, import rejection of malformed JSON and of an
invalid enum (board left untouched in both cases), import acceptance +
confirm + persistence across reload, corrupt-storage recovery (banner shown,
raw bytes preserved and downloadable, reset flow), a simulated `setItem`
failure (save-error shown, form data retained), Escape-to-close plus focus
return, a real cross-tab conflict (second tab's write triggers a banner in the
first, blocks a destructive edit, clears on explicit reload), and a copy of the
app served from a nested subdirectory to confirm relative-asset loading with no
console errors. Desktop (1440px) and mobile (360px) screenshots were reviewed
by eye for layout and hierarchy.

## Limitations

- No automated axe/contrast audit was run; focus states and color choices were
  checked visually against WCAG AA guidance, not machine-verified.
- The "undo" buffer holds only the single most recent deletion.
- Reconciliation on cross-tab conflict is "stop and ask to reload," not a
  field-level merge — simplest safe behavior for a local-only demo.
