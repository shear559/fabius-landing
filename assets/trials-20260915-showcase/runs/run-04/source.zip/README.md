# Lattice — fictional marketing landing page (demo)

A static, vanilla HTML/CSS/JS landing page for **Lattice**, a fictional local-first research
notebook. Built for a design/engineering benchmark — the product, its pricing, and its facts
are supplied fiction, not a real business.

## Run it

No build step. Serve the three files (`index.html`, `styles.css`, `app.js`) from any static
server; all asset references are relative, so it also works from a nested path
(e.g. `http://localhost:8080/some/sub/path/index.html`).

```sh
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Opening `index.html` directly via `file://` also works (no fetch/XHR is used).

## Implementation decisions

- **Visual system**: warm paper canvas + near-black ink + one rust/terracotta accent, serif
  display type (system font stack: Iowan Old Style/Palatino/Georgia) paired with system-ui body
  type — an editorial identity that needs no remote fonts. All colors, spacing, radii and type
  sizes are CSS custom properties (tokens) in `styles.css`.
- **Icon family**: one inline SVG sprite (`<symbol>` defs at the top of `index.html`), single
  stroke weight, `currentColor`, reused for capture/connect/export/search/template/etc.
- **Hero illustration**: an original hand-built SVG scene (notes with fictional titles + source
  chips, connecting lines, an export card and target) with a user-controlled Play/Pause/Restart
  demonstration that steps through Capture → Connect → Export. `prefers-reduced-motion` disables
  the autoplay interval and turns Play into a manual "advance one stage" action; CSS also forces
  near-zero transition/animation durations under reduced motion.
- **Progressive enhancement without JS**: the mobile nav panel and the two hidden feature panels
  use `[hidden]` in the markup but a CSS override (`.mobile-nav[hidden]{display:block}` /
  `.panels > .panel[hidden]{display:block}`) makes them visible by default; an inline
  `<html class="no-js">` → `class="js"` swap (tiny inline script in `<head>`) re-enables the real
  hiding only once JavaScript has actually run. Result: with JS off, all nav links and all three
  feature panels are present and readable; with JS on, only the active tab/panel is shown and the
  mobile nav toggles as expected. Prices, the pricing toggle's default (monthly) values, and all
  FAQ entries are static content and need no JS to read.
- **Feature tabs**: real `role="tablist"`/`role="tab"`/`role="tabpanel"` semantics,
  `aria-selected`/`tabindex` managed on click, and Arrow/Home/End keyboard navigation with
  automatic activation.
- **Mobile nav**: a `<button data-testid="menu-toggle">` with `aria-expanded`, toggling a
  `data-testid="mobile-nav"` region; `Escape` closes it and returns focus to the toggle;
  clicking any link inside it closes it.
- **Billing toggle**: `data-testid="billing-monthly"` / `"billing-yearly"` swap the text content
  of `price-solo` / `price-studio` and a "billed monthly/yearly" caption; values are hard-coded
  ($12/$29 monthly, $108/$264 yearly) and switching back to monthly restores the exact original
  strings.
- **FAQ**: four native `<details>/<summary>` elements — no JS required to open/close.

## Checks I actually ran

Used a headless Chromium session (via the Playwright library already available on this machine)
served from a nested path (`/nested/path/site/index.html`) to mirror real deployment, plus manual
screenshot review at 360px and 1440px. All of the following passed (38/38 assertions, script not
retained in this delivery):

- Feature tabs: default panel visibility, click-to-switch, `aria-selected` updates, and
  Arrow-Right keyboard navigation through all three tabs/panels.
- Billing toggle: initial $12/$29 monthly values, switching to yearly shows $108/$264, and
  switching back to monthly restores $12/$29 exactly.
- All four FAQ `summary` elements present and open on click.
- Primary CTA "Explore the workflow" present with `href="#workflow"`.
- Hero demonstration: Play advances the stage/status text; Restart returns it to "Capture".
- Mobile (360px) nav: hidden by default, opens on toggle with `aria-expanded` sync, closes on
  Escape with focus returned to the toggle, and closes when a link is selected (and the page
  navigates to that section's hash).
- No horizontal overflow at 360px viewport width.
- JavaScript-disabled pass (`javaScriptEnabled: false`): prices, mobile nav links, all three
  feature panels, and the FAQ are all present/visible without JS.
- No console errors on page load.
- Visual review via full-page and section screenshots at 1440px and 360px (hero, feature tabs,
  pricing, FAQ, mobile nav open).

Not run: automated accessibility audit tooling (e.g. axe) and cross-browser testing beyond
Chromium — manual review only for contrast/focus/semantics.

## Known limitations

- The hero SVG illustration and mock panel graphics are simple, hand-built shapes rather than a
  design-tool export; they're legible at the sizes used but not photorealistic.
- The "Studio" plan's vault/template counts are fictional product tiering details invented to
  differentiate the two plans, built only from the facts supplied in the brief (local storage,
  Markdown export, source links, reusable templates, optional full-text search) — no adoption,
  review, or performance claims are made anywhere on the page.
- Reduced-motion handling for the hero demo was verified by reading the code path and CSS media
  query, not by running an automated reduced-motion browser check in this pass.
- No automated Lighthouse/axe accessibility score was captured; focus states, contrast, and ARIA
  roles were checked by manual review and the interaction tests above.
