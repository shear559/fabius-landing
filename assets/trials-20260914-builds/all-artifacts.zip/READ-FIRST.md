# Fabius build trials, 2026-09-14

Twelve runs of claude-sonnet-5 on the three September 10 briefs: two runs with the Fabius 3.1.0 contracts read first, two without, per task. Graded by the unchanged September 10 browser oracle (Chromium + WebKit, 360/1440), its capture helper, its exact mathematics oracle (1,233 probes) and two blind claude-opus-5 judges for the eight proof criteria.

- `results.json` — the published data; `briefs/`, `contracts/manifest.json` (Fabius commit and file hashes), `runs/plan.json`.
- `runs/run-NN/` — `source.zip` (every file the run left, brief excluded), `answer.md`, `trace.json`, `checks.json` (raw grade or score plus judge verdicts), `checks.html`, captures as lossless WebP.
- `judging/proof-judges-raw.json` — both judges' verdicts as returned.
- `evaluation/` — the oracle, capture and scoring code as run (paths normalized); `scripts/` — the pipeline, assembler and page generator.

Paths are normalized: `[fabius]/` is the Fabius repository at the recorded commit, `[study]` the study directory, `[user]` the home directory. Protocol: https://fabius-landing.vercel.app/assets/trials-20260914-builds/protocol.html
