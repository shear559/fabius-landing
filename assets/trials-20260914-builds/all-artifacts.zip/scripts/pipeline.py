#!/usr/bin/env python3
"""Evaluate finished builds2 runs with the September 10 harness: meta from the agent transcript,
browser rubric + captures for landing/app, numeric oracle + 127-sample curve for math. Idempotent per run."""
import json,os,sys,subprocess,datetime,hashlib,shutil,glob
S='[study]'
TASKS='[study]/tasks'
plan=json.load(open(f'{S}/runs/plan.json')); agents=json.load(open(f'{S}/runs/agents.json'))
only=set(sys.argv[1:])
def sha(b): return hashlib.sha256(b).hexdigest()
def extract(rid):
    out=f'{TASKS}/{agents[rid]}.output'
    if not os.path.exists(out): return None
    events=[]; final=None; first=None; last=None; tokens=0; model=None; calls=0; complete=False
    for line in open(out,encoding='utf-8',errors='ignore'):
        try: j=json.loads(line)
        except Exception: continue
        ts=j.get('timestamp')
        if ts: first=first or ts; last=ts
        m=j.get('message')
        if not isinstance(m,dict): continue
        if j.get('type')=='assistant':
            model=m.get('model') or model; u=m.get('usage') or {}; tokens+=int(u.get('output_tokens') or 0)
            c=m.get('content'); has_tool=False
            if isinstance(c,list):
                for blk in c:
                    if blk.get('type')=='tool_use':
                        has_tool=True; calls+=1; inp=blk.get('input') or {}
                        s=inp.get('command') if blk.get('name')=='Bash' else json.dumps({k:(v[:200] if isinstance(v,str) else v) for k,v in inp.items() if k in ('file_path','pattern','path')})
                        events.append({'kind':'tool_use','name':blk.get('name'),'input':(s or '')[:500]})
                    elif blk.get('type')=='text' and blk.get('text','').strip():
                        final=blk['text']; events.append({'kind':'text','chars':len(blk['text'])})
            if not has_tool and final: complete=True
    if not complete: return None
    f=datetime.datetime.fromisoformat(first.replace('Z','+00:00')); l=datetime.datetime.fromisoformat(last.replace('Z','+00:00'))
    return {'answer':final,'events':events,'meta':{'model':model,'elapsed_seconds':round((l-f).total_seconds(),1),'output_tokens':tokens,'tool_calls':calls,'started':first,'ended':last}}
for r in plan:
    rid=r['id']
    if only and rid not in only: continue
    work=f'{S}/runs/{rid}/work'; out=f'{S}/eval-out/{rid}'; os.makedirs(out,exist_ok=True)
    if os.path.exists(f'{out}/done.json'): print(rid,'already evaluated'); continue
    ex=extract(rid)
    if not ex: print(rid,'not finished'); continue
    deliverables={'landing':['index.html','styles.css','app.js'],'app':['index.html','styles.css','app.js'],'math':['solution.md','solution.py','verification.md']}[r['task']]
    missing=[d for d in deliverables if not os.path.exists(f'{work}/{d}')]
    open(f'{out}/answer.md','w').write(ex['answer']); json.dump(ex['events'],open(f'{out}/trace.json','w'),indent=1)
    meta={'id':rid,'task':r['task'],'repeat':r['repeat'],'arm':r['arm'],**ex['meta'],'missing_deliverables':missing,'status':'Completed' if not missing else 'Incomplete'}
    files=sorted(f for f in os.listdir(work) if f!='BRIEF.md' and not f.startswith('_') and os.path.isfile(f'{work}/{f}'))
    meta['files']={f:{'bytes':os.path.getsize(f'{work}/{f}'),'sha256':sha(open(f'{work}/{f}','rb').read())} for f in files}
    if r['task'] in ('landing','app') and not missing:
        g=subprocess.run(['node','grade.mjs','--kind',r['task'],'--directory',work,'--run-id',rid,'--output',f'{out}/grade'],cwd=f'{S}/eval/web-oracle',capture_output=True,text=True,timeout=1500)
        meta['grade_exit']=g.returncode; open(f'{out}/grade.stdout.txt','w').write(g.stdout[-4000:]+'\n'+g.stderr[-2000:])
        cap=f'{out}/captures'; shutil.rmtree(cap,ignore_errors=True)
        c=subprocess.run(['node','capture.mjs','--kind',r['task'],'--directory',work,'--run-id',rid,'--output',cap],cwd=f'{S}/eval',capture_output=True,text=True,timeout=600)
        meta['capture_exit']=c.returncode; open(f'{out}/capture.stdout.txt','w').write(c.stdout[-2000:]+'\n'+c.stderr[-2000:])
        for png in glob.glob(f'{cap}/*.png'):
            subprocess.run(['cwebp','-quiet','-lossless',png,'-o',png[:-4]+'.webp'],check=False)
    if r['task']=='math' and not missing:
        sc=subprocess.run([sys.executable,'-I','-S','-B','score.py',f'{work}/solution.py','--output',f'{out}/score.json'],cwd=f'{S}/eval/math-oracle',capture_output=True,text=True,timeout=300)
        meta['score_exit']=sc.returncode; open(f'{out}/score.stdout.txt','w').write(sc.stdout[-3000:]+'\n'+sc.stderr[-2000:])
        ts=[round(-2+6*i/126,10) for i in range(127)]
        cr=subprocess.run([sys.executable,'-I','-S','-B','candidate_runner.py',f'{work}/solution.py'],cwd=f'{S}/eval/math-oracle',input=json.dumps(ts),capture_output=True,text=True,timeout=120)
        try:
            res=json.loads(cr.stdout)['results']; curve=[{'t':t,**x['output']} for t,x in zip(ts,res) if x.get('ok')]
        except Exception as e: curve=[]; meta['curve_error']=str(e)[:200]
        json.dump(curve,open(f'{out}/curve.json','w'))
        meta['curve_points']=len(curve)
    json.dump(meta,open(f'{out}/meta.json','w'),indent=1); json.dump({'evaluated':datetime.datetime.utcnow().isoformat()+'Z'},open(f'{out}/done.json','w'))
    print(rid,r['task'],r['arm'],'r'+str(r['repeat']),'| elapsed',meta['elapsed_seconds'],'tokens',meta['output_tokens'],'calls',meta['tool_calls'],'| missing',missing,'| grade',meta.get('grade_exit'),'capture',meta.get('capture_exit'),'score',meta.get('score_exit'),'curve',meta.get('curve_points'))
