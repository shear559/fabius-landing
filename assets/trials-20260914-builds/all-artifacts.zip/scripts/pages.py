#!/usr/bin/env python3
"""Protocol page, report page and archive for the September 14 build study, from the assembled results.json."""
import re,json,os,html,subprocess,shutil,glob,hashlib
ID='trials-20260914-builds'; OUT=f'[user]/Desktop/Workspace/03-Personal/fabius-landing/assets/{ID}'; BASE=f'/assets/{ID}'
S='[study]'
d=json.load(open(f'{OUT}/results.json')); m=d['meta']; E=html.escape
HEAD=lambda title:f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>{E(title)} · Fabius build trials</title><link rel="stylesheet" href="/styles.css?v=2026-09-14"><link rel="stylesheet" href="{BASE}/evidence.css"></head><body class="evidence-page"><main class="evidence"><a class="evidence-home" href="/#trials">← Fabius · three real tasks</a>'
FOOT='</main></body></html>'
ARM={'baseline':'Without Fabius','fabius':'With Fabius'}
# ── report
rows=''
for t in d['tasks']:
    for p in t['runs']:
        for arm in ('baseline','fabius'):
            a=p[arm]; rid=a['artifactUrl'].split('/')[-2]
            extra=f"{a['scenarios']['passed']}/{a['scenarios']['executed']}" if a.get('scenarios') else ('1233/1233' if t['id']=='math' and a['checks'][0]['passed'] else '')
            rows+=f"<tr><td>{E(t['title'])}</td><td>{p['repeat']}</td><td>{ARM[arm]}</td><td><a href=\"{BASE}/runs/{rid}/checks.html\">{rid}</a></td><td>{a['passed']}/{a['total']}</td><td>{extra}</td><td>{a['seconds']}</td><td>{a['tokens']}</td><td>{a.get('toolCalls','')}</td></tr>"
detail=''
for t in d['tasks']:
    detail+=f"<h2>{E(t['title'])}</h2><div class=\"evidence-scroll\"><table><thead><tr><th>Check</th>"
    for p in t['runs']:
        for arm in ('baseline','fabius'): detail+=f"<th>{ARM[arm]} · r{p['repeat']}</th>"
    detail+='</tr></thead><tbody>'
    for i,c in enumerate(t['runs'][0]['baseline']['checks']):
        detail+=f"<tr><td>{E(c['label'])}</td>"
        for p in t['runs']:
            for arm in ('baseline','fabius'):
                cc=p[arm]['checks'][i]; detail+=f"<td>{'met' if cc['passed'] else 'missed'}</td>"
        detail+='</tr>'
    detail+='</tbody></table></div>'
    for p in t['runs']:
        for arm in ('baseline','fabius'):
            a=p[arm]; rid=a['artifactUrl'].split('/')[-2]
            detail+=f"<details><summary>{ARM[arm]}, run {p['repeat']} ({rid}): every check with its recorded detail</summary><ul>"+''.join(f"<li><strong>{E(c['label'])}</strong> — {'met' if c['passed'] else 'missed'}. {E(c['detail'])}</li>" for c in a['checks'])+f"</ul><p><a href=\"{a['artifactUrl']}\">source ZIP</a> · <a href=\"{a['proofUrl']}\">check record</a> · <a href=\"{BASE}/runs/{rid}/answer.md\">final message</a> · <a href=\"{BASE}/runs/{rid}/trace.json\">tool trace</a></p></details>"
corr=[]
for rid in ('run-05','run-06','run-07','run-08'):
    pre=f'{S}/eval-out/{rid}/grade-pre-alert-fix/results.json'
    if os.path.exists(pre):
        a=json.load(open(pre))['summary']['byCheck']; b=json.load(open(f'{S}/eval-out/{rid}/grade/results.json'))['summary']['byCheck']
        ch=[k for k in ('A08','A09','A10') if a[k]['passed']!=b[k]['passed']]
        if ch: corr.append(f"{rid}: {', '.join(ch)} changed from missed to met")
corr_text=('Runner correction (native alert counted as import-error feedback, regraded for all four application runs after the oracle self-test matched its 13 controls): '+'; '.join(corr)+'; the other application runs were unchanged. Original results are kept in each run\'s record.') if corr else 'The runner correction changed no result.'
report=HEAD('Results, including ties and misses')+'<h1>Results, including ties and misses</h1><p>'+E(corr_text)+'</p><p>All twelve runs are shown: three tasks, two conditions, two fresh runs each, on one model. Checks met counts the recorded groups (browser scenario groups for the page and the app; the numeric probe set plus eight proof criteria for the mathematics). Browser scenarios are the individual executions behind the groups. No aggregate improvement is claimed.</p><div class="evidence-scroll"><table><thead><tr><th>Task</th><th>Repeat</th><th>Condition</th><th>Run</th><th>Checks met</th><th>Scenarios / probes</th><th>Seconds</th><th>Output tokens</th><th>Tool calls</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+detail+f'<h2>Files</h2><p><a href="{BASE}/protocol.html">How the trials were run</a> · <a href="{BASE}/all-artifacts.zip">All artifacts (ZIP)</a> · <a href="{BASE}/results.json">results.json</a></p>'+FOOT
open(f'{OUT}/report.html','w',encoding='utf-8').write(report)
# ── protocol
C=d['contracts']
contracts=''.join(f"<details><summary>{'Page and app runs' if k=='ui' else 'Mathematics runs'}: {len(v)} files read first</summary><ul>"+''.join(f"<li><code>{E(c['path'])}</code> <small>sha256 {E(c['sha256'][:16])}…</small></li>" for c in v)+'</ul></details>' for k,v in C.items())
P=HEAD('How the build trials were run')+'<h1>How the build trials were run</h1>'
P+='<p>This study records what one model produced on three briefs, twice with the Fabius contracts read first and twice without them, each run in its own fresh context. It replaces the September 10 study as the demonstration on the front page; that study, on a different model, remains published and linked. It is a small paired study, not a benchmark: it does not establish a general improvement and does not predict another model.</p>'
P+='<h2>The twelve runs</h2>'
P+=f'<p>The briefs are the September 10 briefs, byte for byte (hashes in the manifest inside the archive): the Lattice landing page, the Fieldnote Board application and the parametric constrained optimization problem. Every run used {E(m["model"])} as a fresh Claude Code general-purpose subagent with file and shell tools, no web access, and its own empty working directory holding only BRIEF.md. Both arms were told they could run node, python3, a headless Chrome and the local Playwright library to check their own work, and to aim for about fifteen minutes; there was no hard cap. The twelve runs were dispatched within about a minute of each other on {E(m["date"])} and ran concurrently on one shared machine, so elapsed seconds describe that load, not an isolated speed benchmark. No run was retried, repaired or re-prompted; the first complete result of each run is the published artifact.</p>'
P+='<h2>What changes between conditions</h2>'
P+='<p>Without Fabius means the harness&#x27;s own subagent system prompt plus the brief, with an instruction to write only inside the working directory and read nothing outside it. It is not a bare API call.</p>'
P+=f'<p>With Fabius adds one instruction before the brief: read a listed set of files in full, in order, because they govern how the task is done. The page and app runs read the 3.1.0 router, Parcus, Disciplina and Decor contracts plus the visual-system template and the design critique reference; the mathematics runs read the router, Parcus, Disciplina and Scientia contracts plus the codebase-and-proof reference. They were read from the tracked Fabius repository at commit {E(m["fabiusCommit"])}; every file&#x27;s SHA-256 is recorded in results.json and below. Reading those files is part of the treatment and shows up in its time and token counts.</p>'+contracts
P+='<h2>Isolation, and where it wobbled</h2>'
P+='<p>Each run wrote its deliverables inside its own directory, and the deliverables are what was graded. Three runs reported in their own final messages that they had written temporary verification scripts outside their directory, in a shared scratch area or the Playwright folder, before cleaning up; one run said a scratch script it had authored there was later found changed and ignored it. These were helper scripts for self-checks, not deliverables, and no artifact file was shared between runs, but a run could in principle have glimpsed another run&#x27;s class names through such a file. The instruction was clear and was not fully obeyed in both arms; this is reported rather than hidden.</p>'
P+='<h2>Evaluation</h2>'
P+='<p>The page and app artifacts were graded by the September 10 browser oracle unchanged: the frozen rubric (seven groups for the page, sixteen for the app), each group exercised in Chromium and WebKit at 360 and 1440 pixels, so 28 scenario executions per page and 68 per app; a group counts as met only when every execution passes. The same capture helper then recorded the six walkthrough states per artifact in fresh contexts with external requests blocked; published images are lossless WebP conversions. The mathematics artifacts were scored by the September 10 exact geometric oracle at its 1,233 parameter probes, and their solvers were sampled at 127 parameters for the plot. The eight proof criteria were graded by two independent blind claude-opus-5 judges per submission, from masked copies of solution.md, verification.md and solution.py together with the frozen rubric and the reference solution; a criterion counts as met only when both judges independently returned pass. All four proofs received eight of eight from both judges.</p>'
P+='<h2>Runner correction, applied symmetrically</h2>'
P+='<p>After the first grading pass, one application run was recorded as giving no feedback on three import-rejection groups although the runner&#x27;s own dialog log showed it had refused each bad file with a native alert stating the reason and left the board untouched. The brief allows native dialogs and asks for a useful error; the September 10 predicate only looked at page text and form validity. Following that study&#x27;s own rule, the original results are retained (grade-pre-alert-fix in each run&#x27;s record), the runner was corrected so that a native alert whose message reads as an import error counts as visible feedback, the oracle self-test was rerun against its controls, and the three groups were regraded for all four application runs with the corrected runner. Which runs changed is stated in the report; no other check and no candidate file was touched.</p>'
P+='<h2>What was found, in one paragraph</h2>'
diffs=[]
for t in d['tasks']:
    for p in t['runs']:
        b,f=p['baseline'],p['fabius']; diffs.append(f"{t['title']} run {p['repeat']}: {b['passed']}/{b['total']} without, {f['passed']}/{f['total']} with")
P+='<p>'+E('; '.join(diffs))+'. The page and the mathematics are ties on every check. The application shows where the runs differed; the report lists every missed group with the failing observation, and the live previews on the front page show the products themselves.</p>'
P+='<h2>Limits</h2>'
P+='<p>Two runs per condition, one model, one host, no human judges, no cross-model replication, no statistical claim. The briefs and the check rubric come from the September 10 study and were written by the maintainer of the rules; the checks measure the supplied contract, not visual quality or production readiness. The baseline carries the harness&#x27;s own system prompt, which already asks for care. Time and token differences include the contract reading and are reported as costs of the treatment, not as a finding. Generated JavaScript runs on this site only inside sandboxed frames with an opaque origin; the products path carries a byte-identical copy of each artifact plus, for the applications, a one-line wrapper that loads an in-memory storage stand-in. No candidate file was edited.</p>'
P+=f'<p><a href="{BASE}/landing.md">landing brief</a> · <a href="{BASE}/app.md">app brief</a> · <a href="{BASE}/math.md">math brief</a> · <a href="{BASE}/report.html">Results</a> · <a href="{BASE}/all-artifacts.zip">All artifacts (ZIP)</a></p>'+FOOT
open(f'{OUT}/protocol.html','w',encoding='utf-8').write(P)
# ── archive
ST=f'{S}/_zip'; shutil.rmtree(ST,ignore_errors=True); os.makedirs(ST)
def norm(s):
    s=re.sub(r'[study][0-9a-f-]*(?:/scratchpad/builds2)?','[study]',s)
    s=re.sub(r'[session][A-Za-z0-9-]*','[session]',s)
    return s.replace(S,'[study]').replace('[study]','[session]').replace('[fabius]/','[fabius]/').replace('[playwright-qa]','[playwright-qa]').replace('[user]','[user]')
def put(src,dst,text=True):
    os.makedirs(os.path.dirname(f'{ST}/{dst}'),exist_ok=True)
    if text: open(f'{ST}/{dst}','w',encoding='utf-8').write(norm(open(src,encoding='utf-8',errors='ignore').read()))
    else: shutil.copy(src,f'{ST}/{dst}')
put(f'{OUT}/results.json','results.json')
for b in ('landing.md','app.md','math.md'): put(f'{S}/briefs/{b}',f'briefs/{b}')
put(f'{S}/contracts/manifest.json','contracts/manifest.json'); put(f'{S}/runs/plan.json','runs/plan.json'); put(f'{S}/judged.json','judging/proof-judges-raw.json')
put(f'{S}/pipeline.py','scripts/pipeline.py'); put(f'{S}/assemble2.py','scripts/assemble.py'); put(f'{S}/pages2.py','scripts/pages.py')
for f in ('web-oracle/grade.mjs','web-oracle/rubric.json','web-oracle/README.md','capture.mjs','math-oracle/oracle.py','math-oracle/score.py','math-oracle/candidate_runner.py','math-oracle/proof-rubric.json','math-oracle/reference.md'): put(f'{S}/eval/{f}',f'evaluation/{f}')
for rd in sorted(glob.glob(f'{OUT}/runs/run-*')):
    rid=os.path.basename(rd)
    for f in os.listdir(rd): put(f'{rd}/{f}',f'runs/{rid}/{f}',text=f.endswith(('.md','.json','.html')))
open(f'{ST}/READ-FIRST.md','w').write('# Fabius build trials, 2026-09-14\n\nTwelve runs of claude-sonnet-5 on the three September 10 briefs: two runs with the Fabius 3.1.0 contracts read first, two without, per task. Graded by the unchanged September 10 browser oracle (Chromium + WebKit, 360/1440), its capture helper, its exact mathematics oracle (1,233 probes) and two blind claude-opus-5 judges for the eight proof criteria.\n\n- `results.json` — the published data; `briefs/`, `contracts/manifest.json` (Fabius commit and file hashes), `runs/plan.json`.\n- `runs/run-NN/` — `source.zip` (every file the run left, brief excluded), `answer.md`, `trace.json`, `checks.json` (raw grade or score plus judge verdicts), `checks.html`, captures as lossless WebP.\n- `judging/proof-judges-raw.json` — both judges\' verdicts as returned.\n- `evaluation/` — the oracle, capture and scoring code as run (paths normalized); `scripts/` — the pipeline, assembler and page generator.\n\nPaths are normalized: `[fabius]/` is the Fabius repository at the recorded commit, `[study]` the study directory, `[user]` the home directory. Protocol: https://fabius-landing.vercel.app'+BASE+'/protocol.html\n')
zp=f'{OUT}/all-artifacts.zip'
if os.path.exists(zp): os.remove(zp)
subprocess.run(['zip','-q','-r','-X',zp,'.'],cwd=ST,check=True); shutil.rmtree(ST)
left=subprocess.run(['grep','-rl','[user]\\|/private/tmp/claude-501',OUT],capture_output=True,text=True).stdout.strip()
print('pages written; archive bytes',os.path.getsize(zp),'; private paths left:',left or 'none')
