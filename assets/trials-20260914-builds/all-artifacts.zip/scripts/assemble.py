#!/usr/bin/env python3
"""Assemble the September 14 build study into the landing's assets/trials-20260914-builds/ in the viewer schema."""
import re,json,os,sys,shutil,subprocess,hashlib,html,glob,datetime,zipfile
S='[study]'
ID='trials-20260914-builds'; OUT=f'[user]/Desktop/Workspace/03-Personal/fabius-landing/assets/{ID}'; BASE=f'/assets/{ID}'
plan=json.load(open(f'{S}/runs/plan.json')); man=json.load(open(f'{S}/contracts/manifest.json')); labels=json.load(open(f'{S}/check-labels.json'))
judged=json.load(open(f'{S}/judged.json'))['judged'] if os.path.exists(f'{S}/judged.json') else []
J={j['id']:j for j in judged}
rub=json.load(open(f'{S}/eval/math-oracle/proof-rubric.json'))
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
def norm(s):
    s=re.sub(r'[study][0-9a-f-]*(?:/scratchpad/builds2)?','[study]',s)
    s=re.sub(r'[session][A-Za-z0-9-]*','[session]',s)
    return s.replace('[fabius]/','[fabius]/').replace(S,'[study]').replace('[study]','[session]').replace('[playwright-qa]','[playwright-qa]').replace('[user]','[user]')
shutil.rmtree(OUT,ignore_errors=True); os.makedirs(f'{OUT}/runs',exist_ok=True); os.makedirs(f'{OUT}/products',exist_ok=True)
shutil.copy('[user]/Desktop/Workspace/03-Personal/fabius-landing/assets/trials-20260910/evidence.css',f'{OUT}/evidence.css')
shutil.copy('[user]/Desktop/Workspace/03-Personal/fabius-landing/assets/trials-20260910/products/preview-storage.js',f'{OUT}/products/preview-storage.js')
for b in ('landing.md','app.md','math.md'): shutil.copy(f'{S}/briefs/{b}',f'{OUT}/{b}')
TASKS={'math':{'title':'Constrained mathematics','summary':'One parametric optimization problem, six regimes, a complete proof and executable formulas.','question':'Minimize x² + 2y² + 3z² + xy − yz + (2 − 2t)x + 5y + z, for every t ∈ [−2, 4].','feasibleSet':'x + y + z = 1; x, y, z ≥ 0; x ≤ 3/5; 2y + z ≥ 1/2. The plot shows each submitted solver’s sampled objective value.','transitions':[-1.5,-1,-0.5,0,1.8]},
       'landing':{'title':'A complete landing page','summary':'Lattice: a fictional research notebook, with feature tabs, billing controls, mobile navigation and keyboard behavior.'},
       'app':{'title':'A working task app','summary':'Fieldnote Board: editing, combined filters, persistent storage, import/export, recovery and cross-tab conflicts.'}}
def ui_checks(rid,kind):
    g=json.load(open(f'{S}/eval-out/{rid}/grade/results.json')); by=g['summary']['byCheck']; checks=[]
    for cid,label in labels[kind].items():
        v=by.get(cid,{'passed':0,'executed':0}); passed=v['executed']>0 and v['passed']==v['executed']
        detail=f"{v['passed']}/{v['executed']} browser scenario executions passed."
        if not passed:
            fails=[]
            for r in g['results']:
                if r['id']!=cid or r['status']=='pass': continue
                keys=[o['key'] for o in r['observations'] if not o.get('pass')]
                fails.append(f"{r['environment']}: "+', '.join(keys) if keys else f"{r['environment']}: failed")
            detail+=' Failed observations: '+'; '.join(dict.fromkeys(fails))+'.'
        checks.append({'id':cid,'label':label,'passed':passed,'detail':detail})
    return checks,g['summary']
def math_checks(rid):
    sc=json.load(open(f'{S}/eval-out/{rid}/score.json'))
    checks=[{'id':'numeric','label':labels['math']['numeric'],'passed':bool(sc['passed']),'detail':f"{sc['passed_samples']} of {sc['total_samples']} parameter probes passed for this one problem. This does not replace a proof."}]
    jr=J.get(rid)
    for dim in rub['dimensions']:
        cid=dim['id']; label=labels['math'].get(cid,cid)
        if not jr: checks.append({'id':cid,'label':label,'passed':False,'detail':'Proof review pending.'}); continue
        vs=[]
        for jj in jr['judges']:
            v=next((x for x in jj['verdict']['rows'] if x['id']==cid),None)
            vs.append((jj['judge'],v['verdict'] if v else 'missing',v['quote'] if v else '',v['note'] if v else ''))
        agreed=len({v[1] for v in vs})==1; passed=agreed and vs[0][1]=='pass'
        detail=('Both blind judges: '+vs[0][1]+'.' if agreed else 'Judges split ('+', '.join(f'{v[0]} {v[1]}' for v in vs)+'); counted as not met.')+' '+' '.join(f'{v[0]}: “{v[2]}” {v[3]}' for v in vs)
        checks.append({'id':cid,'label':label,'passed':passed,'detail':detail.strip()})
    return checks
tasks=[]
for kind in ('math','landing','app'):
    task={'id':kind,**TASKS[kind],'runs':[]}
    for rep in (1,2):
        pair={'repeat':rep}
        for arm in ('baseline','fabius'):
            r=next(x for x in plan if x['task']==kind and x['repeat']==rep and x['arm']==arm); rid=r['id']
            meta=json.load(open(f'{S}/eval-out/{rid}/meta.json')); work=f'{S}/runs/{rid}/work'; od=f'{OUT}/runs/{rid}'; pd=f'{OUT}/products/{rid}'; os.makedirs(od,exist_ok=True); os.makedirs(pd,exist_ok=True)
            # source zip: every non-hidden file the run left, brief excluded
            files=sorted(f for f in os.listdir(work) if f!='BRIEF.md' and not f.startswith('_') and os.path.isfile(f'{work}/{f}'))
            subprocess.run(['zip','-q','-j','-X',f'{od}/source.zip']+[f'{work}/{f}' for f in files],check=True)
            open(f'{od}/answer.md','w').write(norm(open(f'{S}/eval-out/{rid}/answer.md').read()))
            json.dump(json.loads(norm(open(f'{S}/eval-out/{rid}/trace.json').read())),open(f'{od}/trace.json','w'),indent=1)
            entry={'passed':0,'total':0,'seconds':meta['elapsed_seconds'],'tokens':meta['output_tokens'],'toolCalls':meta['tool_calls'],'checks':[],'snapshots':[],'artifactUrl':f'{BASE}/runs/{rid}/source.zip','proofUrl':f'{BASE}/runs/{rid}/checks.html','status':meta['status'],'files':meta['files']}
            if kind in ('landing','app'):
                entry['checks'],summary=ui_checks(rid,kind); entry['scenarios']={'passed':summary['passed'],'executed':summary['scenarioExecutions']}
                cap=json.load(open(f'{S}/eval-out/{rid}/captures/captures.json'))
                for snap in cap['snapshots']:
                    src=f"{S}/eval-out/{rid}/captures/{snap['file'][:-4]}.webp"
                    if os.path.exists(src) and snap.get('actionSucceeded',True) is not None:
                        dst=f"{od}/{snap['file'][:-4]}.webp"; shutil.copy(src,dst); entry['snapshots'].append({'id':snap['id'],'label':snap['label'],'url':f"{BASE}/runs/{rid}/{snap['file'][:-4]}.webp"})
                for f in ('index.html','styles.css','app.js'): shutil.copy(f'{work}/{f}',f'{pd}/{f}')
                if kind=='app':
                    s=open(f'{work}/index.html',encoding='utf-8').read(); i=s.index('<script'); open(f'{pd}/preview.html','w',encoding='utf-8').write(s[:i]+'<script src="../preview-storage.js"></script>\n'+s[i:])
                else: shutil.copy(f'{work}/index.html',f'{pd}/preview.html')
                entry['productUrl']=f'{BASE}/products/{rid}/index.html'; entry['previewUrl']=f'{BASE}/products/{rid}/preview.html'
                json.dump(json.loads(norm(json.dumps(json.load(open(f'{S}/eval-out/{rid}/grade/results.json'))))),open(f'{od}/checks.json','w'),indent=1)
                json.dump(json.loads(norm(json.dumps(cap))),open(f'{od}/captures.json','w'),indent=1)
            else:
                entry['checks']=math_checks(rid); entry['curve']=json.load(open(f'{S}/eval-out/{rid}/curve.json'))
                for f in ('solution.md','solution.py','verification.md'): shutil.copy(f'{work}/{f}',f'{pd}/{f}')
                entry['solutionUrl']=f'{BASE}/products/{rid}/solution.md'; entry['codeUrl']=f'{BASE}/products/{rid}/solution.py'; entry['verificationUrl']=f'{BASE}/products/{rid}/verification.md'
                json.dump({'numeric':json.load(open(f'{S}/eval-out/{rid}/score.json')),'proofReview':J.get(rid)},open(f'{od}/checks.json','w'),indent=1)
            entry['total']=len(entry['checks']); entry['passed']=sum(1 for c in entry['checks'] if c['passed'])
            # checks.html: a plain record page per run
            E=html.escape; rows=''.join(f"<tr><td>{E(c['id'])}</td><td>{E(c['label'])}</td><td>{'met' if c['passed'] else 'missed'}</td><td>{E(c['detail'])}</td></tr>" for c in entry['checks'])
            open(f'{od}/checks.html','w',encoding='utf-8').write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>{rid} · check record · Fabius build trials</title><link rel="stylesheet" href="/styles.css?v=2026-09-14"><link rel="stylesheet" href="{BASE}/evidence.css"></head><body class="evidence-page"><main class="evidence"><a class="evidence-home" href="/#trials">← Fabius · three real tasks</a><h1>{rid} · {E(TASKS[kind]["title"])} · {"With Fabius" if arm=="fabius" else "Without Fabius"} · run {rep}</h1><p>{E(meta["model"] or "")} · {meta["elapsed_seconds"]} s · {meta["output_tokens"]} output tokens · {meta["tool_calls"]} tool calls · {entry["passed"]} of {entry["total"]} checks met.</p><div class="evidence-scroll"><table><thead><tr><th>Check</th><th>Label</th><th>Result</th><th>Detail</th></tr></thead><tbody>{rows}</tbody></table></div><p><a href="{BASE}/runs/{rid}/source.zip">Source ZIP</a> · <a href="{BASE}/runs/{rid}/answer.md">Final message</a> · <a href="{BASE}/runs/{rid}/trace.json">Tool trace</a> · <a href="{BASE}/runs/{rid}/checks.json">Raw check record</a></p></main></body></html>')
            pair[arm]=entry
        task['runs'].append(pair)
    tasks.append(task)
meta={'model':'claude-sonnet-5','effort':'default','version':man['fabius_version'],'fabiusCommit':man['fabius_commit'],'date':'2026-09-14','repeatCount':2,'runCapSeconds':900,'capLabel':'about fifteen minutes asked, no hard cap',
      'protocolUrl':f'{BASE}/protocol.html','reportUrl':f'{BASE}/report.html','artifactsUrl':f'{BASE}/all-artifacts.zip',
      'previewNote':'Live previews load the unmodified generated files in a sandboxed frame with an opaque origin: they cannot reach this site, the network or your storage. Each preview frame gets its own in-memory storage stand-in, so boards reset on reload. The source ZIP holds the exact bytes.',
      'limitations':'Two fresh runs per condition on one model, from the same brief and the same tools; the treatment reads the pinned 3.1.0 contracts first. Checks describe these artifacts; they do not establish a general improvement or predict another model.'}
json.dump({'meta':meta,'contracts':man['contracts'],'tasks':tasks},open(f'{OUT}/results.json','w'),indent=1,ensure_ascii=False)
print('results.json written')
for t in tasks:
    for p in t['runs']: print(t['id'],'r'+str(p['repeat']),'baseline',f"{p['baseline']['passed']}/{p['baseline']['total']}",'fabius',f"{p['fabius']['passed']}/{p['fabius']['total']}")
