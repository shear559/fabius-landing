#!/usr/bin/env node
// Capture actual candidate UI states. This helper does not grade, patch, or improve candidates.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import playwright from '[playwright-qa]/node_modules/playwright/index.js';
import {serve} from './web-oracle/grade.mjs';

const FILE = fileURLToPath(import.meta.url);
const KEY = 'fieldnote-board:v1';
const TASK = Object.freeze({title:'Review launch evidence',project:'Research',status:'doing',priority:'high',dueDate:'2026-09-20',tags:'evidence,launch'});
const STATES = Object.freeze({
  landing:['initial','feature-connect','billing-yearly','workflow','faq'],
  app:['initial','new-task-form','after-create','search','import-error']
});
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const seam = id => `[data-testid="${id}"]`;
const errorInfo = error => ({name:error?.name || 'Error',message:String(error?.message || error).slice(0,2000)});

export function plannedStates(kind) {
  if (!Object.hasOwn(STATES,kind)) throw new Error('--kind must be landing or app');
  return [...STATES[kind]];
}
export function parseArgs(args) {
  if (args.length === 1 && ['--help','-h'].includes(args[0])) return {help:true};
  const allowed = new Set(['--kind','--directory','--run-id','--output']);
  const values = {};
  for (let index=0;index<args.length;index+=2) {
    const key=args[index],value=args[index+1];
    if (!allowed.has(key) || !value || value.startsWith('--') || Object.hasOwn(values,key)) throw new Error('Use each required flag once: --kind --directory --run-id --output');
    values[key]=value;
  }
  if (Object.keys(values).length!==4) throw new Error('All four flags are required: --kind --directory --run-id --output');
  plannedStates(values['--kind']);
  if (!/^[A-Za-z0-9_-]{1,80}$/.test(values['--run-id'])) throw new Error('--run-id must be an opaque identifier containing only letters, digits, underscore or hyphen');
  if (!path.isAbsolute(values['--directory']) || !path.isAbsolute(values['--output'])) throw new Error('--directory and --output must be absolute paths');
  return {kind:values['--kind'],directory:values['--directory'],runId:values['--run-id'],output:values['--output']};
}

async function inventory(directory) {
  const files=[];
  async function visit(relative='') {
    const entries=await fs.readdir(path.join(directory,relative),{withFileTypes:true});
    for (const entry of entries.sort((a,b)=>a.name.localeCompare(b.name))) {
      const name=path.join(relative,entry.name);
      if (entry.isSymbolicLink()) throw new Error('Candidate artifacts must not contain symlinks');
      if (entry.isDirectory()) await visit(name);
      else if (entry.isFile()) {
        if (files.length>=2000) throw new Error('Candidate exceeds the 2000-file capture limit');
        const bytes=await fs.readFile(path.join(directory,name));
        files.push({file:name.split(path.sep).join('/'),bytes:bytes.length,sha256:sha(bytes)});
      } else throw new Error('Candidate contains a non-file artifact');
    }
  }
  await visit();
  if (!files.some(item=>item.file==='index.html')) throw new Error('Candidate must contain index.html');
  return {files,treeSha256:sha(JSON.stringify(files))};
}
function publicRequest(url,origin) {
  try {const value=new URL(url);return value.origin===origin?value.pathname:`${value.protocol}//${value.host}${value.pathname}`;} catch {return String(url).slice(0,300);}
}
async function settle(page) {
  await page.evaluate(async()=>{
    if (document.fonts?.ready) await Promise.race([document.fonts.ready,new Promise(resolve=>setTimeout(resolve,1500))]);
  }).catch(()=>{});
  await sleep(180);
}
async function anchor(locator) {
  await locator.first().evaluate(element=>{
    element.scrollIntoView({block:'start',inline:'nearest',behavior:'instant'});
    window.scrollBy({top:-96,left:0,behavior:'instant'});
  });
}
async function visible(page,selector) {return page.locator(selector).first().isVisible().catch(()=>false);}
async function visibleCards(page) {
  return page.locator(seam('task-card')).evaluateAll(elements=>elements.filter(element=>{
    const style=getComputedStyle(element),rect=element.getBoundingClientRect();
    return style.display!=='none'&&style.visibility!=='hidden'&&rect.width>0&&rect.height>0;
  }).map(element=>({id:element.dataset.taskId||null,text:element.innerText.slice(0,500)})));
}
async function stored(page) {
  const result=await page.evaluate(key=>{
    try {return {value:localStorage.getItem(key),error:null};}
    catch(error){return {value:null,error:error.name};}
  },KEY);
  let board=null;
  try {board=JSON.parse(result.value);} catch {}
  return {raw:result.value,board,error:result.error};
}
async function observation(page) {
  return page.evaluate(()=>({
    path:location.pathname+location.hash,
    viewport:{width:innerWidth,height:innerHeight},
    scroll:{x:scrollX,y:scrollY},
    documentWidth:Math.max(document.documentElement.scrollWidth,document.body?.scrollWidth||0),
    visibleText:(document.body?.innerText||'').slice(0,2500),
    brokenVisibleImages:[...document.images].filter(element=>{
      const rect=element.getBoundingClientRect(),style=getComputedStyle(element);
      return rect.width>0&&rect.height>0&&style.display!=='none'&&style.visibility!=='hidden'&&(!element.complete||element.naturalWidth===0);
    }).map(element=>element.getAttribute('src'))
  }));
}

async function record(ctx,id,action) {
  const startedAt=new Date().toISOString();
  let result;
  try {result=await action();}
  catch(error) {
    result={actionSucceeded:false,label:`${id}: requested interaction could not be completed`,observed:{error:errorInfo(error)}};
    ctx.report.actionErrors.push({id,...errorInfo(error)});
  }
  await settle(ctx.page);
  const entry={id,label:result.label,file:null,actionSucceeded:Boolean(result.actionSucceeded),observed:result.observed||{},capturedAt:new Date().toISOString(),actionStartedAt:startedAt};
  try {entry.observed.render=await observation(ctx.page);} catch(error) {entry.observed.renderError=errorInfo(error);}
  try {
    const file=`${id}.png`;
    await ctx.page.screenshot({path:path.join(ctx.output,file),type:'png',fullPage:false,animations:'disabled',caret:'hide',timeout:15000});
    const bytes=await fs.readFile(path.join(ctx.output,file));
    entry.file=file;entry.sha256=sha(bytes);entry.bytes=bytes.length;
  } catch(error) {
    ctx.report.captureFailures.push({id,...errorInfo(error)});
    ctx.report.missingStates.push({id,reason:'Screenshot was not captured'});
  }
  if (!entry.actionSucceeded) ctx.report.missingStates.push({id,reason:'Requested interaction outcome was not confirmed; any attached screenshot shows the actual observed state'});
  ctx.report.snapshots.push(entry);
  await fs.writeFile(path.join(ctx.output,'captures.partial.json'),JSON.stringify(ctx.report,null,2)+'\n');
  return entry;
}

async function landing(ctx) {
  const page=ctx.page;
  await record(ctx,'feature-connect',async()=>{
    const tab=page.locator(seam('feature-connect'));
    await tab.click();
    const selected=await tab.getAttribute('aria-selected'),panelVisible=await visible(page,seam('panel-connect'));
    await anchor(tab);
    return {actionSucceeded:selected==='true'&&panelVisible,label:selected==='true'&&panelVisible?'Connect feature selected; its panel is visible':'Connect feature clicked; selected panel was not confirmed',observed:{selected,panelVisible,panelText:panelVisible?await page.locator(seam('panel-connect')).innerText():null}};
  });
  await record(ctx,'billing-yearly',async()=>{
    const control=page.locator(seam('billing-yearly'));
    await control.click();await settle(page);
    const solo=await page.locator(seam('price-solo')).innerText(),studio=await page.locator(seam('price-studio')).innerText();
    const amounts=[solo,studio].map(value=>Number(value.replace(/[^0-9.]/g,'')));
    const matches=amounts[0]===108&&amounts[1]===264;
    await anchor(control);
    return {actionSucceeded:matches,label:matches?'Yearly billing selected; displayed prices are 108 and 264':'Yearly billing clicked; expected price change was not confirmed',observed:{solo,studio,amounts}};
  });
  await record(ctx,'workflow',async()=>{
    const section=page.locator('#workflow');
    await anchor(section);
    const isVisible=await section.isVisible();
    return {actionSucceeded:isVisible,label:isVisible?'Workflow section in the viewport':'Workflow section could not be shown',observed:{visible:isVisible,text:await section.innerText()}};
  });
  await record(ctx,'faq',async()=>{
    const summary=page.locator(seam('faq-0'));
    const before=await summary.evaluate(element=>({tag:element.tagName,parent:element.parentElement?.tagName,open:element.parentElement?.open===true}));
    if(!before.open)await summary.click();
    await anchor(summary);
    const after=await summary.evaluate(element=>({tag:element.tagName,parent:element.parentElement?.tagName,open:element.parentElement?.open===true,text:element.parentElement?.innerText}));
    const opened=after.tag==='SUMMARY'&&after.parent==='DETAILS'&&after.open;
    return {actionSucceeded:opened,label:opened?'First FAQ opened; actual answer shown':'FAQ click attempted; an open native answer was not confirmed',observed:after};
  });
}
async function form(page) {
  if (!await visible(page,seam('task-form'))) await page.locator(seam('create-task')).click();
  await page.locator(seam('task-form')).waitFor({state:'visible'});
  return page.locator(seam('task-form'));
}
function exactTask(task) {
  return task&&task.title===TASK.title&&task.project===TASK.project&&task.status===TASK.status&&task.priority===TASK.priority&&task.dueDate===TASK.dueDate&&Array.isArray(task.tags)&&task.tags.length===2&&task.tags[0]==='evidence'&&task.tags[1]==='launch';
}
async function confirmCustomImport(page) {
  const dialogs=page.getByRole('dialog').or(page.getByRole('alertdialog'));
  for(let index=0;index<await dialogs.count();index+=1){
    const dialog=dialogs.nth(index);
    if(!await dialog.isVisible())continue;
    const buttons=dialog.getByRole('button',{name:/^(?:yes\b|replace\b|confirm\b|import\b|continue\b)/i});
    for(let position=0;position<await buttons.count();position+=1){
      const button=buttons.nth(position);
      if(await button.isVisible()){const label=await button.innerText();await button.click();return {clicked:true,label,scope:'visible dialog'};}
    }
  }
  const buttons=page.getByRole('button',{name:/^(?:yes(?:,|\s|$)|replace(?: board| data| tasks)?$|confirm(?: import| replacement)?$|import (?:and replace|this file|board)$|continue$)/i});
  for(let position=0;position<await buttons.count();position+=1){
    const button=buttons.nth(position);
    if(await button.isVisible()){const label=await button.innerText();await button.click();return {clicked:true,label,scope:'explicit confirmation control'};}
  }
  return {clicked:false};
}
async function app(ctx) {
  const page=ctx.page;
  await record(ctx,'new-task-form',async()=>{
    await page.locator(seam('create-task')).click();
    const target=page.locator(seam('task-form'));
    await target.waitFor({state:'visible'});
    await anchor(target);
    return {actionSucceeded:true,label:'New task form opened',observed:{visible:await target.isVisible(),fields:await target.locator('input,select,textarea').evaluateAll(elements=>elements.map(element=>({name:element.name,type:element.type,value:element.value})))}};
  });
  await record(ctx,'after-create',async()=>{
    const before=await stored(page),target=await form(page);
    for(const [key,value] of Object.entries(TASK)){
      const input=target.locator(`[name="${key}"]`);
      if(['status','priority'].includes(key))await input.selectOption(value);else await input.fill(value);
    }
    await page.locator(seam('save-task')).click();await settle(page);
    const after=await stored(page),tasks=Array.isArray(after.board?.tasks)?after.board.tasks:[];
    const matches=tasks.filter(task=>task.title===TASK.title),cards=await visibleCards(page);
    const matched=matches.find(exactTask),rendered=Boolean(matched&&cards.some(card=>card.id===matched.id&&card.text.includes(TASK.title)));
    if(rendered)await anchor(page.locator(seam('task-card')).filter({hasText:TASK.title}).first());
    const succeeded=Boolean(matched&&rendered);
    return {actionSucceeded:succeeded,label:succeeded?'Review launch evidence created and present in saved board':'Save attempted; the requested saved task was not confirmed',observed:{requested:TASK,storageError:after.error,matchingRecords:matches,rendered,visibleCards:cards,beforeStorageSha256:before.raw===null?null:sha(before.raw),afterStorageSha256:after.raw===null?null:sha(after.raw)}};
  });
  await record(ctx,'search',async()=>{
    const search=page.locator(seam('search'));
    await search.fill(TASK.title);await settle(page);await anchor(search);
    const value=await search.inputValue(),cards=await visibleCards(page),matches=cards.length>0&&cards.every(card=>card.text.toLowerCase().includes(TASK.title.toLowerCase()));
    return {actionSucceeded:value===TASK.title&&matches,label:matches?'Search for Review launch evidence; matching task shown':'Search entered; expected matching task was not confirmed',observed:{search:value,visibleCards:cards}};
  });
  await record(ctx,'import-error',async()=>{
    let formDismissed=false;
    if(await visible(page,seam('task-form'))&&await page.locator(seam('task-form')).evaluate(element=>Boolean(element.closest('dialog,[role="dialog"],[aria-modal="true"]')))){
      await page.keyboard.press('Escape');formDismissed=!await visible(page,seam('task-form'));
    }
    if(await visible(page,seam('search')))await page.locator(seam('search')).fill('');
    const before=await stored(page),beforeText=await page.locator('body').innerText(),dialogStart=ctx.report.dialogs.length;
    await page.locator(seam('import-file')).setInputFiles({name:'capture-invalid.json',mimeType:'application/json',buffer:Buffer.from('{"schemaVersion":1,"tasks":[')});
    await settle(page);
    const confirmation=await confirmCustomImport(page);if(confirmation.clicked)await settle(page);
    const after=await stored(page),afterText=await page.locator('body').innerText(),beforeLines=new Set(beforeText.split('\n').map(value=>value.trim()));
    const newFeedback=afterText.split('\n').map(value=>value.trim()).filter(value=>value&&!beforeLines.has(value)&&/invalid|malformed|JSON|error|unable|failed|cannot|could not|not imported|unexpected|reject/i.test(value));
    const dialogs=ctx.report.dialogs.slice(dialogStart),nativeError=dialogs.some(dialog=>dialog.type==='alert'&&/invalid|malformed|JSON|error|unable|failed|cannot|unexpected|reject/i.test(dialog.message));
    const unchanged=before.raw===after.raw,visibleError=newFeedback.length>0;
    if(visibleError){const notice=page.getByText(newFeedback[0],{exact:true}).first();if(await notice.count())await anchor(notice);}
    const succeeded=unchanged&&(visibleError||nativeError);
    const label=unchanged&&visibleError?'Malformed JSON selected; visible error and saved board unchanged':unchanged&&nativeError?'Malformed JSON rejected in a browser alert; saved board unchanged':'Malformed JSON selected; rejection with preserved board was not confirmed';
    return {actionSucceeded:succeeded,label,observed:{formDismissed,confirmation,dialogs,newVisibleFeedback:newFeedback,nativeError,storageUnchanged:unchanged,beforeStorageSha256:before.raw===null?null:sha(before.raw),afterStorageSha256:after.raw===null?null:sha(after.raw)}};
  });
}

export async function capture({kind,directory,runId,output}) {
  plannedStates(kind);
  if(!/^[A-Za-z0-9_-]{1,80}$/.test(runId||''))throw new Error('Invalid opaque run ID');
  if(!path.isAbsolute(directory)||!path.isAbsolute(output))throw new Error('Absolute input/output paths required');
  const source=await fs.realpath(directory),destination=path.resolve(output);
  if(destination===source||destination.startsWith(source+path.sep))throw new Error('Output must be outside the immutable candidate directory');
  const before=await inventory(source);
  await fs.mkdir(destination,{recursive:true});
  const outputReal=await fs.realpath(destination);
  if(outputReal===source||outputReal.startsWith(source+path.sep))throw new Error('Resolved output must be outside the immutable candidate directory');
  if((await fs.readdir(outputReal)).length)throw new Error('Output directory must be empty; prior captures are never overwritten');
  const report={schemaVersion:1,runId,kind,startedAt:new Date().toISOString(),helperSha256:sha(await fs.readFile(FILE)),source:before,policy:{presentation:'Composed walkthrough from captured states; not a recording of model generation.',browser:'Google Chrome',desktopViewport:{width:1440,height:960},mobileViewport:{width:360,height:800},deviceScaleFactor:1,fullPage:false,reducedMotion:'reduce',screenshotAnimations:'disabled',freshContexts:true,externalRequests:'blocked',candidateEdits:false,scoresProvided:false},snapshots:[],mobilefile:null,mobile:null,missingStates:[],captureFailures:[],actionErrors:[],infrastructureErrors:[],console:[],network:[],dialogs:[]};
  const server=await serve(source),origin=new URL(server.url).origin;
  let browser;
  try {
    browser=await playwright.chromium.launch({channel:'chrome',headless:true,args:['--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run']});
    report.browserVersion=browser.version();
    async function contextFor(viewport,mobile=false) {
      const context=await browser.newContext({viewport,deviceScaleFactor:1,isMobile:mobile,hasTouch:mobile,reducedMotion:'reduce',serviceWorkers:'block',acceptDownloads:false});
      await context.route('**/*',async route=>{
        const request=route.request(),url=request.url();
        if(/^https?:/.test(url)&&new URL(url).origin!==origin){report.network.push({viewport,request:publicRequest(url,origin),method:request.method(),resourceType:request.resourceType(),external:true,blocked:true});await route.abort('blockedbyclient');}
        else await route.continue();
      });
      await context.routeWebSocket('**/*',async socket=>{
        report.network.push({viewport,request:publicRequest(socket.url(),origin),resourceType:'websocket',blocked:true});
        await socket.close({code:1008,reason:'Static capture blocks WebSocket connections'});
      });
      const page=await context.newPage();
      page.setDefaultTimeout(3500);page.setDefaultNavigationTimeout(15000);
      page.on('console',message=>{if(['error','warning'].includes(message.type()))report.console.push({viewport,type:message.type(),text:message.text().slice(0,2000)});});
      page.on('pageerror',error=>report.console.push({viewport,type:'pageerror',...errorInfo(error)}));
      page.on('response',response=>{if(response.status()>=400)report.network.push({viewport,request:publicRequest(response.url(),origin),status:response.status()});});
      page.on('requestfailed',request=>report.network.push({viewport,request:publicRequest(request.url(),origin),failure:request.failure()?.errorText}));
      page.on('dialog',async dialog=>{
        report.dialogs.push({viewport,type:dialog.type(),message:dialog.message(),action:'accept'});
        await dialog.accept().catch(()=>{});
      });
      return {context,page};
    }
    const desktop=await contextFor(report.policy.desktopViewport);
    try {
      const ctx={page:desktop.page,output:outputReal,report};
      await record(ctx,'initial',async()=>{
        const response=await desktop.page.goto(server.url,{waitUntil:'networkidle'});
        await desktop.page.evaluate(()=>window.scrollTo({top:0,left:0,behavior:'instant'}));
        const status=response?.status()??null;
        return {actionSucceeded:status!==null&&status<400,label:'Desktop first visit — untouched initial output',observed:{httpStatus:status,freshStorage:true}};
      });
      if(kind==='landing')await landing(ctx);else await app(ctx);
    } finally {await desktop.context.close();}
    const mobile=await contextFor(report.policy.mobileViewport,true);
    try {
      const response=await mobile.page.goto(server.url,{waitUntil:'networkidle'});
      await mobile.page.evaluate(()=>window.scrollTo({top:0,left:0,behavior:'instant'}));await settle(mobile.page);
      const file='mobile-initial.png';
      await mobile.page.screenshot({path:path.join(outputReal,file),type:'png',fullPage:false,animations:'disabled',caret:'hide',timeout:15000});
      const bytes=await fs.readFile(path.join(outputReal,file));
      report.mobilefile=file;
      report.mobile={id:'mobile-initial',label:'Mobile first visit — separate fresh context',file,sha256:sha(bytes),bytes:bytes.length,actionSucceeded:Boolean(response&&response.status()<400),observed:{httpStatus:response?.status()??null,freshStorage:true,render:await observation(mobile.page)}};
    } catch(error) {
      report.captureFailures.push({id:'mobile-initial',...errorInfo(error)});
      report.missingStates.push({id:'mobile-initial',reason:'Mobile screenshot was not captured'});
    } finally {await mobile.context.close();}
  } catch(error) {report.infrastructureErrors.push(errorInfo(error));}
  finally {
    if(browser)await browser.close().catch(()=>{});
    await server.close();
    const after=await inventory(source);
    report.sourceAfterTreeSha256=after.treeSha256;
    report.sourceUnchanged=before.treeSha256===after.treeSha256;
    if(!report.sourceUnchanged)report.infrastructureErrors.push({name:'SourceChanged',message:'Candidate files changed during capture; preserve captures but do not treat them as an immutable artifact record.'});
    for(const id of plannedStates(kind))if(!report.snapshots.some(snapshot=>snapshot.id===id))report.missingStates.push({id,reason:'Capture sequence did not reach this state'});
    report.finishedAt=new Date().toISOString();
    await fs.writeFile(path.join(outputReal,'captures.json'),JSON.stringify(report,null,2)+'\n');
    await fs.rm(path.join(outputReal,'captures.partial.json'),{force:true});
  }
  return report;
}

async function main() {
  const options=parseArgs(process.argv.slice(2));
  if(options.help){process.stdout.write('Usage: node capture.mjs --kind landing|app --directory ABS --run-id OPAQUE --output ABS\nCaptures finalized immutable candidate artifacts only. Output must be empty. No scores are produced.\n');return;}
  const report=await capture(options);
  process.stdout.write(JSON.stringify({runId:report.runId,kind:report.kind,desktopImages:report.snapshots.filter(snapshot=>snapshot.file).length,mobileImages:report.mobilefile?1:0,missingStates:report.missingStates.length,captureFailures:report.captureFailures.length,infrastructureErrors:report.infrastructureErrors.length,sourceUnchanged:report.sourceUnchanged})+'\n');
  process.exitCode=report.infrastructureErrors.length||report.captureFailures.length?2:0;
}
if(process.argv[1]&&path.resolve(process.argv[1])===FILE)main().catch(error=>{console.error(error.message);process.exitCode=2;});
