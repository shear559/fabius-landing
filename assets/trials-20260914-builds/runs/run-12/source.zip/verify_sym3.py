import sympy as sp
x,y,t = sp.symbols('x y t', real=True)
g = -2*t*x + 4*x**2 + 8*x*y - 5*x + 6*y**2 - 3*y + 4
gx = sp.diff(g,x); gy = sp.diff(g,y)
Rat = sp.Rational

print("Remaining vertices / edges never optimal on [-2,4]:")

# vertex (0,0): active c1(x>=0) grad(1,0), c2(y>=0) grad(0,1)
l1,l2 = sp.symbols('l1 l2')
sol = sp.solve([sp.Eq(gx.subs({x:0,y:0}), l1), sp.Eq(gy.subs({x:0,y:0}), l2)], [l1,l2])
print("(0,0):", sol, " l2 =", sol[l2], "-> needs l2>=0 always false since l2=-3")

# vertex (0,1): active c1(x>=0) grad(1,0), c3(x+y<=1) i.e. -x-y>=-1 grad c3=(-1,-1)
l1b,l3b = sp.symbols('l1b l3b')
solb = sp.solve([sp.Eq(gx.subs({x:0,y:1}), l1b - l3b), sp.Eq(gy.subs({x:0,y:1}), -l3b)], [l1b,l3b])
print("(0,1):", solb)

# vertex (3/5,2/5): active c3 grad(-1,-1), c4(x<=3/5) grad(-1,0)
l3c,l4c = sp.symbols('l3c l4c')
solc = sp.solve([sp.Eq(gx.subs({x:Rat(3,5),y:Rat(2,5)}), -l3c-l4c), sp.Eq(gy.subs({x:Rat(3,5),y:Rat(2,5)}), -l3c)], [l3c,l4c])
print("(3/5,2/5):", solc)

# edge C interior: x+y=1, y=1-x, x in (0,3/5); only c3 active grad(-1,-1)
xC = x
yC = 1-x
lC = sp.symbols('lC')
# gx = -lC, gy = -lC  => need gx==gy along the edge
gxC = sp.simplify(gx.subs({x:xC,y:yC}))
gyC = sp.simplify(gy.subs({x:xC,y:yC}))
print("edge C: gx,gy as fn of x:", gxC, gyC, " equal req:", sp.simplify(gxC-gyC))
lC_expr = -gxC
print("edge C lambda_C(x) =", lC_expr, " need >=0 and also stationarity gx=gy holds only at solving x; solve x from gx=gy:")
xsolC = sp.solve(sp.Eq(gxC,gyC), x)
print("  x satisfying gx=gy on edge C:", xsolC)

# edge D interior: x=3/5, y in (1/10,2/5); only c4 active grad(-1,0) => need gy=0
gyD = sp.simplify(gy.subs({x:Rat(3,5)}))
print("edge D: gy(x=3/5,y) =", gyD, " solve gy=0:", sp.solve(sp.Eq(gyD,0), y))
