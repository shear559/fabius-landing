import sympy as sp

x,y,t = sp.symbols('x y t', real=True)
g = -2*t*x + 4*x**2 + 8*x*y - 5*x + 6*y**2 - 3*y + 4

def val(xe, ye):
    return sp.simplify(g.subs({x: xe, y: ye}))

Rat = sp.Rational

print("=== Branch 1: t in [-2,-3/2], (x,y)=(0,1/4) ===")
print("value:", val(0, Rat(1,4)))

print("=== Branch 2: t in [-3/2,-1], unconstrained ===")
x2 = Rat(3,4)*t + Rat(9,8)
y2 = -t/2 - Rat(1,2)
z2 = 1 - x2 - y2
print("x2,y2,z2:", x2, y2, sp.simplify(z2))
v2 = sp.expand(val(x2,y2))
print("value2:", v2)
print("check endpoints: t=-3/2 ->", v2.subs(t, Rat(-3,2)), " t=-1 ->", v2.subs(t,-1))

print("=== Branch 3: t in [-1,-1/2], edge B y=0, x=(5+2t)/8 ===")
x3 = (5+2*t)/8
y3 = 0
z3 = 1 - x3 - y3
v3 = sp.expand(val(x3, y3))
print("x3,z3,value3:", x3, sp.simplify(z3), v3)
print("check endpoints: t=-1 ->", v3.subs(t,-1), " t=-1/2 ->", v3.subs(t,Rat(-1,2)))

print("=== Branch 4: t in [-1/2,0], vertex (1/2,0) ===")
print("value:", val(Rat(1,2), 0))

print("=== Branch 5: t in [0,9/5], edge E, x=(9+t)/18, y=t/18 ===")
x5 = (9+t)/18
y5 = t/18
z5 = 1 - x5 - y5
v5 = sp.expand(val(x5,y5))
print("x5,y5,z5,value5:", x5,y5, sp.simplify(z5), v5)
print("check endpoints: t=0 ->", v5.subs(t,0), " t=9/5 ->", v5.subs(t,Rat(9,5)))

print("=== Branch 6: t in [9/5,4], vertex (3/5,1/10) ===")
print("value:", val(Rat(3,5), Rat(1,10)))

print()
print("=== continuity check of x*(t), y*(t) at breakpoints ===")
bpts = [Rat(-3,2), -1, Rat(-1,2), 0, Rat(9,5)]
for bp in bpts:
    print("t=",bp)

# Multiplier checks (redo symbolically)
print()
print("=== multiplier checks ===")
gx = sp.diff(g,x); gy = sp.diff(g,y)
print("gx,gy:", gx, gy)

# branch1: only c1 (x>=0) active, grad c1=(1,0). lam1 = gx, need gy=0
print("branch1 gy at (0,1/4):", gy.subs({x:0,y:Rat(1,4)}))
lam1 = gx.subs({x:0,y:Rat(1,4)})
print("lam1 = gx =", lam1, " -> lam1>=0 requires t<=", sp.solve(sp.Eq(lam1,0), t))

# branch3: only c2 (y>=0) active grad c2=(0,1); lam2=gy, need gx=0
print("branch3 gx at x3,0:", sp.simplify(gx.subs({x:x3,y:0})))
lam2_3 = sp.simplify(gy.subs({x:x3,y:0}))
print("lam2(branch3) =", lam2_3)

# vertex4 (1/2,0): active c2(y=0) grad(0,1) and c5(y-x+1/2=0) grad(-1,1)
lam2_4, lam5_4 = sp.symbols('lam2_4 lam5_4')
eqs = [sp.Eq(gx.subs({x:Rat(1,2),y:0}), -lam5_4), sp.Eq(gy.subs({x:Rat(1,2),y:0}), lam2_4+lam5_4)]
sol4 = sp.solve(eqs, [lam2_4, lam5_4])
print("vertex4 multipliers:", sol4)

# branch5 edge E: only c5 active, grad c5=(-1,1); lam5 = gy = -gx
print("branch5 gx+gy:", sp.simplify(gx.subs({x:x5,y:y5}) + gy.subs({x:x5,y:y5})))
lam5_5 = sp.simplify(gy.subs({x:x5,y:y5}))
print("lam5(branch5) =", lam5_5)

# vertex6 (3/5,1/10): active c4 (x<=3/5) grad(-1,0), c5 grad(-1,1)
lam4_6, lam5_6 = sp.symbols('lam4_6 lam5_6')
eqs6 = [sp.Eq(gx.subs({x:Rat(3,5),y:Rat(1,10)}), -lam4_6-lam5_6), sp.Eq(gy.subs({x:Rat(3,5),y:Rat(1,10)}), lam5_6)]
sol6 = sp.solve(eqs6, [lam4_6, lam5_6])
print("vertex6 multipliers:", sol6)
