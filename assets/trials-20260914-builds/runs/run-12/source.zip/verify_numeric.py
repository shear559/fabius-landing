import numpy as np
from scipy.optimize import minimize, LinearConstraint
import solution

def f(v, t):
    x,y,z = v
    return x**2+2*y**2+3*z**2+x*y-y*z+(2-2*t)*x+5*y+z

def formula(t):
    r = solution.solve(t)
    return r["x"], r["y"], r["z"]

A_eq = LinearConstraint(np.array([[1,1,1]]), 1, 1)
# x>=0,y>=0,z>=0,x<=0.6, 2y+z>=0.5  => build inequality constraints as LinearConstraint with bounds
lin_ineq = LinearConstraint(np.array([
    [1,0,0],
    [0,1,0],
    [0,0,1],
    [-1,0,0],
    [0,2,1],
]), lb=[0,0,0,-0.6, 0.5], ub=[np.inf,np.inf,np.inf,np.inf,np.inf])

max_err = 0.0
worst = None
ts = list(np.linspace(-2,4,121)) + [-1.5,-1.0,-0.5,0.0,1.8,-2,4,
                                     -1.5+1e-6,-1.5-1e-6,-1.0+1e-6,-1.0-1e-6,
                                     -0.5+1e-6,-0.5-1e-6,1e-6,-1e-6,1.8+1e-6,1.8-1e-6]
for t in ts:
    best = None
    for x0 in [[0,0,1],[0.6,0.4,0],[0.5,0.5,0],[0.2,0.2,0.6],[0.6,0.1,0.3],[0,1,0]]:
        res = minimize(f, x0, args=(t,), method='SLSQP',
                        constraints=[A_eq, lin_ineq], options={'maxiter':500,'ftol':1e-14})
        if res.success and (best is None or res.fun < best.fun):
            best = res
    fx,fy,fz = formula(t)
    fval = f((fx,fy,fz), t)
    err = abs(best.fun - fval)
    xerr = max(abs(best.x[0]-fx), abs(best.x[1]-fy), abs(best.x[2]-fz))
    if err > max_err:
        max_err = err
        worst = (t, best.x, best.fun, (fx,fy,fz), fval)
    if err > 1e-5 or xerr > 1e-4:
        print("MISMATCH t=",t,"scipy",best.x,best.fun,"formula",(fx,fy,fz),fval)

print("max value error over grid:", max_err)
print("worst case:", worst)
print("done, n points tested:", len(ts))

# feasibility of the formula solution at every tested t
tol = 1e-9
feas_fail = []
for t in ts:
    r = solution.solve(t)
    x, y, z = r["x"], r["y"], r["z"]
    checks = [
        abs(x + y + z - 1) <= 1e-9,
        x >= -tol, y >= -tol, z >= -tol,
        x <= 0.6 + tol,
        2 * y + z >= 0.5 - tol,
    ]
    if not all(checks):
        feas_fail.append((t, x, y, z, checks))
print("feasibility violations:", len(feas_fail), feas_fail[:5])

# continuity: value and point agree at breakpoints approached from both sides
for bp in [-1.5, -1.0, -0.5, 0.0, 1.8]:
    a = solution.solve(bp - 1e-9)
    b = solution.solve(bp)
    c = solution.solve(bp + 1e-9)
    da = max(abs(a['x']-b['x']), abs(a['y']-b['y']), abs(a['z']-b['z']), abs(a['value']-b['value']))
    dc = max(abs(c['x']-b['x']), abs(c['y']-b['y']), abs(c['z']-b['z']), abs(c['value']-b['value']))
    print(f"breakpoint {bp}: left-diff={da:.3e} right-diff={dc:.3e}")

# int input and interval-endpoint / out-of-range behavior
print("int input:", solution.solve(-2), solution.solve(4))
for bad in [-2.0001, 4.0001, 10]:
    try:
        solution.solve(bad)
        print("NO ERROR RAISED for", bad)
    except ValueError:
        print("correctly rejected", bad)
