import sympy as sp

x,y,z,t = sp.symbols('x y z t', real=True)

f = x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2-2*t)*x + 5*y + z

# substitute z = 1-x-y
g = sp.expand(f.subs(z, 1-x-y))
print("g_t(x,y) =", g)

# Hessian of g wrt x,y
H = sp.hessian(g, (x,y))
print("Hessian:", H)
print("Hessian eigen (should be PD):", H.eigenvals())

# unconstrained stationary point
gx = sp.diff(g, x)
gy = sp.diff(g, y)
sol = sp.solve([gx, gy], [x, y])
print("unconstrained stationary:", sol)

xs, ys = sol[x], sol[y]
zs = sp.simplify(1 - xs - ys)
print("x*,y*,z* unconstrained:", sp.simplify(xs), sp.simplify(ys), zs)

val_unconstrained = sp.simplify(g.subs({x:xs, y:ys}))
print("value at unconstrained stationary:", val_unconstrained)
