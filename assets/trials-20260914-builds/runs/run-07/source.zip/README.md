# Fieldnote Board

A local-first task board for a small project team. Fictional demo data, no backend,
no network calls, no build step, no dependencies.

## Run it

Any static file server works, from any path depth:

```
python3 -m http.server 8080
# then open http://localhost:8080/<any/nested/path>/index.html
```

Or just double-click `index.html` (file:// also works — localStorage is per-origin,
so a `file://` open persists independently of a server-hosted copy of the same files).
All asset references (`styles.css`, `app.js`) are relative, so the app works from any
mount path.

If JavaScript is disabled, a `<noscript>` banner explains the app cannot run instead of
showing a blank page.

## Files

- `index.html` — markup, the task form (modal), the recovery panel, toast region.
- `styles.css` — all styling: responsive grid (360px → 1440px+), light/dark palette
  via `prefers-color-scheme`, `prefers-reduced-motion` overrides, focus states.
- `app.js` — a single IIFE, no globals leaked. Organized top-to-bottom as: utilities →
  validation → seed data → persistence → DOM cache → toasts/notices → recovery panel →
  filtering/rendering → form/modal lifecycle → mutations (create/edit/delete/undo/status)
  → import/export → event wiring → init.

## Data model

`localStorage["fieldnote-board:v1"]` = `{ schemaVersion: 1, tasks: Task[] }`.

```
Task = {
  id: string,        // generated, unique, <=80 chars
  title: string,     // trimmed, nonempty, <=120 chars
  project: string,    // trimmed, nonempty, <=80 chars
  status: "todo" | "doing" | "done",
  priority: "low" | "medium" | "high",
  dueDate: "" | "YYYY-MM-DD",   // must be a real calendar date if non-empty
  tags: string[]      // <=8 items, each trimmed, nonempty, <=24 chars, case-insensitive deduped
}
```

Every read from storage (startup and import) re-validates every field against this
shape before it is trusted; every write re-serializes only these fields, so extra/legacy
keys never survive a save.

## Error handling & recovery design

- **Startup**: `getItem` → if `null`, seed a fictional 8-task / 3-project / all-status
  board and persist it. If parse or shape validation fails, the app **never** touches
  storage — it stores the raw string in memory, disables the board and "New task", and
  shows a recovery panel with the exact failure reason, a "Download original data" button
  (byte-for-byte `Blob` export of the untouched string) and an explicit "Reset board and
  start fresh" button gated behind `window.confirm`.
- **Every write** (`persist()`) is wrapped in try/catch. On failure (quota exceeded,
  storage disabled, etc.) the in-memory state is **not** advanced and no success is
  claimed:
  - Create/Edit: the modal stays open with the user's typed values intact — nothing is
    lost, they can retry.
  - Delete/status-change/undo/import: the optimistic change is not applied (or is rolled
    back for status), and a toast explains the save failed.
- **Cross-tab conflict**: a `storage` event (fired by the browser only for *other* tabs
  writing the same key) sets a `conflictPending` flag and shows a persistent banner with
  a "Reload board" button. While pending, every mutating action (create, edit, delete,
  status change, undo, import, reset) is blocked with a toast rather than silently
  overwriting whatever the other tab wrote. "Reload board" does a full `location.reload()`,
  which is the simplest correct reconciliation: it re-reads the actual current storage
  from scratch rather than attempting a partial merge.
- **Import** is validated fully (schemaVersion, size ≤1 MiB, JSON parse, every task's
  shape, duplicate IDs) into a separate array *before* anything is written — a single bad
  task rejects the whole file and the existing board is provably untouched. A native
  `confirm()` gates replacing the board once validation passes.

## Accessibility & interaction notes

- All controls have labels or `aria-label`s (per-card status selects are labelled with
  the task title so screen readers don't hear eight identical "Status" controls).
- The task-form modal: focus moves to the first field on open, `Tab`/`Shift+Tab` are
  trapped inside it, `Escape` closes it, and focus returns to whatever opened it. The
  rest of the page is marked `inert` while the modal is open.
- `[hidden]` is rescued with `[hidden]{display:none!important}` — several elements
  (`.modal-overlay`, `.recovery-panel`) set their own `display` for layout, which would
  otherwise beat the browser's default `[hidden]` rule at equal specificity and leave a
  "hidden" element still visible/clickable.
- `prefers-reduced-motion: reduce` collapses all animation/transition durations to
  effectively zero (modal entrance, toast entrance, hover transitions).
- Import's real file-picker button is a native `<button>` that calls `.click()` on a
  visually-hidden `<input type="file">` (rather than a styled `<label for>`, which is not
  keyboard-operable by default) — so Import stays reachable and activatable by keyboard.
- Deletion is reversible via a toast with an `Undo` button (`data-testid="undo-delete"`)
  that stays up for 8 seconds; undoing re-persists the exact removed record at its
  original position.

## Checks actually executed

Verified end-to-end with a scripted Chromium session (Playwright) driving the real DOM
and real `localStorage`/`storage`-event/file-download APIs — 40 assertions, all passing,
covering: seed shape (≥6 tasks / ≥2 projects / all 3 statuses), create, tag
trim+dedupe+cap, per-field validation errors (blank title, overlong title) with the modal
staying open, cancel, Escape + focus restore, edit-preserves-others, status change via
card control + persistence, combined search+filter to a no-results state, delete +
undo + persistence-after-reload, export (full board, correct schemaVersion), import
(valid replace, atomic rejection of a bad enum, atomic rejection of an invalid calendar
date, malformed JSON, cancelled confirmation leaving the board untouched), corrupt-storage
detection (exact-byte preservation, recovery panel, byte-identical download, reset →
reseed), a genuine two-tab conflict (a second tab's write triggers the banner in the
first, blocks a mutating action, and a full reload picks up the second tab's data), and
`prefers-reduced-motion` collapsing the modal's animation duration. Both a 360px and a
1440px viewport were screenshotted and reviewed for layout/design coherence.

`<input type="date">` structurally prevents impossible calendar dates (e.g. Feb 30) from
ever being entered through the picker/keyboard, so the app-level `isValidDateString`
calendar check is exercised in practice through the import path (pasted/hand-authored
JSON), not through the form — both paths share the same validator.

Not machine-verified (would need a real quota-exceeded browser profile or a genuinely
disabled `localStorage`, and screen-reader software): the storage-write-failure UI copy,
and real assistive-technology narration of the modal/labels — these were reviewed by
code inspection instead.

## Known limitations

- Cross-tab reconciliation is reload-based, not a live merge; a tab with unsaved form
  input open when a conflict arrives must still discard that draft on reload (it is not
  silently lost — the conflict banner blocks the save first, telling the user to reload).
- No pagination/virtualization; fine at fictional-team scale (tens to low hundreds of
  tasks), not designed for thousands.
- Search is substring match only (no fuzzy matching).
