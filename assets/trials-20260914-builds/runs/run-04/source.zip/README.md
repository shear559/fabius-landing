# Lattice — landing page (fictional product demo)

A static marketing page for **Lattice**, a fictional local-first research notebook.
Vanilla HTML/CSS/JS only — no build step, no remote fonts, no libraries, no network
calls, no backend. `index.html`, `styles.css` and `app.js` are the whole artifact.

## Run it

Any static file server works, from any path depth (all asset URLs are relative):

```
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Or just double-click `index.html` — it also works opened directly via `file://`
except that the browser's own `file://` sandboxing can vary; a static server is the
more representative check and is what was used below.

## Implementation decisions

- **Visual system.** Cool off-white canvas (`#f4f5f2`), near-black ink (never pure
  `#000`), and one accent — a brick/rust red (`#b5442e`) — reserved for the primary
  action, the active tab, focus rings, and small emphasis marks. Display headings use
  the system serif stack (`ui-serif`/Georgia) for an editorial, notebook-like voice;
  body and UI text use the system sans stack; small data-like text (source bullets,
  price periods, step numbers) uses `ui-monospace` as a citation-style accent. All
  three are local system fonts — no `@font-face`, no remote loading. Spacing snaps to
  an 8px base unit; radius uses one grammar per element type (pill for tags/toggles,
  `md`/`lg` for cards); elevation is minimal (one soft shadow, used only on the
  hero illustration card and the featured pricing plan).
- **Hero illustration** is an original inline SVG: a small "notebook window" card
  (title bar, text lines, one highlighted line with a link glyph standing in for a
  source) surrounded by a loose lattice of connected nodes — a literal reading of the
  product name and of "notes with sources attached," not a stock UI screenshot.
- **Content mirrors structure.** The three feature tabs (Capture / Connect / Export)
  and the three workflow steps use the same order and iconography, so the page
  teaches one shape twice instead of two unrelated lists.
- **Progressive enhancement for every required interaction.** Each interactive
  region ships a fully discoverable default in raw HTML, then JavaScript enhances it:
  - Mobile nav: `#mobile-nav` has no `hidden` attribute in the markup, so without JS
    it sits in the normal flow as a plain visible link list. `app.js` sets
    `hidden`/`aria-expanded` on load and wires the toggle, `Escape`-to-close-and-refocus,
    and close-on-link-click. Desktop nav (`.nav-desktop`) is shown by CSS at
    `min-width: 760px` regardless of JS.
  - Feature tabs: all three panels ship visible (stacked, each with its own
    heading) so the content is readable without JS. `app.js` hides the inactive
    panels, sets `role="tab"`/`aria-selected`/roving `tabindex`, and handles
    Arrow/Home/End key navigation with automatic activation.
  - Pricing: the markup already shows the exact monthly figures ($12 / $29) as
    static text. `app.js` swaps the text and `aria-pressed` state on toggle click;
    returning to Monthly restores the exact original strings.
  - FAQ uses four native `<details>/<summary>` elements — no JS required at all.
- **No invented business claims.** No customers, reviews, ratings, adoption or
  performance numbers appear anywhere, including in illustration text and SVG. The
  page is marked as a fictional demonstration in a persistent banner at the very top,
  again in the footer, and in the `<meta name="description">`.
- **Pricing copy** states the fictional numbers only (Solo $12/mo or $108/yr; Studio
  $29/mo or $264/yr) and labels the active billing period; no discount percentage is
  claimed since that would be an invented-sounding figure layered on supplied numbers.

## Checks actually executed

Run with Chromium (via Playwright, pointed at the local Google Chrome binary) against
the page served by `python3 -m http.server`, plus a manual keyboard pass. All of the
following passed on the delivered files:

- Mobile nav (360px viewport): starts closed (`aria-expanded="false"`, panel
  `hidden`); `menu-toggle` click opens it and flips `aria-expanded`; `Escape` closes
  it and returns focus to the toggle button; clicking a link inside it closes the
  panel and navigates to the real target section (`#workflow`).
- Feature tabs (1440px viewport): `feature-capture` selected and `panel-capture`
  visible by default with the other two panels hidden; clicking `feature-connect`
  switches the visible panel and `aria-selected`; `ArrowRight` from Connect moves
  both focus and selection to `feature-export`; the three panels' text content was
  checked to be distinct and substantial (not placeholder copy).
- Billing toggle: initial `price-solo`/`price-studio` read exactly `$12`/`$29`;
  clicking `billing-yearly` updates them to exactly `$108`/`$264`; clicking
  `billing-monthly` again restores exactly `$12`/`$29`.
- All four FAQ `<summary>` elements (`faq-0`…`faq-3`) open their native `<details>`
  on click.
- The "Explore the workflow" link's `href` is `#workflow` and a `#workflow` section
  exists on the page.
- At 1440px, `.nav-desktop` is visible and `menu-toggle` is hidden (and the inverse
  was confirmed at 360px in the mobile-nav checks above).
- **JavaScript disabled** (separate browser context, `javaScriptEnabled: false`,
  360px viewport): mobile nav links are visible, the Solo price shows the correct
  static `$12`, all three feature panels are visible, and the FAQ summary is visible
  — confirming core content, prices and navigation stay discoverable without JS.
- Asset resolution from a **nested path**: copied the three files into a
  `nested/deep/` subdirectory under a second static server and confirmed
  `index.html`, `styles.css` and `app.js` all resolved with `200` (relative URLs, no
  path assumptions).
- No network/remote references: grepped all three files for `http(s)://`,
  absolute-rooted asset paths (`/…`), `@import`/`@font-face`; the only match is the
  inline `data:` URI favicon's embedded SVG namespace string, which triggers no
  network request.
- Contrast: computed WCAG relative-luminance contrast ratios for the token pairs in
  use — body ink/ink-soft on canvas ≥11:1, `--muted` on canvas/surface ≥4.8:1,
  accent on canvas ≥5:1, white on accent ≥5.4:1 (all pass the 4.5:1 body-text floor).
  `--border-strong` was checked against the 3:1 non-text floor and adjusted from an
  initial `#c7c9bc` (1.53:1, too low) to `#8d8f80` (≈3.0–3.3:1) since it is used as a
  visible border on the ghost button and billing toggle, not purely decorative.
- Keyboard focus: tabbed through the first 12 interactive elements at 1440px and read
  computed style on each `document.activeElement` — every one (skip link, nav links,
  CTAs, first feature tab, billing buttons) shows a solid 2px accent
  (`rgb(181,68,46)`) `outline`, confirming `:focus-visible` styling is applied
  consistently and isn't suppressed anywhere. Tab order skips the two inactive
  feature tabs, confirming the roving-`tabindex` implementation.
- Visual review: full-page screenshots captured at 1440px and 360px and inspected for
  hierarchy, spacing rhythm, one-accent discipline, and layout integrity (no overflow,
  no clipped text, alternating section backgrounds reading as the section divider).

Not executed: a screen-reader pass with an actual AT (VoiceOver/NVDA), automated
axe-core/Lighthouse scans, and cross-browser checks beyond Chromium (no other engine
was available in this environment). Reduced-motion behavior was implemented (a
global `prefers-reduced-motion: reduce` rule collapses all transitions/animations to
near-zero) but not verified by forcing that media feature in a driven browser.

## Known limitations

- Single light theme only; no dark mode. The brief allows either light, dark, or
  both — light-only was chosen to keep quality high within the run budget rather
  than shipping a thinner second theme.
- No automated accessibility scanner (axe/Lighthouse) was run; verification relied on
  targeted Playwright checks (contrast math, computed focus styles, DOM state) plus
  manual review, not a full audit tool.
- Verified only in Chromium; not cross-checked in WebKit/Firefox.
- The hero illustration and step icons are original inline SVG/CSS, not artwork
  reviewed by anyone but the author of this page.
