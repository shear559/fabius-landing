"""
Independent verification of solution.py against:
  (1) a from-scratch numerical QP solve (scipy SLSQP, many random restarts)
  (2) a fine brute-force grid search over the feasible polygon (numpy)
  (3) feasibility of the closed-form point at every sampled t
  (4) continuity of x(t),y(t),z(t),value(t) across all 6 breakpoints,
      approaching from both sides
  (5) that value(t) is not beaten by ANY feasible point found by grid/SLSQP
      (within numerical tolerance)

This script is verification-only; solution.py itself uses only the
standard library, this script may use numpy/scipy.
"""
import itertools
import math
import random
import sys

import numpy as np
from scipy.optimize import minimize, linprog

sys.path.insert(0, ".")
from solution import solve  # noqa: E402


def f(t, x, y, z):
    return (x**2 + 2*y**2 + 3*z**2 + x*y - y*z
            + (2 - 2*t)*x + 5*y + z)


def feasible(x, y, z, tol=1e-7):
    checks = {
        "x+y+z=1": abs(x + y + z - 1) <= tol,
        "x>=0": x >= -tol,
        "y>=0": y >= -tol,
        "z>=0": z >= -tol,
        "x<=3/5": x <= 0.6 + tol,
        "2y+z>=1/2": 2*y + z >= 0.5 - tol,
    }
    return checks


def scipy_solve(t, restarts=25, seed=0):
    """Independent numeric solve via SLSQP from many random feasible-ish
    starts, taking the best result. Uses (x,y) as free vars, z=1-x-y."""
    rng = random.Random(seed)

    def obj(v):
        x, y = v
        z = 1 - x - y
        return f(t, x, y, z)

    cons = [
        {"type": "ineq", "fun": lambda v: v[0]},                     # x>=0
        {"type": "ineq", "fun": lambda v: v[1]},                     # y>=0
        {"type": "ineq", "fun": lambda v: 1 - v[0] - v[1]},           # z>=0
        {"type": "ineq", "fun": lambda v: 0.6 - v[0]},                # x<=3/5
        {"type": "ineq", "fun": lambda v: 2*v[1] + (1 - v[0] - v[1]) - 0.5},  # 2y+z>=1/2
    ]
    best = None
    for _ in range(restarts):
        x0 = rng.uniform(0, 0.6)
        y0 = rng.uniform(0, 1 - x0)
        res = minimize(obj, [x0, y0], method="SLSQP", constraints=cons,
                        bounds=[(0, 0.6), (0, 1)],
                        options={"maxiter": 500, "ftol": 1e-14})
        if res.success:
            if best is None or res.fun < best.fun:
                best = res
    x, y = best.x
    z = 1 - x - y
    return x, y, z, f(t, x, y, z)


def grid_solve(t, n=1201):
    """Brute-force fine grid over the polygon; returns best point found."""
    xs = np.linspace(0, 0.6, n)
    ys = np.linspace(0, 1, n)
    best_val = math.inf
    best = None
    for x in xs:
        # y range from feasibility: y>=0, y<=1-x, y>=x-0.5
        ylo = max(0.0, x - 0.5)
        yhi = 1 - x
        if yhi < ylo - 1e-9:
            continue
        yy = np.linspace(ylo, yhi, 60)
        zz = 1 - x - yy
        vals = x**2 + 2*yy**2 + 3*zz**2 + x*yy - yy*zz + (2 - 2*t)*x + 5*yy + zz
        i = np.argmin(vals)
        if vals[i] < best_val:
            best_val = vals[i]
            best = (x, yy[i], zz[i])
    return best[0], best[1], best[2], best_val


def check_kkt(t):
    """Full 3-var KKT stationarity + complementary slackness + multiplier
    signs, independently re-derived from the (x,y,z) solve returns (not
    imported from solution.py's internal formulas)."""
    r = solve(t)
    x, y, z = r["x"], r["y"], r["z"]

    # grad f
    gx = 2*x + y + (2 - 2*t)
    gy = 4*y + x - z + 5
    gz = 6*z - y + 1

    tol = 1e-7
    act_x0 = abs(x) <= tol
    act_y0 = abs(y) <= tol
    act_z0 = abs(z) <= tol
    act_x35 = abs(x - 0.6) <= tol
    act_g5 = abs(2*y + z - 0.5) <= tol

    # Solve stationarity for nu and the active multipliers via least squares
    # over the *active* set only (inactive multipliers forced to 0), then
    # check nonneg + residual ~ 0 + non-active constraints strictly satisfied.
    # Unknowns: nu, lam1(x>=0), lam2(y>=0), lam3(z>=0), lam4(x<=3/5), lam5(2y+z>=1/2)
    # stationarity:
    #  gx + nu - lam1 + lam4 = 0
    #  gy + nu - lam2 - 2*lam5 = 0
    #  gz + nu - lam3 - lam5 = 0
    names = ["lam1", "lam2", "lam3", "lam4", "lam5"]
    active_mask = [act_x0, act_y0, act_z0, act_x35, act_g5]
    # columns for [nu, lam1, lam2, lam3, lam4, lam5], zero out inactive lam cols
    A = np.array([
        [1, -1, 0, 0, 1, 0],
        [1, 0, -1, 0, 0, -2],
        [1, 0, 0, -1, 0, -1],
    ], dtype=float)
    b = -np.array([gx, gy, gz], dtype=float)
    # zero out columns for inactive multipliers (force lam_i = 0)
    for i, is_active in enumerate(active_mask):
        if not is_active:
            A[:, 1 + i] = 0
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    resid = A @ sol - b
    nu = sol[0]
    lams = dict(zip(names, sol[1:]))
    for i, is_active in enumerate(active_mask):
        if not is_active:
            lams[names[i]] = 0.0
    return {
        "point": (x, y, z),
        "residual_norm": float(np.linalg.norm(resid)),
        "nu": float(nu),
        "lams": lams,
        "active": active_mask,
    }


def main():
    results = []

    # ---- 1. Dense sweep: closed form vs SLSQP vs grid ----
    ts = np.linspace(-2, 4, 241)  # step 0.025
    max_gap_slsqp = 0.0
    max_gap_grid = 0.0
    infeasible_points = []
    for t in ts:
        t = float(t)
        r = solve(t)
        x, y, z, val = r["x"], r["y"], r["z"], r["value"]

        chk = feasible(x, y, z)
        if not all(chk.values()):
            infeasible_points.append((t, chk))

        xs_, ys_, zs_, val_slsqp = scipy_solve(t, restarts=8)
        gap_slsqp = val - val_slsqp  # closed form should not be worse (>~0)
        max_gap_slsqp = max(max_gap_slsqp, gap_slsqp)

        xg, yg, zg, val_grid = grid_solve(t, n=241)
        gap_grid = val - val_grid
        max_gap_grid = max(max_gap_grid, gap_grid)

        results.append((t, val, val_slsqp, val_grid))

    print(f"[sweep] {len(ts)} t-values checked")
    print(f"[sweep] infeasible closed-form points: {len(infeasible_points)}")
    if infeasible_points:
        print(infeasible_points[:5])
    print(f"[sweep] max(closed_form - slsqp_best) = {max_gap_slsqp:.3e} (should be ~0 or negative)")
    print(f"[sweep] max(closed_form - grid_best)  = {max_gap_grid:.3e} (should be ~0 or negative, grid is coarse)")

    # ---- 2. Continuity at breakpoints, from both sides ----
    breakpoints = [-2.0, -1.5, -1.0, -0.5, 0.0, 1.8, 4.0]
    print("\n[continuity] checking x,y,z,value approaching each breakpoint from both sides")
    eps = 1e-6
    for bp in breakpoints:
        left = bp - eps if bp - eps >= -2 else None
        right = bp + eps if bp + eps <= 4 else None
        rc = solve(bp)
        msgs = [f"t={bp}: center=({rc['x']:.9f},{rc['y']:.9f},{rc['z']:.9f}) val={rc['value']:.9f} piece={rc['piece']}"]
        if left is not None:
            rl = solve(left)
            dl = max(abs(rl['x']-rc['x']), abs(rl['y']-rc['y']), abs(rl['z']-rc['z']), abs(rl['value']-rc['value']))
            msgs.append(f"  left(-eps) max-abs-diff={dl:.3e}")
        if right is not None:
            rr = solve(right)
            dr = max(abs(rr['x']-rc['x']), abs(rr['y']-rc['y']), abs(rr['z']-rc['z']), abs(rr['value']-rc['value']))
            msgs.append(f"  right(+eps) max-abs-diff={dr:.3e}")
        print("\n".join(msgs))

    # ---- 3. KKT check across pieces ----
    print("\n[KKT] stationarity residual and multiplier signs at representative t per piece")
    reps = [-2.0, -1.75, -1.5, -1.25, -1.0, -0.75, -0.5, -0.25, 0.0, 0.9, 1.8, 2.9, 4.0]
    max_resid = 0.0
    bad_signs = []
    for t in reps:
        k = check_kkt(t)
        max_resid = max(max_resid, k["residual_norm"])
        for name, val in k["lams"].items():
            if val < -1e-6:
                bad_signs.append((t, name, val))
        print(f" t={t:>6}: resid={k['residual_norm']:.2e} nu={k['nu']:.6f} lams={ {k2: round(v2,6) for k2,v2 in k['lams'].items()} }")
    print(f"[KKT] max residual over all reps: {max_resid:.3e}")
    print(f"[KKT] multipliers with wrong sign: {bad_signs}")

    # ---- 4. Envelope theorem check: dvalue/dt ~ -2x(t) ----
    print("\n[envelope] check dvalue/dt == -2*x(t) via central finite differences (skip exact breakpoints)")
    max_env_err = 0.0
    for t in np.linspace(-1.999, 3.999, 161):
        t = float(t)
        h = 1e-6
        if any(abs(t - bp) < 5e-5 for bp in breakpoints):
            continue
        r0 = solve(t - h)
        r1 = solve(t + h)
        dv = (r1["value"] - r0["value"]) / (2*h)
        rt = solve(t)
        expected = -2 * rt["x"]
        err = abs(dv - expected)
        max_env_err = max(max_env_err, err)
    print(f"[envelope] max |dvalue/dt - (-2x(t))| = {max_env_err:.3e}")

    # ---- 5. Domain errors ----
    print("\n[domain] out-of-range should raise")
    for bad in (-2.0001, 4.0001, -10, 10):
        try:
            solve(bad)
            print(f"  t={bad}: NO ERROR RAISED (unexpected)")
        except ValueError:
            print(f"  t={bad}: ValueError raised as expected")

    print("\n[types] int input works")
    ri = solve(-2)
    print(f"  solve(-2) -> {ri}")

    print("\nDONE")


if __name__ == "__main__":
    main()
