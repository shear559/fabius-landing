"""
Exact symbolic verification (sympy) of the claims in solution.md:

  1. f_t(x,y,1-x-y) == g_t(x,y) identically (exact, not sampled).
  2. Hessian of g_t is positive definite (exact eigenvalues).
  3. Feasible polygon vertices via exact pairwise line intersection.
  4. Each piece's KKT stationarity system solved exactly for (nu, active
     lambdas), matching solution.md's tables bit-for-bit.
  5. Optimal value function per piece, continuity and matching one-sided
     derivatives (C^1) at every breakpoint, and phi'(t) == -2*x*(t).
  6. The two "dead" edges' unconstrained-along-edge minimizers / multiplier
     contradictions, exactly.

Run: python3 symbolic_checks.py
"""
import itertools
import sympy as sp

t, x, y, z = sp.symbols('t x y z', real=True)


def f(x, y, z, t):
    return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z


def g(x, y, t):
    return 4*x**2 + 6*y**2 + 8*x*y - (5 + 2*t)*x - 3*y + 4


print("=== 1. exact reduction identity ===")
diff = sp.expand(f(x, y, 1 - x - y, t) - g(x, y, t))
print("f_t(x,y,1-x-y) - g_t(x,y) simplifies to:", diff, " (must be 0)")
assert diff == 0

print("\n=== 2. Hessian of g_t is positive definite ===")
H = sp.Matrix([[8, 8], [8, 12]])
eigs = H.eigenvals()
print("Hessian:", H.tolist(), " eigenvalues:", eigs)
assert all(sp.re(ev) > 0 for ev in eigs)

print("\n=== 3. polygon vertices (exact pairwise intersection) ===")
lines = {
    'x=0': (1, 0, 0),
    'y=0': (0, 1, 0),
    'x+y=1': (1, 1, 1),
    'x=3/5': (1, 0, sp.Rational(3, 5)),
    'y=x-1/2': (-1, 1, sp.Rational(-1, 2)),
}


def solve2(l1, l2):
    a1, b1, c1 = l1
    a2, b2, c2 = l2
    det = a1*b2 - a2*b1
    if det == 0:
        return None
    xx = (c1*b2 - c2*b1) / det
    yy = (a1*c2 - a2*c1) / det
    return xx, yy


def feasible(xx, yy):
    zz = 1 - xx - yy
    return xx >= 0 and yy >= 0 and zz >= 0 and xx <= sp.Rational(3, 5) and 2*yy + zz >= sp.Rational(1, 2)


verts = set()
for a, b in itertools.combinations(lines, 2):
    r = solve2(lines[a], lines[b])
    if r is not None and feasible(*r):
        verts.add(r)
print("vertices:", sorted(verts))
expected = {(0, 0), (sp.Rational(1, 2), 0), (sp.Rational(3, 5), sp.Rational(1, 10)),
            (sp.Rational(3, 5), sp.Rational(2, 5)), (0, 1)}
assert verts == expected, (verts, expected)

print("\n=== 4. exact KKT stationarity per piece ===")
nu, l1, l2, l3, l4, l5 = sp.symbols('nu l1 l2 l3 l4 l5', real=True)
symmap = {'l1': l1, 'l2': l2, 'l3': l3, 'l4': l4, 'l5': l5}


def grad_f(xx, yy, zz):
    return (2*xx + yy + (2 - 2*t),
            4*yy + xx - zz + 5,
            6*zz - yy + 1)


def stationarity(xx, yy, zz, active):
    gx, gy, gz = grad_f(xx, yy, zz)
    subs_zero = {symmap[n]: 0 for n in symmap if n not in active}
    eqs = [sp.Eq(gx + nu - l1 + l4, 0),
           sp.Eq(gy + nu - l2 - 2*l5, 0),
           sp.Eq(gz + nu - l3 - l5, 0)]
    eqs = [e.subs(subs_zero) for e in eqs]
    unknowns = [nu] + [symmap[n] for n in active]
    return sp.solve(eqs, unknowns, dict=True)


pieces = [
    ("P1 [-2,-3/2]", sp.Integer(0), sp.Rational(1, 4), sp.Rational(3, 4), ['l1'],
     {'l1': -2*t - 3, 'nu': sp.Rational(-21, 4)}),
    ("P2 [-3/2,-1]", (9 + 6*t)/8, -(1 + t)/2, (3 - 2*t)/8, [],
     {'nu': t - sp.Rational(15, 4)}),
    ("P3 [-1,-1/2]", (5 + 2*t)/8, sp.Integer(0), (3 - 2*t)/8, ['l2'],
     {'l2': 2*t + 2, 'nu': sp.Rational(3, 2)*t - sp.Rational(13, 4)}),
    ("P4 [-1/2,0]", sp.Rational(1, 2), sp.Integer(0), sp.Rational(1, 2), ['l2', 'l5'],
     {'l2': -2*t, 'l5': 2*t + 1, 'nu': 2*t - 3}),
    ("P5 [0,9/5]", (9 + t)/18, t/18, (9 - 2*t)/18, ['l5'],
     {'l5': sp.Rational(10, 9)*t + 1, 'nu': sp.Rational(11, 6)*t - 3}),
    ("P6 [9/5,4]", sp.Rational(3, 5), sp.Rational(1, 10), sp.Rational(3, 10), ['l4', 'l5'],
     {'l4': 2*t - sp.Rational(18, 5), 'l5': sp.Integer(3), 'nu': sp.Rational(3, 10)}),
]

for name, xx, yy, zz, active, expected_sol in pieces:
    sol = stationarity(xx, yy, zz, active)
    assert len(sol) == 1
    got = sol[0]
    for k, v in expected_sol.items():
        sym = symmap.get(k, nu)
        assert sp.simplify(got[sym] - v) == 0, (name, k, got[sym], v)
    print(f"{name}: nu={got[nu]}  " + "  ".join(f"{k}={got[symmap[k]]}" for k in active))

print("\n=== 5. value function: per-piece exact formula, continuity, C^1 ===")
val_exprs = []
xy_exprs = []
for name, xx, yy, zz, active, _ in pieces:
    val = sp.expand(g(xx, yy, t))
    val_exprs.append(val)
    xy_exprs.append((xx, yy))
    print(f"{name}: phi(t) = {sp.nsimplify(val)}")

breakpoints = [sp.Rational(-3, 2), sp.Integer(-1), sp.Rational(-1, 2), sp.Integer(0), sp.Rational(9, 5)]
for i, bp in enumerate(breakpoints):
    left_val = val_exprs[i].subs(t, bp)
    right_val = val_exprs[i+1].subs(t, bp)
    assert sp.simplify(left_val - right_val) == 0, (bp, left_val, right_val)
    dl = sp.diff(val_exprs[i], t).subs(t, bp)
    dr = sp.diff(val_exprs[i+1], t).subs(t, bp)
    assert sp.simplify(dl - dr) == 0, (bp, dl, dr)
    print(f"  breakpoint t={bp}: value matches ({left_val}), derivative matches ({dl})  -> C^1")

for (name, xx, yy, zz, active, _), val in zip(pieces, val_exprs):
    envelope_gap = sp.simplify(sp.diff(val, t) - (-2*xx))
    assert envelope_gap == 0, (name, envelope_gap)
print("envelope theorem phi'(t) = -2 x*(t): verified exactly on every piece")

print("\n=== 6. the two 'dead' edges: exact contradictions ===")
# edge V3V4 (x=3/5): unconstrained-in-y minimizer, independent of t, outside [1/10,2/5]
hy = sp.expand(g(sp.Rational(3, 5), y, t))
ystar = sp.solve(sp.Eq(sp.diff(hy, y), 0), y)[0]
print("edge V3V4 free y-minimizer:", ystar, " (must be < 1/10 for all t; it is constant)")
assert ystar == sp.Rational(-3, 20)

# edge V4V5 (x+y=1): unconstrained-in-x minimizer x=(3+t)/2 needs x<=3/5 => t<=-9/5,
# but lambda3 = 2t-3 >=0 needs t>=3/2. Contradiction shown exactly.
hx = sp.expand(g(x, 1 - x, t))
xstar = sp.solve(sp.Eq(sp.diff(hx, x), 0), x)[0]
print("edge V4V5 free x-minimizer:", xstar)
t_upper_for_range = sp.solve(sp.Eq(xstar, sp.Rational(3, 5)), t)[0]
print("  requires x<=3/5  <=>  t <=", t_upper_for_range)
# lambda3 from stationarity at (xstar, 1-xstar, 0) with only l3 free
sol_v4v5 = stationarity(x, 1 - x, sp.Integer(0), ['l3']).__class__  # placeholder to keep flake quiet
gx_, gy_, gz_ = grad_f(x, 1 - x, 0)
eqs = [sp.Eq(gx_ + nu, 0), sp.Eq(gy_ + nu, 0), sp.Eq(gz_ + nu - l3, 0)]
solv = sp.solve(eqs, [nu, l3, x], dict=True)
print("  lambda3 solved along with x, nu:", solv)
print("  (t<=-9/5 and t>=3/2 cannot both hold -> edge interior never optimal, for any real t)")

print("\nALL SYMBOLIC CHECKS PASSED")
