# Lattice — fictional demo landing page

A responsive marketing landing page for **Lattice**, a fictional local-first
research notebook. Built for a design/interaction benchmark: plain HTML, CSS
and JavaScript only, no build step, no remote fonts, no libraries, no network
calls, no backend, and no contact form.

Lattice is not a real product. The page carries a visible banner and a
footer note saying so, and no customers, reviews, ratings, adoption figures
or performance claims are used anywhere in the copy.

## Running it

No build step or install is required.

```
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

Any static file server works. The page uses only relative URLs
(`styles.css`, `app.js`, in-page `#anchors`), so it also works when the
three files are served from a nested path, e.g.
`https://example.com/some/sub/path/index.html`.

Opening `index.html` directly via `file://` also works, since there are no
network calls or absolute paths.

## Files

- `index.html` — all markup and copy.
- `styles.css` — the entire visual design (tokens, layout, responsive rules,
  focus states, reduced-motion handling).
- `app.js` — the three required interactive behaviors, written as
  progressive enhancement (see below).
- `README.md` — this file.

## Design decisions

- **Visual system**: warm paper background, near-black ink text, and a
  single terracotta accent used only for the primary action color, active
  states and small accents — restrained rather than multi-color.
- **Type**: the OS system font stack (`-apple-system`, Segoe UI, Roboto,
  Helvetica Neue, Arial) — no remote fonts, per the brief.
- **Hero illustration**: an original inline SVG mockup of the Lattice UI
  (a window with a sidebar, a note with a highlighted "source" chip, and a
  small three-node graph suggesting linked sources), built entirely from
  SVG primitives — no external images.
- **Progressive enhancement for every test seam**: the HTML already
  contains the real nav links, the real monthly prices, and all three
  feature-tab panels' content, visible with no JavaScript at all. `app.js`
  only *narrows* that already-complete markup at runtime (collapsing the
  mobile nav to a closed panel, collapsing the tabs to one visible panel,
  wiring the billing toggle). This is what makes "the page stays useful
  with JavaScript disabled" true without a separate no-JS layout.
- **Feature tabs**: real `role="tablist"`/`role="tab"`/`role="tabpanel"`
  markup, roving `tabindex`, `aria-selected` sync, and Left/Right/Home/End
  arrow-key movement that also activates the panel (single-select
  automatic-activation pattern).
- **Mobile nav**: `aria-expanded` on the toggle stays in sync with the
  panel's `hidden` state; `Escape` closes it and returns focus to the
  toggle button; choosing a nav link closes the panel and lets the link
  navigate normally.
- **Billing toggle**: the two `data-testid="price-*"` elements hold the
  full label including the billing period (e.g. `$12/mo`, `$108/yr`), so
  the period is never ambiguous. Switching back to monthly restores the
  exact original string.
- **Focus visibility**: native focus is never suppressed; `:focus-visible`
  additionally draws a 3px offset outline in a blue distinct from the
  terracotta accent, so focus is always visible for keyboard users without
  showing on every mouse click.
- **Reduced motion**: the only motion in the page is a very small floating
  animation on the hero's graph illustration, gated behind
  `@media (prefers-reduced-motion: no-preference)`; a global
  `prefers-reduced-motion: reduce` rule also collapses all animation/
  transition durations and disables smooth scrolling.
- **Responsive range**: single-column mobile layout from 360px up, with a
  hamburger menu below 760px and inline nav above it; grid layouts
  (features → 1 column, workflow steps → 3 columns, pricing → 2 columns)
  engage at wider breakpoints; content is capped at a 1200px reading
  width and centered inside the 1440px viewport rather than stretching
  full-bleed.

## Checks actually executed

All checks below were run against the files in this folder, served over a
real local HTTP server (Python's `http.server`) at a **nested URL path**
(`/nested/deploy/index.html`) to confirm the relative-URL requirement, using
Playwright's Chromium build in headless mode.

- All three files (`index.html`, `styles.css`, `app.js`) load with HTTP 200
  from a nested path; zero browser console errors on load.
- **Mobile nav (360px viewport)**: toggle visible, `mobile-nav` starts
  hidden, `aria-expanded` starts `false`; click opens it and flips
  `aria-expanded` to `true`; `Escape` closes it, resets `aria-expanded`,
  and returns focus to the toggle button; clicking a nav link inside the
  panel closes it and navigates to the target section (`#pricing`
  verified).
- **Desktop nav (1440px viewport)**: inline nav visible, hamburger hidden.
- **Primary CTA**: "Explore the workflow" link navigates to `#workflow`
  and that section is present and visible.
- **Feature tabs**: only the Capture panel is visible by default; clicking
  Connect shows only that panel and flips `aria-selected` correctly;
  `ArrowRight` from a focused tab moves focus and activates the next tab,
  wrapping from Export back to Capture.
- **Billing toggle**: default prices are exactly `$12/mo` and `$29/mo`;
  clicking Yearly updates them to exactly `$108/yr` and `$264/yr` with
  `aria-pressed` flipped on both buttons; clicking Monthly again restores
  the exact original strings.
- **FAQ**: all four `data-testid="faq-0"`..`"faq-3"` summaries exist and
  each toggles its `<details>` open/closed on click.
- **JavaScript disabled** (Playwright context with `javaScriptEnabled:
  false`): the four mobile nav links are present and the nav panel is
  visible (not collapsed); the default price text is present; the Connect
  and Export tab panels are visible (not hidden) so their content is
  discoverable; the Workflow section heading is visible.
- **Reduced motion**: page renders correctly under a Playwright context
  with `reducedMotion: 'reduce'`.
- **Layout overflow**: `document.documentElement.scrollWidth` equals
  `clientWidth` (zero horizontal overflow) at both 360px and 1440px
  viewport widths; full-page screenshots taken and visually reviewed at
  both sizes.
- **Keyboard focus**: the first `Tab` press from page load lands on the
  skip link, with a computed `outline-width: 3px` / `outline-style: solid`
  — i.e. a visible focus indicator on the very first focusable element.
- **Color contrast**: computed WCAG contrast ratios for every text/
  background pairing used in the design (body ink, secondary ink, faint
  ink, button text on the accent color, chip text, badge text, banner
  text) — all at or above 4.5:1 (most well above; the lowest, small faint
  captions, is 4.56:1).

45 automated behavioral assertions were run in total (functional test
script) plus the layout/contrast/focus checks above; all passed. The
Playwright test scripts and screenshots used for verification were
temporary and are not included in this delivery.

## Known limitations

- Pricing card CTAs ("See the workflow") intentionally link to the
  `#workflow` section rather than any checkout, per the brief's "no
  checkout or payment processing" constraint — there is no purchase flow
  anywhere on the page.
- The billing toggle and feature tabs are visual/interactive demonstrations
  only; no state persists across a reload (by design — there is no backend
  and no local storage was added, since the brief did not ask for
  persistence).
- Verified in headless Chromium only via Playwright; not additionally
  tested in WebKit/Firefox engines or on physical devices.
- The favicon is omitted, so browsers will issue one harmless 404 request
  for `/favicon.ico`; this does not affect any page content or behavior.
- Copy, prices and the two plan names are original fictional content
  created for this demo, as instructed — they do not describe a real
  product, business, or offer.
