"""
Reproducible verification script for solution.py.

Run:  python3 verify.py

Requires numpy and scipy (used only to independently cross-check the
closed-form solver; solution.py itself has no such dependency).
Exits with a non-zero status and prints FAILURES if any check fails.
"""
import io
import contextlib
import math
import sys

import numpy as np
from scipy.optimize import minimize

import solution as sol

FAILS = []


def check(name, cond, detail=""):
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {name} {detail}")
    if not cond:
        FAILS.append(name)


def f_obj(v, t):
    x, y, z = v
    return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z


CONS = [
    {'type': 'eq',   'fun': lambda v: v[0] + v[1] + v[2] - 1},
    {'type': 'ineq', 'fun': lambda v: v[0]},
    {'type': 'ineq', 'fun': lambda v: v[1]},
    {'type': 'ineq', 'fun': lambda v: v[2]},
    {'type': 'ineq', 'fun': lambda v: 0.6 - v[0]},
    {'type': 'ineq', 'fun': lambda v: 2*v[1] + v[2] - 0.5},
]
STARTS = [np.array(p) for p in
          [(0.2, 0.2, 0.6), (0.5, 0.0, 0.5), (0.0, 0.5, 0.5),
           (0.6, 0.1, 0.3), (0.1, 0.3, 0.6)]]


def slsqp_best(t):
    best_val, best_x = math.inf, None
    for s in STARTS:
        r = minimize(f_obj, s, args=(t,), method='SLSQP', constraints=CONS,
                     bounds=[(0, 1)]*3, options={'ftol': 1e-14, 'maxiter': 500})
        if r.success and r.fun < best_val:
            best_val, best_x = r.fun, r.x
    return best_val, best_x


def feasible(d, tol=1e-7):
    x, y, z = d['x'], d['y'], d['z']
    return (x >= -tol and y >= -tol and z >= -tol and x <= 0.6 + tol
            and 2*y + z >= 0.5 - tol and abs(x + y + z - 1) < 1e-7)


# 1. Import has no side effects (already imported above; re-import in a
#    subprocess-free way by capturing stdout of a fresh call is not needed
#    since Python caches modules — this checks solve() itself is silent).
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    _ = sol.solve(1.234)
check("solve() prints nothing", buf.getvalue() == "")

# 2. Finite outputs + feasibility across a dense grid.
grid = np.linspace(-2, 4, 6001)
bad_feas = bad_fin = 0
for t in grid:
    d = sol.solve(float(t))
    if not feasible(d):
        bad_feas += 1
    if not all(math.isfinite(d[k]) for k in ('x', 'y', 'z', 'value')):
        bad_fin += 1
check("feasible on 6001-pt grid over [-2,4]", bad_feas == 0, f"violations={bad_feas}")
check("finite x,y,z,value on grid", bad_fin == 0, f"violations={bad_fin}")

# 3. Breakpoint continuity: left/right limits agree with the value at the
#    breakpoint itself, to floating precision, as eps -> 0.
breaks = [-1.5, -1.0, -0.5, 0.0, 1.8]
worst_cont = 0.0
for b in breaks:
    for key in ('x', 'y', 'z', 'value'):
        db = sol.solve(b)[key]
        dl = sol.solve(b - 1e-7)[key]
        dr = sol.solve(b + 1e-7)[key]
        worst_cont = max(worst_cont, abs(dl - db), abs(dr - db))
check("continuity at all 5 breakpoints (tol 1e-5)", worst_cont < 1e-5,
      f"worst={worst_cont:.2e}")

# 4. Envelope theorem: dV/dt = -2 x*(t) exactly (finite-difference check).
worst_env = 0.0
for t in np.linspace(-1.99, 3.99, 200):
    h = 1e-6
    dplus = sol.solve(t + h)['value']
    dminus = sol.solve(t - h)['value']
    dVdt_num = (dplus - dminus) / (2*h)
    x_t = sol.solve(t)['x']
    worst_env = max(worst_env, abs(dVdt_num - (-2*x_t)))
check("envelope theorem dV/dt = -2 x*(t)", worst_env < 1e-4, f"worst={worst_env:.2e}")

# 5. Independent cross-check against SLSQP (multi-start) from scratch.
rng = np.random.default_rng(12345)
ts = list(np.linspace(-2, 4, 61)) + list(rng.uniform(-2, 4, 40)) + \
     [-2, -1.5, -1, -0.5, 0, 1.8, 4]
worst_val = worst_pt = 0.0
for t in ts:
    t = float(t)
    val, pt = slsqp_best(t)
    d = sol.solve(t)
    worst_val = max(worst_val, abs(d['value'] - val))
    worst_pt = max(worst_pt, max(abs(d['x']-pt[0]), abs(d['y']-pt[1]), abs(d['z']-pt[2])))
check("matches independent SLSQP solve (value)", worst_val < 1e-4, f"worst={worst_val:.2e}")
check("matches independent SLSQP solve (point)", worst_pt < 1e-3, f"worst={worst_pt:.2e}")

# 6. int vs float input agree.
d_int, d_float = sol.solve(2), sol.solve(2.0)
check("int input == float input", d_int['x'] == d_float['x'] and
      d_int['value'] == d_float['value'])

# 7. Domain endpoints handled.
check("t=-2 finite & feasible", feasible(sol.solve(-2)))
check("t=4 finite & feasible", feasible(sol.solve(4)))

print()
if FAILS:
    print("FAILURES:", FAILS)
    sys.exit(1)
else:
    print("ALL CHECKS PASSED")
