# Fieldnote Board

A local-first task board for a small field-research team. Fictional demo, no backend, no network calls. Everything lives in the browser's `localStorage`.

## Run instructions

No build step, no dependencies. Serve the folder with any static file server and open `index.html` — it also works from a nested path since every asset reference (`./styles.css`, `./app.js`) is relative.

```
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

or `npx serve .`, or double-click `index.html` to open it via `file://` (localStorage still works per-origin/per-file in most browsers, though a real static server is recommended for parity with how it'll be tested).

## Data model

Stored under `localStorage["fieldnote-board:v1"]` as:

```json
{ "schemaVersion": 1, "tasks": [ { "id": "...", "title": "...", "project": "...", "status": "todo|doing|done", "priority": "low|medium|high", "dueDate": "YYYY-MM-DD or \"\"", "tags": ["..."] } ] }
```

Field limits: `id` ≤80 chars, `title` ≤120, `project` ≤80, each tag ≤24 chars, ≤8 tags per task. Tags typed as comma-separated text are trimmed and deduplicated case-insensitively (first-seen casing wins).

On a genuinely empty store (`getItem` returns `null`) the app seeds a 7-task sample board across 2 projects (Riverbank Survey, Community Outreach) covering all three statuses, then persists it.

## Error handling design

- **Corrupt storage on load** — if the stored value fails to parse as JSON, or doesn't match the schema (wrong `schemaVersion`, missing/invalid fields, bad enum, bad date, duplicate ids), the app never overwrites it. It shows a red recovery banner with **Download original data** (exports the exact stored bytes as a file) and **Reset board** (confirmation-gated; only this explicit action replaces the corrupt value with a fresh seed). All create/edit/delete/status/import actions are blocked while unresolved, with the reason surfaced inline.
- **Storage write failures** (e.g. quota exceeded, storage disabled) — the in-memory task list still updates so the edit isn't lost and stays visible/editable/exportable, but a persistent banner states the change is *not* saved to the device rather than claiming success.
- **Cross-tab conflicts** — a `storage` event for the board key that doesn't match what this tab last wrote flips the app into a blocked "conflict" mode: a banner explains the board changed elsewhere and offers **Reload board**. Until reloaded, every mutating action (create, edit, delete, undo, status change, import, reset) is refused rather than risking a stale read-modify-write that would silently drop the other tab's data. A full reload was chosen over ad-hoc merging because it is the only option that's provably safe with no risk of losing either side's edits.
- **Import** is fully validated (schema, size ≤1 MiB, every task's fields, duplicate ids) *before* anything is touched, so a bad file leaves the current board completely unchanged (atomic). A valid file still requires an explicit confirm before it replaces the board.
- All user-supplied and imported text (titles, projects, tags) is rendered via `textContent`, never `innerHTML`, so HTML/script in task data can't execute.

## Checks actually executed

Verified with a local static server and Playwright (Chromium), covering: seed creation and shape on empty storage; blank-storage vs. corrupt-storage vs. valid-storage boot paths; create/edit with inline validation (blank title, overlong text, invalid calendar date e.g. 2026-02-30) and that the modal stays open on error; tag dedup case-insensitivity; edit preserving other records and the task's id; status change persistence; delete → undo → reload-survival; search/filter combination behavior and the "no results" state; visible match/total count; export including filtered-out records; import happy path, duplicate-id rejection, malformed-JSON rejection, oversize rejection, and that rejected imports leave the board untouched; that imported HTML in a title renders as inert text; corrupt-storage banner + byte preservation + blocked mutations + reset flow; simulated cross-tab `storage` event triggering the conflict banner and blocking a delete; Escape-to-close-with-focus-restore on the modal; screenshots at 360px and 1440px for layout/overflow sanity; presence of accessible labels on the search field and card action buttons.

Not independently machine-checked (reviewed by inspection instead): full modal Tab-cycle focus trap, `prefers-reduced-motion` suppression, and the JavaScript-disabled `<noscript>` message (the last two require browser settings a scripted harness can't easily toggle mid-session).

## Limitations

- Undo is single-level: deleting a second task discards the ability to undo the first.
- Cross-tab conflict resolution is "reload wins" (safe, simple) rather than field-level merge; the README/banner is explicit about that trade-off per the brief's allowance.
- Project names are freeform text tied to whatever's currently in the board rather than a separately managed list — the project filter's options are derived from current tasks.
