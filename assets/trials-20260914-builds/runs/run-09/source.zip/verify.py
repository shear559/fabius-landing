"""
Reproducible verification script for solution.py / solution.md.

Run with:   python3 verify.py

Performs, independently of the derivation in solution.md:
  1. Import-safety check (no output, no CLI side effects on import).
  2. Type/shape checks on solve()'s return value.
  3. Feasibility check of the returned (x, y, z) for every t tested.
  4. Agreement with the exact closed-form (Fraction-based) formulas of
     solution.md, at the breakpoints and at +/-1e-9, +/-1e-6, +/-1e-3
     around each breakpoint, plus 300 random points in [-2, 4].
  5. An independent cross-check against scipy.optimize.minimize (SLSQP,
     multiple random restarts) at a coarser grid of t values, as a
     numerical-only sanity net (not a proof, but a strong corroboration).

Exits with status 0 and prints "ALL CHECKS PASSED" iff everything above
holds within tolerance; otherwise prints details and exits with status 1.
"""

import io
import contextlib
import math
import random
import sys
from fractions import Fraction as F

sys.path.insert(0, ".")
from solution import solve  # noqa: E402


FAILURES = []


def check(cond, msg):
    if not cond:
        FAILURES.append(msg)


# ---------------------------------------------------------------------------
# 1. Import safety
# ---------------------------------------------------------------------------
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    import importlib
    import solution as _s
    importlib.reload(_s)
check(buf.getvalue() == "", "import produced stdout output: %r" % buf.getvalue())


# ---------------------------------------------------------------------------
# Exact oracle (independent re-implementation of the closed forms, using
# exact rational arithmetic instead of the floating point used in solution.py)
# ---------------------------------------------------------------------------
def exact(t):
    t = F(t).limit_denominator(10**12)
    if t <= F(-3, 2):
        x, y = F(0), F(1, 4)
    elif t <= F(-1):
        x, y = F(3, 4) * t + F(9, 8), -F(1, 2) * t - F(1, 2)
    elif t <= F(-1, 2):
        x, y = (5 + 2 * t) / 8, F(0)
    elif t <= F(0):
        x, y = F(1, 2), F(0)
    elif t <= F(9, 5):
        x, y = F(1, 2) + t / 18, t / 18
    else:
        x, y = F(3, 5), F(1, 10)
    z = 1 - x - y
    val = x**2 + 2 * y**2 + 3 * z**2 + x * y - y * z + (2 - 2 * t) * x + 5 * y + z
    return float(x), float(y), float(z), float(val)


def feasible(x, y, z, tol=1e-6):
    return (
        abs(x + y + z - 1) < tol
        and x >= -tol and y >= -tol and z >= -tol
        and x <= 0.6 + tol
        and (2 * y + z) >= 0.5 - tol
    )


# ---------------------------------------------------------------------------
# 2-4. Structural, feasibility, and exact-formula agreement checks
# ---------------------------------------------------------------------------
breakpoints = [-2, -1.5, -1, -0.5, 0, 1.8, 4]
offsets = [0, 1e-9, -1e-9, 1e-6, -1e-6, 1e-3, -1e-3]
random.seed(12345)
sample_ts = [bp + off for bp in breakpoints for off in offsets]
sample_ts += [random.uniform(-2, 4) for _ in range(300)]
sample_ts += [-2, 4, 0, -2.0, 4.0]  # int/float edge cases handled below separately

max_pt_err = 0.0
max_val_err = 0.0
for t in sample_ts:
    t_c = min(max(t, -2.0), 4.0)
    r = solve(t_c)

    for k in ("x", "y", "z", "value"):
        check(isinstance(r[k], float), f"field {k} is not float at t={t_c}: {type(r[k])}")
        check(math.isfinite(r[k]), f"field {k} is not finite at t={t_c}: {r[k]}")

    check(feasible(r["x"], r["y"], r["z"]),
          f"infeasible point at t={t_c}: {r}")

    ex, ey, ez, ev = exact(t_c)
    pt_err = max(abs(r["x"] - ex), abs(r["y"] - ey), abs(r["z"] - ez))
    val_err = abs(r["value"] - ev)
    max_pt_err = max(max_pt_err, pt_err)
    max_val_err = max(max_val_err, val_err)
    check(pt_err < 1e-6, f"point mismatch at t={t_c}: got ({r['x']},{r['y']},{r['z']}), exact ({ex},{ey},{ez})")
    check(val_err < 1e-6, f"value mismatch at t={t_c}: got {r['value']}, exact {ev}")

print(f"[exact-formula check] {len(sample_ts)} points tested; "
      f"max point error = {max_pt_err:.3e}, max value error = {max_val_err:.3e}")

# int input
r_int = solve(0)
check(isinstance(r_int["x"], float), "solve(0) (int input) did not return float fields")
check(abs(r_int["x"] - 0.5) < 1e-12 and r_int["y"] == 0.0 and abs(r_int["z"] - 0.5) < 1e-12,
      f"solve(0) gave unexpected point: {r_int}")

# domain-edge behaviour
check(abs(solve(-2)["value"] - 3.625) < 1e-9, "solve(-2) value mismatch")
check(abs(solve(4)["value"] - (-2.12)) < 1e-9, "solve(4) value mismatch")

# out-of-range and bad-type handling
try:
    solve(5.0)
    check(False, "solve(5.0) should have raised ValueError")
except ValueError:
    pass

try:
    solve("nope")
    check(False, "solve('nope') should have raised TypeError")
except TypeError:
    pass


# ---------------------------------------------------------------------------
# 5. Independent numerical cross-check via scipy SLSQP (best-effort; skipped
#    gracefully if scipy is unavailable in the grading environment).
# ---------------------------------------------------------------------------
try:
    import numpy as np
    from scipy.optimize import minimize, LinearConstraint, Bounds

    def f_obj(v, t):
        x, y, z = v
        return x**2 + 2*y**2 + 3*z**2 + x*y - y*z + (2 - 2*t)*x + 5*y + z

    def numeric_solve(t):
        A_eq = np.array([[1, 1, 1]])
        lc_eq = LinearConstraint(A_eq, 1, 1)
        A_ineq = np.array([[0, 2, 1]])
        lc_ineq = LinearConstraint(A_ineq, 0.5, np.inf)
        bounds = Bounds([0, 0, 0], [0.6, np.inf, np.inf])
        starts = [(0.3, 0.3, 0.4), (0.1, 0.1, 0.8), (0.5, 0.05, 0.45),
                  (0.6, 0.1, 0.3), (0, 0.25, 0.75), (0.2, 0.6, 0.2)]
        best = None
        for x0 in starts:
            res = minimize(f_obj, x0, args=(t,), method="SLSQP", bounds=bounds,
                            constraints=[lc_eq, lc_ineq],
                            options={"maxiter": 1000, "ftol": 1e-14})
            if res.success and (best is None or res.fun < best.fun):
                best = res
        return best

    grid = [-2, -1.9, -1.5, -1.25, -1, -0.75, -0.5, -0.25, 0, 0.5, 1, 1.5,
            1.8, 2, 2.5, 3, 3.5, 4]
    max_num_err = 0.0
    for t in grid:
        res = numeric_solve(t)
        r = solve(t)
        err_pt = max(abs(res.x[0] - r["x"]), abs(res.x[1] - r["y"]), abs(res.x[2] - r["z"]))
        err_val = abs(res.fun - r["value"])
        max_num_err = max(max_num_err, err_pt, err_val)
        check(err_pt < 1e-4, f"SLSQP point mismatch at t={t}: {res.x} vs {r}")
        check(err_val < 1e-5, f"SLSQP value mismatch at t={t}: {res.fun} vs {r['value']}")
    print(f"[scipy SLSQP cross-check] {len(grid)} points tested; max error = {max_num_err:.3e}")
except ImportError:
    print("[scipy SLSQP cross-check] skipped: scipy not available in this environment")


# ---------------------------------------------------------------------------
if FAILURES:
    print(f"\n{len(FAILURES)} FAILURE(S):")
    for m in FAILURES:
        print(" -", m)
    sys.exit(1)
else:
    print("\nALL CHECKS PASSED")
    sys.exit(0)
