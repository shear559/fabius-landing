# Lattice — fictional landing page demo

A static, three-file marketing page (`index.html`, `styles.css`, `app.js`) for **Lattice**, a
fictional local-first research notebook. Built for a design/implementation benchmark — Lattice
is not a real product, and the page says so on-page (top banner and footer).

## Run it

No build step, no dependencies, no network calls.

```
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```

Or open `index.html` directly from the filesystem. All asset references (`styles.css`, `app.js`)
are relative with no leading slash, so the three files can also be dropped into any subdirectory
of a static host (e.g. `https://example.com/some/nested/path/index.html`) and still resolve
correctly. This was verified by serving the files from a nested path (`/nested/path/segment/`)
under a local `python3 -m http.server` and confirming both assets load with `curl -I`.

## Implementation decisions

- **Visual system**: warm paper background, near-black warm ink for text, a single deep-teal
  accent color (`#1f6f5c`) used deliberately once per surface — no secondary accent colors, per
  a "one accent, otherwise neutral" approach to avoid a generic AI-generated look. Headings use a
  system serif stack (`Georgia`/`Iowan Old Style`/fallbacks) for a "notebook" feel; body text uses
  the system sans stack. No remote fonts are loaded.
- **Hero illustration**: an original inline SVG mockup of a notebook UI (project sidebar, a note
  with a source-link chip, a search bar, an export button) built entirely from SVG primitives —
  no external image assets. It's marked `aria-hidden` since the same information is already in
  the surrounding text.
- **Progressive enhancement / JS-disabled behavior**: the HTML on its own already contains every
  navigation link, all three feature-panel bodies, the default (monthly) prices, and all four FAQ
  answers (native `<details>/<summary>`, which needs no JavaScript). `app.js` only *adds* the
  collapsed/tabbed presentation on top of that: it hides the mobile nav behind the toggle, and
  hides the two non-active feature panels, only after confirming it has run. With JavaScript
  disabled, the mobile nav stays open as a plain link list, and all three feature panels are shown
  stacked with headings — nothing is lost, only the "toggle physically hides things" layer is
  gone.
- **Feature tabs**: implemented as a real ARIA tablist (`role="tab"`/`role="tabpanel"`,
  `aria-selected`, roving `tabindex`, arrow-key movement including wrap-around and Home/End),
  driven by `data-testid` hooks (`feature-capture`/`feature-connect`/`feature-export` and
  `panel-capture`/`panel-connect`/`panel-export`). Each panel has distinct, non-duplicated body
  copy.
- **Mobile nav**: `[data-testid="menu-toggle"]` toggles `[data-testid="mobile-nav"]` by setting its
  `hidden` attribute and syncing `aria-expanded`/`aria-label`. `Escape` closes it and returns focus
  to the toggle (listened for on `document`, not scoped to the nav, since focus stays on the
  button after opening). Selecting any nav link closes the menu before the browser follows the
  link. The desktop nav (`.desktop-nav`) is shown at ≥720px via CSS regardless of JS state; the
  mobile nav is force-hidden at that width too.
- **Billing toggle**: `[data-testid="billing-monthly"]`/`[data-testid="billing-yearly"]` swap the
  text content of `[data-testid="price-solo"]`/`[data-testid="price-studio"]` between the exact
  supplied figures ($12/$29 monthly, $108/$264 yearly) and update a separate "/ month" / "/ year"
  label plus `aria-pressed` state. Re-selecting monthly restores the exact original strings byte
  for byte (verified programmatically, see below).
- **Focus visibility**: default `outline` is suppressed only in favor of a `:focus-visible` double
  ring (`box-shadow` with a background-colored inner ring and a dark outer ring) that stays legible
  against both the paper background and the teal accent buttons, rather than relying on a single
  outline color that could wash out on one of those surfaces.
- **Reduced motion**: a `prefers-reduced-motion: reduce` query collapses all transition/animation
  durations to effectively zero and turns off smooth scrolling, so anchor-nav jumps and hover state
  changes are instant.
- **Responsive layout**: mobile-first CSS with a single content max-width (1120px); the header/nav
  switches from a hamburger disclosure to an inline nav at 720px; the hero, workflow steps, and
  pricing cards move from stacked to multi-column layouts at 860px. Checked at 360px and 1440px
  (see below) with no horizontal overflow at either width.
- **No fabricated business claims**: no customers, reviews, ratings, adoption numbers, or
  performance statistics appear anywhere. The FAQ answers state plainly that this demo does not
  promise automatic cloud backup and that cancellation doesn't touch files already exported.

## Checks actually executed

Using Chromium via the Playwright library (no other browser engines were available in this
environment) driven by a throwaway Node script (not part of the deliverable), against the three
files served over `python3 -m http.server` from a nested path:

- Mobile viewport (375×800): `menu-toggle` starts `aria-expanded="false"` with `mobile-nav`
  hidden; clicking opens it and flips `aria-expanded="true"`; `Escape` closes it and returns focus
  to the toggle; reopening and clicking a nav link inside it both closes the menu and navigates to
  `#workflow`.
- Desktop viewport (1440×900): desktop nav and CTA visible, mobile toggle/nav not visible; feature
  tabs default to Capture selected/visible with the other two panels hidden; clicking
  `feature-connect` flips `aria-selected` and panel visibility correctly; `ArrowRight`/`ArrowLeft`
  from a focused tab move focus and selection, including wrap-around at both ends; billing toggle
  moves `price-solo`/`price-studio` to exactly `$108`/`$264` on yearly and exactly back to
  `$12`/`$29` on monthly; all four `faq-0..faq-3` `<summary>` elements open their `<details>` on
  click; the "Explore the workflow" link's `href` is exactly `#workflow`; a keyboard `Tab` press
  produces a visible focus box-shadow/outline on the first stop; `document.documentElement`
  reports no horizontal overflow at 1440px width.
- 360px viewport: no horizontal overflow; hamburger toggle visible; desktop nav hidden.
- `prefers-reduced-motion: reduce` emulation: computed transition durations on a primary button
  collapse to ~0.
- JavaScript fully disabled (`javaScriptEnabled: false`): mobile nav is visible by default with
  its links intact; default prices read `$12`/`$29`; all three feature panels
  (`panel-capture`/`panel-connect`/`panel-export`) render visible with their real content; the
  first FAQ summary is present; the primary CTA link and its `#workflow` href are present.
- Static-file check only (not a full HTML validator run): confirmed via `curl -I` that
  `index.html`, `styles.css`, and `app.js` all resolve with correct content types when the three
  files are served from a nested subdirectory path, matching the relative (no leading-slash) asset
  references used in `index.html`.

All of the above passed on this run. The verification script itself was a temporary local file and
is not part of this deliverable.

## Known limitations

- Only Chromium (via Playwright) was used for interactive verification; WebKit/Firefox rendering
  was not separately checked in this run.
- The hero illustration is a static SVG mockup, not a functioning app — it's explicitly framed as
  illustrative in the surrounding copy.
- No automated color-contrast audit tool was run; contrast choices (ink/teal on the paper
  background) were chosen by eye against the design system's own palette, not measured against a
  formal WCAG contrast checker.
- No dark-mode/`prefers-color-scheme` variant is provided — the brief did not request one and the
  page commits to a single light theme.
- The billing toggle and feature tabs are visual/ARIA-only conveniences; with JavaScript disabled
  they fall back to "everything is already on the page" rather than an equivalent interactive
  control, which is the intended trade-off described above, not an oversight.
