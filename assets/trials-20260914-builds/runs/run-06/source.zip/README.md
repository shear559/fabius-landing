# Fieldnote Board

A local-first task board for a small field-research team (fictional demo). No build step, no
dependencies, no backend, no network calls, no accounts. Everything lives in this browser's
`localStorage`.

## Run it

Any static file server works, from any path depth:

```sh
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Opening `index.html` directly via `file://` also works in most browsers, since all assets
(`styles.css`, `app.js`) are referenced with relative, non-rooted paths and there is no module
loader, fetch, or API call.

## Files

- `index.html` — structure, the task dialog (native `<dialog>`), noscript fallback.
- `styles.css` — design tokens (color/type/space/radius), mobile-first layout, dark-mode via
  `prefers-color-scheme`, reduced-motion override.
- `app.js` — the entire app: storage, validation, rendering, all event wiring. One plain script
  (no modules, no build), so it runs unchanged from `file://` or any static host.

## Data model

`localStorage["fieldnote-board:v1"]` holds `{ schemaVersion: 1, tasks: [...] }`. Each task has
exactly: `id, title, project, status, priority, dueDate, tags`. Enums, length limits and the
comma-tag dedupe/trim rule are enforced in one place (`validateTaskShape` for stored/imported
documents, `validateFormInput` for the create/edit form) so startup-corruption checks, import
checks and form checks can't drift apart.

On a **genuinely empty** key (nothing stored yet — first visit), the app seeds 7 fictional tasks
across 2 projects ("Riverbank Survey", "Trailhead Signage Refresh") covering all three statuses.
A reset after corruption or a fresh import intentionally does **not** reseed demo data — it
starts from an empty, valid board, since the seeding rule is scoped to "genuinely empty storage",
not "empty by any other route."

## Error handling, by scenario

- **Corrupt storage on startup** (unparsable JSON, or JSON that doesn't match the schema): the
  raw bytes are left untouched in `localStorage`, a recovery banner explains this, and the board
  is not usable until the user either downloads the raw bytes or explicitly resets (with a native
  `confirm()`) to a fresh empty board.
- **Storage write throws** (quota exceeded, private-mode restrictions, etc.): the attempted
  change is still applied to the in-memory task list — so it's visible and exportable for the
  rest of the session — but a visible banner (`data-testid="save-error-notice"`) says the change
  was **not** saved; the app never silently claims persistence it doesn't have.
- **Another tab writes the board** (`storage` event fires only in *other* tabs, by spec): a
  conflict banner appears and every mutating control (new/edit/delete/status/undo/import) is
  disabled — both defensively in each handler and visibly via the `disabled` attribute on
  rendered controls — until the user clicks the banner's reload control, which does a full
  `location.reload()` and re-reads the current authoritative state.
- **Import**: file size is checked before reading (reject over 1 MiB); the whole document is
  parsed and schema-validated (duplicate ids, bad enums, bad dates, oversized fields, malformed
  JSON) before anything changes — an invalid file leaves the current board completely untouched
  (atomic). A valid file requires an explicit native `confirm()` before it replaces the board.
- **Delete**: removes the task immediately, persists that removal, and offers a visible
  `data-testid="undo-delete"` toast that reinserts the exact same record at its original index
  and persists that restoration too (survives a reload).
- **JavaScript disabled**: a `<noscript>` banner is the only thing rendered; the app root starts
  `hidden` in the markup and is only revealed once `app.js` actually runs.

## Design

Mobile (360px) is a stacked single column of status sections; desktop (≥900px, checked at 1440px)
becomes a three-column board (To do / Doing / Done). One accent color (a muted green) is reserved
for the primary action and focus states; priority/overdue use restrained outline pills, not fills.
`prefers-reduced-motion: reduce` collapses all transition/animation durations. The task dialog is
a native `<dialog>` (`showModal()`), so Escape-to-close is native; focus is explicitly returned to
whichever control opened it.

## Checks actually run

A Playwright script (not shipped — deleted after use, per the "no hidden grader files" spirit)
drove a real Chromium instance against a local static server and verified, end-to-end: seeded
board on first load; create/edit/delete/undo with persistence across reload; tag dedupe
(case-insensitive) and the 8-tag/24-char limits; blank-title and invalid-date form errors;
search + all three filters + the no-results state; status change from the card control; export
producing the full (unfiltered) board as a downloaded JSON file; import accepting a valid
replacement (with confirmation) and rejecting an invalid one (duplicate ids) while leaving the
prior board completely intact; Escape-to-close with focus restoration; corrupt-storage recovery
(bytes preserved, download-raw and reset-board both checked, reset produces an empty, not
reseeded, board); a monkey-patched throwing `localStorage.setItem` producing the save-error
banner while keeping the attempted change visible in memory; and a real two-tab conflict (a
second `page` in the same browser context) showing the conflict banner and a working reload
control after the first tab wrote a change. The app was also copied three directories deep and
served from there to confirm the relative-path/nested-URL requirement, with no console errors.
Both the 360px and 1440px layouts were captured and visually reviewed.

## Known limitations

- Card-level Edit/Delete buttons are ~36px tall, not the full 44×44px touch-target guideline —
  a deliberate density trade-off for a data-dense board; the primary "New task" action and all
  form controls do meet 44px.
- No automated screen-reader pass; accessible names, focus-visible styling, and keyboard
  reachability were checked, but not verified with an actual assistive-technology client.
- The cross-tab conflict reconciliation is intentionally simple: block-and-reload, not a
  field-level merge. This is stated as a safety choice, not an oversight — it guarantees no
  silent overwrite of newer external state.
