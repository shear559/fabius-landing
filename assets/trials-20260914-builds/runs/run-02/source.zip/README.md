# Lattice — fictional landing page (design demonstration)

Lattice is a **fictional** product used to demonstrate a landing page. It is not real
software, has no backend, and nothing on this page is a verified business claim.

## Run it

Static files, no build step. Serve the folder with any static file server and open
`index.html` — it also works at a nested URL path since all asset references
(`styles.css`, `app.js`) are relative, not rooted at `/`.

```sh
# from this folder
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

Or just double-click `index.html` to open it directly from disk — no interactive
feature (nav, tabs, billing toggle) depends on being served, though a server is closer
to how it will actually be hosted.

## Files

- `index.html` — structure and content.
- `styles.css` — all visual design (tokens as CSS custom properties, then layout).
- `app.js` — the three interactive behaviors (mobile nav, feature tabs, billing toggle).
  No libraries, no network calls, no build step.

## Implementation decisions

**Visual system.** Paper-and-ink theme fitting a notebook product: neutral off-white
canvas (`#f5f5f3`, deliberately not cream/beige), near-black ink text, one accent —
a rust/terracotta (`#9c4517`) standing in for annotation ink — reserved for emphasis,
focus rings, and the active tab/state. Display headings use a system serif stack
(`ui-serif, Georgia, ...`) for an editorial/field-notebook register; body and UI text
use the system sans stack. No remote fonts, per the brief. Spacing snaps to an 8px
base unit; radius uses one grammar per element family (pill for controls/badges,
`lg`/`md` for cards). Sections alternate canvas/white for rhythm instead of added
chrome.

**Hero illustration.** An original inline SVG "lattice of notes" mockup: two compact
note cards connected to a larger, accent-outlined focused note, evoking the product's
own concept (notes linked to sources) rather than a generic decorative graphic. Built
entirely from primitives that represent a real UI (card chrome, text bars, a source
chip), not an abstract assembled "scene."

**Progressive enhancement (JS-optional).** The brief requires core content, prices,
and navigation to stay discoverable with JavaScript disabled. All markup ships in its
"most open" state — the mobile nav links and all three feature panels are present and
visible in the HTML with no `hidden` attribute. On load, `app.js` then applies the
interactive behavior: it collapses the mobile nav behind the toggle and hides the two
inactive tab panels. With JavaScript off, everything stays visible and linkable; with
it on, the tested ARIA/disclosure behavior takes over.

**Feature tabs.** Real `role="tablist"`/`role="tab"`/`role="tabpanel"` semantics, a
roving `tabindex` (only the selected tab is in the tab order), and Arrow/Home/End key
support. Each panel has distinct written content (capture / connect / export) matching
the supplied product facts.

**Billing toggle.** Monthly/yearly amounts are fixed fictional strings per plan
(`$12`/`$108`, `$29`/`$264`) stored as `data-monthly` / `data-yearly` attributes and
swapped verbatim — there is no computed math, so switching back to monthly always
restores the exact original text. A visible, `aria-live` label states which period is
showing.

**Pricing card differentiation.** The "Studio" plan is distinguished with a background
tint rather than a colored border on a rounded card, to keep the one-accent rule
intact and avoid an over-decorated control.

**FAQ.** Four native `<details>/<summary>` elements — no JS required, keyboard and
screen-reader accessible by default, answering exactly the four required facts (local
storage, Markdown export, backup-by-export with no promised cloud backup, and that
cancellation doesn't affect already-exported files).

**No invented claims.** No customers, testimonials, ratings, or performance numbers
appear anywhere. The page states its fictional nature in a persistent top banner and
again in the footer.

**Reduced motion.** All transitions (menu icon morph, button press scale, smooth
anchor scrolling) are wrapped in `@media (prefers-reduced-motion: no-preference)`, so
motion is off by default and only added back when the visitor hasn't asked to reduce
it. There is no autoplay, looping, or entrance animation.

## Checks actually run

Using a headless Chromium (Playwright) against the page served over HTTP from a
nested path (`/nested/path/index.html`), at 360px and 1440px viewports:

- Mobile nav: toggle opens/closes `mobile-nav`, `aria-expanded` stays in sync, `Escape`
  closes it and returns focus to the toggle, selecting a link closes the nav and
  navigates to the target section.
- Feature tabs: only the selected panel is visible; clicking and `ArrowRight` both move
  selection and update `aria-selected`; panel contents differ from one another.
- Billing toggle: `price-solo`/`price-studio` show `$12`/`$29` initially, switch to
  `$108`/`$264` on yearly, and return to the exact original `$12`/`$29` on monthly.
- All four FAQ `<details>` open on click.
- The primary CTA resolves to `href="#workflow"`.
- Desktop nav is visible and the mobile toggle is hidden at 1440px (and vice versa at
  360px).
- A JavaScript-disabled browser context: mobile nav links, prices, and all three
  feature panels are still present and readable in the DOM.
- No console/page errors during any of the above.
- Verified visually with full-page screenshots at 360px and 1440px (design review:
  fixed a duplicate list-number bug next to the step badges, and removed an
  accent-bordered highlight card and a few purely decorative section labels).

Not run: real screen-reader software, physical devices, or automated axe/contrast
tooling — contrast for the palette was checked by manual calculation (relative
luminance) against WCAG 2.2 AA, not by an automated scanner.

## Known limitations

- Single light theme only; no dark mode.
- No automated accessibility scanner (axe, Lighthouse) was available in this
  environment — accessibility was reviewed by hand (semantics, focus order, contrast
  math, keyboard interaction) rather than tool-verified.
- The hero SVG illustration is decorative (`aria-hidden="true"`); it is not a
  functional interactive element.
- Pricing has no real checkout, as required by the brief — the "See how the workflow
  works" link is the only pricing-section call to action.
