const assert = require('node:assert');
const { average, sum, max } = require('./stats.js');
// existing suite: covers the pure functions only
assert.strictEqual(average([2, 4, 6]), 4);
assert.strictEqual(sum([2, 4, 6]), 12);
assert.strictEqual(max([2, 4, 6]), 6);
console.log('ok');
