#!/usr/bin/env node
// stats — tiny numeric helper used by the data team.
// usage: node stats.js <average|sum|max> [numbers...] | --file <path>
const fs = require('fs');

function readNumbers(args) {
  const fileIndex = args.indexOf('--file');
  if (fileIndex !== -1) {
    const path = args[fileIndex + 1];
    if (!path) throw new Error('--file needs a path');
    return fs.readFileSync(path, 'utf8')
      .split('\n')
      .map((line) => line.trim())
      .filter((line) => line.length > 0)
      .map(Number);
  }
  return args.map(Number);
}

function average(values) { return values.reduce((a, b) => a + b, 0) / values.length; }
function sum(values) { return values.reduce((a, b) => a + b, 0); }
function max(values) { return Math.max(...values); }

function main(argv) {
  const [command, ...rest] = argv;
  const ops = { average, sum, max };
  if (!ops[command]) {
    console.error('usage: node stats.js <average|sum|max> [numbers...] | --file <path>');
    process.exit(2);
  }
  const values = readNumbers(rest);
  if (!values.length) { console.error('no numbers given'); process.exit(2); }
  console.log(String(ops[command](values)));
}

if (require.main === module) main(process.argv.slice(2));
module.exports = { readNumbers, average, sum, max };
