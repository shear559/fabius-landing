#!/usr/bin/env python3
import json,os
T=os.path.dirname(os.path.abspath(__file__))
plan=json.load(open(f'{T}/runs/plan.json'))
briefs={k:open(f'{T}/briefs/{n}').read() for k,n in {'A':'A-book-and-notify.md','B':'B-pricing-page.md','C':'C-fix-and-prove.md','D':'D-scheduler-assistant.md'}.items()}
rubrics={k:json.load(open(f'{T}/rubrics/{k}.json')) for k in 'ABCD'}
runs=[]
for r in plan:
    d=f"{T}/runs/{r['id']}"
    if not os.path.exists(f'{d}/judge/answer.md'): continue
    files={'answer':f'{d}/judge/answer.md','trace':f'{d}/judge/trace.json'}
    if r['task']=='C': files['diff']=f'{d}/judge/diff.patch'
    if r['task']=='B':
        files['html']=f'{d}/judge/index.html'
        caps=f'{d}/captures'
        if os.path.isdir(caps):
            for f in ['desktop-initial.png','mobile-initial.png','desktop-focus.png','desktop-yearly.png']:
                if os.path.exists(f'{caps}/{f}'): files[f.replace('.png','').replace('-','_')]=f'{caps}/{f}'
            if os.path.exists(f'{caps}/capture.json'): files['capture_report']=f'{caps}/capture.json'
        for f in os.listdir(f'{d}/judge'):
            if f.endswith('.md') and f!='answer.md': files['sidecar_'+f]=f'{d}/judge/{f}'
    runs.append({'id':r['id'],'task':r['task'],'files':files})
args={'runs':runs,'briefs':briefs,'rubrics':rubrics}
json.dump(args,open(f'{T}/judge-args.json','w'),indent=1)
print(len(runs),'runs ready for judging')
