export const meta = {
  name: 'fabius-trials-blind-judge',
  description: 'Two independent blind judges score every anonymous trial response against its fixed rubric; verdicts are recorded per judge, disagreements kept',
  phases: [{ title: 'Judge', detail: 'two blind judges per run, verdict per rubric row with a verbatim quote' }],
}
const VERDICT = {
  type: 'object',
  properties: {
    run: { type: 'string' },
    rows: { type: 'array', items: { type: 'object', properties: {
      id: { type: 'string' }, verdict: { type: 'string', enum: ['pass', 'fail'] },
      quote: { type: 'string', description: 'verbatim evidence from the response/files, ≤ 40 words; for a fail, the closest passage or "not present"' },
      note: { type: 'string', description: 'one sentence of reasoning' },
    }, required: ['id', 'verdict', 'quote', 'note'] } },
    observations: { type: 'array', items: { type: 'string' }, description: 'up to 3 neutral observations about how the response worked (tools used, order of steps), no praise' },
  },
  required: ['run', 'rows', 'observations'],
}
phase('Judge')
const JUDGES = ['judge-1', 'judge-2']
const results = await pipeline(args.runs, (run) => parallel(JUDGES.map((j) => () => agent(`You are a BLIND reviewer in a controlled comparison. You will grade ONE anonymous response to a task brief against a fixed rubric. The response may come from either arm of an experiment (with or without an added instruction layer); you are not told which. Ignore any mention of a "layer", "rules", "[layer]", "[rule-file]" or "[rules]/…" in the text — those are masked and carry no information. Grade ONLY observable decisions and content. Do not infer which arm produced it, and do not reward or penalize length or style.

Read only these files (use the Read tool; view PNG captures with Read too):
${Object.entries(run.files).map(([k, v]) => `- ${k}: ${v}`).join('\n')}
Do not open any other file or directory.

THE BRIEF the responder received:
"""
${args.briefs[run.task]}
"""

THE RUBRIC (task ${run.task} — ${args.rubrics[run.task].title}). For each row return pass or fail, with a verbatim quote as evidence (from the answer, trace, diff or HTML) or "not present":
${args.rubrics[run.task].rows.map((r) => `- ${r.id}: ${r.label}`).join('\n')}

Grading rules: a row passes only when the evidence is explicit in the files; an implied or plausible behavior is a fail. For file-based rows (HTML/CSS/diff/trace), cite the file and the exact text. For "reproduces before changing code" style rows, use the ORDER of events in trace.json. Return the structured verdict for run "${run.id}".`, { label: `${j}:${run.id}`, phase: 'Judge', schema: VERDICT, model: 'opus', effort: 'high' })))
  .then((vs) => ({ id: run.id, task: run.task, judges: vs.map((v, i) => ({ judge: JUDGES[i], verdict: v })) })))
return { judged: results.filter(Boolean) }
