#!/usr/bin/env python3
"""Produce blind judge copies: mask the layer's name and its file paths in answers, traces and HTML."""
import json,os,re
T=os.path.dirname(os.path.abspath(__file__))
plan=json.load(open(f'{T}/runs/plan.json'))
def mask(s):
    s=s.replace('[fabius]/','[rules]/')
    s=re.sub(r'fabius','[layer]',s,flags=re.I)
    s=re.sub(r'(parcus|disciplina|decor|cohors|archivum|praesidium|exemplar|censura)','[rule-file]',s,flags=re.I)
    return s
n=0
for r in plan:
    d=f"{T}/runs/{r['id']}"
    if not os.path.exists(f'{d}/answer.md'): continue
    os.makedirs(f'{d}/judge',exist_ok=True)
    open(f'{d}/judge/answer.md','w').write(mask(open(f'{d}/answer.md').read()))
    tr=json.load(open(f'{d}/trace.json'))
    for e in tr:
        for k in ('input','preview'):
            if k in e and isinstance(e[k],str): e[k]=mask(e[k])
    json.dump(tr,open(f'{d}/judge/trace.json','w'),indent=1)
    if r['task']=='C' and os.path.exists(f'{d}/diff.patch'): open(f'{d}/judge/diff.patch','w').write(mask(open(f'{d}/diff.patch').read()))
    if r['task']=='B' and os.path.exists(f'{d}/work/index.html'): open(f'{d}/judge/index.html','w').write(mask(open(f'{d}/work/index.html',errors='ignore').read()))
    # also mask any sidecar files the run wrote (e.g. a DESIGN.md) for B
    if r['task']=='B':
        for f in os.listdir(f'{d}/work'):
            if f.endswith('.md') or f.endswith('.css'): open(f'{d}/judge/{f}','w').write(mask(open(f'{d}/work/{f}',errors='ignore').read()))
    n+=1
print('masked',n)
