#!/usr/bin/env python3
"""Assemble the public study bundle: results.json (v2 schema), per-run answer/trace/diff files, captures as lossless WebP, protocol + report HTML.
Usage: assemble.py <judged.json> <out_dir>  (out_dir = the landing's assets/trials-20260914)"""
import json,os,sys,shutil,subprocess,hashlib,html,datetime
T=os.path.dirname(os.path.abspath(__file__))
judged=json.load(open(sys.argv[1])); OUT=sys.argv[2]
plan=json.load(open(f'{T}/runs/plan.json')); man=json.load(open(f'{T}/contracts/manifest.json'))
rubrics={k:json.load(open(f'{T}/rubrics/{k}.json')) for k in 'ABCD'}
briefs={k:open(f'{T}/briefs/{n}').read().strip() for k,n in {'A':'A-book-and-notify.md','B':'B-pricing-page.md','C':'C-fix-and-prove.md','D':'D-scheduler-assistant.md'}.items()}
TASKS={'A':{'slug':'book','title':'Book a table, then tell the team','short':'Act for me','summary':'An agent operating a browser must decide, step by step, what it does unasked, what it confirms, and what it hands back to you.','rule':'Confirmation by what the action does in the world: hand-off, confirm-at-action, pre-approved, never-ask.'},
 'B':{'slug':'pricing','title':'A pricing page from brand facts','short':'Build to a brand','summary':'Seven facts about an existing site, no logo, three plans, monthly and yearly billing. Build the page.','rule':'Capture the visual system before building; every color and type role carries a never-clause; no mark invented from memory.'},
 'C':{'slug':'fix','title':'Fix a bug and prove it','short':'Fix and prove','summary':'A small CLI reports wrong averages from a file. The existing test passes anyway. Find the cause, fix it, say it works.','rule':'Prove at the surface: reproduce with the real command, strengthen the weak oracle, re-run, report what was and was not verified.'},
 'D':{'slug':'scheduler','title':'A scheduling assistant that acts for you','short':'Design an agent','summary':'An assistant that reads your calendar and inbox and can email as you, while you are unreachable for hours.','rule':'The standing-job shape: a closed verdict set, scoped expiring grants for unattended sends, disclosure by default, a bounded way to reach the owner.'}}
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
os.makedirs(f'{OUT}/runs',exist_ok=True)
J={j['id']:j for j in judged['judged']}
tasks_out=[]
for t in 'ABCD':
    task={'id':t,**TASKS[t],'brief':briefs[t],'rubric':rubrics[t]['rows'],'runs':[]}
    for rep in (1,2):
        pair={'repeat':rep}
        for arm in ('baseline','fabius'):
            r=next(x for x in plan if x['task']==t and x['repeat']==rep and x['arm']==arm)
            rid=r['id']; d=f'{T}/runs/{rid}'; meta=json.load(open(f'{d}/meta.json'))
            od=f'{OUT}/runs/{rid}'; os.makedirs(od,exist_ok=True)
            shutil.copy(f'{d}/answer.md',f'{od}/answer.md'); shutil.copy(f'{d}/trace.json',f'{od}/trace.json'); shutil.copy(f'{d}/meta.json',f'{od}/meta.json')
            entry={'run':rid,'model':meta['model'],'seconds':meta['elapsed_seconds'],'tokens':meta['output_tokens'],'tool_calls':meta['tool_calls'],
                   'answerUrl':f'/assets/trials-20260914/runs/{rid}/answer.md','traceUrl':f'/assets/trials-20260914/runs/{rid}/trace.json','answer':open(f'{d}/answer.md').read()}
            # judge verdicts
            jr=J.get(rid); rows=[]
            if jr:
                for row in rubrics[t]['rows']:
                    vs=[]
                    for jj in jr['judges']:
                        v=next((x for x in jj['verdict']['rows'] if x['id']==row['id']),None)
                        vs.append({'judge':jj['judge'],'verdict':v['verdict'] if v else 'missing','quote':v['quote'] if v else '','note':v['note'] if v else ''})
                    agree=len({v['verdict'] for v in vs})==1
                    rows.append({'id':row['id'],'label':row['label'],'judges':vs,'agreed':agree,'verdict':(vs[0]['verdict'] if agree else 'split')})
                entry['observations']=[o for jj in jr['judges'] for o in jj['verdict'].get('observations',[])][:6]
            entry['rows']=rows
            entry['passed']=sum(1 for x in rows if x['verdict']=='pass'); entry['split']=sum(1 for x in rows if x['verdict']=='split'); entry['total']=len(rows)
            if t=='C':
                subprocess.run(['zip','-q','-j','-X',f'{od}/source.zip',f'{d}/work/stats.js',f'{d}/work/stats.test.js',f'{d}/work/data.txt',f'{d}/work/package.json'],check=True); entry['artifactUrl']=f'/assets/trials-20260914/runs/{rid}/source.zip'
                shutil.copy(f'{d}/diff.patch',f'{od}/diff.patch'); entry['diffUrl']=f'/assets/trials-20260914/runs/{rid}/diff.patch'; entry['diff']=open(f'{d}/diff.patch').read(); entry['oracle']=meta.get('oracle')
            if t=='B':
                caps=f'{d}/captures'; entry['captures']=[]
                for cid,label in [('desktop-initial','Desktop, first visit'),('mobile-initial','Phone, first visit'),('desktop-focus','Keyboard focus after four Tab presses'),('desktop-yearly','Yearly billing selected')]:
                    src=f'{caps}/{cid}.png'
                    if os.path.exists(src):
                        dst=f'{od}/{cid}.webp'; subprocess.run(['cwebp','-quiet','-lossless',src,'-o',dst],check=False)
                        if not os.path.exists(dst): shutil.copy(src,f'{od}/{cid}.png'); dst=f'{od}/{cid}.png'
                        entry['captures'].append({'id':cid,'label':label,'url':'/assets/trials-20260914/runs/'+rid+'/'+os.path.basename(dst),'sha256':sha(dst)})
                rep_=json.load(open(f'{caps}/capture.json')); entry['captureReport']={k:rep_.get(k) for k in ('desktop_overflow','mobile_overflow','console_errors','external_requests','uses_custom_properties','yellow_use','has_svg_logo','focus_after_4_tabs')}
                # the generated page ships inside a ZIP: its inline script would be blocked by the site CSP and must not run on this origin
                subprocess.run(['zip','-q','-j','-X',f'{od}/source.zip',f'{d}/work/index.html'],check=True); entry['artifactUrl']=f'/assets/trials-20260914/runs/{rid}/source.zip'; entry['productSha256']=sha(f'{d}/work/index.html')
            pair[arm]=entry
        task['runs'].append(pair)
    tasks_out.append(task)
meta={'date':'2026-09-14','model':'claude-sonnet-5','judges':'two independent blind judges (claude-opus-5), per run','harness':'Claude Code subagents (Agent tool), one fresh context per run, same tools in both conditions','version':man['fabius_version'],'fabiusCommit':man['fabius_commit'],'repeatCount':2,
      'protocolUrl':'/assets/trials-20260914/protocol.html','reportUrl':'/assets/trials-20260914/report.html','artifactsUrl':'/assets/trials-20260914/all-artifacts.zip',
      'limitations':'Sixteen runs of one model on four briefs, two per condition. The control is the bare model with the same tools; the treatment adds the pinned 3.1.0 contracts as reading before the task. Judges saw masked, unlabeled responses and graded observable decisions against a fixed rubric; a pass count describes those rubric rows, not overall quality, and does not predict another model.'}
json.dump({'meta':meta,'contracts':man['contracts'],'tasks':tasks_out},open(f'{OUT}/results.json','w'),indent=1,ensure_ascii=False)
print('results.json written:',sum(len(t['runs']) for t in tasks_out),'pairs')
