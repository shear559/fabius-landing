// Capture each pricing-page run: desktop/mobile initial, keyboard-focus state, yearly state; block network; record console errors.
const { chromium, webkit } = require('playwright');
const fs = require('fs'); const path = require('path');
const T = '[study]';
const runs = JSON.parse(fs.readFileSync(`${T}/runs/plan.json`)).filter(r => r.task === 'B');
(async () => {
  const browser = await chromium.launch();
  for (const r of runs) {
    const file = `${T}/runs/${r.id}/work/index.html`;
    const out = `${T}/runs/${r.id}/captures`; fs.mkdirSync(out, { recursive: true });
    const report = { id: r.id, exists: fs.existsSync(file), console_errors: [], external_requests: [], states: {} };
    if (!report.exists) { fs.writeFileSync(`${out}/capture.json`, JSON.stringify(report, null, 1)); console.log(r.id, 'no index.html'); continue; }
    for (const [w, h, tag] of [[1440, 960, 'desktop'], [390, 844, 'mobile']]) {
      const ctx = await browser.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
      await ctx.route('**/*', route => { const u = route.request().url(); if (u.startsWith('file://')) return route.continue(); report.external_requests.push(u); return route.abort(); });
      const page = await ctx.newPage();
      page.on('console', m => { if (m.type() === 'error') report.console_errors.push(`${tag}: ${m.text()}`); });
      page.on('pageerror', e => report.console_errors.push(`${tag}: ${e.message}`));
      await page.goto('file://' + file, { waitUntil: 'load' }); await page.waitForTimeout(600);
      await page.screenshot({ path: `${out}/${tag}-initial.png` }); report.states[`${tag}-initial`] = true;
      if (tag === 'desktop') {
        // keyboard: tab through to the first control that changes billing, screenshot focus ring state
        const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
        report.desktop_overflow = overflow;
        for (let i = 0; i < 4; i++) await page.keyboard.press('Tab');
        await page.waitForTimeout(150);
        await page.screenshot({ path: `${out}/desktop-focus.png` }); report.states['desktop-focus'] = true;
        const focusInfo = await page.evaluate(() => { const a = document.activeElement; if (!a) return null; const cs = getComputedStyle(a); return { tag: a.tagName, text: (a.textContent || '').trim().slice(0, 40), outline: cs.outlineStyle + ' ' + cs.outlineWidth + ' ' + cs.outlineColor, boxShadow: cs.boxShadow.slice(0, 80) }; });
        report.focus_after_4_tabs = focusInfo;
        // yearly: find a control whose text mentions year/annual
        const yearly = page.locator('button, input[type=checkbox], input[type=radio], [role=switch], [role=tab], label').filter({ hasText: /year|annual/i }).first();
        if (await yearly.count()) { try { await yearly.click({ timeout: 2000 }); await page.waitForTimeout(300); await page.screenshot({ path: `${out}/desktop-yearly.png` }); report.states['desktop-yearly'] = true; report.yearly_text = await page.evaluate(() => document.body.innerText.match(/\$\s?\d+(\.\d+)?[^\n]{0,20}/g)?.slice(0, 8)); } catch (e) { report.yearly_error = String(e).slice(0, 120); } }
        report.uses_custom_properties = await page.evaluate(() => { const css = [...document.styleSheets].flatMap(s => { try { return [...s.cssRules].map(r => r.cssText); } catch { return []; } }).join('\n'); return { vars: (css.match(/--[a-z0-9-]+\s*:/gi) || []).length, focusVisible: /focus-visible/.test(css), inlineHex: (document.documentElement.outerHTML.match(/style="[^"]*#[0-9a-f]{3,6}/gi) || []).length }; });
        report.yellow_use = await page.evaluate(() => { const hits = []; for (const el of document.querySelectorAll('*')) { const cs = getComputedStyle(el); const bg = cs.backgroundColor; if (bg === 'rgb(255, 233, 92)') hits.push({ tag: el.tagName, cls: el.className && String(el.className).slice(0, 40), text: (el.textContent || '').trim().slice(0, 30), isButton: el.matches('button, a.btn, a[role=button], input[type=submit]') }); } return hits.slice(0, 20); });
        report.has_svg_logo = await page.evaluate(() => !!document.querySelector('header svg, nav svg, .logo svg, [class*=logo] svg, [class*=brand] svg'));
        report.title = await page.title();
      } else {
        report.mobile_overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
      }
      await ctx.close();
    }
    fs.writeFileSync(`${out}/capture.json`, JSON.stringify(report, null, 1));
    console.log(r.id, 'captured', Object.keys(report.states).length, 'states; console errors', report.console_errors.length, '; external', report.external_requests.length, '; yellow hits', (report.yellow_use||[]).length, '; svg logo', report.has_svg_logo);
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
