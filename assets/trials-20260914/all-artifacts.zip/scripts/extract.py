#!/usr/bin/env python3
"""Extract answer, tool trace, usage and artifacts for each trial run from the subagent JSONL transcripts."""
import json, os, sys, subprocess, datetime, hashlib
T=os.path.dirname(os.path.abspath(__file__)); TASKS='[session]/tasks'
plan=json.load(open(f'{T}/runs/plan.json')); agents=json.load(open(f'{T}/runs/agents.json'))
def sha(b): return hashlib.sha256(b).hexdigest()
def summarize_input(name, inp):
    if not isinstance(inp, dict): return str(inp)[:300]
    if name=='Bash': return inp.get('command','')[:600]
    if name in ('Read','Write','Edit','Glob','Grep'): return json.dumps({k:(v[:300] if isinstance(v,str) else v) for k,v in inp.items() if k in ('file_path','pattern','path','old_string','new_string','content')})[:800]
    return json.dumps(inp)[:400]
done=0
for r in plan:
    rid=r['id']; out=f"{TASKS}/{agents[rid]}.output"
    if not os.path.exists(out): print(rid,'no output yet'); continue
    events=[]; final=None; first_ts=None; last_ts=None; out_tokens=0; model=None; tool_count=0; complete=False
    for line in open(out,encoding='utf-8',errors='ignore'):
        try: j=json.loads(line)
        except Exception: continue
        ts=j.get('timestamp');
        if ts: first_ts=first_ts or ts; last_ts=ts
        m=j.get('message')
        if not isinstance(m,dict): continue
        if j.get('type')=='assistant':
            model=m.get('model') or model
            u=m.get('usage') or {}
            out_tokens+=int(u.get('output_tokens') or 0)
            c=m.get('content'); has_tool=False
            if isinstance(c,list):
                for blk in c:
                    if blk.get('type')=='tool_use':
                        has_tool=True; tool_count+=1
                        events.append({'kind':'tool_use','name':blk.get('name'),'input':summarize_input(blk.get('name'),blk.get('input'))})
                    elif blk.get('type')=='text' and blk.get('text','').strip():
                        final=blk['text']; events.append({'kind':'text','chars':len(blk['text'])})
            if not has_tool and final: complete=True
        elif j.get('type')=='user':
            c=m.get('content')
            if isinstance(c,list):
                for blk in c:
                    if isinstance(blk,dict) and blk.get('type')=='tool_result':
                        content=blk.get('content'); text=content if isinstance(content,str) else ' '.join(x.get('text','') for x in content if isinstance(x,dict)) if isinstance(content,list) else str(content)
                        events.append({'kind':'tool_result','chars':len(text or ''),'preview':(text or '')[:400]})
    if not complete: print(rid,'not complete yet'); continue
    d=f"{T}/runs/{rid}"; os.makedirs(d,exist_ok=True)
    open(f'{d}/answer.md','w').write(final)
    json.dump(events,open(f'{d}/trace.json','w'),indent=1)
    dur=None
    if first_ts and last_ts:
        f=datetime.datetime.fromisoformat(first_ts.replace('Z','+00:00')); l=datetime.datetime.fromisoformat(last_ts.replace('Z','+00:00')); dur=round((l-f).total_seconds(),1)
    meta={'id':rid,'task':r['task'],'repeat':r['repeat'],'arm':r['arm'],'model':model,'elapsed_seconds':dur,'output_tokens':out_tokens,'tool_calls':tool_count,'answer_sha256':sha(final.encode()),'started':first_ts,'ended':last_ts}
    # artifacts
    if r['task']=='C':
        fx=f'{T}/fixtures/stats-cli'
        p=subprocess.run(['diff','-ru',fx,f'{d}/work'],capture_output=True,text=True); open(f'{d}/diff.patch','w').write(p.stdout)
        meta['diff_lines']=len(p.stdout.splitlines())
        # re-run the surface ourselves (oracle): average --file must print 4, args path 4, test must pass
        chk={}
        for label,cmd in [('cli_file',['node','stats.js','average','--file','data.txt']),('cli_args',['node','stats.js','average','2','4','6']),('test',['node','stats.test.js'])]:
            q=subprocess.run(cmd,cwd=f'{d}/work',capture_output=True,text=True,timeout=30); chk[label]={'stdout':q.stdout.strip()[:200],'code':q.returncode}
        meta['oracle']=chk
    if r['task']=='B':
        ix=f'{d}/work/index.html'; meta['index_html']=os.path.exists(ix); meta['index_bytes']=os.path.getsize(ix) if os.path.exists(ix) else 0
        meta['work_files']=sorted(os.listdir(f'{d}/work'))
    json.dump(meta,open(f'{d}/meta.json','w'),indent=1); done+=1; print(rid,r['task'],r['arm'],'ok',dur,'s',out_tokens,'tok',tool_count,'tools', meta.get('oracle',{}).get('cli_file',{}).get('stdout',''))
print('extracted',done)
