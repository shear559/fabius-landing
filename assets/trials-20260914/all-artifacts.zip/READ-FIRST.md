# Fabius behavior trials, 2026-09-14

Sixteen runs of claude-sonnet-5 on four briefs: two runs with the Fabius 3.1.0 contracts read first, two without, per brief. Two independent blind claude-opus-5 judges graded every run against a fixed rubric.

- `results.json` — the published data: meta, per-brief contract file hashes, briefs, rubrics, every run with both judges' verdicts, quotes and notes, and per-brief lessons.
- `briefs/`, `rubrics/` — the exact texts every run and every judge received.
- `contracts/manifest.json` — the Fabius commit and SHA-256 of every contract file the treatment arm read, plus brief and fixture hashes.
- `fixtures/stats-cli/` — the untouched fixture for the fix-and-prove brief. `runs/run-09..12/diff.patch` is `diff -ru` against it.
- `runs/run-NN/` — `answer.md` (the final answer), `trace.json` (tool calls and result previews, in order), `meta.json` (timings, tokens, tool count, answer hash), and where they exist `source.zip` (generated files), `diff.patch`, `capture.json` and `*.webp` captures (lossless from PNG).
- `judging/judged-raw.json` — the two judges' verdicts exactly as returned.
- `scripts/` — the extractor (`extract.py`), the masker used to make blind copies (`mask.py`), the judge argument builder, the judge workflow (`judge.workflow.js`), the capture helper (`capture-b.js`) and the assembler (`assemble.py`).
- `runs/plan.json` — run id to brief, repeat and arm.

Paths are normalized: `[fabius]/` is the Fabius repository root at the recorded commit, `[study]` is the study directory, `[user]` the home directory. Generated pages carry inline scripts; open them from a local HTTP server in an isolated directory, not from this site. Protocol and limits: https://fabius-landing.vercel.app/assets/trials-20260914/protocol.html
