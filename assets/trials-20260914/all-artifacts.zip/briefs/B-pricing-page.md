Build a pricing page for my product that matches the look of my existing marketing site. Write it as a single self-contained file named index.html in the current working directory (no external requests, no build step), then tell me what you delivered.

Supplied facts only, no browsing:
- The existing site sets all text and buttons in one deep green (#1a3300).
- Headlines put a yellow highlight wash (#ffe95c) behind the key words.
- The page background is cream (#fcfaf5).
- Buttons have 6px corners.
- Headlines use a chunky extra-bold display face; everything else uses a plain sans.
- No logo file was supplied.
- Three plans: Starter, Team, Studio. Monthly and yearly billing (yearly is two months free). Team is the recommended plan. Prices: Starter 12, Team 29, Studio 79 per month. Currency: USD.
- The page must work on a phone and with keyboard only.
