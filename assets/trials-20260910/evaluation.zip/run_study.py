"""Run the predeclared matched study; never repair or select generated artifacts."""
from pathlib import Path
import concurrent.futures, datetime, hashlib, http.client, io, json, os, random
import shutil, signal, socket, subprocess, tarfile, tempfile, time

ROOT = Path(__file__).resolve().parent
CORE = Path('[user]/Desktop/Workspace/03-Personal/fabius')
CLI = '[user]/.codex/plugins/.plugin-appserver/codex'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
CAP = 720
CONFIG = json.loads((ROOT/'isolation/isolation-preflight.json').read_text())
PROTOCOL = json.loads((ROOT/'protocol/design.json').read_text())
BASE = Path(tempfile.mkdtemp(prefix='paired-study-')).resolve()
RUNS = ROOT/'runs'; RUNS.mkdir(exist_ok=True)
SESSION = ROOT/'session.json'
SESSION.write_text(json.dumps({'workspace':str(BASE),'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')

def digest(data): return hashlib.sha256(data).hexdigest()
def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0)); return s.getsockname()[1]
def stop(p):
    if p is None: return
    try: os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError: return
    try: p.wait(timeout=3)
    except subprocess.TimeoutExpired:
        try: os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError: pass
        p.wait(timeout=3)
def wait_http(port,path='/'):
    until=time.monotonic()+20
    while time.monotonic()<until:
        try:
            c=http.client.HTTPConnection('127.0.0.1',port,timeout=1);c.request('GET',path)
            r=c.getresponse();body=r.read();c.close()
            if r.status==200:return body
        except (OSError,http.client.HTTPException):pass
        time.sleep(.1)
    raise RuntimeError('Local test resource did not start')

snapshot=subprocess.check_output(['git','archive',PROTOCOL['source_commit']],cwd=CORE)
for name,entry in PROTOCOL['contracts'].items():
    assert digest((CORE/entry['path']).read_bytes())==entry['sha256']
for name,h in PROTOCOL['task_hashes'].items():
    assert digest((ROOT/'protocol'/name).read_bytes())==h

ids=list(range(1,13));random.Random(20260910).shuffle(ids)
plan=[]
for repeat in (1,2):
    for task in ('math','landing','app'):
        for arm in (('baseline','fabius') if repeat==1 else ('fabius','baseline')):
            plan.append({'id':'run-%02d'%ids.pop(),'task':task,'repeat':repeat,'arm':arm})
(ROOT/'protocol/run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')

def run(item):
    output=RUNS/item['id'];output.mkdir()
    work=BASE/item['id'];work.mkdir()
    names=['fabius','fabius-parcus','fabius-disciplina']+(['fabius-decor'] if item['task']!='math' else [])
    if item['arm']=='fabius':
        dest=work/'.ruleset';dest.mkdir()
        with tarfile.open(fileobj=io.BytesIO(snapshot)) as archive:
            for m in archive.getmembers():
                if m.isfile() and '..' not in Path(m.name).parts and not m.name.startswith('/'):
                    p=dest/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(archive.extractfile(m).read())
    port=free_port();cdp=free_port()
    common=('This is an independent artifact-generation trial. Complete the user brief autonomously. '
            'You have a hard 720-second wall-clock limit starting with this model invocation. '
            'All user requirements matter; implement and verify the complete artifact within that limit. '
            'Use only this task directory, existing system tools and the explicitly provided browser resource. '
            'There is no project record to find or update. Do not read personal files, parent directories, '
            'other trials, hidden tests, external repositories or network services. Do not delegate, install '
            'dependencies, publish, call model APIs, change account settings or ask for more input. '
            'Node 26 and Python 3.9 standard libraries are installed. UI source should use relative assets. '
            'Do not edit any .ruleset files if present. Do not leave background servers running. '
            'The last answer must accurately name produced files, executed checks and remaining limits. '
            'For browser verification, a static HTTP server already serves this task directory at '
            f'http://127.0.0.1:{port}/ and an isolated Chrome instance is available at '
            f'http://127.0.0.1:{cdp}. Use Node ESM: import pkg from '
            "'[user]/node_modules/playwright/index.js'; const { chromium }=pkg; "
            f"const browser=await chromium.connectOverCDP('http://127.0.0.1:{cdp}'); "
            'create your own browser context/page for checks and close that context when done. '
            'You may take screenshots and inspect them with the image tool. Both arms have the same browser/tool setup. '
            'Any .ruleset references are supplementary read-only task resources; all outputs belong outside that folder.')
    developer=common
    if item['arm']=='fabius':
        developer+='\n\nApply the following pinned Fabius 3.0.1 operating contracts to this task. Their exact bodies follow. Linked repository paths resolve inside .ruleset/. The task/environment instructions above control scope and available tools.\n'
        for name in names:
            developer+='\n<contract source=".ruleset/skills/'+name+'/SKILL.md">\n'+(CORE/'skills'/name/'SKILL.md').read_text()+'\n</contract>\n'
    brief=(ROOT/'protocol'/(item['task']+'.md')).read_text()
    (output/'brief.md').write_text(brief);(output/'developer.txt').write_text(developer)
    profile=CONFIG['sandbox_profile']
    profile+=' (deny file-write* (subpath '+json.dumps(str(work/'.ruleset'))+'))'
    profile+=' (deny file-read-data (require-all (subpath '+json.dumps(str(BASE))+') (require-not (subpath '+json.dumps(str(work))+'))))'
    args=CONFIG['common_argv'][:-3]
    args[2]=profile
    # Seatbelt cannot be initialized again inside a Seatbelt-sandboxed process.
    # Keep the external policy; do not ask the native tool runner to nest it.
    args[args.index('-s')+1]='danger-full-access'
    args[args.index('-C')+1]=str(work)
    args[args.index('sandbox_workspace_write.network_access=false')]='sandbox_workspace_write.network_access=true'
    key=next(i for i,v in enumerate(args) if v.startswith('developer_instructions='))
    args[key]='developer_instructions='+json.dumps(developer)
    preflight=subprocess.run(args+['debug','prompt-input',brief],cwd=work,capture_output=True,text=True,timeout=30)
    (output/'prompt-input.json').write_text(preflight.stdout);(output/'preflight-stderr.txt').write_text(preflight.stderr)
    assert preflight.returncode==0,preflight.stderr
    prompt=json.loads(preflight.stdout);payload=json.dumps(prompt)
    assert 'AGENTS.md instructions' not in payload and 'CANONICAL SOURCE' not in payload and 'Available skills' not in payload
    if item['arm']=='baseline':assert 'fabius' not in payload.lower()
    else:
        joined='\n'.join(c.get('text','') for m in prompt for c in m.get('content',[]))
        assert all((CORE/'skills'/n/'SKILL.md').read_text() in joined for n in names)
    preflight_hash=digest(preflight.stdout.encode())
    # Debug loads the known user MCP entries, which need explicit disabling.
    # Exec ignores user config entirely; a bare enabled=false entry would create
    # an invalid partial MCP transport in that otherwise empty configuration.
    exec_args=[]; index=0
    while index<len(args):
        if args[index]=='-c' and args[index+1].startswith('mcp_servers.'):
            index+=2
        else:
            exec_args.append(args[index]); index+=1
    command=exec_args+['exec','--ignore-user-config','--ignore-rules','--ephemeral','--strict-config','--skip-git-repo-check','--json','--color','never','--output-last-message',str(work/'final.txt'),'-']
    receipt={**item,'model':'gpt-6-astra','effort':'high','service_tier':'priority','limit_seconds':CAP,'task_sha256':digest(brief.encode()),'developer_sha256':digest(developer.encode()),'prompt_input_sha256':preflight_hash,'contract_names':names if item['arm']=='fabius' else [],'workspace':str(work),'command':command,'status':'starting','tool_network_policy':'Local HTTP/CDP available; external network use prohibited in shared instructions, web/apps/MCP disabled. Provider account access unchanged.'}
    (output/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
    http=chrome=proc=None
    try:
        with (output/'http.log').open('wb') as hlog,(output/'chrome.log').open('wb') as clog:
            # The browser/server inherit the same read-denial, so file:// and
            # HTTP symlinks cannot expose the hidden oracle or personal records.
            http=subprocess.Popen(['/usr/bin/sandbox-exec','-p',profile,'python3','-m','http.server',str(port),'--bind','127.0.0.1','--directory',str(work)],stdout=hlog,stderr=hlog,start_new_session=True)
            chrome=subprocess.Popen(['/usr/bin/sandbox-exec','-p',profile,CHROME,'--headless=new','--no-sandbox','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-extensions','--disable-gpu','--remote-debugging-port='+str(cdp),'--user-data-dir='+str(work/'.browser'),'about:blank'],stdout=clog,stderr=clog,start_new_session=True)
            wait_http(port);wait_http(cdp,'/json/version')
            started=time.monotonic();receipt['started_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['status']='running'
            (output/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
            print(json.dumps({'event':'started','id':item['id'],'task':item['task'],'repeat':item['repeat']}),flush=True)
            with (output/'events.jsonl').open('wb') as events,(output/'stderr.log').open('wb') as err:
                proc=subprocess.Popen(command,cwd=work,stdin=subprocess.PIPE,stdout=events,stderr=err,start_new_session=True)
                try:proc.communicate(brief.encode(),timeout=CAP);receipt['status']='completed' if proc.returncode==0 else 'process_error'
                except subprocess.TimeoutExpired:receipt['status']='timeout';stop(proc)
            receipt['elapsed_seconds']=round(time.monotonic()-started,3);receipt['exit_code']=proc.returncode
    finally:
        stop(proc);stop(http);stop(chrome)
    receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    artifact=output/'artifact';artifact.mkdir()
    for p in sorted(work.rglob('*')):
        rel=p.relative_to(work)
        if '.ruleset' in rel.parts or '.browser' in rel.parts or '__pycache__' in rel.parts:continue
        if p.is_file() and not p.is_symlink():
            q=artifact/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
    receipt['artifact_sha256']={str(p.relative_to(artifact)):digest(p.read_bytes()) for p in sorted(artifact.rglob('*')) if p.is_file()}
    events=[]
    for line in (output/'events.jsonl').read_text(errors='replace').splitlines():
        try:events.append(json.loads(line))
        except json.JSONDecodeError:pass
    receipt['usage']=[e.get('usage') for e in events if e.get('type')=='turn.completed']
    receipt['errors']=[e for e in events if e.get('type') in ('error','turn.failed')]
    receipt['thread_ids']=[e.get('thread_id') for e in events if e.get('type')=='thread.started']
    receipt['events_sha256']=digest((output/'events.jsonl').read_bytes())
    (output/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'event':'finished','id':item['id'],'status':receipt['status'],'seconds':receipt['elapsed_seconds'],'files':len(receipt['artifact_sha256']),'errors':receipt['errors']}),flush=True)
    return receipt

if __name__=='__main__':
    for i in range(0,len(plan),2):
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(run,plan[i:i+2]))
        if any(r['status']=='process_error' and not r['artifact_sha256'] for r in results):
            raise SystemExit('Infrastructure/configuration failure: pause study and investigate, preserving attempts.')
    (ROOT/'generation-complete.json').write_text(json.dumps({'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[r['id'] for r in plan]},indent=2)+'\n')
