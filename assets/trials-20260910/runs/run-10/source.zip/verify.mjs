import pkg from '[user]/node_modules/playwright/index.js';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:62409');
const base = 'http://127.0.0.1:62408/';
const key = 'fieldnote-board:v1';
const results = [];
const contexts = [];
const check = (name) => { results.push(name); console.log('PASS', name); };
const make = async (options = {}) => { const context = await browser.newContext({ acceptDownloads: true, ...options }); contexts.push(context); return { context, page: await context.newPage() }; };
const data = page => page.evaluate(key => JSON.parse(localStorage.getItem(key)), key);
const raw = page => page.evaluate(key => localStorage.getItem(key), key);
const upload = (page, value, name = 'board.json') => page.getByTestId('import-file').setInputFiles({ name, mimeType: 'application/json', buffer: Buffer.from(typeof value === 'string' ? value : JSON.stringify(value)) });
try {
  const { context, page } = await make({ viewport: { width: 1440, height: 1080 } });
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  const requests = []; page.on('request', r => requests.push(r.url()));
  await page.goto(base);
  assert.equal(await page.getByTestId('task-card').count(), 8);
  const initial = await data(page);
  assert.equal(initial.schemaVersion, 1); assert.equal(new Set(initial.tasks.map(t => t.status)).size, 3);
  check('First visit seeds eight valid tasks across two projects and all statuses');
  await page.screenshot({ path: 'desktop.png', fullPage: true });
  await page.getByTestId('create-task').click();
  await page.getByTestId('save-task').click();
  assert.match(await page.locator('#error-title').innerText(), /120/);
  await page.locator('[name="title"]').fill('x'.repeat(121));
  await page.locator('[name="project"]').fill('Test project');
  await page.locator('[name="dueDate"]').fill('2026-02-30');
  await page.getByTestId('save-task').click();
  assert.equal(await page.locator('[name="title"]').getAttribute('aria-invalid'), 'true');
  assert.match(await page.locator('#error-dueDate').innerText(), /real calendar/);
  await page.locator('[name="title"]').fill('  Check the launch details  ');
  await page.locator('[name="dueDate"]').fill('2028-02-29');
  await page.locator('[name="tags"]').fill(' Design,design, WEB , , web, Launch ');
  await page.getByTestId('save-task').click();
  const afterCreate = await data(page); const created = afterCreate.tasks.at(-1);
  assert.equal(created.title, 'Check the launch details'); assert.deepEqual(created.tags, ['Design', 'WEB', 'Launch']);
  assert.deepEqual(afterCreate.tasks.slice(0, -1), initial.tasks);
  check('Create validates blank/overlong titles and impossible dates, trims fields, deduplicates tags, and preserves other records');
  const card = page.locator('[data-task-id="' + created.id + '"]');
  await card.locator('[data-action="edit"]').click();
  assert.equal(await page.locator('[name="tags"]').inputValue(), 'Design, WEB, Launch');
  await page.locator('[name="title"]').fill('Final launch checklist');
  await page.getByTestId('save-task').click();
  await card.locator('[data-action="status"]').selectOption('doing');
  let current = await data(page); assert.equal(current.tasks.at(-1).status, 'doing');
  assert.equal(current.tasks.at(-1).title, 'Final launch checklist');
  const exact = current.tasks.at(-1);
  await card.locator('[data-action="delete"]').click(); assert.equal((await data(page)).tasks.length, 8);
  await page.getByTestId('undo-delete').click(); assert.deepEqual((await data(page)).tasks.at(-1), exact);
  await page.reload(); assert.deepEqual((await data(page)).tasks.at(-1), exact);
  check('Edit and native status changes persist; delete/undo restores the exact task across reload');
  await page.getByTestId('search').fill('LAUNCH');
  await page.getByTestId('filter-project').selectOption('Test project');
  await page.getByTestId('filter-status').selectOption('doing');
  await page.getByTestId('filter-priority').selectOption('medium');
  assert.equal(await page.getByTestId('task-card').count(), 1);
  assert.match(await page.locator('#result-count').innerText(), /1 of 9/);
  await page.getByTestId('filter-priority').selectOption('high');
  assert.equal(await page.getByTestId('task-card').count(), 0); assert.equal(await page.locator('#empty-state').isVisible(), true);
  const downloading = page.waitForEvent('download'); await page.getByTestId('export').click(); const download = await downloading;
  const exported = JSON.parse(await fs.readFile(await download.path(), 'utf8'));
  assert.deepEqual(exported, await data(page)); check('Combined search/filters, matching count, no-results state, and full-board export');
  await page.locator('#clear-filters').click();
  await page.getByTestId('create-task').click(); await page.keyboard.press('Escape');
  assert.equal(await page.getByTestId('create-task').evaluate(n => n === document.activeElement), true);
  check('Escape closes the modal and restores keyboard focus');
  const beforeImports = await raw(page);
  const valid = { schemaVersion: 1, tasks: [{ id: 'imported-1', title: '<img src=x onerror=alert(1)>', project: 'Imported project', status: 'todo', priority: 'low', dueDate: '2024-02-29', tags: ['<script>test</script>'] }] };
  const invalids = [
    ['malformed JSON', '{broken'],
    ['unsupported schema', { ...valid, schemaVersion: 2 }],
    ['duplicate IDs', { ...valid, tasks: [valid.tasks[0], valid.tasks[0]] }],
    ['unsupported status', { ...valid, tasks: [{ ...valid.tasks[0], status: 'blocked' }] }],
    ['unsupported priority', { ...valid, tasks: [{ ...valid.tasks[0], priority: 'urgent' }] }],
    ['invalid calendar date', { ...valid, tasks: [{ ...valid.tasks[0], dueDate: '2025-02-29' }] }],
    ['one invalid record', { ...valid, tasks: [valid.tasks[0], { ...valid.tasks[0], id: 'bad', title: '' }] }],
    ['oversized file', ' '.repeat(1048577)]
  ];
  for (const [label, value] of invalids) {
    await upload(page, value); await page.getByText('Import could not be completed', { exact: true }).waitFor();
    assert.equal(await raw(page), beforeImports, label);
    await page.getByRole('button', { name: 'Dismiss', exact: true }).click();
  }
  check('Malformed, oversized, invalid schema/enums/dates, duplicates, and mixed-invalid imports are rejected atomically');
  page.once('dialog', d => d.dismiss()); await upload(page, valid); await page.waitForTimeout(150);
  assert.equal(await raw(page), beforeImports);
  page.once('dialog', d => d.accept()); await upload(page, valid);
  await page.waitForFunction(() => JSON.parse(localStorage.getItem('fieldnote-board:v1')).tasks.length === 1);
  await page.reload(); assert.deepEqual(await data(page), valid);
  assert.equal(await page.getByTestId('task-card').locator('img,script').count(), 0);
  assert.match(await page.getByTestId('task-card').innerText(), /<img src=x onerror=alert\(1\)>/);
  check('Import cancellation leaves the board untouched; confirmed import survives reload and renders HTML-like text safely');
  const other = await context.newPage(); await other.goto(base);
  await page.getByTestId('create-task').click();
  await page.locator('[name="title"]').fill('Stale form'); await page.locator('[name="project"]').fill('Studio');
  await other.getByTestId('create-task').click(); await other.locator('[name="title"]').fill('From another tab'); await other.locator('[name="project"]').fill('Studio'); await other.getByTestId('save-task').click();
  await page.getByText('This board changed in another tab.', { exact: true }).waitFor();
  assert.equal(await page.getByTestId('save-task').isDisabled(), true);
  await page.keyboard.press('Escape');
  assert.equal(await page.getByTestId('create-task').isDisabled(), true);
  await page.getByRole('button', { name: 'Reload board', exact: true }).click();
  assert.equal(await page.getByTestId('task-card').count(), 2);
  check('Real second-tab writes show a conflict, block stale editing, and allow explicit reload');
  assert.deepEqual(errors, []); assert.equal(requests.every(url => url.startsWith(base) || url.startsWith('data:') || url.startsWith('blob:')), true);
  check('No browser JavaScript errors or external resource requests');
  const mobile = await make({ viewport: { width: 360, height: 800 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, reducedMotion: 'reduce' });
  await mobile.page.goto(base); await mobile.page.screenshot({ path: 'mobile.png', fullPage: true });
  assert.equal(await mobile.page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await mobile.page.getByTestId('create-task').click();
  await mobile.page.screenshot({ path: 'mobile-form.png', fullPage: false });
  assert.equal(await mobile.page.locator('dialog').evaluate(n => n.getBoundingClientRect().right <= innerWidth && n.getBoundingClientRect().left >= 0), true);
  check('360px board and form fit without horizontal overflow; reduced-motion mode exercised');
  await mobile.page.keyboard.press('Escape');
  const corrupt = await make(); await corrupt.page.goto(base);
  const original = '  { broken original data\n"keep":"é"';
  await corrupt.page.evaluate(([k, v]) => localStorage.setItem(k, v), [key, original]); await corrupt.page.reload();
  await corrupt.page.getByText('Your saved board needs recovery.', { exact: true }).waitFor();
  assert.equal(await raw(corrupt.page), original); assert.equal(await corrupt.page.getByTestId('create-task').isDisabled(), true);
  const origDownloading = corrupt.page.waitForEvent('download'); await corrupt.page.getByRole('button', { name: 'Download original data' }).click();
  assert.equal(await fs.readFile(await (await origDownloading).path(), 'utf8'), original);
  corrupt.page.once('dialog', d => d.dismiss()); await corrupt.page.getByRole('button', { name: 'Reset board', exact: true }).click(); assert.equal(await raw(corrupt.page), original);
  corrupt.page.once('dialog', d => d.accept()); await corrupt.page.getByRole('button', { name: 'Reset board', exact: true }).click(); assert.equal((await data(corrupt.page)).tasks.length, 8);
  check('Corrupt startup preserves original bytes, downloads them exactly, and resets only on confirmation');
  const failure = await make(); await failure.page.goto(base);
  const beforeFailure = await raw(failure.page);
  await failure.page.evaluate(() => { window.originalSetItem = Storage.prototype.setItem; Storage.prototype.setItem = function() { throw new DOMException('Quota exceeded', 'QuotaExceededError'); }; });
  await failure.page.getByTestId('create-task').click(); await failure.page.locator('[name="title"]').fill('Kept in memory'); await failure.page.locator('[name="project"]').fill('Recovery'); await failure.page.getByTestId('save-task').click();
  assert.equal(await failure.page.getByTestId('task-card').count(), 9); assert.equal(await raw(failure.page), beforeFailure);
  await failure.page.getByText('Changes are not saved', { exact: true }).waitFor();
  assert.match(await failure.page.locator('#save-state').innerText(), /Not saved/);
  await failure.page.evaluate(() => { Storage.prototype.setItem = window.originalSetItem; }); await failure.page.getByRole('button', { name: 'Retry saving' }).click();
  assert.equal((await data(failure.page)).tasks.length, 9);
  check('Write failure preserves the working board in memory, labels it unsaved, and retries successfully');
  const empty = await make(); await empty.page.goto(base); await empty.page.evaluate(k => localStorage.setItem(k, JSON.stringify({ schemaVersion: 1, tasks: [] })), key); await empty.page.reload();
  assert.equal(await empty.page.getByTestId('task-card').count(), 0); assert.equal(await empty.page.getByText('Make room for your first idea.').isVisible(), true);
  check('A saved empty board remains empty and shows an actionable state');
  const noJS = await make({ javaScriptEnabled: false }); await noJS.page.goto(base); assert.equal(await noJS.page.locator('noscript').isVisible(), true);
  check('JavaScript-disabled browser displays a useful message');
  await fs.writeFile('verification-results.json', JSON.stringify({ passed: results.length, checks: results }, null, 2) + '\n');
} finally {
  for (const context of contexts) await context.close();
  await browser.close();
}
