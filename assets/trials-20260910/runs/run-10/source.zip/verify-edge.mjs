import pkg from '[user]/node_modules/playwright/index.js';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:62409');
const base = 'http://127.0.0.1:62408/';
const KEY = 'fieldnote-board:v1';
const contexts = [];
const checks = [];
const pass = label => { checks.push(label); console.log('PASS', label); };
const make = async (init) => { const c = await browser.newContext(); contexts.push(c); if (init) await c.addInitScript(init); const p = await c.newPage(); await p.goto(base); return p; };
const board = p => p.evaluate(k => JSON.parse(localStorage.getItem(k)), KEY);
const put = (p, obj) => p.getByTestId('import-file').setInputFiles({ name: 'edge.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(obj)) });
try {
  const p = await make(); const initial = await board(p);
  const task = { id: 'edge-id-\"<>', title: 'Edge task', project: 'all', status: 'doing', priority: 'high', dueDate: '2000-02-29', tags: ['one,two', 'Case', 'case'] };
  const invalids = [
    { ...task, status: ['todo'] }, { ...task, id: '' }, { ...task, id: 'x'.repeat(81) }, { ...task, title: ' x ' },
    { ...task, project: 'x'.repeat(81) }, { ...task, tags: Array(9).fill('tag') }, { ...task, tags: ['x'.repeat(25)] },
    { ...task, tags: [' '] }, { ...task, dueDate: '1900-02-29' }, { ...task, dueDate: '0000-01-01' },
    { ...task, dueDate: '2026-04-31' }, { ...task, extra: true }, { ...task, priority: null }
  ];
  for (const item of invalids) {
    await put(p, { schemaVersion: 1, tasks: [item] });
    await p.getByText('Import could not be completed', { exact: true }).waitFor(); assert.deepEqual(await board(p), initial);
    await p.getByRole('button', { name: 'Dismiss', exact: true }).click();
  }
  pass('13 additional invalid-task cases preserve the prior board, including status arrays, string bounds, tags, and Gregorian leap rules');
  p.once('dialog', d => d.accept()); await put(p, { schemaVersion: 1, tasks: [task, { ...task, id: 'two', project: 'Second project' }] });
  await p.waitForFunction(() => JSON.parse(localStorage.getItem('fieldnote-board:v1')).tasks.length === 2);
  await p.getByTestId('filter-project').selectOption({ index: 1 });
  // Projects sort as "all", "Second project" in this browser locale.
  assert.equal(await p.getByTestId('task-card').count(), 1);
  const first = p.getByTestId('task-card').first(); await first.locator('[data-action="edit"]').click();
  await p.locator('[name="title"]').fill('Edited only the title'); await p.getByTestId('save-task').click();
  assert.deepEqual((await board(p)).tasks[0].tags, task.tags);
  await p.getByTestId('filter-project').selectOption({ index: 0 }); assert.equal(await p.getByTestId('task-card').count(), 2);
  pass('A project named all can be filtered separately; unchanged imported tags containing commas survive editing');
  await p.getByTestId('create-task').click();
  await p.locator('[name="title"]').fill('Boundary task'); await p.locator('[name="project"]').fill('x'.repeat(81)); await p.locator('[name="tags"]').fill(Array.from({ length: 9 }, (_, i) => 'tag' + i).join(','));
  await p.getByTestId('save-task').click();
  assert.equal(await p.locator('[name="project"]').getAttribute('aria-invalid'), 'true'); assert.equal(await p.locator('[name="tags"]').getAttribute('aria-invalid'), 'true');
  for (let i = 0; i < 14; i++) { await p.keyboard.press('Tab'); assert.equal(await p.evaluate(() => document.querySelector('dialog').contains(document.activeElement)), true); }
  await p.keyboard.press('Escape');
  pass('Overlong form projects and too many tags show errors; keyboard Tab remains inside the modal');
  const denied = await make(() => { Storage.prototype.getItem = function() { throw new DOMException('Denied', 'SecurityError'); }; Storage.prototype.setItem = function() { throw new DOMException('Denied', 'SecurityError'); }; });
  await denied.getByText('Changes are not saved', { exact: true }).waitFor();
  await denied.getByTestId('create-task').click(); await denied.locator('[name="title"]').fill('Memory only'); await denied.locator('[name="project"]').fill('Offline'); await denied.getByTestId('save-task').click();
  assert.equal(await denied.getByTestId('task-card').count(), 1);
  const dl = denied.waitForEvent('download'); await denied.getByTestId('export').click(); assert.equal(JSON.parse(await fs.readFile(await (await dl).path(), 'utf8')).tasks[0].title, 'Memory only');
  pass('Storage read denial still permits recoverable work and a full JSON export');
  const quota = await make(() => { Storage.prototype.setItem = function() { throw new DOMException('Full', 'QuotaExceededError'); }; });
  assert.equal(await quota.getByTestId('task-card').count(), 8); assert.equal(await quota.evaluate(k => localStorage.getItem(k), KEY), null);
  assert.match(await quota.locator('#save-state').innerText(), /Not saved/);
  pass('First-visit write failure keeps the example board in memory and accurately marks it unsaved');
  await fs.mkdir('nested-check', { recursive: true });
  for (const file of ['index.html', 'styles.css', 'app.js']) await fs.symlink('../' + file, 'nested-check/' + file);
  await p.goto(base + 'nested-check/'); assert.equal(await p.getByTestId('task-card').count(), 2);
  assert.equal(await p.locator('.kanban').evaluate(n => getComputedStyle(n).display), 'grid');
  await p.getByTestId('create-task').click(); assert.equal(await p.locator('dialog').isVisible(), true); await p.keyboard.press('Escape');
  pass('Nested URL loads relative HTML/CSS/JS assets and remains functional');
  await fs.writeFile('edge-verification-results.json', JSON.stringify({ passed: checks.length, checks }, null, 2) + '\n');
} finally {
  await fs.rm('nested-check', { recursive: true, force: true });
  for (const c of contexts) await c.close();
  await browser.close();
}
