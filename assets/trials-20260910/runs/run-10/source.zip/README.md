# Fieldnote Board

A fictional, local-only task board for a small studio. The dashboard includes a full-board progress overview, three status columns, search and combined filters, project shortcuts, and a keyboard-accessible task editor. Desktop columns stack into a single readable flow on mobile.

## Run

Serve this directory with any static HTTP server and open `index.html` (or the directory URL). For example, from this directory:

```sh
python3 -m http.server 8080
```

Open `http://localhost:8080/`. Stop that server with Ctrl+C when finished. No build step or dependency installation is needed. The app consists of `index.html`, `styles.css`, and `app.js`; all assets are relative or embedded. Copy those three files together into a nested directory to serve at a nested URL. The app makes no external resource requests or network API calls.

## Data and behavior

The only persistence key is `fieldnote-board:v1`. Its JSON document contains `schemaVersion: 1` and `tasks`. Each task has exactly these fields:

| Field | Accepted value |
| --- | --- |
| `id` | Unique, nonblank string, at most 80 characters |
| `title` | Trimmed, nonempty string, at most 120 characters |
| `project` | Trimmed, nonempty string, at most 80 characters |
| `status` | `todo`, `doing`, or `done` |
| `priority` | `low`, `medium`, or `high` |
| `dueDate` | Empty string or a real Gregorian date, `YYYY-MM-DD`, years 0001–9999 |
| `tags` | Up to 8 trimmed, nonempty strings, at most 24 characters each |

Eight fictional tasks are seeded only when the key is absent. An existing empty board stays empty. Task IDs use `crypto.randomUUID()` when available, with a checked local fallback. Form text is trimmed; comma-separated tags are deduplicated case-insensitively. Unchanged imported tags are preserved when editing other fields, including tags containing commas.

Search matches title, project, or any tag without regard to case; it combines with all three native-select filters. The visible matching count reflects filters; overview totals and export always include the full board. Project names are free text, including the literal name `all` (the project filter distinguishes that option from “All projects”).

Edit, status changes, and deletion preserve unrelated records. Delete offers an undo stack for the current session; each undo restores the original record and saves it. Restored tasks survive reload. Undo history itself is not persisted and is cleared by import or explicit reload.

## Import, recovery, and conflicts

- Export downloads the full working board as JSON, including filtered-out and unsaved records.
- Import accepts JSON files up to 1 MiB (1,048,576 bytes). Every task is validated before an explicit confirmation asks to replace the whole board. Malformed JSON, unsupported schema/enums, invalid dates, duplicate IDs, extra/missing task fields, invalid string/tag bounds, and oversized files are rejected without changing the prior board. Cancelling confirmation also leaves it untouched.
- Imported strings are rendered with DOM text nodes, never interpreted as HTML.
- Corrupt saved data is preserved exactly on startup. A visible recovery notice offers an original-data download and a confirmed reset to the example board. A confirmed valid import can also recover the board.
- Storage read/write exceptions show an explicit unsaved notice. The working board stays available in memory, with retry and export actions. A failed write never advances the saved snapshot or claims success. If a recovery write fails, the original corrupt contents remain downloadable.
- Storage events from other tabs show a conflict notice and disable creation, editing, deletion, status changes, undo, and import. Every write also checks the saved snapshot immediately beforehand. The user can export the working copy, then explicitly reload the latest stored board. Open forms stay intact while editing is blocked. Reload warns before discarding an open form or unsaved memory state.
- Unsaved changes request the browser's standard leave-page warning. Such browser warnings are supplementary; exporting is the reliable way to retain in-memory work.

The application is local to the browser origin, not a shared team service. Tabs and nested paths on the same origin use the same storage key. Different origins, browser profiles, or ports have separate boards. No authentication, backend, synchronization service, telemetry, or service worker is included.

## Accessibility and responsive design

All controls have labels or accessible names, including per-task edit/delete/status controls. Native selects and buttons support keyboard interaction. The task dialog traps Tab/Shift+Tab, closes with Escape, and restores focus to its opener or the corresponding refreshed task control. Validation errors are visible and associated with their fields. Notices and result updates use live regions. Nonessential transitions are disabled with `prefers-reduced-motion`. A `noscript` message explains that JavaScript is required.

The due-date field deliberately uses explicit `YYYY-MM-DD` text entry so impossible dates can produce an actionable error instead of being silently cleared by a native date input.

## Checks actually executed

Verification used the supplied isolated Chrome instance through the existing Playwright installation. Test storage writes were confined to newly created isolated browser contexts, all closed afterward. No background server was started by these checks.

- `node --check app.js` — JavaScript syntax passed.
- `node verify.mjs` — 14 workflow check groups passed: seeding; create/edit/status; blank/overlong title and invalid-date validation; normalized tags; exact delete/undo and reload persistence; combined filtering/counts/no-results; full export; Escape/focus return; atomic import rejection and cancellation; confirmed import persistence and inert HTML-like text; real second-tab conflicts; corrupt-data preservation/download/reset; write failure and retry; saved-empty-board behavior; and JavaScript-disabled behavior. The suite also checked for browser errors, external requests, and mobile overflow.
- `node verify-edge.mjs` — 6 edge check groups passed, including 13 additional malformed-task cases, Gregorian leap-year boundaries, a project named `all`, preserving imported comma-containing tags, overlong project/tag errors, modal keyboard containment, unavailable storage reads, failed initial seeding writes, and functionality under a nested URL. The temporary nested test directory was removed.
- Final direct browser checks passed at 360, 768, 1024, and 1440px with no horizontal overflow. They also verified that reduced-motion CSS produces zero-duration transitions, Shift+Tab wraps inside the modal, and the pre-write snapshot guard blocks stale deletion even when no storage event has been dispatched.
- Desktop 1440px and mobile 360px screenshots were captured and visually inspected. The mobile modal was also inspected.

`verification-results.json` and `edge-verification-results.json` record the passing groups. `verify.mjs` and `verify-edge.mjs` are optional development checks, not runtime dependencies; their browser connection and Playwright path target the supplied verification environment.

## Files and limits

Runtime: `index.html`, `styles.css`, `app.js`. Documentation: `README.md`. Verification: the two `.mjs` scripts, two result JSON files, and `desktop.png`, `mobile.png`, `mobile-form.png`.

Verified in the supplied Chromium browser, not Safari/Firefox or with a physical screen reader. Modern browser support for native `<dialog>`, localStorage, and file downloads is expected. The board has no pagination or virtualization, so exceptionally large valid files may render slowly. localStorage is a snapshot store, not a transactional multi-user database; tab changes are handled with explicit conflict/reload protection, not automatic merging. Export backups remain useful because browsers can clear local storage, and unsaved memory work cannot survive closing the tab. Undo history is session-only.
