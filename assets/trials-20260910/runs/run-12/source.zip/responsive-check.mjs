import pkg from '[user]/node_modules/playwright/index.js';
import { writeFile } from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:60320');
const context = await browser.newContext({ reducedMotion: 'reduce' });
const results = [];
try {
  const page = await context.newPage();
  for (const width of [360, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 950 });
    await page.goto('http://127.0.0.1:60319/');
    const dimensions = await page.evaluate(() => ({ viewport: innerWidth, content: document.documentElement.scrollWidth }));
    if (dimensions.content > width) throw Error(`Overflow at ${width}`);
    results.push(`No horizontal overflow at ${width}px`);
    if (width === 360 || width === 1440) {
      await page.screenshot({ path: `hero-${width}.png` });
      for (const name of ['connect', 'export']) {
        await page.getByTestId(`feature-${name}`).click();
        await page.locator('#features').screenshot({ path: `${name}-${width}.png` });
      }
    }
  }
  await page.setViewportSize({ width: 360, height: 800 });
  await page.getByTestId('billing-yearly').click();
  if (await page.getByTestId('price-studio').textContent() !== '$264') throw Error('Mobile yearly billing');
  results.push('Mobile yearly billing updates Studio to $264');
  await page.getByTestId('billing-monthly').click();
  if (await page.getByTestId('price-studio').textContent() !== '$29') throw Error('Mobile monthly billing');
  results.push('Mobile monthly billing restores Studio to $29');
  for (let i=0;i<4;i++) {
    await page.getByTestId(`faq-${i}`).click();
    if (!await page.getByTestId(`faq-${i}`).evaluate(el => el.parentElement.open)) throw Error(`Mobile FAQ ${i}`);
  }
  results.push('All four mobile FAQs open by click');
  await page.getByTestId('menu-toggle').click();
  await page.setViewportSize({ width: 1440, height: 950 });
  if (!await page.locator('.desktop-nav').isVisible() || await page.getByTestId('menu-toggle').getAttribute('aria-expanded') !== 'false') throw Error('Resize navigation state');
  results.push('Resizing an open mobile menu restores desktop navigation and resets menu state');
  // WCAG contrast calculation for the principal page text colors.
  const luminance = hex => {
    const values = hex.match(/\w\w/g).map(v => parseInt(v,16)/255).map(v => v <= .04045 ? v/12.92 : ((v+.055)/1.055)**2.4);
    return values[0]*.2126 + values[1]*.7152 + values[2]*.0722;
  };
  const contrast = (a,b) => { const x=luminance(a),y=luminance(b); return (Math.max(x,y)+.05)/(Math.min(x,y)+.05); };
  const pairs = [['283e32','f6f5ee'],['626b60','f6f5ee'],['626b60','e8eddb'],['c1cabb','283e32'],['def29f','283e32']];
  for (const [foreground,background] of pairs) {
    const ratio = contrast(foreground,background);
    if (ratio < 4.5) throw Error(`Text contrast ${foreground}/${background}: ${ratio}`);
    results.push(`Text contrast #${foreground} on #${background}: ${ratio.toFixed(2)}:1`);
  }
  await writeFile('responsive-checks.json', JSON.stringify({passed: results.length, results}, null, 2)+'\n');
  console.log(results.join('\n'));
} finally { await context.close(); await browser.close(); }
