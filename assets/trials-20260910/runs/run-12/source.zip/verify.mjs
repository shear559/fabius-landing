import pkg from '[user]/node_modules/playwright/index.js';
import { writeFile, mkdir, copyFile, rm } from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:60320');
const results = [];
function check(condition, name) { if (!condition) throw new Error(name); results.push(name); }
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce' });
const page = await context.newPage();
const errors = [];
const requests = [];
page.on('pageerror', error => errors.push(error.message));
page.on('request', request => requests.push(request.url()));
try {
  const response = await page.goto('http://127.0.0.1:60319/');
  check(response.ok(), 'Static server returns the page');
  await page.screenshot({ path: 'desktop.png', fullPage: true });
  check(await page.locator('.desktop-nav').isVisible(), 'Desktop navigation is visible at 1440px');
  check(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No horizontal overflow at 1440px');
  for (const name of ['capture', 'connect', 'export']) {
    await page.getByTestId(`feature-${name}`).click();
    check(await page.getByTestId(`feature-${name}`).getAttribute('aria-selected') === 'true', `${name} tab selected`);
    for (const other of ['capture', 'connect', 'export']) check(await page.getByTestId(`panel-${other}`).isVisible() === (other === name), `${name}: ${other} panel visibility`);
  }
  await page.getByTestId('feature-export').focus();
  await page.keyboard.press('ArrowRight');
  check(await page.getByTestId('feature-capture').evaluate(el => el === document.activeElement && el.getAttribute('aria-selected') === 'true'), 'ArrowRight wraps and activates capture');
  await page.keyboard.press('ArrowLeft');
  check(await page.getByTestId('feature-export').evaluate(el => el === document.activeElement), 'ArrowLeft wraps to export');
  await page.keyboard.press('Home');
  check(await page.getByTestId('feature-capture').evaluate(el => el === document.activeElement), 'Home selects first tab');
  await page.keyboard.press('End');
  check(await page.getByTestId('feature-export').evaluate(el => el === document.activeElement), 'End selects last tab');
  for (const period of ['yearly', 'monthly']) {
    await page.getByTestId(`billing-${period}`).click();
    const expected = period === 'yearly' ? ['$108', '$264', '/ year'] : ['$12', '$29', '/ month'];
    check(await page.getByTestId('price-solo').textContent() === expected[0], `${period} Solo exact price`);
    check(await page.getByTestId('price-studio').textContent() === expected[1], `${period} Studio exact price`);
    check((await page.locator('.price-period').allTextContents()).every(text => text === expected[2]), `${period} billing periods labeled`);
    check(await page.getByTestId(`billing-${period}`).getAttribute('aria-pressed') === 'true', `${period} billing state exposed`);
  }
  check(await page.locator('details').count() === 4, 'Exactly four native FAQs');
  for (let i = 0; i < 4; i++) {
    const summary = page.getByTestId(`faq-${i}`);
    await summary.focus();
    await page.keyboard.press('Enter');
    check(await summary.evaluate(el => el.parentElement.open), `FAQ ${i} opens by keyboard`);
    await page.keyboard.press('Enter');
    check(!await summary.evaluate(el => el.parentElement.open), `FAQ ${i} closes by keyboard`);
  }
  await page.locator('.hero .button').click();
  check(new URL(page.url()).hash === '#workflow', 'Primary CTA links to workflow');
  check(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior === 'auto'), 'Reduced motion disables smooth scroll');
  check(await page.evaluate(() => [...document.querySelectorAll('a[href^="#"]')].every(a => a.hash === '' || a.hash === '#' || document.getElementById(decodeURIComponent(a.hash.slice(1))))), 'Every section navigation target exists');
  await page.getByTestId('feature-capture').click();
  await page.setViewportSize({ width: 360, height: 800 });
  await page.goto('http://127.0.0.1:60319/');
  check(await page.getByTestId('menu-toggle').isVisible(), 'Mobile menu toggle visible at 360px');
  check(!await page.getByTestId('mobile-nav').isVisible(), 'Mobile navigation initially closed');
  await page.getByTestId('menu-toggle').click();
  check(await page.getByTestId('mobile-nav').isVisible() && await page.getByTestId('menu-toggle').getAttribute('aria-expanded') === 'true', 'Menu click opens navigation and updates aria-expanded');
  await page.getByTestId('mobile-nav').locator('a').first().focus();
  await page.keyboard.press('Escape');
  check(!await page.getByTestId('mobile-nav').isVisible() && await page.getByTestId('menu-toggle').getAttribute('aria-expanded') === 'false', 'Escape closes navigation and resets aria-expanded');
  check(await page.getByTestId('menu-toggle').evaluate(el => el === document.activeElement), 'Escape returns focus to menu toggle');
  await page.getByTestId('menu-toggle').click();
  await page.getByTestId('mobile-nav').locator('a[href="#pricing"]').click();
  check(!await page.getByTestId('mobile-nav').isVisible() && new URL(page.url()).hash === '#pricing', 'Mobile section link navigates and closes menu');
  await page.getByTestId('menu-toggle').click();
  await page.getByTestId('menu-toggle').click();
  check(!await page.getByTestId('mobile-nav').isVisible(), 'Toggle click closes mobile navigation');
  for (const name of ['capture', 'connect', 'export']) {
    await page.getByTestId(`feature-${name}`).click();
    check(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), `No horizontal overflow at 360px with ${name} panel`);
  }
  await page.getByTestId('feature-capture').click();
  await page.evaluate(() => scrollTo(0, 0));
  await page.screenshot({ path: 'mobile.png', fullPage: true });
  await page.getByTestId('menu-toggle').focus();
  await page.keyboard.press('Tab');
  await page.keyboard.press('Shift+Tab');
  check(await page.getByTestId('menu-toggle').evaluate(el => getComputedStyle(el).outlineStyle !== 'none'), 'Keyboard focus has visible outline');
  check(errors.length === 0, 'No browser JavaScript errors');
  check(requests.every(url => url.startsWith('http://127.0.0.1:60319/')), 'No remote network requests');
  const noJs = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 360, height: 800 } });
  try {
    const fallback = await noJs.newPage();
    await fallback.goto('http://127.0.0.1:60319/');
    check(await fallback.getByTestId('mobile-nav').isVisible(), 'No-JS mobile navigation is visible');
    for (const name of ['capture', 'connect', 'export']) check(await fallback.getByTestId(`panel-${name}`).isVisible(), `No-JS ${name} content is visible`);
    check(await fallback.getByTestId('price-solo').textContent() === '$12' && await fallback.getByTestId('price-studio').textContent() === '$29', 'No-JS monthly prices visible');
    check((await fallback.locator('[data-plan="solo"]').textContent()).includes('$108') && (await fallback.locator('[data-plan="studio"]').textContent()).includes('$264'), 'No-JS yearly prices visible');
    await fallback.getByTestId('faq-2').click();
    check(await fallback.getByTestId('faq-2').evaluate(el => el.parentElement.open), 'Native FAQ works without JavaScript');
    await fallback.locator('.hero .button').click();
    check(new URL(fallback.url()).hash === '#workflow', 'No-JS workflow navigation works');
    check(await fallback.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No-JS mobile has no horizontal overflow');
  } finally { await noJs.close(); }
  await mkdir('nested-check', { recursive: true });
  try {
    for (const file of ['index.html', 'styles.css', 'app.js']) await copyFile(file, `nested-check/${file}`);
    await page.goto('http://127.0.0.1:60319/nested-check/');
    check(await page.evaluate(() => document.documentElement.classList.contains('js') && getComputedStyle(document.body).backgroundColor === 'rgb(246, 245, 238)'), 'Relative CSS and JS work at a nested URL');
    await page.getByTestId('billing-yearly').click();
    check(await page.getByTestId('price-solo').textContent() === '$108', 'Billing interaction works at nested URL');
  } finally { await rm('nested-check', { recursive: true, force: true }); }
  await writeFile('checks.json', JSON.stringify({ passed: results.length, results, browserErrors: errors }, null, 2) + '\n');
  console.log(`PASS: ${results.length} browser checks`);
} finally { await context.close(); await browser.close(); }
