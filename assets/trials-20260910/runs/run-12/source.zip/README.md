# Lattice

A finished, responsive marketing page for a **fictional local-first research notebook**. The product facts and prices are supplied fiction. The page includes no customers, testimonials, ratings, adoption claims, checkout, contact form, or backend.

## Run

Serve this directory with any static server and open `index.html`. No installation or build step is needed. For example, with Python available:

```sh
python3 -m http.server 8000
```

Then visit `http://localhost:8000/`. Stop that server with Ctrl+C when finished. In the provided environment, the page is already available at `http://127.0.0.1:60319/`.

Keep `index.html`, `styles.css`, and `app.js` together when moving the page. The CSS and JavaScript references are relative, so the page also works under a nested URL such as `/lattice/`. The favicon and illustrations are inline; there are no remote fonts, image assets, libraries, API calls, or analytics in the page.

## Implementation

- **Visual system:** warm paper, forest green, pale sage, and lime accents; system Georgia and Arial; numbered editorial sections; original notebook, note cards, connection diagram, export file, and workflow illustrations built with HTML, CSS, and inline SVG.
- **Content:** hero, three feature views, three-step workflow, two fictional pricing plans, four native FAQs, and a closing workflow link. The notebook's sample research content and project counts are illustrative.
- **Mobile navigation:** available below 761px, with synchronized `aria-expanded`, click-to-toggle behavior, Escape dismissal with focus restoration, and dismissal after choosing a section. Desktop navigation stays available above the breakpoint.
- **Feature tabs:** proper tab and panel relationships, one visible panel with JavaScript enabled, roving tab stops, Left/Right arrow navigation with wrapping, and Home/End support.
- **Billing:** Monthly and Yearly buttons expose their selection through `aria-pressed`. The exact supplied amounts and billing periods update together. A polite status message announces changes. No payment action is offered; plan links lead to relevant page sections.
- **Progressive enhancement:** without JavaScript, the mobile navigation and all three feature panels are visible, and the pricing cards show both monthly and yearly prices. Section links and native FAQs continue to work. Interactive controls become visible after initialization.
- **Accessibility:** semantic landmarks, a skip link, labeled navigation, visible keyboard focus, accessible illustration description, native FAQ disclosure controls, and reduced-motion support.

## Checks actually executed

`node --check app.js` passed. A Python standard-library HTML audit also confirmed unique IDs, all 16 required test seams, and the presence of all four requested deliverables.

`node verify.mjs` passed **63 browser assertions** in the provided Chrome instance:

- Static serving, desktop navigation, and no horizontal overflow at 1440px.
- All three tab selections and selected/hidden states; Left/Right wrapping and Home/End keyboard behavior.
- Exact yearly prices ($108/$264), monthly restoration ($12/$29), visible billing periods, and pressed states.
- Four native FAQs opening and closing with the keyboard.
- Primary CTA destination, all section link targets, and reduced-motion scroll behavior.
- Mobile menu opening and closing at 360px, Escape focus return, link dismissal, and synchronized expanded state.
- No horizontal overflow for any feature panel at 360px; visible focus under actual keyboard navigation.
- No JavaScript errors or remote requests during the main browser session.
- JavaScript-disabled mobile navigation, all feature content, both sets of prices, native FAQ behavior, section navigation, and overflow.
- Actual nested-directory serving of copied HTML/CSS/JS and a working billing interaction. The temporary directory was removed afterward.

`node responsive-check.mjs` passed **13 further checks**:

- No horizontal overflow at 360, 768, 1024, and 1440px.
- Mobile billing changes, all four mobile FAQs, and switching from an open mobile menu to desktop.
- Calculated WCAG contrast for five principal text/background pairs: 4.63:1 to 10.53:1. This is a targeted color check, not a complete accessibility audit.

I visually inspected the full-page desktop and mobile screenshots, the 360px and 1440px hero views, and the mobile Connect and Export feature views. That review led to a tighter mobile headline and removal of an unintended spacing shift between feature panels. The successful checks and saved screenshots reflect those corrections.

The first browser test run failed because the test checked `:focus-visible` after programmatic focus while still in pointer modality. The test was corrected to use actual Tab/Shift+Tab keyboard navigation; the page's focus styling then passed.

### Verification artifacts

- `verify.mjs`, `responsive-check.mjs`: browser verification scripts. These use only the explicitly provided Playwright resource and Chrome endpoint; they are not runtime dependencies of the page.
- `checks.json`, `responsive-checks.json`: successful assertion reports.
- `desktop.png`, `mobile.png`: full-page screenshots at 1440px and 360px.
- `hero-360.png`, `hero-1440.png`: viewport screenshots.
- `connect-360.png`, `connect-1440.png`, `export-360.png`, `export-1440.png`: feature screenshots.

To rerun the scripts in the same provided environment, run `node verify.mjs` and `node responsive-check.mjs` from this directory. They expect the static server at port 60319 and the provided Chrome CDP endpoint at port 60320. They close their own browser contexts and disconnect when finished. No background servers were started by the implementation or verification.

## Known limitations

This is a marketing demonstration, not a working notebook. The notebook illustration does not edit or store notes, search, or export files. Billing selection is temporary page state and resets on reload. The Studio/Solo packaging is a design choice for this fictional demo. Validation used the provided Chrome only; Safari, Firefox, physical devices, and a screen-reader audit were not tested. Small text inside the decorative notebook is illustrative; all essential product information is also presented in the page's main text.
