import pkg from '[user]/node_modules/playwright/index.js';
import {mkdir,copyFile,rm,writeFile} from 'node:fs/promises';
const {chromium}=pkg;const browser=await chromium.connectOverCDP('http://127.0.0.1:60699');
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
const p=await context.newPage();const key='fieldnote-board:v1';const checks=[];
const ok=(value,label)=>{if(!value)throw Error(label);checks.push(label);};
async function importDoc(doc){p.once('dialog',d=>d.accept());await p.getByTestId('import-file').setInputFiles({name:'edge.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(doc))});await p.waitForTimeout(60);}
try{
 await p.goto('http://127.0.0.1:60698/');const initial=await p.evaluate(k=>JSON.parse(localStorage.getItem(k)),key);const task=initial.tasks[0];
 for(const [field,value] of [['status',['todo']],['priority',['high']],['id',''],['title','x'.repeat(121)],['project','x'.repeat(81)],['tags',['x'.repeat(25)]],['tags',Array(9).fill('tag')],['dueDate','1900-02-29'],['dueDate','0000-01-01']]){
  const doc={schemaVersion:1,tasks:[{...task,[field]:value}]};await p.getByTestId('import-file').setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(doc))});await p.waitForTimeout(30);ok(await p.evaluate(({k,b})=>localStorage.getItem(k)===b,{k:key,b:JSON.stringify(initial,null,2)}),`Rejects invalid ${field}: ${JSON.stringify(value).slice(0,30)}`);
 }
 await importDoc({schemaVersion:1,tasks:[{...task,project:'all',tags:['one,two','Same','same']}, {...initial.tasks[1],project:'Other'}]});
 await p.getByTestId('filter-project').selectOption({label:'all'});ok(await p.getByTestId('task-card').count()===1,'Project named all can be filtered independently of All projects');await p.locator('#clear-filters').click();ok(await p.getByTestId('task-card').count()===2,'Clearing project all restores all tasks');
 await p.locator(`[data-task-id="${task.id}"] [data-action=edit]`).click();await p.locator('[name=title]').fill('Changed title');await p.getByTestId('save-task').click();ok(JSON.stringify(await p.evaluate(k=>JSON.parse(localStorage.getItem(k)).tasks[0].tags,key))==='["one,two","Same","same"]','Unchanged imported tags survive an unrelated edit exactly');
 await p.getByTestId('create-task').click();await p.locator('[name=title]').fill('Draft');await p.locator('[name=project]').fill('Local');
 const p2=await context.newPage();await p2.goto('http://127.0.0.1:60698/');await p2.getByTestId('task-card').first().locator('[data-action=status]').selectOption('done');await p.waitForTimeout(50);ok(await p.getByTestId('save-task').isDisabled()&&(await p.locator('#form-error').innerText()).includes('another tab'),'Open draft is blocked with an in-modal conflict message');await p.keyboard.press('Escape');await p.locator('#reload-board').click();
 // Native dialog traps keyboard focus.
 await p.getByTestId('create-task').click();await p.locator('#close-dialog').focus();await p.keyboard.press('Shift+Tab');ok(await p.getByTestId('save-task').evaluate(e=>e===document.activeElement),'Modal keyboard focus wraps inside the dialog');await p.keyboard.press('Escape');
 // Compare named foreground/background roles rather than assuming palette contrast.
 const ratios=await p.evaluate(()=>{const css=getComputedStyle(document.documentElement);const lum=s=>{const c=s.trim().slice(1).match(/../g).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return c[0]*.2126+c[1]*.7152+c[2]*.0722;};return [['muted','canvas',4.5],['muted','soft',4.5],['ink','surface',4.5],['accent','surface',4.5],['border-strong','surface',3],['focus','canvas',3]].map(([f,b,min])=>{const a=lum(css.getPropertyValue('--'+f)),z=lum(css.getPropertyValue('--'+b));return {f,b,min,ratio:(Math.max(a,z)+.05)/(Math.min(a,z)+.05)};});});ok(ratios.every(r=>r.ratio>=r.min),'Named text, input border, and focus colors pass their contrast thresholds');
 await mkdir('nested-check/board',{recursive:true});for(const file of ['index.html','styles.css','app.js'])await copyFile(file,'nested-check/board/'+file);await p.goto('http://127.0.0.1:60698/nested-check/board/');ok(await p.getByTestId('task-card').count()===2&&await p.locator('h1').evaluate(el=>getComputedStyle(el).fontSize)==='48px','Nested URL resolves script and stylesheet with relative paths');
 await writeFile('edge-results.json',JSON.stringify({passed:checks.length,checks,ratios},null,2));console.log(JSON.stringify({passed:checks.length,checks,ratios},null,2));
}finally{await context.close();await browser.close();await rm('nested-check',{recursive:true,force:true});}
