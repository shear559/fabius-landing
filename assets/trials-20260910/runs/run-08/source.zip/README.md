# Fieldnote Board

A fictional, local-only task board for Northstar Studio. Vanilla HTML, CSS, and JavaScript; no build, packages, external assets, authentication, APIs, or backend.

## Run

Serve this directory with any static HTTP server, for example:

```sh
python3 -m http.server 8000
```

Open `http://localhost:8000/`. You can also put `index.html`, `styles.css`, and `app.js` together in any nested directory. Assets use relative URLs. The application makes no network requests beyond loading its own files. Open through HTTP rather than `file://`, whose storage behavior varies between browsers.

## Use

Create a task with **New task** or a column’s plus button. Edit and delete controls appear on every card; its native select changes status. The latest deletion can be undone until dismissed, replaced by another deletion, imported over, or the page reloads. A restored task is persisted immediately.

Search covers title, project, and tags, case-insensitively. All filters combine. Counts show matching and total tasks; overview numbers describe the full board. Export always downloads the full board, regardless of filters. Import validates the whole file and asks for explicit confirmation before replacing the board.

On mobile, columns stack into a single reading order. Controls have accessible names and visible focus; the dialog supports Escape, Tab wrapping, and focus restoration. Reduced motion disables transitions. A noscript notice explains why JavaScript is required.

## Data and recovery

- Storage key: `fieldnote-board:v1`, containing `{ "schemaVersion": 1, "tasks": [...] }`.
- Every task has exactly `id`, `title`, `project`, `status`, `priority`, `dueDate`, and `tags`. Validation enforces the specified lengths, types, enums, trimmed text, actual calendar dates, tag count, and unique IDs. Dates use years 0001–9999 and are displayed without timezone drift.
- Form tags are comma-separated, trimmed, and deduplicated case-insensitively. Imported tags are preserved exactly when an unrelated field is edited.
- Nine fictional tasks across three projects and all three statuses seed only when the storage key is absent. An existing valid empty board stays empty.
- Import accepts schema version 1 JSON files up to 1,048,576 bytes. Every task is validated before confirmation and replacement. A bad record rejects the entire import. Task text enters the DOM through text nodes; only fixed internal icon markup uses HTML.
- Corrupt saved text is never repaired or overwritten automatically. Recovery offers a verbatim text download and a confirmed reset to an empty board. If reset cannot be written, the original remains available. If storage cannot be read at all, editing is blocked with a visible explanation.
- A failed write retains the working board in memory, marks it explicitly **not saved**, and offers retry. Export remains available. Leaving the page loses unpersisted memory, so export a backup first.
- Storage events from another tab pause task changes, import, reset, and undo. The storage value is also compared immediately before mutations to catch changes before their event is handled. Explicit **Reload saved board** adopts the saved version; unsaved memory or an open draft requires discard confirmation. Export can preserve the current in-memory version first. No automatic merge occurs.
- Local storage belongs to the browser origin, not a folder. Two copies on the same scheme, host, and port share this board. Export/import is the transfer and backup mechanism.

## Verification

Final result: 55 passing browser assertions (39 main checks and 16 edge checks), plus a passing JavaScript syntax check. No browser JavaScript errors or HTTP failures were recorded in the main suite.

Executed in the provided isolated Chrome environment using the existing Playwright package. The verification scripts require that environment’s absolute Playwright path and CDP/static-server endpoints; the application does not depend on them. Run the suites sequentially because concurrent CDP clients interfere with native confirmation dialogs.

```sh
node --check app.js
node verify.mjs
node verify-edge.mjs
```

`verification-results.json` records the main suite: CRUD and persistence, exact undo after reload, combined search/filters, complete export, invalid and confirmed imports, malicious text, empty states, real two-tab conflict handling, corrupt-data preservation/download/reset, simulated quota errors and retry, 360px layout, modal Escape/focus, reduced motion, JavaScript-disabled messaging, and browser console/HTTP checks.

`edge-results.json` records additional checks for enum types, text/tag/ID limits, leap-year validation, a project named `all`, imported tags containing commas, conflict while editing, modal Tab wrapping, palette contrast, and a real nested URL load. Temporary nested test files are removed after the check.

Screenshots: `desktop.png` (1440px), `mobile.png` (360px), and `mobile-form.png`. Desktop and mobile layouts were visually inspected. Named foreground/background contrast pairs meet 4.5:1 for text and 3:1 for controls/focus. A discovered modal Tab-boundary issue and muted-text contrast issue were corrected and retested.

## Limits

This is a single-device demonstration, not shared team synchronization. Browser storage has finite capacity and can be cleared by browser settings. There is no server backup, deletion history beyond the most recent undo, or draft persistence. Date entry uses explicit YYYY-MM-DD text with validation. Imports larger than 1 MiB are rejected, including an export if a board grows beyond that limit. LocalStorage has no transactional cross-tab compare-and-swap; event handling and immediate value checks protect ordinary stale-tab edits, but do not provide database-grade concurrent transactions. Testing covered the supplied Chrome instance, not other browser engines or a full screen-reader audit.
