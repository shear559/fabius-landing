"""Reproducible standard-library verification; run: python3 -B verify_solution.py."""

import ast
from fractions import Fraction as Q
from itertools import combinations
import math
from pathlib import Path
import random
import subprocess
import sys

from solution import solve


# The oracle uses the original reduced inequalities and enumerates every
# vertex and edge. It does not use the claimed regimes or breakpoints.
# Each row is a*x + b*y <= c.
CONSTRAINTS = (
    (Q(-1), Q(0), Q(0)),
    (Q(0), Q(-1), Q(0)),
    (Q(1), Q(1), Q(1)),
    (Q(1), Q(0), Q(3, 5)),
    (Q(1), Q(-1), Q(1, 2)),
)


def feasible(p):
    x, y = p
    return all(a * x + b * y <= c for a, b, c in CONSTRAINTS)


def intersection(row1, row2):
    a, b, c = row1
    d, e, f = row2
    det = a * e - b * d
    if det == 0:
        return None
    return ((c * e - b * f) / det, (a * f - c * d) / det)


VERTICES = sorted({
    p for row1, row2 in combinations(CONSTRAINTS, 2)
    for p in [intersection(row1, row2)]
    if p is not None and feasible(p)
})
EDGES = [
    (p, q) for p, q in combinations(VERTICES, 2)
    if any(a * p[0] + b * p[1] == c == a * q[0] + b * q[1]
           for a, b, c in CONSTRAINTS)
]


def objective(t, x, y, z):
    return (x*x + 2*y*y + 3*z*z + x*y - y*z
            + (2-2*t)*x + 5*y + z)


def oracle(t):
    """Exact minimum over all vertices, edge minima, and the interior."""
    candidates = list(VERTICES)
    # Invert H = [[8,8],[8,12]] against the linear coefficient vector.
    l1, l2 = 5 + 2*t, Q(3)
    interior = ((12*l1 - 8*l2) / 32, (8*l2 - 8*l1) / 32)
    if feasible(interior):
        candidates.append(interior)
    for p, q in EDGES:
        dx, dy = q[0]-p[0], q[1]-p[1]
        gx, gy = 8*p[0]+8*p[1]-l1, 8*p[0]+12*p[1]-l2
        curvature = 8*dx*dx + 16*dx*dy + 12*dy*dy
        u = max(Q(0), min(Q(1), -(gx*dx+gy*dy) / curvature))
        candidates.append((p[0]+u*dx, p[1]+u*dy))
    x, y = min(candidates, key=lambda p: objective(t, *p, 1-sum(p)))
    z = 1-x-y
    return (x, y, z, objective(t, x, y, z))


def exact_formula(t):
    """The document's formulas, independently checked against the oracle."""
    if t <= Q(-3, 2):
        p, v = (Q(0), Q(1, 4), Q(3, 4)), Q(29, 8)
        multipliers = (-3-2*t, Q(0), Q(0), Q(0), Q(0), Q(-21, 4))
    elif t <= -1:
        p = ((9+6*t)/8, -(1+t)/2, (3-2*t)/8)
        v = (31-36*t-12*t*t)/16
        multipliers = (Q(0), Q(0), Q(0), Q(0), Q(0), t-Q(15, 4))
    elif t <= Q(-1, 2):
        p, v = ((5+2*t)/8, Q(0), (3-2*t)/8), 4-(5+2*t)**2/16
        multipliers = (Q(0), 2+2*t, Q(0), Q(0), Q(0), (6*t-13)/4)
    elif t <= 0:
        p, v = (Q(1, 2), Q(0), Q(1, 2)), Q(5, 2)-t
        multipliers = (Q(0), -2*t, Q(0), Q(0), 1+2*t, -3+2*t)
    elif t <= Q(9, 5):
        p, v = (Q(1, 2)+t/18, t/18, Q(1, 2)-t/9), Q(5, 2)-t-t*t/18
        multipliers = (Q(0), Q(0), Q(0), Q(0), 1+10*t/9, -3+11*t/6)
    else:
        p, v = (Q(3, 5), Q(1, 10), Q(3, 10)), Q(67, 25)-6*t/5
        multipliers = (Q(0), Q(0), Q(0), 2*t-Q(18, 5), Q(3), Q(3, 10))
    return (*p, v), multipliers


def check_certificate(t, result, multipliers):
    x, y, z, value = result
    a, b, c, d, e, lam = multipliers
    g = (-x, -y, -z, x-Q(3, 5), Q(1, 2)-2*y-z)
    assert x+y+z == 1
    assert all(gi <= 0 for gi in g)
    assert all(mu >= 0 for mu in multipliers[:5])
    assert all(mu*gi == 0 for mu, gi in zip(multipliers[:5], g))
    assert 2*x+y+2-2*t+lam-a+d == 0
    assert 4*y+x-z+5+lam-b-2*e == 0
    assert 6*z-y+1+lam-c-e == 0
    assert objective(t, x, y, z) == value


def check_import():
    source = Path(__file__).with_name("solution.py").read_text()
    compile(source, "solution.py", "exec")
    tree = ast.parse(source)
    assert len(tree.body) == 2
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Constant)
    assert isinstance(tree.body[0].value.value, str)
    function = tree.body[1]
    assert isinstance(function, ast.FunctionDef) and function.name == "solve"
    assert not function.decorator_list and not function.args.defaults
    assert function.returns is None
    # Import in a fresh interpreter with attempted input/file opening blocked.
    code = (
        "import builtins\n"
        "def blocked(*args, **kwargs):\n"
        "    raise AssertionError('unexpected import-time I/O')\n"
        "builtins.open = blocked\n"
        "builtins.input = blocked\n"
        "import solution\n"
    )
    proc = subprocess.run(
        [sys.executable, "-B", "-c", code], input="", text=True,
        capture_output=True, cwd=str(Path(__file__).resolve().parent),
        timeout=10,
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout == proc.stderr == ""


def check_boundaries(transitions):
    # Ascending coefficients of the six value polynomials in solution.md.
    polynomials = (
        (Q(29, 8), Q(0), Q(0)),
        (Q(31, 16), Q(-9, 4), Q(-3, 4)),
        (Q(39, 16), Q(-5, 4), Q(-1, 4)),
        (Q(5, 2), Q(-1), Q(0)),
        (Q(5, 2), Q(-1), Q(-1, 18)),
        (Q(67, 25), Q(-6, 5), Q(0)),
    )
    expected_active = ({0}, {1}, {1, 4}, {1, 4}, {3, 4})
    expected_zero_active = ({0}, {1}, {4}, {1}, {3})
    for i, t in enumerate(transitions):
        a, b, c = polynomials[i]
        d, e, f = polynomials[i+1]
        result, multipliers = exact_formula(t)
        x, y, z, value = result
        assert a+b*t+c*t*t == d+e*t+f*t*t == value
        assert b+2*c*t == e+2*f*t == -2*x
        assert 2*c != 2*f
        g = (-x, -y, -z, x-Q(3, 5), Q(1, 2)-2*y-z)
        active = {j for j, gi in enumerate(g) if gi == 0}
        zero_active = {j for j in active if multipliers[j] == 0}
        assert active == expected_active[i]
        assert zero_active == expected_zero_active[i]
    endpoints = (Q(-2), *transitions, Q(4))
    for i, (left, right) in enumerate(zip(endpoints, endpoints[1:])):
        a, b, c = polynomials[i]
        for t in (left, (left+right)/2, right):
            result, _ = exact_formula(t)
            assert a+b*t+c*t*t == result[3]
            assert b+2*c*t == -2*result[0]


def main():
    check_import()
    assert len(VERTICES) == len(EDGES) == 5
    transitions = (Q(-3, 2), Q(-1), Q(-1, 2), Q(0), Q(9, 5))
    check_boundaries(transitions)
    rationals = {Q(i, 200) for i in range(-400, 801)}
    for t in transitions:
        rationals.add(t)
        for k in (1, 2, 6, 12, 30, 100):
            rationals.update((t-Q(1, 10**k), t+Q(1, 10**k)))
    for t in sorted(rationals):
        result, multipliers = exact_formula(t)
        check_certificate(t, result, multipliers)
        assert result == oracle(t), (t, result, oracle(t))

    floats = {i/1000 for i in range(-2000, 4001)}
    for t in (-2.0, 4.0, *(float(q) for q in transitions)):
        floats.add(t)
        for direction in (-math.inf, math.inf):
            u = t
            for _ in range(64):
                u = math.nextafter(u, direction)
                if -2 <= u <= 4:
                    floats.add(u)
    rng = random.Random(20260910)
    floats.update(rng.uniform(-2, 4) for _ in range(1000))
    coordinate_error = value_error = feasibility_error = 0.0
    for t in sorted(floats):
        actual = solve(t)
        assert isinstance(actual, dict)
        x, y, z, value = (actual[key] for key in ("x", "y", "z", "value"))
        assert all(isinstance(v, (int, float)) and math.isfinite(v)
                   for v in (x, y, z, value))
        expected = tuple(float(v) for v in oracle(Q.from_float(t)))
        err = max(abs(a-b) for a, b in zip((x, y, z), expected[:3]))
        coordinate_error = max(coordinate_error, err)
        value_error = max(value_error, abs(value-expected[3]))
        violation = max(0.0, abs(x+y+z-1), -x, -y, -z,
                        x-0.6, 0.5-2*y-z)
        feasibility_error = max(feasibility_error, violation)
        assert err <= 2e-15, (t, actual, expected)
        assert abs(value-expected[3]) <= 5e-15, (t, actual, expected)
        assert violation <= 5e-16, (t, actual, violation)
        assert value == objective(t, x, y, z)

    invalid = (-3, 5, math.nan, math.inf, -math.inf, 10**1000,
               math.nextafter(-2.0, -math.inf), math.nextafter(4.0, math.inf))
    for t in invalid:
        try:
            solve(t)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid parameter accepted")
    for t in (None, "0", 1+0j, Q(1, 2), [], {}):
        try:
            solve(t)
        except TypeError:
            pass
        else:
            raise AssertionError("unsupported type accepted")
    for t in range(-2, 5):
        assert solve(t) == solve(float(t))

    print("PASS: syntax and silent, I/O-free module import")
    print("PASS: exact oracle enumerated 5 vertices and 5 edges plus interior")
    print(f"PASS: {len(rationals)} exact rational formula, value, and KKT checks")
    print(f"PASS: {len(floats)} float comparisons with exact geometric oracle")
    print("PASS: endpoints, transitions, 64 nextafter steps on each available side")
    print("PASS: exact boundary active sets, zero multipliers, and value C1 matching")
    print("PASS: integer inputs and 14 invalid-input cases")
    print(f"Maximum coordinate absolute error: {coordinate_error:.17g}")
    print(f"Maximum value absolute error: {value_error:.17g}")
    print(f"Maximum constraint violation: {feasibility_error:.17g}")


if __name__ == "__main__":
    main()
