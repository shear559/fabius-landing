import pkg from '[user]/node_modules/playwright/index.js';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:61807');
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const errors = [];
const externalRequests = [];
page.on('pageerror', error => errors.push(error.message));
page.on('request', request => { if (!request.url().startsWith('http://127.0.0.1:61806/')) externalRequests.push(request.url()); });
const results = [];
function passed(message) { results.push(message); console.log('PASS ' + message); }
try {
  await page.goto('http://127.0.0.1:61806/', {waitUntil: 'networkidle'});
  await assertLayout(page, 1440);
  assert(await page.locator('.desktop-nav').isVisible());
  assert(!(await page.getByTestId('menu-toggle').isVisible()));
  passed('1440px layout: no horizontal overflow; desktop navigation visible');
  await page.screenshot({path:'desktop.png', fullPage:true});
  for (const name of ['capture', 'connect', 'export']) {
    await page.getByTestId('feature-' + name).click();
    assert.equal(await page.getByTestId('feature-' + name).getAttribute('aria-selected'), 'true');
    for (const other of ['capture', 'connect', 'export']) assert.equal(await page.getByTestId('panel-' + other).isVisible(), other === name);
  }
  await page.getByTestId('feature-capture').focus();
  await page.keyboard.press('ArrowLeft');
  assert(await page.getByTestId('feature-export').evaluate(el => el === document.activeElement && el.getAttribute('aria-selected') === 'true'));
  await page.keyboard.press('ArrowRight');
  assert(await page.getByTestId('feature-capture').evaluate(el => el === document.activeElement));
  await page.keyboard.press('End');
  assert(await page.getByTestId('feature-export').evaluate(el => el === document.activeElement));
  await page.keyboard.press('Home');
  assert(await page.getByTestId('feature-capture').evaluate(el => el === document.activeElement));
  passed('All feature panels switch exclusively; tab ARIA, arrow wraparound, Home and End work');
  await page.getByTestId('billing-yearly').click();
  assert.equal(await page.getByTestId('price-solo').textContent(), '$108');
  assert.equal(await page.getByTestId('price-studio').textContent(), '$264');
  assert.deepEqual(await page.locator('.price-period').allTextContents(), ['/ year', '/ year']);
  assert.equal(await page.getByTestId('billing-yearly').getAttribute('aria-pressed'), 'true');
  await page.getByTestId('billing-monthly').click();
  assert.equal(await page.getByTestId('price-solo').textContent(), '$12');
  assert.equal(await page.getByTestId('price-studio').textContent(), '$29');
  assert.deepEqual(await page.locator('.price-period').allTextContents(), ['/ month', '/ month']);
  assert.equal(await page.getByTestId('billing-monthly').getAttribute('aria-pressed'), 'true');
  passed('Yearly prices and period labels update; exact monthly values restore');
  assert.equal(await page.locator('details').count(), 4);
  for (let i = 0; i < 4; i++) {
    await page.getByTestId('faq-' + i).focus();
    await page.keyboard.press('Enter');
    assert(await page.getByTestId('faq-' + i).evaluate(el => el.parentElement.open));
    await page.keyboard.press('Enter');
    assert(!(await page.getByTestId('faq-' + i).evaluate(el => el.parentElement.open)));
  }
  passed('All four native FAQs open and close with the keyboard');
  const invalidAnchors = await page.locator('a[href^="#"]').evaluateAll(links => links.filter(a => a.hash && !document.getElementById(a.hash.slice(1))).map(a => a.getAttribute('href')));
  assert.deepEqual(invalidAnchors, []);
  await page.getByRole('link', {name:'Explore the workflow', exact:true}).first().click();
  await page.waitForTimeout(700);
  assert.equal(new URL(page.url()).hash, '#workflow');
  passed('Every section anchor resolves; primary CTA navigates to workflow');
  await page.setViewportSize({width:360, height:800});
  await page.goto('http://127.0.0.1:61806/', {waitUntil:'networkidle'});
  await assertLayout(page, 360);
  const toggle = page.getByTestId('menu-toggle');
  const nav = page.getByTestId('mobile-nav');
  assert(await toggle.isVisible());
  assert(!(await nav.isVisible()));
  await toggle.click();
  assert(await nav.isVisible());
  assert.equal(await toggle.getAttribute('aria-expanded'), 'true');
  await nav.locator('a').first().focus();
  await page.keyboard.press('Escape');
  assert(!(await nav.isVisible()));
  assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
  assert(await toggle.evaluate(el => el === document.activeElement));
  await toggle.click();
  await toggle.click();
  assert(!(await nav.isVisible()));
  await toggle.click();
  await nav.getByRole('link', {name:'Pricing', exact:true}).click();
  assert(!(await nav.isVisible()));
  assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
  assert.equal(new URL(page.url()).hash, '#pricing');
  passed('360px mobile navigation: toggle, ARIA, Escape focus return and link close work');
  await page.goto('http://127.0.0.1:61806/', {waitUntil:'networkidle'});
  await page.screenshot({path:'mobile.png', fullPage:true});
  for (const width of [390, 620, 621, 768, 1024]) {
    await page.setViewportSize({width, height:900});
    await assertLayout(page, width);
  }
  passed('No horizontal overflow at 360, 390, 620, 621, 768, 1024 and 1440px');
  await page.emulateMedia({reducedMotion:'reduce'});
  assert.equal(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior), 'auto');
  passed('Reduced motion disables smooth scrolling');
  assert.deepEqual(errors, []);
  assert.deepEqual(externalRequests, []);
  passed('No JavaScript errors or external page requests');
  const noJs = await browser.newContext({javaScriptEnabled:false, viewport:{width:360,height:800}});
  try {
    const fallback = await noJs.newPage();
    await fallback.goto('http://127.0.0.1:61806/');
    await assertLayout(fallback, 360);
    assert(await fallback.locator('.desktop-nav').isVisible());
    for (const name of ['capture','connect','export']) assert(await fallback.getByTestId('panel-' + name).isVisible());
    assert.equal(await fallback.getByTestId('price-solo').textContent(), '$12');
    assert.equal(await fallback.getByTestId('price-studio').textContent(), '$29');
    assert.deepEqual(await fallback.locator('.annual-reference').allTextContents(), ['Or $108 per year with yearly billing.', 'Or $264 per year with yearly billing.']);
    await fallback.getByTestId('faq-2').click();
    assert(await fallback.getByTestId('faq-2').evaluate(el => el.parentElement.open));
    await fallback.locator('.desktop-nav a[href="#workflow"]').click();
    assert.equal(new URL(fallback.url()).hash,'#workflow');
    passed('JavaScript disabled at 360px: navigation, all features, both billing prices and native FAQs remain usable');
  } finally { await noJs.close(); }
  // A temporary nested copy exercises real relative CSS and script resolution.
  await fs.mkdir('nested-check', {recursive:true});
  for (const file of ['index.html','styles.css','app.js']) await fs.copyFile(file,'nested-check/' + file);
  try {
    await page.goto('http://127.0.0.1:61806/nested-check/', {waitUntil:'networkidle'});
    assert.equal(await page.evaluate(() => getComputedStyle(document.body).backgroundColor), 'rgb(247, 247, 240)');
    await page.getByTestId('billing-yearly').click();
    assert.equal(await page.getByTestId('price-solo').textContent(), '$108');
    passed('Nested URL path loads relative stylesheet and working JavaScript');
  } finally { await fs.rm('nested-check', {recursive:true}); }
  await fs.writeFile('verification-results.txt', results.map(r=>'PASS ' + r).join('\n') + '\n');
} finally {
  await context.close();
  await browser.close();
}
async function assertLayout(page, width) {
  const dimensions = await page.evaluate(() => ({scroll:document.documentElement.scrollWidth, client:document.documentElement.clientWidth}));
  assert(dimensions.scroll <= width, JSON.stringify({width,...dimensions}));
}
