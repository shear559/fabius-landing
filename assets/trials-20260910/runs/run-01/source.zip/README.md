# Lattice

A complete, responsive landing page for a **fictional local-first research notebook**. Built with vanilla HTML, CSS, and JavaScript. No build step, runtime dependencies, remote assets, backend, analytics, signup, contact form, or payment processing.

## Run

Serve this directory with any static HTTP server and open `index.html` (or the directory URL).

For example, with Python already installed:

```sh
python3 -m http.server 8080
```

Then visit `http://localhost:8080/`. Stop the server with Ctrl+C when finished. This implementation was verified using the supplied static server at `http://127.0.0.1:61806/`; no additional server was started.

The three runtime files can also be copied together into a nested directory. Styles and scripts use `./` relative URLs; all navigation uses local section anchors. No routing configuration is needed.

## Files

- `index.html` — complete content, inline SVG icons, original HTML/CSS notebook illustrations, navigation, feature tabs, pricing, and four native FAQs.
- `styles.css` — responsive visual system, component styles, visible keyboard focus, and reduced-motion overrides.
- `app.js` — mobile navigation, keyboard-operable feature tabs, and billing controls.
- `verify.mjs` — browser verification script using the explicitly supplied Playwright and Chrome resources. This is a development check, not a runtime dependency.
- `verification-results.txt` — checks that passed during this run.
- `desktop.png`, `mobile.png` — full-page screenshots at 1440px and 360px.
- `desktop-detail.png`, `mobile-detail.png` — viewport screenshots used for a closer visual review.

## Implementation decisions

The design uses warm paper, forest green, a restrained clay accent, and a system serif/sans-serif pairing. A custom lattice mark, notebook window, source card, template sheets, and workflow miniatures are drawn directly in HTML, CSS, and inline SVG. No image downloads or external fonts are required.

Content follows the supplied fictional product facts. Both pricing plans and their feature grouping are illustrative, and the page explicitly identifies itself as a fictional demonstration. Calls to action explore real sections of the page rather than implying a working signup or checkout.

The mobile menu is a disclosure below the header. It synchronizes `aria-expanded`, closes on link selection, and closes on Escape while returning focus to the toggle. It also resets when leaving the mobile breakpoint.

Feature tabs use tablist/tab/tabpanel semantics, automatic activation, and roving focus. Left/Right arrows wrap between tabs; Home/End select the first/last tab. Only the active panel is visible with JavaScript enabled. Every panel remains visible without JavaScript.

Billing buttons announce pressed state and update the displayed totals and actual billing period: Solo $12/month or $108/year; Studio $29/month or $264/year. Alternative billing prices remain explicitly listed. Prices are never presented as monthly equivalents of an annual total.

JavaScript enhances the initial HTML. Without it, the normal navigation remains available at mobile sizes, all three feature panels are readable, both price options are listed, and native FAQs still work. Billing and mobile-menu controls only appear after enhancement.

There is a skip link, named navigation regions, visible focus styling, labeled controls, and descriptions for the illustrative UI. Reduced-motion preferences disable smooth scrolling and transitions.

## Checks actually executed

The main browser checks were run with the provided isolated Chrome through Playwright. They were repeated after the readability refinements.

- `node --check app.js` passed.
- `node verify.mjs` passed all assertions.
- No horizontal overflow at 360, 390, 620, 621, 768, 1024, and 1440px.
- Desktop navigation is visible at 1440px; the mobile toggle is visible at 360px.
- Mobile menu opens and closes via the button, updates ARIA, closes on navigation, and returns focus after Escape.
- Every feature tab selects only its corresponding panel. Arrow wraparound, Home, End, selected state, and focus movement passed.
- Yearly prices become exactly $108 and $264 with `/ year` labels; switching back restores exactly $12 and $29 with `/ month` labels.
- All four native FAQs open and close using Enter.
- Every section anchor resolves. The primary CTA reaches `#workflow`.
- Reduced-motion emulation produces non-smooth scrolling.
- No JavaScript page errors or external page requests were observed during the main interaction checks.
- With JavaScript disabled at 360px: navigation, all feature panels, both billing prices, and the native backup FAQ remain available and functional.
- A temporary nested copy at `/nested-check/` loaded its relative stylesheet and working billing script. That test copy was removed afterward.
- Additional browser assertions passed for visible keyboard focus, the skip link, both alternate feature panels at 360px, and yearly pricing at 360px.
- A Python standard-library HTML parser check passed for unique IDs, valid ARIA references, existing relative stylesheet/script paths, and absence of a form.
- Full-page desktop/mobile screenshots and close-up hero screenshots were generated and visually reviewed. Supporting text sizes and contrast were refined during that review.

To replay the main checks **in the supplied environment**, leave its static server and isolated Chrome available and run `node verify.mjs`. The script uses the provided absolute Playwright import and CDP endpoint, creates its own browser contexts, and closes them when finished. It will refresh the full-page screenshots and main verification log. Additional one-off focus and parser checks are documented above.

## Known limitations

This is a marketing demonstration, not a notebook application. Notebook previews are illustrative; they do not edit, store, search, or export notes. Plan links explore the page and do not create accounts or initiate purchases.

Browser verification covered the supplied Chromium instance, including a JavaScript-disabled context. Safari, Firefox, physical devices, and screen-reader software were not tested. The illustrations contain intentionally small decorative text; their meaningful descriptions and the product explanation are available as normal page content.
