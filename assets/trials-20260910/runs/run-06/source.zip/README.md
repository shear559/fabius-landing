# Fieldnote Board

A fictional studio's local-first task board. The dashboard uses warm paper tones, forest green actions, a project sidebar, and three status columns. At 360px the columns stack into a readable single-column board. All fonts, icons, and application code are local; no build, installation, account, backend, or API is required.

## Run

Serve this directory with any static HTTP server, for example:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Open `http://127.0.0.1:8000/`. Stop that server with Ctrl+C when finished. You can also copy `index.html`, `styles.css`, and `app.js` into any nested directory on a static server. Asset paths are relative. Modern browsers supporting native `dialog`, localStorage, and File/Blob APIs are required.

## Using the board

Create a task with **New task** or a column's **Add task** button. Every card provides Edit, Delete, and a native status select. The task editor supports Tab/Shift+Tab, Escape, and focus restoration. Search matches title, project, and tags without case sensitivity; it combines with all three filters. The visible count reports matching and total tasks, while the overview always describes the full board.

Export downloads every task, including tasks hidden by filters. Import validates the entire file, then asks explicitly before replacing the board. Corrupt data recovery offers an original-data download and a reset that also requires confirmation. There is a JavaScript-disabled explanation and a reduced-motion stylesheet rule.

## Data and failure handling

- The only application storage key is `fieldnote-board:v1`, containing `{ "schemaVersion": 1, "tasks": [...] }`. Tasks contain exactly `id`, `title`, `project`, `status`, `priority`, `dueDate`, and `tags`.
- Seven fictional tasks spanning two projects and all three statuses are seeded only when the storage key is absent. A valid empty task array stays empty. Empty-string storage is corruption, not absence. An unreadable storage API starts an explicitly unsaved, empty in-memory board.
- Both forms and imports validate field types, lengths, enums, and calendar dates, including leap years. Imports reject duplicate IDs and missing/extra task fields. Files larger than 1,048,576 bytes are rejected before reading; exactly 1 MiB is allowed. All tasks are validated before any replacement. IDs use `crypto.randomUUID()` where available, with a checked fallback.
- Form titles/projects are trimmed. Comma-separated tags are trimmed, empty pieces removed, and duplicates removed case-insensitively while preserving the first spelling. When editing an imported task without changing its tag field, the exact original tag array is preserved, including tags containing commas.
- Imported content is rendered with text nodes and `textContent`. The only HTML insertion is for fixed, application-owned SVG icons.
- A successful change writes the full versioned board while preserving unrelated records. On write failure the changed board remains in memory, a prominent notice states that it is not saved, and **Export backup** / **Try saving again** remain available. Persistence is never reported as successful after a failed write.
- Corrupt startup content is retained unchanged and downloadable as UTF-8 text. Startup never repairs, replaces, or seeds over it. Reset and valid import are explicit replacement operations.
- Storage events pause edits when another tab changes or clears the board. Each mutation also compares the current storage bytes with the last observed bytes, including before/after an import confirmation. A conflict blocks task creation, editing, deletion, status changes, undo, and import until **Reload board** is chosen. Export remains available. Reload asks again before discarding unsaved in-memory changes.
- Undo restores the exact most recently deleted record at its prior position and saves it. Once restored, it survives reload. The pending undo itself lasts only within the current page session, until another deletion, import/reset, or dismissal.

## Verification

The browser checks use only the supplied isolated Chrome/CDP resource and provisioned Playwright package. Each script creates and closes its own browser contexts; storage changes for failure simulation are confined to those contexts. The harness is specific to this evaluation environment and is not an application dependency. Run the two browser scripts sequentially because they share one Chrome instance:

```sh
node --check app.js
node checks/verify.mjs
node checks/edge-cases.mjs
```

Final verification passed: **44 main workflow checks and 30 edge-case checks (74 total)**, plus the JavaScript syntax check. Executed checks and their final results are in `checks/results.json` and `checks/edge-results.json`. They cover CRUD and record preservation, tag normalization, date/text validation, undo after reload, combined filters, full-board export, import cancellation and atomic rejection, confirmed imports, HTML-as-text rendering, corrupt-data preservation/download/reset, write failures and memory backups, explicit conflict reloads, inaccessible storage, keyboard focus, reduced motion, disabled JavaScript, relative nested-path assets, and viewport overflow. No application JavaScript errors or external resource requests were observed in the main suite.

Screenshots inspected:

- `checks/desktop.png` — 1440px desktop, full board.
- `checks/mobile.png` — 360px mobile, full board.
- `checks/mobile-form.png` — 360px task editor.

## Limits

This is a local-only demonstration: there is no team synchronization, authentication, cloud backup, or server persistence. localStorage belongs to the browser profile and origin; copies served at different paths on the same origin intentionally share this key. Clearing browser data removes saved work. Export is the portable backup mechanism. Failed writes cannot survive closing/reloading unless exported or successfully retried. Form drafts and pending undo are not persisted. Import/reset replace the board after confirmation and are not undoable. Dates are calendar dates without time zones or reminders. Automated browser verification was performed in Chrome; other browser engines and assistive technologies were not independently tested. No background server was started or left running by this implementation.
