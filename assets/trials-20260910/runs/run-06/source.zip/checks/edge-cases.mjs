import pkg from '[user]/node_modules/playwright/index.js';
import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:60696');
const base = 'http://127.0.0.1:60695/', key = 'fieldnote-board:v1';
const contexts = [], results = [];
const pass = (name, value) => { assert.ok(value, name); results.push(name); console.log('PASS', name); };
async function make(options = {}) { const c = await browser.newContext(options); contexts.push(c); return c; }
const raw = p => p.evaluate(k => localStorage.getItem(k), key);
const board = async p => JSON.parse(await raw(p));
async function upload(p, value, confirm = true) {
 const handler = d => confirm ? d.accept() : d.dismiss(); p.once('dialog', handler);
 await p.getByTestId('import-file').setInputFiles({ name: 'test.json', mimeType: 'application/json', buffer: Buffer.from(typeof value === 'string' ? value : JSON.stringify(value)) });
 await p.waitForTimeout(100); p.off('dialog', handler);
}
try {
 const c = await make({ viewport: { width: 360, height: 800 }, reducedMotion: 'reduce', acceptDownloads: true }); const p = await c.newPage(); await p.goto(base);
 const original = await board(p), initial = await raw(p);
 const source = original.tasks[0];
 const invalids = [
  ['Empty ID', { ...source, id: '' }], ['Overlong ID', { ...source, id: 'x'.repeat(81) }],
  ['Missing field', Object.fromEntries(Object.entries(source).filter(([k]) => k !== 'tags'))],
  ['Extra task field', { ...source, other: 'ignored?' }], ['Whitespace title', { ...source, title: '  ' }],
  ['Untrimmed project', { ...source, project: ' test ' }], ['Overlong project', { ...source, project: 'x'.repeat(81) }],
  ['Nonarray tags', { ...source, tags: 'tag' }], ['Too many tags', { ...source, tags: Array.from({length:9}, (_,i)=>`tag${i}`) }],
  ['Blank tag', { ...source, tags: [''] }], ['Overlong tag', { ...source, tags: ['x'.repeat(25)] }],
  ['Nonstring due date', { ...source, dueDate: null }], ['Invalid month', { ...source, dueDate: '2026-13-01' }]
 ];
 for (const [name, task] of invalids) { await upload(p, { schemaVersion: 1, tasks: [task] }); pass(`${name} import is rejected atomically`, await raw(p) === initial); }
 await upload(p, { schemaVersion: 1, tasks: [{ ...source, id: ' ID with surrounding spaces ', tags: ['a,b', 'Design', 'design'], dueDate: '2000-02-29' }] });
 await p.getByTestId('task-card').locator('[data-action="edit"]').click(); await p.locator('[name="title"]').fill('Changed title only'); await p.getByTestId('save-task').click();
 pass('Editing preserves untouched imported comma tags and valid ID bytes', JSON.stringify((await board(p)).tasks[0].tags) === JSON.stringify(['a,b','Design','design']) && (await board(p)).tasks[0].id === ' ID with surrounding spaces ');
 const empty = JSON.stringify({ schemaVersion: 1, tasks: [] }); await upload(p, empty + ' '.repeat(1048576 - Buffer.byteLength(empty)));
 pass('Exactly 1 MiB valid document is accepted', (await board(p)).tasks.length === 0);
 await upload(p, original);
 await p.getByTestId('create-task').click();
 await p.locator('[name="title"]').fill('Validation task'); await p.locator('[name="project"]').fill('x'.repeat(81)); await p.getByTestId('save-task').click();
 pass('Form rejects overlong project visibly', (await p.locator('#form-error').textContent()).includes('80'));
 await p.locator('[name="project"]').fill('Project'); await p.locator('[name="tags"]').fill('x'.repeat(25)); await p.getByTestId('save-task').click();
 pass('Form rejects overlong tag visibly', (await p.locator('#form-error').textContent()).includes('24'));
 await p.locator('[name="tags"]').fill('a,b,c,d,e,f,g,h,i'); await p.getByTestId('save-task').click();
 pass('Form rejects more than eight tags visibly', (await p.locator('#form-error').textContent()).includes('8'));
 await p.locator('[name="tags"]').fill('a,A,b'); await p.getByTestId('save-task').click();
 await p.getByTestId('create-task').click(); await p.locator('[name="title"]').fill('Another task'); await p.locator('[name="project"]').fill('Project'); await p.getByTestId('save-task').click();
 const ids = (await board(p)).tasks.map(t=>t.id); pass('Repeated creation generates unique IDs', ids.length === new Set(ids).size && ids.every(id=>id.length && id.length<=80));
 await p.getByTestId('task-card').first().locator('[data-action="edit"]').click();
 for(let i=0;i<18;i++) { await p.keyboard.press('Tab'); assert.ok(await p.evaluate(()=>document.querySelector('dialog').contains(document.activeElement)), 'Modal contains keyboard focus'); }
 await p.keyboard.press('Escape');
 pass('Modal traps Tab focus and returns focus to Edit on Escape', await p.getByTestId('task-card').first().locator('[data-action="edit"]').evaluate(e=>e===document.activeElement));
 pass('Reduced-motion preference suppresses transitions', await p.getByTestId('create-task').evaluate(e=>getComputedStyle(e).transitionDuration==='0s'));
 const issues = await p.locator('button,input,select').evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length && !n.disabled).filter(n=>!n.getAttribute('aria-label') && !n.getAttribute('aria-labelledby') && !(n.labels?.length) && !n.textContent.trim()).map(n=>n.outerHTML));
 pass('Every visible enabled control has an accessible naming source', issues.length===0);
 const beforeFail = await raw(p);
 await p.evaluate(()=>{ window.originalSetItem=Storage.prototype.setItem; Storage.prototype.setItem=function(){throw new DOMException('test','QuotaExceededError')}; });
 await p.getByTestId('task-card').first().locator('[data-action="delete"]').click();
 await p.getByTestId('undo-delete').click();
 pass('Undo stays usable while writes fail', await raw(p)===beforeFail && await p.getByTestId('task-card').count()===9);
 await p.getByTestId('task-card').first().locator('[data-action="status"]').selectOption('done');
 const waitDownload = p.waitForEvent('download'); await p.getByRole('button',{name:'Export backup',exact:true}).click(); const downloaded=await waitDownload;
 let text='';for await (const chunk of await downloaded.createReadStream()) text+=chunk;
 pass('Backup export contains unsaved in-memory changes', JSON.parse(text).tasks[0].status==='done' && JSON.parse(await raw(p)).tasks[0].status!=='done');
 await p.evaluate(()=>{Storage.prototype.setItem=window.originalSetItem}); await p.getByRole('button',{name:'Try saving again',exact:true}).click();
 pass('Retry persists memory changes when storage recovers', (await board(p)).tasks[0].status==='done' && (await p.locator('#save-state').textContent()).includes('All changes saved'));
 const tab=await c.newPage();await tab.goto(base);await tab.evaluate(()=>localStorage.clear());await p.waitForTimeout(100);
 pass('External storage clear blocks stale mutation', await p.getByTestId('create-task').isDisabled());
 await p.getByRole('button',{name:'Reload board',exact:true}).click();
 pass('Explicit reload after external clear seeds genuinely empty storage', (await board(p)).tasks.length===7);
 const blocked=await make();await blocked.addInitScript(()=>{Storage.prototype.getItem=function(){throw new DOMException('denied','SecurityError')};Storage.prototype.setItem=function(){throw new DOMException('denied','SecurityError')};});
 const bp=await blocked.newPage();await bp.goto(base);
 pass('Unreadable storage does not silently seed', await bp.getByTestId('task-card').count()===0 && (await bp.locator('#notice-area').textContent()).includes('could not be read'));
 await bp.getByTestId('create-task').click();await bp.locator('[name="title"]').fill('Memory only');await bp.locator('[name="project"]').fill('Recovery');await bp.getByTestId('save-task').click();
 pass('Fully unavailable storage still supports recoverable memory work', await bp.getByTestId('task-card').count()===1 && (await bp.locator('#save-state').textContent()).includes('Not saved'));
 const cc=await make();const cp=await cc.newPage();await cp.goto(base);await cp.evaluate(k=>localStorage.setItem(k,''),key);await cp.reload();
 pass('Empty-string corrupt storage is not treated as absent', await raw(cp)==='' && (await cp.locator('#notice-area').textContent()).includes('needs recovery'));
 await writeFile('checks/edge-results.json',JSON.stringify({passed:results.length,checks:results},null,2));
}finally{for(const c of contexts)await c.close();await browser.close();}
