"""Reproducible standard-library checks: run python3 verify.py."""

from fractions import Fraction as Q
from itertools import combinations
import ast
import math
from pathlib import Path
import random
import subprocess
import sys

from solution import solve

# Independent geometric oracle for F(x,y): A_i (x,y) <= c_i.
CONSTRAINTS = [(Q(-1), Q(0), Q(0)), (Q(0), Q(-1), Q(0)),
               (Q(1), Q(1), Q(1)), (Q(1), Q(0), Q(3, 5)),
               (Q(1), Q(-1), Q(1, 2))]


def feasible(p):
    return all(a*p[0] + b*p[1] <= c for a, b, c in CONSTRAINTS)


def linear_solve(a, b, c, d, u, v):
    determinant = a*d - b*c
    if not determinant:
        return None
    return ((u*d-b*v)/determinant, (a*v-u*c)/determinant)


def vertices():
    result = set()
    for (a, b, u), (c, d, v) in combinations(CONSTRAINTS, 2):
        p = linear_solve(a, b, c, d, u, v)
        if p is not None and feasible(p):
            result.add(p)
    return sorted(result)


VERTICES = vertices()
EDGES = []
for a, b, c in CONSTRAINTS:
    endpoints = [p for p in VERTICES if a*p[0] + b*p[1] == c]
    assert len(endpoints) == 2, endpoints
    EDGES.append(tuple(endpoints))
assert len(VERTICES) == 5


def objective(t, p):
    x, y = p[:2]
    z = 1-x-y
    return x*x + 2*y*y + 3*z*z + x*y - y*z + (2-2*t)*x + 5*y + z


def oracle(t):
    """Exact minimum over vertices, all edge stationary points, and interior."""
    t = Q(t)
    candidates = list(VERTICES)
    p = linear_solve(Q(8), Q(8), Q(8), Q(12), 5+2*t, Q(3))
    if feasible(p):
        candidates.append(p)
    for a, b in EDGES:
        dx, dy = b[0]-a[0], b[1]-a[1]
        gx, gy = 8*a[0]+8*a[1]-5-2*t, 8*a[0]+12*a[1]-3
        curvature = 8*dx*dx + 16*dx*dy + 12*dy*dy
        s = max(Q(0), min(Q(1), -(gx*dx+gy*dy)/curvature))
        candidates.append((a[0]+s*dx, a[1]+s*dy))
    p = min(candidates, key=lambda point: objective(t, point))
    return (*p, 1-p[0]-p[1]), objective(t, p)


# Exact transcription of the document, kept separate from the geometric oracle.
BOUNDS = list(map(Q, [-2])) + [Q(-3, 2), Q(-1), Q(-1, 2), Q(0), Q(9, 5), Q(4)]
POINTS = [
    [(0, 0), (Q(1, 4), 0), (Q(3, 4), 0)],
    [(Q(9, 8), Q(3, 4)), (Q(-1, 2), Q(-1, 2)), (Q(3, 8), Q(-1, 4))],
    [(Q(5, 8), Q(1, 4)), (0, 0), (Q(3, 8), Q(-1, 4))],
    [(Q(1, 2), 0), (0, 0), (Q(1, 2), 0)],
    [(Q(1, 2), Q(1, 18)), (0, Q(1, 18)), (Q(1, 2), Q(-1, 9))],
    [(Q(3, 5), 0), (Q(1, 10), 0), (Q(3, 10), 0)],
]
VALUES = [(Q(29, 8), 0, 0), (Q(31, 16), Q(-9, 4), Q(-3, 4)),
          (Q(39, 16), Q(-5, 4), Q(-1, 4)), (Q(5, 2), -1, 0),
          (Q(5, 2), -1, Q(-1, 18)), (Q(67, 25), Q(-6, 5), 0)]
ZERO = (0, 0)
# lambda, alpha, beta, gamma, mu, nu, each constant + slope*t.
MULTIPLIERS = [
    [(Q(-21, 4), 0), (-3, -2), ZERO, ZERO, ZERO, ZERO],
    [(Q(-15, 4), 1), ZERO, ZERO, ZERO, ZERO, ZERO],
    [(Q(-13, 4), Q(3, 2)), ZERO, (2, 2), ZERO, ZERO, ZERO],
    [(-3, 2), ZERO, (0, -2), ZERO, ZERO, (1, 2)],
    [(-3, Q(11, 6)), ZERO, ZERO, ZERO, ZERO, (1, Q(10, 9))],
    [(Q(3, 10), 0), ZERO, ZERO, ZERO, (Q(-18, 5), 2), (3, 0)],
]


def formula(t, i=None):
    t = Q(t)
    if i is None:
        i = next(i for i in range(6) if BOUNDS[i] <= t <= BOUNDS[i+1])
    p = tuple(a+b*t for a, b in POINTS[i])
    a, b, c = VALUES[i]
    return p, a+b*t+c*t*t, tuple(a+b*t for a, b in MULTIPLIERS[i])


def check_certificate(t, i):
    (x, y, z), value, m = formula(t, i)
    lam, alpha, beta, gamma, mu, nu = m
    assert x+y+z == 1
    g = (-x, -y, -z, x-Q(3, 5), Q(1, 2)-2*y-z)
    assert all(v <= 0 for v in g)
    assert all(v >= 0 for v in m[1:])
    assert all(a*b == 0 for a, b in zip(g, m[1:]))
    assert 2*x+y+2-2*t+lam-alpha+mu == 0
    assert 4*y+x-z+5+lam-beta-2*nu == 0
    assert 6*z-y+1+lam-gamma-nu == 0
    assert objective(t, (x, y, z)) == value
    _, b, c = VALUES[i]
    assert b+2*c*t == -2*x


def main():
    # Affine signs are determined at endpoints; degree <= 2 identities at
    # three distinct exact points establish each whole polynomial identity.
    for i in range(6):
        a, b = BOUNDS[i:i+2]
        for t in (a, (a+b)/2, b):
            check_certificate(t, i)
    for i, t in enumerate(BOUNDS[1:-1]):
        assert formula(t, i) == formula(t, i+1)
        d_left = VALUES[i][1]+2*VALUES[i][2]*t
        d_right = VALUES[i+1][1]+2*VALUES[i+1][2]*t
        assert d_left == d_right
    expected_active = [{0}, {1}, {1, 4}, {1, 4}, {3, 4}]
    for t, expected in zip(BOUNDS[1:-1], expected_active):
        (x, y, z), _, _ = formula(t)
        g = (-x, -y, -z, x-Q(3, 5), Q(1, 2)-2*y-z)
        assert {i for i, v in enumerate(g) if v == 0} == expected
    print('Exact certificates: 6 full regimes; 5 boundary matches and active sets PASS')

    rng = random.Random(20260910)
    rationals = {Q(-2)+Q(6*k, 600) for k in range(601)}
    rationals.update(BOUNDS)
    for _ in range(600):
        denominator = rng.randint(1, 10000)
        rationals.add(Q(rng.randint(-2*denominator, 4*denominator), denominator))
    for t in BOUNDS[1:-1]:
        for exponent in (1, 4, 12, 30, 100):
            rationals.update((t-Q(1, 10**exponent), t+Q(1, 10**exponent)))
    for t in rationals:
        p, v, _ = formula(t)
        assert (p, v) == oracle(t), t
    print(f'Exact geometric oracle: {len(rationals)} rational parameters PASS')

    floats = {float(t) for t in rationals}
    floats.update(-2+6*k/2000 for k in range(2001))
    floats.update(rng.uniform(-2, 4) for _ in range(1000))
    for boundary in BOUNDS:
        t = float(boundary)
        floats.add(t)
        for direction in (-math.inf, math.inf):
            u = t
            for _ in range(8):
                u = math.nextafter(u, direction)
                if -2 <= u <= 4:
                    floats.add(u)
    floats.update((-1e-300, 1e-300, -1e-100, 1e-100, -0.0))
    max_coordinate_error = max_value_error = max_feasibility_error = 0.0
    for t in sorted(floats):
        result = solve(t)
        assert isinstance(result, dict)
        assert all(math.isfinite(result[k]) for k in ('x', 'y', 'z', 'value'))
        p, v = oracle(Q.from_float(t))
        actual = tuple(result[k] for k in ('x', 'y', 'z'))
        coordinate_error = max(abs(a-float(b)) for a, b in zip(actual, p))
        value_error = abs(result['value']-float(v))
        x, y, z = actual
        feasibility_error = max(abs(x+y+z-1), -x, -y, -z, x-0.6, 0.5-2*y-z, 0)
        assert coordinate_error <= 3e-15, (t, result, p)
        assert value_error <= 1e-14, (t, result, v)
        assert feasibility_error <= 5e-16, (t, result)
        max_coordinate_error = max(max_coordinate_error, coordinate_error)
        max_value_error = max(max_value_error, value_error)
        max_feasibility_error = max(max_feasibility_error, feasibility_error)
    for t in range(-2, 5):
        assert solve(t) == solve(float(t))
    for t in (-3, 5, math.nan, math.inf, -math.inf, 10**1000):
        try:
            solve(t)
        except ValueError:
            pass
        else:
            raise AssertionError(('accepted invalid parameter', t))
    for t in (None, '0', True, 1j, Q(1, 2)):
        try:
            solve(t)
        except TypeError:
            pass
        else:
            raise AssertionError(('accepted invalid type', t))
    print(f'Floating-point geometric oracle: {len(floats)} parameters PASS')
    print(f'Max coordinate error: {max_coordinate_error:.17g}')
    print(f'Max value error: {max_value_error:.17g}')
    print(f'Max feasibility residual: {max_feasibility_error:.17g}')
    print('Integer inputs and invalid-input handling PASS')

    directory = Path(__file__).resolve().parent
    process = subprocess.run([sys.executable, '-B', '-c', 'import solution'],
                             cwd=directory, stdin=subprocess.DEVNULL,
                             capture_output=True, text=True, check=True)
    assert process.stdout == process.stderr == ''
    tree = ast.parse((directory/'solution.py').read_text())
    assert all(isinstance(node, (ast.Expr, ast.Import, ast.FunctionDef)) for node in tree.body)
    assert all(isinstance(node.value, ast.Constant) for node in tree.body if isinstance(node, ast.Expr))
    assert [alias.name for node in tree.body if isinstance(node, ast.Import)
            for alias in node.names] == ['math']
    assert all(not node.decorator_list and not node.args.defaults and not node.args.kw_defaults
               for node in tree.body if isinstance(node, ast.FunctionDef))
    print('Quiet import and absence of module-level I/O/CLI execution PASS')
    print('ALL CHECKS PASSED')


if __name__ == '__main__':
    main()
