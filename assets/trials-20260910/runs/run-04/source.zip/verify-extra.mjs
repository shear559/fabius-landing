import pkg from '[user]/node_modules/playwright/index.js';
import fs from 'node:fs/promises';
const {chromium}=pkg;
const browser=await chromium.connectOverCDP('http://127.0.0.1:62412');
const origin='http://127.0.0.1:62411';const KEY='fieldnote-board:v1';const checks=[];
const check=(v,s)=>{if(!v)throw Error(s);checks.push(s);};
const ctx=await browser.newContext({viewport:{width:1440,height:1000}});
let noJS;
try{
 const page=await ctx.newPage();await page.goto(origin);
 const first=page.getByTestId('task-card').first();const id=await first.getAttribute('data-task-id');
 await first.locator('[data-action=edit]').click();await page.locator('[name=title]').fill('Focus restoration check');await page.getByTestId('save-task').click();
 await page.waitForFunction(()=>document.activeElement.dataset.action==='edit');
 check(await page.evaluate(id=>document.activeElement.dataset.action==='edit'&&document.activeElement.closest('[data-task-id]').dataset.taskId===id,id),'Editing restores focus to the replacement card edit button');
 await page.locator(`[data-task-id="${id}"] [data-action=status]`).selectOption('doing');
 check(await page.evaluate(()=>document.activeElement.dataset.action==='status'),'Changing status keeps keyboard focus on the moved card');
 await page.getByTestId('create-task').click();await page.getByTestId('save-task').focus();await page.keyboard.press('Tab');check(await page.locator('#close-dialog').evaluate(n=>n===document.activeElement),'Native modal traps forward Tab');await page.keyboard.press('Escape');
 const stored=await page.evaluate(k=>localStorage.getItem(k),KEY);const task=JSON.parse(stored).tasks[0];
 const variants=[{status:['todo']},{priority:'urgent'},{dueDate:'1900-02-29'},{dueDate:'2026-04-31'},{dueDate:'0000-01-01'},{id:''},{id:'x'.repeat(81)},{project:'x'.repeat(81)},{title:'x'.repeat(121)},{title:' untrimmed '},{tags:['']},{tags:['x'.repeat(25)]},{tags:Array.from({length:9},(_,i)=>String(i))},{extra:'unexpected'}];
 for(const change of variants){await page.getByTestId('import-file').setInputFiles({name:'invalid.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schemaVersion:1,tasks:[{...task,...change}]}))});await page.waitForTimeout(30);check(await page.evaluate(k=>localStorage.getItem(k),KEY)===stored&&await page.locator('#feedback').evaluate(n=>n.classList.contains('error')),`Rejects schema boundary ${JSON.stringify(change)}`);}
 // A valid JSON document containing an invalid task is also corrupt startup data.
 const bad=JSON.stringify({schemaVersion:1,tasks:[{...task,tags:['']}]});await page.evaluate(([k,v])=>localStorage.setItem(k,v),[KEY,bad]);await page.reload();check(await page.locator('#recovery').isVisible()&&await page.evaluate(k=>localStorage.getItem(k),KEY)===bad,'Semantically corrupt startup document is preserved');
 await page.evaluate(k=>localStorage.removeItem(k),KEY);await page.reload();
 await page.setViewportSize({width:360,height:800});await page.getByTestId('create-task').click();await page.screenshot({path:'mobile-form.png',fullPage:true});
 check(await page.locator('dialog').evaluate(n=>n.getBoundingClientRect().right<=innerWidth&&n.getBoundingClientRect().left>=0),'Modal fits 360px viewport');await page.keyboard.press('Escape');
 await page.screenshot({path:'mobile.png',fullPage:true});await page.setViewportSize({width:1440,height:1100});await page.screenshot({path:'desktop.png',fullPage:true});
 const targets=await page.locator('button:visible,select:visible,input:visible').evaluateAll(nodes=>nodes.filter(n=>{const r=n.getBoundingClientRect();return r.width<44||r.height<44}).map(n=>({tag:n.tagName,name:n.getAttribute('aria-label')||n.textContent,width:n.getBoundingClientRect().width,height:n.getBoundingClientRect().height})));
 check(targets.length===0,`Visible dashboard controls meet 44px target floor: ${JSON.stringify(targets)}`);
 const ratios=await page.evaluate(()=>{
  const css=getComputedStyle(document.documentElement);const rgb=x=>{x=x.trim().slice(1);return [0,2,4].map(i=>parseInt(x.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);};
  const lum=t=>rgb(css.getPropertyValue(t)).reduce((n,v,i)=>n+v*[.2126,.7152,.0722][i],0);const ratio=(a,b)=>{a=lum(a);b=lum(b);return(Math.max(a,b)+.05)/(Math.min(a,b)+.05)};
  return {text:ratio('--text','--canvas'),muted:ratio('--muted','--sidebar'),accent:ratio('--accent','--accent-soft'),controls:ratio('--control-border','--surface'),focus:ratio('--focus','--canvas'),button:ratio('--surface','--dark')};
 });check(ratios.text>=4.5&&ratios.muted>=4.5&&ratios.accent>=4.5&&ratios.controls>=3&&ratios.focus>=3&&ratios.button>=4.5,`Named contrast pairs pass: ${JSON.stringify(ratios)}`);
 await fs.mkdir('nested-check',{recursive:true});for(const name of ['index.html','styles.css','app.js'])await fs.symlink(`../${name}`,`nested-check/${name}`);
 await page.goto(`${origin}/nested-check/`);check(await page.getByTestId('task-card').count()>=6&&await page.locator('.columns').evaluate(n=>getComputedStyle(n).display==='grid'),'Application and relative assets work at a nested static URL');
 noJS=await browser.newContext({javaScriptEnabled:false});const disabled=await noJS.newPage();await disabled.goto(origin);check(await disabled.locator('noscript').innerText().then(t=>t.includes('needs JavaScript')),'JavaScript-disabled users receive useful instructions');
 await fs.writeFile('verification-extra-results.json',JSON.stringify({passed:checks.length,checks},null,2));console.log(JSON.stringify({passed:checks.length,checks},null,2));
}finally{await fs.rm('nested-check',{recursive:true,force:true});await noJS?.close();await ctx.close();await browser.close();}
