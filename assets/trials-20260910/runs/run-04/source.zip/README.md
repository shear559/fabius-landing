# Fieldnote Board

A fictional, local-only task board for a small project team. Vanilla HTML, CSS, and JavaScript; no build, packages, accounts, backend, external assets, or network APIs.

## Run

Serve this directory with any static HTTP server and open `index.html` or the directory URL. For example, with Python installed:

```sh
python3 -m http.server 8000
```

Open `http://localhost:8000/`. All application assets use relative paths, so placing the three application files together under a nested URL also works. Use a modern browser with localStorage, native dialogs, and file downloads. Opening through an HTTP server is recommended; storage behavior for `file:` URLs varies by browser.

## Files

- `index.html`: semantic dashboard, filters, recovery controls, and modal form.
- `styles.css`: responsive layout, design tokens, focus styles, and reduced-motion support.
- `app.js`: validation, rendering, task operations, persistence, imports, and recovery.
- `verify.mjs`, `verify-extra.mjs`: browser verification scripts for the provided isolated Chrome environment. These are development evidence, not application dependencies.
- `verification-results.json`, `verification-extra-results.json`: recorded passing checks.
- `desktop.png`, `mobile.png`, `mobile-form.png`: rendered browser captures.

## Data and behavior

The board is stored under `fieldnote-board:v1` as `{ "schemaVersion": 1, "tasks": [...] }`. Each task contains only `id`, `title`, `project`, `status`, `priority`, `dueDate`, and `tags`. IDs are unique; creation uses `crypto.randomUUID` when available, with a collision-checked fallback. Titles and projects are trimmed. Comma-separated form tags are trimmed, empty segments are ignored, and duplicates are removed without regard to case.

Only an absent storage key seeds the seven fictional tasks. A stored empty task array stays empty. Seed deadlines are relative to the local day. “Due this week” counts unfinished tasks due today through six days from today. Search and the three filters combine; overview statistics and JSON exports always include the full board.

New task, edit, native status selection, deletion, and undo all update the board. Undo restores the latest deleted record at its previous position. Once restored, it survives reload. Undo itself is held only in the current tab and is replaced by a later deletion or cleared by import/reload.

Imports accept schema version 1 JSON files up to 1 MiB. Validation covers all task fields, real Gregorian calendar dates (years 0001–9999), duplicate IDs, field lengths, tags, and enums. Validation of every record finishes before confirmation or replacement. Imported text is rendered through DOM text APIs. Extra task fields are rejected; unrelated root-level metadata is discarded. Confirmed import replaces every task, including records hidden by filters, and clears the filters.

## Failure handling

- Malformed or invalid saved data is never seeded over. A recovery notice offers an original-data download and a separately confirmed reset to an empty board. The download contains the original stored string encoded as UTF-8. Cancelling reset leaves storage untouched.
- A failed storage write retains the current board in memory and shows “Changes are not saved.” Export can recover that board; Try saving again retries persistence. A before-unload prompt helps protect unsaved work. Startup read failure does not seed or assume the stored board is empty.
- A storage event from another tab pauses mutations and displays an explicit reload action. The stored string is also compared with the last observed version immediately before each write, catching stale edits before their event is delivered. Forms retain their values while blocked. Export remains available. Reloading with unsaved work requires confirmation.
- Import failures leave the entire prior board intact. Cancelled confirmation also preserves it. Invalid form values remain editable with visible errors.

## Accessibility and design

The board uses native labeled inputs, selects, buttons, and a modal dialog. The form supports Escape, wraps Tab/Shift+Tab, and restores focus to its opener or a useful replacement. Status changes preserve keyboard focus. Save state and feedback are announced with status/alert semantics. Reduced motion suppresses transitions. A noscript message explains the JavaScript requirement.

The warm neutral palette, single green accent, compact project rail, and three desktop task columns become a single scrolling board at 360px. Input boundaries, text, and focus colors have checked contrast; visible dashboard controls have 44px minimum targets.

## Verification

Executed against the supplied static server and isolated Chrome using the supplied Playwright installation; no dependencies were installed and no application server was started by the verification scripts. Each script creates and closes its own browser context. Storage changes made by the tests are confined to those contexts.

```sh
node --check app.js
node verify.mjs
node verify-extra.mjs
```

The final runs passed 63 browser assertions (40 main and 23 supplementary), and `node --check app.js` passed. The main run recorded no page errors or failed HTTP responses.

The main browser suite covers seeding, creation, trimming and tag normalization, editing isolation, status persistence, deletion and exact undo after reload, combined filters, complete export, invalid and confirmed imports, text-safe rendering, two-tab conflict/reload, corrupt recovery/download/reset, failed writes and retry, and reduced motion. It captures page errors and failed HTTP responses.

The supplementary suite covers schema boundaries, modal keyboard focus, semantic corruption, mobile modal fit, touch targets, named color contrast pairs, nested static URLs, and disabled JavaScript. Its temporary nested-path fixture is removed afterward. Screenshots were visually inspected at desktop and mobile sizes. Early supplementary checks exposed modal focus timing and Tab wrapping; the final scripts wait for semantic focus and exercise the corrected behavior. See the result JSON files for exact executed assertions and totals.

## Limits

This is a local demonstration, not a synchronization service. Storage belongs to the browser origin and profile; another browser, port, or device has a separate board. There is no shared backend, user assignment, or automatic backup. Export before clearing browser data. Simultaneous tabs use conflict detection rather than merging; localStorage does not provide a multi-tab transaction API. Unsaved memory and pending undo do not survive closing the tab.

Verification uses the supplied Chrome only. No automated claim of full WCAG conformance, screen-reader certification, or Safari/Firefox coverage is made. The test scripts reference the environment’s supplied Playwright path and CDP address; the application itself has no such dependency.
