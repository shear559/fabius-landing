import pkg from '[user]/node_modules/playwright/index.js';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:60323');
const context = await browser.newContext({ viewport: { width: 360, height: 800 } });
const page = await context.newPage();
const errors = [];
const requests = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
page.on('request', request => requests.push(request.url()));
page.on('response', response => { if (response.status() >= 400) errors.push(`${response.status()} ${response.url()}`); });
const results = [];
function pass(message) { results.push(message); console.log('PASS', message); }
try {
 await page.goto('http://127.0.0.1:60322/', { waitUntil: 'networkidle' });
 assert.equal(await page.title(), 'Lattice — Give your thinking a place.');
 assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
 await page.screenshot({ path: 'checks/mobile.png', fullPage: true });
 pass('360px layout fits viewport');
 const menu = page.getByTestId('menu-toggle');
 const nav = page.getByTestId('mobile-nav');
 assert.equal(await nav.isVisible(), false);
 await menu.click();
 assert.equal(await menu.getAttribute('aria-expanded'), 'true');
 assert.equal(await nav.isVisible(), true);
 await menu.click();
 assert.equal(await nav.isVisible(), false);
 assert.equal(await menu.getAttribute('aria-expanded'), 'false');
 await menu.click();
 await nav.locator('a').first().focus();
 await page.keyboard.press('Escape');
 assert.equal(await menu.getAttribute('aria-expanded'), 'false');
 assert.equal(await nav.isVisible(), false);
 assert.equal(await menu.evaluate(el => el === document.activeElement), true);
 await menu.click();
 await nav.getByRole('link', { name: 'How it works' }).click();
 assert.equal(await nav.isVisible(), false);
 assert.equal(new URL(page.url()).hash, '#workflow');
 assert.equal(await menu.getAttribute('aria-expanded'), 'false');
 pass('Mobile menu click, Escape/focus return, and navigation close');
 const names = ['capture', 'connect', 'export'];
 for (const name of names) {
   await page.getByTestId('feature-' + name).click();
   assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
   await page.getByTestId('panel-' + name).screenshot({ path: 'checks/mobile-' + name + '.png' });
   for (const other of names) {
     assert.equal(await page.getByTestId('panel-' + other).isVisible(), other === name);
     assert.equal(await page.getByTestId('feature-' + other).getAttribute('aria-selected'), String(other === name));
   }
 }
 await page.getByTestId('feature-capture').focus();
 await page.keyboard.press('ArrowRight');
 assert.equal(await page.getByTestId('feature-connect').getAttribute('aria-selected'), 'true');
 assert.equal(await page.getByTestId('feature-connect').evaluate(el => el === document.activeElement), true);
 await page.keyboard.press('End');
 assert.equal(await page.getByTestId('feature-export').getAttribute('aria-selected'), 'true');
 await page.keyboard.press('ArrowRight');
 assert.equal(await page.getByTestId('feature-capture').getAttribute('aria-selected'), 'true');
 await page.keyboard.press('ArrowLeft');
 assert.equal(await page.getByTestId('feature-export').getAttribute('aria-selected'), 'true');
 await page.keyboard.press('Home');
 assert.equal(await page.getByTestId('feature-capture').getAttribute('aria-selected'), 'true');
 const outline = await page.getByTestId('feature-capture').evaluate(el => getComputedStyle(el).outlineStyle);
 assert.notEqual(outline, 'none');
 pass('All three tabs: distinct visibility, ARIA state, arrows/wrap, Home/End, keyboard focus outline');
 for (const [period, solo, studio, unit] of [['yearly', '$108', '$264', '/ year'], ['monthly', '$12', '$29', '/ month']]) {
   await page.getByTestId('billing-' + period).click();
   assert.equal(await page.getByTestId('price-solo').innerText(), solo);
   assert.equal(await page.getByTestId('price-studio').innerText(), studio);
   assert.deepEqual(await page.locator('.price-period').allTextContents(), [unit, unit]);
   assert.equal(await page.getByTestId('billing-' + period).getAttribute('aria-pressed'), 'true');
 }
 pass('Yearly and monthly price round trip with actual billing period');
 for (let i = 0; i < 4; i++) {
   const summary = page.getByTestId('faq-' + i);
   await summary.focus();
   await page.keyboard.press('Enter');
   assert.equal(await summary.evaluate(el => el.parentElement.open), true);
   assert.equal(await summary.locator('..').locator('p').isVisible(), true);
   await page.keyboard.press('Enter');
   assert.equal(await summary.evaluate(el => el.parentElement.open), false);
 }
 pass('Four native FAQs open and close with keyboard');
 await page.locator('.hero-copy .button').click();
 assert.equal(new URL(page.url()).hash, '#workflow');
 pass('Primary CTA targets workflow');
 await page.setViewportSize({ width: 1440, height: 1000 });
 await page.goto('http://127.0.0.1:60322/', { waitUntil: 'networkidle' });
 assert.equal(await page.locator('.desktop-nav').isVisible(), true);
 assert.equal(await menu.isVisible(), false);
 assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
 await page.screenshot({ path: 'checks/desktop.png', fullPage: true });
 await page.screenshot({ path: 'checks/desktop-hero.png' });
 pass('1440px desktop layout and navigation');
 await page.emulateMedia({ reducedMotion: 'reduce' });
 assert.equal(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior), 'auto');
 assert.equal(await page.locator('.button').first().evaluate(el => getComputedStyle(el).transitionDuration), '0s');
 pass('Reduced motion disables smooth scrolling and transitions');
 const brokenAnchors = await page.locator('a[href^="#"]').evaluateAll(links => links.map(link => link.getAttribute('href')).filter(href => href !== '#' && !document.querySelector(href)));
 assert.deepEqual(brokenAnchors, []);
 assert.equal(await page.locator('details').count(), 4);
 pass('All fragment links resolve and exactly four FAQs exist');
 const noJS = await browser.newContext({ javaScriptEnabled: false, viewport: { width: 360, height: 800 } });
 try {
   const fallback = await noJS.newPage();
   await fallback.goto('http://127.0.0.1:60322/');
   for (const name of names) assert.equal(await fallback.getByTestId('panel-' + name).isVisible(), true);
   assert.equal(await fallback.getByTestId('mobile-nav').isVisible(), true);
   assert.equal(await fallback.getByText('Or $108 per year, billed yearly in USD.').isVisible(), true);
   assert.equal(await fallback.getByText('Or $264 per year, billed yearly in USD.').isVisible(), true);
   await fallback.getByTestId('faq-2').click();
   assert.equal(await fallback.getByTestId('faq-2').evaluate(el => el.parentElement.open), true);
   assert.equal(await fallback.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
   pass('JavaScript disabled: navigation, all panels, both billing periods, native FAQ, 360px fit');
 } finally { await noJS.close(); }
 await fs.mkdir('checks/nested', { recursive: true });
 try {
   for (const file of ['index.html', 'styles.css', 'app.js']) await fs.copyFile(file, 'checks/nested/' + file);
   await page.goto('http://127.0.0.1:60322/checks/nested/', { waitUntil: 'networkidle' });
   assert.equal(await page.locator('html').getAttribute('class'), 'js');
   assert.equal(await page.locator('body').evaluate(el => getComputedStyle(el).backgroundColor), 'rgb(245, 243, 236)');
   await page.getByTestId('billing-yearly').click();
   assert.equal(await page.getByTestId('price-solo').innerText(), '$108');
   pass('Nested static URL loads relative CSS/JS and billing works');
 } finally { await fs.rm('checks/nested', { recursive: true, force: true }); }
 for (const width of [375, 768, 1024]) {
   await page.setViewportSize({width, height:900});
   await page.goto('http://127.0.0.1:60322/');
   for (const name of names) {
     await page.getByTestId('feature-' + name).click();
     assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
   }
 }
 pass('375px, 768px, and 1024px: all feature panels fit without page overflow');
 assert.deepEqual(errors, []);
 assert.equal(requests.every(url => url.startsWith('http://127.0.0.1:60322/')), true);
 pass('No browser console/page/HTTP errors and no external requests');
 await fs.writeFile('checks/results.json', JSON.stringify({ results, errors, requests: [...new Set(requests)] }, null, 2) + '\n');
} finally {
 await context.close();
 await browser.close();
}
