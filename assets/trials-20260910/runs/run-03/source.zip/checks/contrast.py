import json
from pathlib import Path
colors = {'canvas':'f5f3ec','surface':'fffefa','soft':'eaece5','text':'202e2b','muted':'5b655e','accent':'245e50','dark':'173e35','on-dark':'f5f3ec','dark-muted':'c0d1c8'}
def luminance(value):
    rgb = [int(value[i:i+2],16)/255 for i in (0,2,4)]
    linear = [v/12.92 if v <= .04045 else ((v+.055)/1.055)**2.4 for v in rgb]
    return sum(a*b for a,b in zip(linear,[.2126,.7152,.0722]))
pairs = [(fg,bg) for fg in ('text','muted','accent') for bg in ('canvas','surface','soft')] + [('on-dark','dark'),('dark-muted','dark')]
results = []
for fg,bg in pairs:
    values=sorted([luminance(colors[fg]),luminance(colors[bg])])
    ratio=(values[1]+.05)/(values[0]+.05)
    assert ratio >= 4.5, (fg,bg,ratio)
    results.append({'foreground':fg,'background':bg,'ratio':round(ratio,2),'passes_AA_text':True})
Path('checks/contrast-results.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS: 11 named foreground/background pairs meet 4.5:1 text contrast')
