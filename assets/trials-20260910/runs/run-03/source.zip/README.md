# Lattice

A complete, responsive marketing page for a **fictional** local-first research notebook. Built with vanilla HTML, CSS, and JavaScript; no dependencies, build step, remote assets, backend, or network API calls.

## Run

Serve this directory with any static HTTP server. For example, from this directory:

```sh
python3 -m http.server 8000
```

Open `http://localhost:8000/`. Stop the server with Ctrl+C. To host under a nested path, keep `index.html`, `styles.css`, and `app.js` together in that directory. Both asset references are relative (`./`).

## Files and design

- `index.html`: complete semantic content, original HTML/SVG notebook illustration, three feature panels, three workflow steps, two plans, and four native FAQs.
- `styles.css`: warm paper and deep teal palette, system serif/sans/monospace typography, shared design tokens, responsive layouts, visible keyboard focus, and reduced-motion/forced-color handling.
- `app.js`: mobile navigation, automatically activated keyboard tabs, and monthly/yearly billing selection.
- `checks/`: executable verification scripts, recorded results, and desktop/mobile screenshots.

The visual design uses an editorial hierarchy, a notebook with attached sources and a question card, and alternating paper/dark sections. The illustrated research project and all product offerings are demonstration content. Fictional status is stated in the top banner, prices, FAQ, and footer. There are no customer endorsements, statistics, payment controls, or contact forms.

The Solo/Studio feature allocation is an illustrative design decision. Solo presents local notes, source links, and Markdown export; Studio adds reusable templates and optional local search. Prices are exactly $12/$29 per month and $108/$264 per year, billed in USD.

## Interaction and accessibility decisions

- The mobile menu synchronizes `aria-expanded` and its accessible label. Escape closes it and restores toggle focus; section selection closes it and moves focus to the target. Desktop navigation remains available.
- Feature controls become ARIA tabs when JavaScript initializes. Left/Right wrap between tabs; Home/End select the first/last. Only the selected panel is visible. Each panel has distinct content and a keyboard focus stop.
- Billing buttons expose pressed state. Live regions announce the entire updated price and period.
- FAQs use native `details`/`summary`, without scripted accordion behavior.
- Without JavaScript, section navigation, all feature panels, and both pricing periods remain visible. Billing controls and the mobile toggle appear only after initialization. Native FAQs still work. This fallback also covers a missing script.
- Product illustrations are explanatory artwork, not functioning notebook controls. The hero has a descriptive accessible label; supporting decorative illustrations are hidden from assistive technology.
- No cookies, analytics, storage, fonts, or external services are used. The demo does not create or retain notes.

## Checks actually executed

Using the supplied static server at `http://127.0.0.1:60322/` and isolated Chrome CDP endpoint at `http://127.0.0.1:60323`:

```sh
node --check app.js
node checks/verify.mjs
python3 checks/contrast.py
```

All final checks passed. `checks/results.json` records browser assertions and requests; `checks/contrast-results.json` records the 11 measured text color pairs.

Browser assertions covered:

- 360px mobile fit; menu opening and closing by toggle, Escape/focus return, closing after section navigation, and synchronized state.
- All three feature selections, panel visibility, ARIA selection, arrow wraparound, Home/End, and computed keyboard focus outline.
- Exact yearly prices and restoration of monthly prices, actual periods, and pressed state.
- Opening and closing all four FAQs with the keyboard.
- Primary CTA target, all fragment link targets, and FAQ count.
- 1440px desktop fit and navigation availability.
- Reduced-motion scroll and transition behavior.
- JavaScript-disabled mobile navigation, all feature panels, both billing periods, native FAQ behavior, and layout fit.
- A real nested static path with copied HTML/CSS/JS: stylesheet applied and billing interaction worked. Temporary copies were removed.
- 375px, 768px, and 1024px layouts with each feature panel selected: no horizontal page overflow.
- No console, page, or HTTP errors and no external requests during the primary browser checks.

Full-page mobile and desktop screenshots, a desktop hero screenshot, and mobile feature-panel screenshots were captured. The full-page compositions, hero, and alternate mobile panels were visually inspected. An initial no-script assertion exposed the test runner's text-selector handling of `noscript`; the final fallback uses ordinary HTML and the complete suite was rerun successfully. Named text contrast pairs all meet 4.5:1; this is not a whole-page accessibility certification.

`checks/verify.mjs` uses the explicitly supplied Playwright installation and browser endpoints; it is a verification harness, not an application dependency. Adjust these paths/endpoints to rerun elsewhere. It creates and closes its own contexts. No additional server was started during implementation.

## Known limitations

This is a marketing prototype, not an implemented notebook: no note editing, local search engine, file export, subscription, payment, or cancellation operation is provided. UI state resets on reload. Verification used the supplied Chrome only; Safari, Firefox, physical devices, and screen readers were not tested. Visuals use system fonts, whose appearance varies by platform.
