# Lattice

A responsive marketing page for a fictional local-first research notebook. Product descriptions and prices are explicitly presented as a demonstration.

## Run

Serve this directory with any static HTTP server. For example:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Open `http://127.0.0.1:8000/`. Stop the server with Ctrl+C. No build, installation, account, or backend is required. Relative stylesheet and script URLs also support nested directory hosting.

## Files

- `index.html`: semantic content, original notebook illustration, features, workflow, pricing, and four native FAQs.
- `styles.css`: responsive design, named palette and spacing tokens, system typography, keyboard focus, and reduced-motion rules.
- `app.js`: mobile navigation, accessible feature tabs, and billing controls.
- `verify.mjs`: browser verification using the provided local Playwright installation and isolated Chrome. The webpage itself has no library dependency.
- `verification.json`: recorded passing assertions and local resource requests.
- `desktop.png`, `desktop-hero.png`, `mobile.png`, `mobile-hero.png`: page screenshots at 1440px and 360px.
- `feature-connect.png`, `feature-export.png`, `no-js-mobile.png`: alternate panels and the JavaScript-disabled fallback.

## Implementation decisions

Warm paper surfaces, charcoal controls, and a rust accent combine with system sans-serif, serif, and monospace fonts. The original HTML/CSS notebook illustration contains invented research about public spaces. It is labeled as illustrative and has an accessible description; it is not an editable application.

Mobile navigation synchronizes `aria-expanded`, closes on Escape with focus restored to the toggle, closes after link selection, and resets when switching to desktop. Every navigation destination exists.

Feature tabs use tablist/tab/tabpanel semantics and a roving tab stop. Left/Right arrows wrap and select; Home and End select the first and last tabs. Exactly one panel is visible when enhanced. Without JavaScript, all panels remain readable, navigation stays visible, and both monthly and yearly pricing options appear as text. Native FAQs also work without JavaScript.

Billing buttons expose selection through `aria-pressed`. Exact prices and actual billing periods update together: monthly $12/$29, yearly $108/$264. Price regions announce changes politely. Both concept plans describe only supplied capabilities; additional Studio entitlements are not invented. There is no checkout.

## Executed checks

- `node --check app.js` passed.
- `node verify.mjs` passed **67 browser assertions** in the provided Chrome browser at `http://127.0.0.1:61811/`.
- Verified mobile menu open/close, synchronized state, Escape focus restoration, and link dismissal.
- Clicked all feature tabs; checked every panel visibility state, selection, arrow wraparound, Home/End, and a visible keyboard focus outline.
- Switched yearly and back to monthly; checked exact prices, period labels, and pressed states.
- Opened and closed all four FAQs with the keyboard.
- Checked the primary CTA and all internal link destinations.
- Checked no horizontal document overflow at 360, 375, 700, 768, 1024, and 1440px; checked desktop navigation visibility.
- Visually inspected full-page mobile and desktop screenshots, the mobile hero, and Connect/Export panel screenshots.
- Verified reduced-motion computed styles for scrolling and button transitions.
- Disabled JavaScript at 360px and checked navigation, all feature panels, monthly/yearly prices, native FAQs, and no horizontal overflow.
- Created a temporary nested directory with relative links to the source files. Verified CSS and JavaScript loading, billing interaction, and workflow navigation there, then removed the directory.
- Captured no page errors, console errors, or failed requests in the main browser context. Its observed requests were all local static resources.
- Calculated nine named text/background contrast pairs with the WCAG sRGB formula. All exceeded 4.5:1; the lowest was rust text on pale rust at 4.82:1. This checks the palette, not whole-page accessibility conformance.

The initial mobile check exposed decorative orbit lines outside the viewport. Those lines were contained, the mobile header was refined, and the final browser checks and screenshots were rerun. Browser contexts were closed. No background server was started by this implementation.

To rerun verification in the supplied environment, keep its static server and Chrome endpoint available and run `node verify.mjs`. The script uses the environment-specific Playwright path `[user]/node_modules/playwright/index.js` and Chrome endpoint `http://127.0.0.1:61812`. Outside that environment, adapt these verification-only settings to your existing browser tooling.

## Known limitations

This is a marketing demonstration, not the notebook product. It does not store research, search notes, export files, create accounts, take payments, or manage subscriptions. The supplied product facts are fiction, not verified business claims. Billing selection resets on reload.

Verification covered the supplied Chrome browser, not Safari, Firefox, physical devices, or assistive-technology applications. Keyboard behavior and palette contrast were checked, but no comprehensive screen-reader or WCAG audit was performed. Font rendering varies by operating system. Without JavaScript, feature exploration becomes stacked content and billing options are static text.
