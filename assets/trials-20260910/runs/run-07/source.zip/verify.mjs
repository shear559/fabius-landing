import pkg from '[user]/node_modules/playwright/index.js';
import { writeFile, mkdtemp, symlink, rm } from 'node:fs/promises';
const { chromium } = pkg;
const browser = await chromium.connectOverCDP('http://127.0.0.1:61812');
const context = await browser.newContext({viewport:{width:360,height:800}});
const page = await context.newPage();
const checks = [];
const errors = [];
const requests = [];
page.on('pageerror', error => errors.push(error.message));
page.on('console', message => { if(message.type()==='error') errors.push(message.text()); });
page.on('requestfailed', request => errors.push(request.url() + ': ' + request.failure()?.errorText));
page.on('request', request => requests.push(request.url()));
function assert(condition, name) { if(!condition) throw new Error(name); checks.push(name); }
try {
 await page.goto('http://127.0.0.1:61811/', {waitUntil:'networkidle'});
 assert(await page.title() === 'Lattice — Room for your next good question', 'Page loads from static server');
 assert(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), '360px: no horizontal overflow');
 const toggle = page.getByTestId('menu-toggle');
 const nav = page.getByTestId('mobile-nav');
 assert(await toggle.isVisible(), '360px: menu toggle visible');
 await toggle.click();
 assert(await nav.isVisible() && await toggle.getAttribute('aria-expanded')==='true','Mobile menu opens with synchronized state');
 await nav.getByRole('link',{name:'Features',exact:true}).focus();
 await page.keyboard.press('Escape');
 assert(!await nav.isVisible() && await toggle.getAttribute('aria-expanded')==='false' && await toggle.evaluate(el=>el===document.activeElement),'Escape closes menu and restores focus');
 await toggle.click(); await toggle.click();
 assert(!await nav.isVisible(),'Menu toggle closes menu');
 await toggle.click(); await nav.getByRole('link',{name:'Features',exact:true}).click();
 assert(!await nav.isVisible() && new URL(page.url()).hash==='#features','Navigation link reaches real section and closes menu');
 for(const feature of ['capture','connect','export']) {
   await page.getByTestId('feature-'+feature).click();
   assert(await page.getByTestId('feature-'+feature).getAttribute('aria-selected')==='true','Selected tab state: '+feature);
   for(const other of ['capture','connect','export']) assert(await page.getByTestId('panel-'+other).isVisible()===(other===feature),feature+': correct panel visibility for '+other);
 }
 await page.getByTestId('feature-capture').focus(); await page.keyboard.press('ArrowLeft');
 assert(await page.getByTestId('feature-export').evaluate(el=>el===document.activeElement) && await page.getByTestId('panel-export').isVisible(),'Left arrow wraps and activates export');
 await page.keyboard.press('ArrowRight');
 assert(await page.getByTestId('feature-capture').evaluate(el=>el===document.activeElement),'Right arrow wraps to capture');
 await page.keyboard.press('End');
 assert(await page.getByTestId('feature-export').getAttribute('aria-selected')==='true','End selects final tab');
 await page.keyboard.press('Home');
 assert(await page.getByTestId('feature-capture').getAttribute('aria-selected')==='true','Home selects first tab');
 assert(await page.getByTestId('feature-capture').evaluate(el=>getComputedStyle(el).outlineStyle==='solid'),'Keyboard focus has visible outline');
 for(const yearly of [true,false]) {
  await page.getByTestId('billing-'+(yearly?'yearly':'monthly')).click();
  assert(await page.getByTestId('price-solo').textContent()===(yearly?'$108':'$12'),'Solo exact '+(yearly?'yearly':'monthly')+' price');
  assert(await page.getByTestId('price-studio').textContent()===(yearly?'$264':'$29'),'Studio exact '+(yearly?'yearly':'monthly')+' price');
  assert(await page.locator('.price-period').allTextContents().then(a=>a.every(v=>v===(yearly?'/ year':'/ month'))),'Actual billing period labels update');
  assert(await page.getByTestId('billing-'+(yearly?'yearly':'monthly')).getAttribute('aria-pressed')==='true','Billing pressed state updates');
 }
 for(let i=0;i<4;i++) {
  const summary=page.getByTestId('faq-'+i); await summary.focus(); await page.keyboard.press('Enter');
  assert(await summary.evaluate(el=>el.parentElement.open),'FAQ '+i+' opens by keyboard');
  assert(await summary.locator('..').locator('p').isVisible(),'FAQ '+i+' answer visible');
  await page.keyboard.press('Enter');
  assert(!await summary.evaluate(el=>el.parentElement.open),'FAQ '+i+' closes by keyboard');
 }
 await page.getByRole('link',{name:'Explore the workflow'}).first().click();
 assert(new URL(page.url()).hash==='#workflow','Primary CTA targets workflow');
 await page.goto('http://127.0.0.1:61811/',{waitUntil:'networkidle'});
 await page.screenshot({path:'mobile.png',fullPage:true});
 await page.screenshot({path:'mobile-hero.png'});
 await page.setViewportSize({width:1440,height:1000});
 assert(await page.locator('.desktop-nav').isVisible() && !await toggle.isVisible(),'1440px: desktop navigation visible and mobile toggle hidden');
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'1440px: no horizontal overflow');
 await page.screenshot({path:'desktop.png',fullPage:true});
 await page.screenshot({path:'desktop-hero.png'});
 for(const feature of ['connect','export']) {
  await page.getByTestId('feature-'+feature).click();
  await page.locator('#features').screenshot({path:'feature-'+feature+'.png'});
 }
 await page.emulateMedia({reducedMotion:'reduce'});
 assert(await page.evaluate(()=>getComputedStyle(document.documentElement).scrollBehavior)==='auto','Reduced motion disables smooth scrolling');
 assert(await page.locator('.button').first().evaluate(el=>getComputedStyle(el).transitionDuration)==='0s','Reduced motion disables button transitions');
 for(const width of [375, 700, 768, 1024]) {
  await page.setViewportSize({width,height:900});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),width+'px: no horizontal overflow');
 }
 const nested = await mkdtemp('./nested-check-');
 try {
  for(const file of ['index.html','styles.css','app.js']) await symlink('../'+file,nested+'/'+file);
  await page.goto('http://127.0.0.1:61811/'+nested.replace('./','')+'/',{waitUntil:'networkidle'});
  assert(await page.evaluate(()=>document.documentElement.classList.contains('js') && getComputedStyle(document.body).backgroundColor==='rgb(245, 243, 236)'), 'Nested URL: relative CSS and JavaScript load');
  await page.getByTestId('billing-yearly').click();
  assert(await page.getByTestId('price-solo').textContent()==='$108','Nested URL: billing interaction works');
  await page.getByRole('link',{name:'Explore the workflow'}).first().click();
  assert(new URL(page.url()).hash==='#workflow','Nested URL: workflow anchor works');
 } finally {await rm(nested,{recursive:true});}
 const links = await page.locator('a[href^="#"]').evaluateAll(els=>els.every(a=>a.hash===''||!!document.getElementById(decodeURIComponent(a.hash.slice(1)))));
 assert(links,'All in-page links have real destinations');
 const nojs = await browser.newContext({javaScriptEnabled:false,viewport:{width:360,height:800}});
 try {
  const p=await nojs.newPage(); await p.goto('http://127.0.0.1:61811/');
  assert(await p.locator('.desktop-nav').isVisible(),'No JavaScript: navigation visible at mobile width');
  for(const feature of ['capture','connect','export']) assert(await p.getByTestId('panel-'+feature).isVisible(),'No JavaScript: '+feature+' content visible');
  assert(await p.getByTestId('price-solo').textContent()==='$12' && await p.getByTestId('price-studio').textContent()==='$29','No JavaScript: monthly prices visible');
  assert(await p.locator('.annual-fallback').first().isVisible() && (await p.locator('.annual-fallback').allTextContents()).join(' ').includes('$264'),'No JavaScript: yearly prices discoverable');
  await p.getByTestId('faq-2').click(); assert(await p.getByTestId('faq-2').locator('..').locator('p').isVisible(),'No JavaScript: native FAQs work');
  assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'No JavaScript: 360px has no horizontal overflow');
  await p.screenshot({path:'no-js-mobile.png',fullPage:true});
 } finally {await nojs.close();}
 assert(requests.every(url=>url.startsWith('http://127.0.0.1:61811/')),'Page requests only local static resources');
 assert(errors.length===0,'No browser console errors, page errors, or failed requests');
 await writeFile('verification.json',JSON.stringify({checks,errors,requests},null,2)+'\n');
 console.log(JSON.stringify({passed:checks.length,errors,requests},null,2));
} finally {await context.close();await browser.close();}
