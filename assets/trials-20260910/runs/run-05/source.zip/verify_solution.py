"""Reproducible standard-library checks; run: python3 verify_solution.py."""

from contextlib import redirect_stderr, redirect_stdout
from fractions import Fraction as F
import importlib
import io
import math
import random
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch


def objective(t, p):
    x, y, z = p
    return x*x + 2*y*y + 3*z*z + x*y - y*z + (2-2*t)*x + 5*y + z


def reduced(t, x, y):
    return objective(t, (x, y, 1-x-y))


# Generic half-plane oracle: a*x+b*y <= c.
HALFPLANES = [
    (F(-1), F(0), F(0)),
    (F(0), F(-1), F(0)),
    (F(1), F(1), F(1)),
    (F(1), F(0), F(3, 5)),
    (F(1), F(-1), F(1, 2)),
]


def feasible(p):
    x, y = p
    return all(a*x+b*y <= c for a, b, c in HALFPLANES)


def linear_solve(a, b, c, d, e, f):
    det = a*d-b*c
    return ((e*d-b*f)/det, (a*f-e*c)/det)


def polygon():
    vertices = set()
    for i, (a, b, e) in enumerate(HALFPLANES):
        for c, d, f in HALFPLANES[i+1:]:
            if a*d-b*c:
                p = linear_solve(a, b, c, d, e, f)
                if feasible(p):
                    vertices.add(p)
    edges = []
    for a, b, c in HALFPLANES:
        ends = sorted(p for p in vertices if a*p[0]+b*p[1] == c)
        assert len(ends) == 2
        edges.append(tuple(ends))
    assert len(vertices) == 5
    return vertices, edges


VERTICES, EDGES = polygon()
# Recover the quadratic coefficients from the original objective rather
# than copying the optimizer formulas or their reduced gradient.
C0 = reduced(F(0), F(0), F(0))
HXX = reduced(0, F(1), F(0)) + reduced(0, F(-1), F(0)) - 2*C0
HYY = reduced(0, F(0), F(1)) + reduced(0, F(0), F(-1)) - 2*C0
HXY = reduced(0, F(1), F(1)) - reduced(0, F(1), F(0)) - reduced(0, F(0), F(1)) + C0
BX0 = (reduced(0, F(1), F(0)) - reduced(0, F(-1), F(0)))/2
BY0 = (reduced(0, F(0), F(1)) - reduced(0, F(0), F(-1)))/2


def oracle(t):
    """Exact rational minimum over the interior and every polygon edge."""
    bx, by = BX0-2*t, BY0
    candidates = set(VERTICES)
    interior = linear_solve(HXX, HXY, HXY, HYY, -bx, -by)
    if feasible(interior):
        candidates.add(interior)
    for (ax, ay), (ex, ey) in EDGES:
        dx, dy = ex-ax, ey-ay
        curvature = HXX*dx*dx + 2*HXY*dx*dy + HYY*dy*dy
        slope = (HXX*ax+HXY*ay+bx)*dx + (HXY*ax+HYY*ay+by)*dy
        s = max(F(0), min(F(1), -slope/curvature))
        candidates.add((ax+s*dx, ay+s*dy))
    x, y = min(candidates, key=lambda p: reduced(t, *p))
    p = (x, y, 1-x-y)
    return p, objective(t, p)


BOUNDS = [F(-2), F(-3, 2), F(-1), F(-1, 2), F(0), F(9, 5), F(4)]


def certificate(i, t):
    """Exact transcription of the solution and KKT tables for checking."""
    zero = F(0)
    if i == 0:
        p = (zero, F(1, 4), F(3, 4))
        multipliers = (F(-21, 4), -3-2*t, zero, zero, zero, zero)
        value = F(29, 8)
    elif i == 1:
        p = ((9+6*t)/8, -(1+t)/2, (3-2*t)/8)
        multipliers = (t-F(15, 4), zero, zero, zero, zero, zero)
        value = F(31, 16)-9*t/4-3*t*t/4
    elif i == 2:
        p = ((5+2*t)/8, zero, (3-2*t)/8)
        multipliers = ((6*t-13)/4, zero, 2+2*t, zero, zero, zero)
        value = F(39, 16)-5*t/4-t*t/4
    elif i == 3:
        p = (F(1, 2), zero, F(1, 2))
        multipliers = (2*t-3, zero, -2*t, zero, zero, 1+2*t)
        value = F(5, 2)-t
    elif i == 4:
        p = (F(1, 2)+t/18, t/18, F(1, 2)-t/9)
        multipliers = (-3+11*t/6, zero, zero, zero, zero, 1+10*t/9)
        value = F(5, 2)-t-t*t/18
    else:
        p = (F(3, 5), F(1, 10), F(3, 10))
        multipliers = (F(3, 10), zero, zero, zero, 2*t-F(18, 5), F(3))
        value = F(67, 25)-6*t/5
    return p, multipliers, value


def check_certificates():
    count = 0
    for i, (lo, hi) in enumerate(zip(BOUNDS, BOUNDS[1:])):
        for t in (lo, (lo+hi)/2, hi):
            p, multipliers, value = certificate(i, t)
            x, y, z = p
            lam, alpha, beta, gamma, delta, rho = multipliers
            g = (-x, -y, -z, x-F(3, 5), F(1, 2)-2*y-z)
            assert x+y+z == 1
            assert all(gi <= 0 for gi in g)
            assert all(m >= 0 for m in multipliers[1:])
            assert all(m*gi == 0 for m, gi in zip(multipliers[1:], g))
            assert 2*x+y+2-2*t+lam-alpha+delta == 0
            assert 4*y+x-z+5+lam-beta-2*rho == 0
            assert 6*z-y+1+lam-gamma-rho == 0
            assert objective(t, p) == value
            assert oracle(t) == (p, value)
            count += 1
    # All certificate coordinates, slacks and multipliers are affine.
    # Two endpoints establish their signs over each complete interval.
    # Stationarity is affine; objective and complementarity are quadratic.
    # Three distinct zeros therefore establish those polynomial identities.
    for i, t in enumerate(BOUNDS[1:-1]):
        assert certificate(i, t) == certificate(i+1, t)
        # Since V' = -2x on each side, this also checks matching derivatives.
    print(f"PASS: {count} exact certificate evaluations; all 5 boundary joins")


def check_import():
    # Loading the source itself is unavoidable; during its execution, deny
    # application file reads and input. The import must remain silent.
    sys.modules.pop("solution", None)
    output = io.StringIO()
    with patch("builtins.open", side_effect=AssertionError("file access on import")), \
         patch("io.open", side_effect=AssertionError("file access on import")), \
         patch("builtins.input", side_effect=AssertionError("input on import")), \
         redirect_stdout(output), redirect_stderr(output):
        module = importlib.import_module("solution")
    assert output.getvalue() == ""
    root = Path(__file__).resolve().parent
    process = subprocess.run(
        [sys.executable, "-B", "-c", "import solution"],
        cwd=root, capture_output=True, text=True, check=True,
    )
    assert process.stdout == process.stderr == ""
    print("PASS: import is silent; execution performs no application file reads or input")
    return module.solve


def compare(solve, t):
    result = solve(t)
    assert isinstance(result, dict)
    actual = tuple(result[k] for k in ("x", "y", "z"))
    assert all(isinstance(v, (int, float)) and math.isfinite(v)
               for v in (*actual, result["value"]))
    exact_p, exact_v = oracle(F(t))
    coordinate_error = max(abs(v-float(e)) for v, e in zip(actual, exact_p))
    value_error = abs(result["value"]-float(exact_v))
    assert coordinate_error <= 2e-15, (t, actual, exact_p)
    assert value_error <= 5e-15, (t, result["value"], exact_v)
    x, y, z = actual
    assert abs(x+y+z-1) <= 3e-16
    assert min(actual) >= 0
    assert x <= 0.6
    assert 2*y+z >= 0.5-2e-16
    assert abs(objective(float(t), actual)-result["value"]) <= 3e-15
    return coordinate_error, value_error


def main():
    solve = check_import()
    check_certificates()
    exact_count = 0
    # This grid includes all transitions exactly as rational parameters.
    for k in range(1201):
        t = F(-2) + F(k, 200)
        i = next(i for i in range(6) if BOUNDS[i] <= t <= BOUNDS[i+1])
        p, _, v = certificate(i, t)
        assert oracle(t) == (p, v)
        exact_count += 1
    print(f"PASS: {exact_count} rational grid points against the exact geometric oracle")

    cases = [float(F(-2)+F(k, 200)) for k in range(1201)]
    cases.extend(range(-2, 5))
    rng = random.Random(20260910)
    cases.extend(rng.uniform(-2, 4) for _ in range(2000))
    # Include actual adjacent binary64 values, signed zero and subnormals.
    for boundary in BOUNDS:
        b = float(boundary)
        cases.append(b)
        for toward in (-math.inf, math.inf):
            t = b
            for _ in range(4):
                t = math.nextafter(t, toward)
                if -2 <= t <= 4:
                    cases.append(t)
        for exponent in (2, 5, 10, 14, 15, 16):
            for sign in (-1, 1):
                t = b + sign*10.0**(-exponent)
                if -2 <= t <= 4:
                    cases.append(t)
    cases.extend([-0.0, 0.0, math.ulp(0.0), -math.ulp(0.0)])
    max_coordinate_error = max_value_error = 0.0
    for t in cases:
        ce, ve = compare(solve, t)
        max_coordinate_error = max(max_coordinate_error, ce)
        max_value_error = max(max_value_error, ve)
    print(f"PASS: {len(cases)} int/float cases against the exact geometric oracle")
    print(f"Maximum coordinate error: {max_coordinate_error:.17g}")
    print(f"Maximum value error: {max_value_error:.17g}")

    invalid_values = [float("nan"), float("inf"), -float("inf"), -3, 5,
                      math.nextafter(-2.0, -math.inf),
                      math.nextafter(4.0, math.inf), 10**1000]
    for t in invalid_values:
        try:
            solve(t)
        except ValueError:
            pass
        else:
            raise AssertionError(("accepted invalid value", t))
    for t in (None, "0", [], {}, 1j, F(1, 2)):
        try:
            solve(t)
        except TypeError:
            pass
        else:
            raise AssertionError(("accepted invalid type", t))
    print("PASS: 8 invalid values and 6 invalid types rejected")

    # Negative control: a feasible but incorrect point must fail the oracle
    # comparison. This checks that the test is not merely feasibility-only.
    def wrong(t):
        p = (0.0, 0.25, 0.75)
        return dict(zip(("x", "y", "z", "value"), (*p, objective(t, p))))
    try:
        compare(wrong, 1.0)
    except AssertionError:
        print("PASS: negative control rejects a feasible nonoptimal point")
    else:
        raise AssertionError("oracle failed to reject negative control")
    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
