"""Reproduce exact geometric and floating-point checks: python3 verify.py."""
from fractions import Fraction as F
from itertools import combinations
import contextlib
import importlib.util
import io
import math
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

# Independent geometry: a*x + b*y <= c. No solution breakpoints are used
# to construct vertices, edges, or the oracle's candidates.
CONSTRAINTS = [(F(-1), F(0), F(0)), (F(0), F(-1), F(0)),
               (F(1), F(1), F(1)), (F(1), F(0), F(3, 5)),
               (F(1), F(-1), F(1, 2))]


def feasible(p):
    x, y = p
    return all(a*x + b*y <= c for a, b, c in CONSTRAINTS)


def intersection(c1, c2):
    a, b, c = c1
    d, e, f = c2
    det = a*e - b*d
    if not det:
        return None
    return ((c*e - b*f)/det, (a*f - c*d)/det)


VERTICES = sorted({p for c1, c2 in combinations(CONSTRAINTS, 2)
                   if (p := intersection(c1, c2)) is not None and feasible(p)})
EDGES = []
for a, b, c in CONSTRAINTS:
    endpoints = [p for p in VERTICES if a*p[0] + b*p[1] == c]
    assert len(endpoints) == 2
    EDGES.append(tuple(endpoints))
assert len(VERTICES) == len(EDGES) == 5


def objective(t, p):
    x, y = p
    z = 1-x-y
    return x*x + 2*y*y + 3*z*z + x*y - y*z + (2-2*t)*x + 5*y + z


def oracle(t):
    """Exact min over all vertices, all edge minima, and interior stationary point."""
    candidates = list(VERTICES)
    # Solve reduced stationarity by a generic 2x2 linear system.
    interior = intersection((F(8), F(8), 5+2*t), (F(8), F(12), F(3)))
    if feasible(interior):
        candidates.append(interior)
    for p, r in EDGES:
        dx, dy = r[0]-p[0], r[1]-p[1]
        gx, gy = 8*p[0]+8*p[1]-5-2*t, 8*p[0]+12*p[1]-3
        curvature = 8*dx*dx + 16*dx*dy + 12*dy*dy
        u = max(F(0), min(F(1), -(gx*dx + gy*dy)/curvature))
        candidates.append((p[0]+u*dx, p[1]+u*dy))
    scored = [(objective(t, p), p) for p in candidates]
    value, point = min(scored)
    assert all(p == point for v, p in scored if v == value)
    return point + (1-sum(point),), value


def formula(t, regime=None):
    """Exact rational transcription of the solution and its KKT table."""
    if regime is None:
        regime = (0 if t <= F(-3, 2) else 1 if t <= -1 else
                  2 if t <= F(-1, 2) else 3 if t <= 0 else
                  4 if t <= F(9, 5) else 5)
    a = b = g = d = e = F(0)
    if regime == 0:
        p, v = (F(0), F(1, 4), F(3, 4)), F(29, 8)
        lam, a = F(-21, 4), -3-2*t
    elif regime == 1:
        p = ((9+6*t)/8, -(1+t)/2, (3-2*t)/8)
        v, lam = F(29, 8)-F(3, 4)*(t+F(3, 2))**2, t-F(15, 4)
    elif regime == 2:
        p, v = ((5+2*t)/8, F(0), (3-2*t)/8), 4-(5+2*t)**2/16
        lam, b = (6*t-13)/4, 2+2*t
    elif regime == 3:
        p, v = (F(1, 2), F(0), F(1, 2)), F(5, 2)-t
        lam, b, e = 2*t-3, -2*t, 1+2*t
    elif regime == 4:
        p = (F(1, 2)+t/18, t/18, F(1, 2)-t/9)
        v, lam, e = F(5, 2)-t-t*t/18, -3+11*t/6, 1+10*t/9
    else:
        p, v = (F(3, 5), F(1, 10), F(3, 10)), F(67, 25)-6*t/5
        lam, d, e = F(3, 10), 2*t-F(18, 5), F(3)
    return p, v, (lam, a, b, g, d, e)


def check_certificate(t, regime=None):
    p, value, multipliers = formula(t, regime)
    x, y, z = p
    lam, a, b, g, d, e = multipliers
    assert x+y+z == 1 and feasible((x, y))
    assert z >= F(3, 10)
    assert min(a, b, g, d, e) >= 0
    assert a*x == b*y == g*z == d*(x-F(3, 5)) == e*(F(1, 2)-2*y-z) == 0
    assert 2*x+y+2-2*t+lam-a+d == 0
    assert 4*y+x-z+5+lam-b-2*e == 0
    assert 6*z-y+1+lam-g-e == 0
    assert objective(t, (x, y)) == value
    return p, value


def derivative(t, regime):
    return [F(0), -(9+6*t)/4, -(5+2*t)/4, F(-1), -1-t/9, F(-6, 5)][regime]


def main():
    # Import from the task directory, checking observable output explicitly.
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        spec = importlib.util.spec_from_file_location('solution', ROOT/'solution.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    assert out.getvalue() == err.getvalue() == ''
    result = subprocess.run([sys.executable, '-c', 'import solution'], cwd=ROOT,
                            stdin=subprocess.DEVNULL, capture_output=True, timeout=10)
    assert result.returncode == 0 and result.stdout == result.stderr == b''
    solve = module.solve

    # Test module execution with file access, input, and printing forbidden.
    source = (ROOT/'solution.py').read_text()
    import builtins
    def forbidden(*args, **kwargs):
        raise AssertionError('import attempted I/O')
    safe_builtins = vars(builtins).copy()
    safe_builtins.update(open=forbidden, input=forbidden, print=forbidden)
    exec(compile(source, str(ROOT/'solution.py'), 'exec'),
         {'__name__': 'solution_import_check', '__builtins__': safe_builtins})

    transitions = [F(-3, 2), F(-1), F(-1, 2), F(0), F(9, 5)]
    bounds = [F(-2)] + transitions + [F(4)]
    for i, t in enumerate(transitions):
        assert formula(t, i) == formula(t, i+1)
        assert derivative(t, i) == derivative(t, i+1) == -2*formula(t, i)[0][0]
    # Feasibility and multiplier signs are affine, so checking both endpoints
    # certifies the complete regime. Three distinct points additionally check
    # the polynomial equalities, of degree at most two, identically.
    identity_checks = 0
    for i, (lo, hi) in enumerate(zip(bounds, bounds[1:])):
        for t in (lo, (lo+hi)/2, hi):
            check_certificate(t, i)
            identity_checks += 1

    exact_points = {F(-2)+F(6*k, 1500) for k in range(1501)} | set(bounds)
    for t in transitions:
        for exponent in range(1, 61):
            for sign in (-1, 1):
                u = t + sign*F(1, 10**exponent)
                if -2 <= u <= 4:
                    exact_points.add(u)
    for t in sorted(exact_points):
        assert check_certificate(t) == oracle(t), ('exact mismatch', t)

    numeric_points = {float(t) for t in exact_points}
    rng = random.Random(20260910)
    numeric_points.update(rng.uniform(-2, 4) for _ in range(1000))
    # Twenty representable neighbors in each direction, including subnormals
    # beside zero; comparisons use the exact rational represented by each float.
    for boundary in bounds:
        for direction in (-math.inf, math.inf):
            t = float(boundary)
            for _ in range(20):
                t = math.nextafter(t, direction)
                if -2 <= t <= 4:
                    numeric_points.add(t)
    max_coordinate_error = max_value_error = max_objective_error = max_violation = 0.0
    for t in sorted(numeric_points):
        actual = solve(t)
        assert all(k in actual for k in ('x', 'y', 'z', 'value'))
        assert all(isinstance(actual[k], (int, float)) and math.isfinite(actual[k])
                   for k in ('x', 'y', 'z', 'value'))
        x, y, z, value = (actual[k] for k in ('x', 'y', 'z', 'value'))
        expected, expected_value = oracle(F.from_float(t))
        coordinate_error = max(abs(a-float(b)) for a, b in zip((x,y,z), expected))
        value_error = abs(value-float(expected_value))
        direct_value = x*x+2*y*y+3*z*z+x*y-y*z+(2-2*t)*x+5*y+z
        objective_error = abs(value-direct_value)
        violation = max(abs(x+y+z-1), -x, -y, -z, x-0.6, 0.5-2*y-z, 0.0)
        assert coordinate_error <= 2e-14, (t, actual, expected)
        assert value_error <= 2e-14, (t, value, expected_value)
        assert objective_error <= 2e-14
        assert violation <= 2e-14
        max_coordinate_error = max(max_coordinate_error, coordinate_error)
        max_value_error = max(max_value_error, value_error)
        max_objective_error = max(max_objective_error, objective_error)
        max_violation = max(max_violation, violation)
    for t in range(-2, 5):
        assert solve(t) == solve(float(t))
    invalid_numbers = [-3, 5, -math.inf, math.inf, math.nan, 10**1000]
    invalid_types = [None, '0', [], {}, complex(0)]
    for t in invalid_numbers:
        try:
            solve(t)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid number accepted')
    for t in invalid_types:
        try:
            solve(t)
        except TypeError:
            pass
        else:
            raise AssertionError('invalid type accepted')

    print('PASS: independent polygon has 5 vertices and 5 edges')
    print(f'PASS: {identity_checks} exact polynomial-certificate points across 6 closed regimes')
    print('PASS: all 5 transitions match in optimizer, value, multipliers, and value derivative')
    print(f'PASS: {len(exact_points)} exact rational geometric-oracle comparisons')
    print(f'PASS: {len(numeric_points)} floating-point geometric-oracle comparisons')
    print(f'max coordinate error: {max_coordinate_error:.17g}')
    print(f'max optimal-value error: {max_value_error:.17g}')
    print(f'max value/objective discrepancy: {max_objective_error:.17g}')
    print(f'max feasibility residual: {max_violation:.17g}')
    print('PASS: 7 integer inputs; 11 rejected invalid inputs; silent import and guarded module execution')


if __name__ == '__main__':
    main()
