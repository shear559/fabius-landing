# Paired build trials — September 10, 2026

This experiment records what one model produced on three substantial briefs, twice with Fabius and twice without it. It is a small artifact study. It does not establish a general performance improvement or predict results on another model.

## The twelve runs

The tasks were a parametric constrained quadratic optimization problem, the Lattice landing page and the Fieldnote Board task application. Each condition received the same task brief. There were two fresh repetitions per condition for each task: twelve valid generation runs in total.

Both conditions used gpt-6-astra at high reasoning effort through Codex CLI 0.153.4, with priority service, the same existing account, Node 26 and Python 3.9 on an Intel Mac. Every valid run had a 720-second wall-clock cap. Matched pairs ran concurrently, with at most two generation processes; task order was mathematics, landing page, application. The second repetition reversed condition dispatch order. Dispatch was nearly simultaneous, so this does not eliminate scheduling or shared-machine effects.

No candidate was rerun for a better result or repaired after generation. Artifacts present at a time cap were retained and evaluated. A completed CLI process is a run status, not a claim that its product satisfied every requirement. Every final artifact is included, with its checks, source archive, elapsed time, usage fields and hashes.

## What changes between conditions

Without Fabius means native Codex instructions plus the common trial instructions and task brief. It does not mean a bare model with no system prompt.

With Fabius adds the exact 3.0.1 router, Parcus and Disciplina skill bodies. The two UI tasks also receive Decor. Linked reference resources are available in a read-only snapshot of the tracked Fabius repository. This includes extra reference availability and extra context, not just a single short prompt. The measured treatment is this pinned configuration; it is not every possible host installation or a newly improved version of the rules.

Fabius source commit: 64cf9aaa44af8c3997bf82ad96d84489afe1e330. Contract and task hashes appear in protocol.json. Full source is available at that commit in the public shear559/fabius repository, subject to its existing licence. The model produces the artifacts using its host tools under those instructions.

Both conditions receive a separate local HTTP server and a separate Chrome CDP endpoint, and may use the installed Playwright library to inspect their work. They are forbidden to install packages, delegate, call another model, publish, use external services or inspect other trials. They may edit and test their own artifact during the timed run. Tools, brief and time cap are matched; extra instruction and retrieval costs are part of the Fabius condition.

## Context and file isolation

Preflight showed that ignoring user configuration alone did not suppress global AGENTS instructions. The valid runs therefore used an external macOS read-denial policy for the CLI, browser and local server. It blocked the installed skill trees, original Fabius checkout, project records, private study outputs and sibling trial workspaces. Only the treatment's own read-only snapshot was available to that condition. The same selected-path boundary applied to both conditions.

Per-run model-input inspection checked that the baseline contained no Fabius instructions or global skill catalogue and that the treatment contained the exact pinned bodies. CLI execution ignored user config/rules and disabled skills discovery, plugins, hooks, memory, apps, web and delegation features. Configured user MCP servers were excluded by --ignore-user-config. The debug inspection and execution configuration differ in how known MCP entries are suppressed; their messages were checked, not the complete provider HTTP request schema.

This is a targeted contamination control, not an audited general-purpose security sandbox. Provider network access remained available. The ban on external task resources also relies on the common instructions and disabled browser/search connectors; it was not a network firewall. Local HTTP/CDP access was intentionally available. Command and HTTP trace review has stated coverage and limits in the methods receipt. Credentials, personal records and raw account logs are not published.

## Mathematics evaluation

The task asks for the optimizer and minimum value for every t in [-2, 4], with exact breakpoints, active sets, KKT certificates, global uniqueness and boundary behavior. It has six regimes, including a constant-vertex interval. The five transitions are -3/2, -1, -1/2, 0 and 9/5. The brief's objective and constraints are reproduced next to the plot; the full brief is downloadable.

An independent Python standard-library oracle uses exact rational geometry and constrained minimization. Its control tests check the reference across the interval and reject deliberately wrong solvers. The numerical evaluation uses 1,233 parameter probes, including transition neighborhoods. Those probes cover one mathematical problem; they are not 1,233 independent model tasks and they do not prove correctness over all real parameters.

The headline groups one numerical criterion with eight proof criteria. A separate agent, blinded to condition labels and run metadata, reviewed the submitted proofs against a fixed rubric with file/line evidence. This review is an agent judgment, not a human referee or a calibrated score. The originally optional C1 review item was made required before candidate inspection to match the brief; the initial freeze and amendment are preserved.

The interactive math plot uses actual values returned by the submitted solvers. It shows a subset of the recorded samples, retaining the endpoints and transition samples. Lines between them are visual guides. Numeric readouts use exact recorded samples, without substituting the reference answer or interpolating a missing result. Overlapping curves remain overlapping.

## Browser evaluation

A separate evaluator, blinded to condition assignment, ran the frozen landing-page and application contracts against immutable submissions at a nested URL path. Tests used fresh Chromium and WebKit contexts at widths 360 and 1440. The recorded environment was Playwright 1.60.0, Chromium 148.0.7778.96 and WebKit 26.4. These are browser simulations on this machine, not physical iPhone tests.

Landing pages have seven grouped criteria covering the page contract, responsive and no-JavaScript behavior, navigation, tabs, monthly/yearly prices, native FAQ behavior and motion/accessibility expectations. Each group is exercised in four browser configurations: 28 scenario executions per artifact. Separate manual checks inspect the actual adjacent billing periods, the three-step workflow and unsupported business or social-proof claims.

Applications have sixteen grouped criteria covering initial data, CRUD, persistence, combined filters, status and undo, round-trip export/import, atomic rejection, literal hostile text, byte-size limits, corrupt-storage recovery, write-failure recovery, cross-tab conflicts, keyboard behavior and no-JavaScript/reduced-motion behavior. The full matrix has 68 scenario executions per artifact because the last group has two variants. These executions measure scenario coverage; they are not independent model trials.

A group passes only if all required configurations pass. The score describes the supplied functional contract, not visual quality, security certification or production readiness. Automated checks can have mistakes. Any demonstrated evaluator bug is documented, its old result retained, a regression control added, and the corrected logic applied symmetrically. A valid document-top href="#" was initially treated as a missing anchor; that false positive was corrected without changing the criterion or candidate. The evaluator correction log and receipts are included.

Two further evaluator corrections accepted visible inline form feedback and valid JSON-error wording that the original predicates had missed. Retained reports, silent negative controls and symmetric reruns distinguish those harness mistakes from product failures. The WebKit focus-return failure survived matched pointer/keyboard probes and a delayed focus check; it remains a primary failure.

A later exploratory probe tried a project literally named all, exposing a collision with the filter sentinel in two applications, one from each condition. The same probe was applied to all four final applications. It was discovered after initial outcomes and is reported separately without changing primary scores. The brief allows any nonempty project name while reserving all as the select sentinel; this contract ambiguity is disclosed with the evidence.

The visual review describes observable hierarchy, typography, composition and mobile usability without assigning a numerical beauty score. It is a qualitative agent assessment of this small set of submissions.

## Working-process review

Fabius is an instruction and orchestration layer. A correctness tie alone does not establish that the layer has no value. This fixed-environment study observes planning, decomposition, tool choice, verification and correction within a single-agent run. It deliberately makes delegation and external services unavailable to both conditions, so it does not measure the full orchestration surface.

After some artifact outcomes were known, the owner requested an explicit process analysis. A separate retrospective, unblinded review therefore describes observable actions in every recorded trace: explicit task framing, verification tools used, reference access and actual edit/retest sequences. Evidence is tied to event IDs, command hashes and artifact paths. It does not infer private reasoning, treat tool-call counts as quality, or create a new performance score after seeing results. Both conditions receive the same descriptive categories, including native Codex behavior in the control. Each run's check record contains this review, separately from the originally specified outcome checks.

A process difference may suggest a follow-up experiment; it is not by itself proof that Fabius caused a better result. The current evidence can support artifact-specific observations and identify where a broader orchestration study is still needed.

## Captures and animation

The comparison uses screenshots of the actual generated pages and apps, captured after predefined actions in fresh contexts. The capture helper records action outcomes, missing states, errors, file hashes and source immutability. Captures use the installed Chrome version recorded in each receipt; this is separate from the two-engine grading matrix.

Desktop frames are 1440 by 960; mobile first visits are 360 by 800. The app walkthrough attempts an actual task creation, search and invalid import. If an action fails, its observed state and failure remain visible. Candidate code is never fixed for the presentation. Published WebP images are lossless conversions of the retained PNG originals.

Animation is a composed walkthrough from captured states, not a continuous video of model generation or an execution-time comparison. Visitors start it explicitly and can pause, step through, enlarge a capture or use reduced motion. The math parameter sweep likewise visits recorded samples; it does not show the model thinking. Generated JavaScript is offered in source ZIPs rather than executed on the main site's origin.

## Costs, attempts and limits

Elapsed seconds include model calls, tools and local verification up to process completion or the time cap. They describe these runs on a shared machine and service, not an isolated speed benchmark. Output tokens are the CLI's output_tokens field; other usage fields, including input_tokens, cached_input_tokens and reasoning_output_tokens, remain in run metadata. Repeated cached context is included in native input accounting. These figures are not dollars and should not be interpreted as model prices.

Two infrastructure attempts preceded the valid series. In the first, both processes failed configuration validation before any model call or artifact: disabled MCP entries formed invalid partial transports when user config was ignored. The same configuration correction was applied to both conditions; the amendment was recorded eight seconds after the replacement processes started. In the second, two actual model starts could not use any file or shell tools because macOS rejected nested Seatbelt sandboxes. They were stopped after roughly two minutes and produced no artifact files. The valid series uses one external sandbox, with nested native/Chrome sandboxing disabled. Both failed attempts and their reasons were retained privately; the protocol records them. They are not quality results and do not receive zeros.

There are only two repetitions per condition for each of three tasks, no across-model replication, no unassisted human user study, and no statistically supported aggregate lift. The task author knows the Fabius system. Reviewers receive opaque run IDs, but generated text can in principle reveal its instructions; blinding cannot be guaranteed solely by relabelling. Reports distinguish measured behavior from reviewer interpretation. A passing artifact still needs a real product's own requirements, security review, deployment and user testing before production use.

## Inspect and reproduce

Download the source ZIP for a run, extract it into an isolated directory, read its brief and verification notes, and inspect its recorded checks. UI artifacts use vanilla local files with no required package installation. Serve them from a local HTTP server; do not rely on file:// loading. The mathematics artifact provides solution.py and solution.md.

The evaluation ZIP contains the actual oracle code, control fixtures, task briefs, protocol, amendments and method receipts. Its READ-FIRST file explains local prerequisites and normalized paths. The math scorer runs with Python standard library only. Browser grading requires Playwright 1.60.0 and the recorded browser engines. Local path constants must be replaced on another machine. A fresh model generation requires your own authorized model access and may differ because generation is stochastic.

Public text files normalize private machine paths to [user], [study] and [workspace]. Each source archive has recorded-original and public-file SHA-256 hashes, and lists every path-redacted file. This is packaging privacy, not a repair of the graded artifact. Original files, PNGs and detailed traces remain in the private study record. The report links every published source archive and check record, including unsuccessful cases.
